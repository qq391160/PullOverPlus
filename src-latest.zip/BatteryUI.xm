// ============================================================================
// CTHermesBatteryUI —— 「屏蔽部件与维修记录」（★ 2.0.90 回归件；注入 Preferences / BatteryUsageUI / SpringBoard）
//   实现：老版 PrefHook 路子（实机验证过），全量迁移为自有命名，按我们的规矩接入：
//   硬门（缺一即完全直通、零动作）：①已授权 ②设置页「屏蔽部件与维修记录」开关=开（5 秒缓存，即时生效）
//   职责：把「电池维修 / 非正品部件」相关提示按住不显示 —— ①电池页状态 ②关于本机信息 ③重要电池信息卡
//         ④桌面小红点 ⑤电池/关于类页面的警告行过滤。
//   红线：只影响显示，不改电池任何状态；全 @try，异常一律放行；开关关=完全恢复系统原样；零新线程（仅按需扫描一次）。
// ============================================================================
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <substrate.h>
#import <CTHermesPaths.h>
#import <CTHardening.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/time.h>
#import <objc/runtime.h>
#import <syslog.h>
#import <ctype.h>
#import <stdlib.h>
#import <string.h>

@interface PSSpecifier : NSObject
- (id)propertyForKey:(id)key;
- (void)setProperty:(id)value forKey:(id)key;
@end

@interface PSListController : UIViewController
- (NSArray *)specifiers;
- (void)setSpecifiers:(NSArray *)specifiers;
@end

@interface PSTableCell : UITableViewCell
- (id)specifier;
@end


// ---------- 日志（[屏蔽] 标签走主诊断日志）与实时门控 ----------
static void CTBUILog(const char *fmt, ...) {
    FILE *fp = CTDiagLogOpenForAppend();
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][屏蔽] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}
#define syslog(pri, ...) CTBUILog(__VA_ARGS__)

static BOOL CTBUIActive(void) {
    static BOOL sOK = NO; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (now - sAt) < 5.0) return sOK;
    sAt = now; sOK = NO;
    @try {
        NSDictionary *p = CTHermesReadPrefs();
        if ([p[S("suppressBatteryServiceWarnings")] boolValue] && CTAuthFileAuthorized()) sOK = YES;
    } @catch (__unused NSException *e) { sOK = NO; }
    return sOK;
}

typedef NS_ENUM(NSUInteger, CTBUIHookKind) {
    CTBUIHookKindSuppressObject,
    CTBUIHookKindEmptyArray,
    CTBUIHookKindFilterSpecifiers,
};

typedef struct {
    Class targetClass;
    SEL selector;
    IMP original;
    CTBUIHookKind kind;
} CTBUIHookRecord;

// 状态门控：改为每次实时判定（见上方 CTBUIActive 函数）

static long long (*origGenuineBatteryStatus)(id, SEL) = NULL;
static long long (*origBatteryHealthServiceState)(id, SEL) = NULL;
static id (*origBatteryServiceSuggestion)(id, SEL, id) = NULL;
static id (*origCurrentSystemHealthInfoSpecifiers)(id, SEL) = NULL;
static BOOL (*origIsVaildCAA)(id, SEL, id) = NULL;
static BOOL (*origIsValidCAA)(id, SEL, id) = NULL;
static void (*origFollowUpAddItem)(id, SEL, id) = NULL;
static BOOL (*origAllowsBadgingForIcon)(id, SEL, id) = NULL;
static CFStringRef gNotifCFName = NULL;
static CTBUIHookRecord gHookRecords[24];
static NSUInteger gHookRecordCount = 0;

static __thread BOOL gInspectingSpecifier = NO;
static IMP gOrigSpecifierPropertyForKey = NULL;
static IMP gOrigSpecifierSetPropertyForKey = NULL;

static NSDictionary *readPrefsDictionary(void) {
    return CTHermesReadPrefs();
}

static void loadPrefs(void) { (void)CTBUIActive(); }   // ★ 2.0.90：状态实时判定（5 秒缓存），不再缓存到变量

static BOOL cStringContainsInsensitive(const char *value, const char *token) {
    if (!value || !token || !token[0]) {
        return NO;
    }

    size_t tokenLength = strlen(token);
    for (const char *cursor = value; *cursor; cursor++) {
        size_t index = 0;
        while (index < tokenLength && cursor[index] &&
               tolower((unsigned char)cursor[index]) == tolower((unsigned char)token[index])) {
            index++;
        }
        if (index == tokenLength) {
            return YES;
        }
    }

    return NO;
}

static BOOL cStringEndsWithInsensitive(const char *value, const char *suffix) {
    if (!value || !suffix) {
        return NO;
    }

    size_t valueLength = strlen(value);
    size_t suffixLength = strlen(suffix);
    if (suffixLength > valueLength) {
        return NO;
    }

    return strncasecmp(value + valueLength - suffixLength, suffix, suffixLength) == 0;
}

static id callObjectNoArgument(id object, const char *selectorName) {
    if (!object || !selectorName) {
        return nil;
    }

    SEL selector = sel_registerName(selectorName);
    if (![object respondsToSelector:selector]) {
        return nil;
    }

    IMP implementation = [object methodForSelector:selector];
    return implementation ? ((id (*)(id, SEL))implementation)(object, selector) : nil;
}

static id callObjectWithObject(id object, const char *selectorName, id argument) {
    if (!object || !selectorName) return nil;
    SEL selector = sel_registerName(selectorName);
    if (![object respondsToSelector:selector]) return nil;
    IMP implementation = [object methodForSelector:selector];
    return implementation ? ((id (*)(id, SEL, id))implementation)(object, selector, argument) : nil;
}
static NSString *inspectionStringForValue(id value) {
    if (!value) {
        return nil;
    }

    if ([value isKindOfClass:[NSString class]]) {
        return (NSString *)value;
    }

    if ([value isKindOfClass:[NSURL class]]) {
        return [(NSURL *)value absoluteString];
    }

    Class metaClass = object_getClass(value);
    if (metaClass && class_isMetaClass(metaClass)) {
        return NSStringFromClass((Class)value);
    }

    return nil;
}

static BOOL stringContainsBatteryWarningToken(NSString *value) {
    if (![value isKindOfClass:[NSString class]] || [value length] == 0) {
        return NO;
    }

    static const char *tokens[] = {
        "importantbatterymessage",
        "important_battery",
        "important battery message",
        "batteryservicesuggestion",
        "battery_service",
        "battery service",
        "servicerecommended",
        "service_recommended",
        "service recommended",
        "nongenuinebattery",
        "nongenuine_battery",
        "non-genuine battery",
        "batteryhealthunknown",
        "battery_health_unknown",
        "battery health unknown",
        "battery not trusted",
        "untrusted battery",
        "recalibrat",
        "plfollowupheadercell",
        "plfollowupsecondaryheadercell",
        "significantly degraded",
        "unable to verify",
        "unable to determine battery health",
        "unable to determine if your iphone battery is a genuine apple part",
        "genuine apple battery",
        "battery authenticity",
        "无法确定iphone电池是否为正品apple部件",
        "无法确定 iphone 电池是否为正品 apple 部件",
        "非正品apple部件",
        "非正品 Apple 部件",
        "重要电池信息",
        "电池健康状况显著下降",
        "无法验证",
        "无法确定电池健康状况",
        "重新校准",
        "建议维修",
    };

    NSString *lowercaseValue = [value lowercaseString];
    for (NSUInteger index = 0; index < sizeof(tokens) / sizeof(tokens[0]); index++) {
        if ([lowercaseValue rangeOfString:S(tokens[index])].location != NSNotFound) {
            return YES;
        }
    }

    return NO;
}

static BOOL valueContainsBatteryWarning(id value) {
    NSString *inspectionString = inspectionStringForValue(value);
    if (stringContainsBatteryWarningToken(inspectionString)) {
        return YES;
    }

    if ([value isKindOfClass:[NSDictionary class]]) {
        for (id key in (NSDictionary *)value) {
            if (valueContainsBatteryWarning(key) || valueContainsBatteryWarning([(NSDictionary *)value objectForKey:key])) {
                return YES;
            }
        }
    }

    return NO;
}



static BOOL specifierContainsBatteryWarning(id specifier);


static id specifierPropertyHook(id self, SEL selector, id key) {
    id result = nil;
    @try {
    result = gOrigSpecifierPropertyForKey ?
        ((id (*)(id, SEL, id))gOrigSpecifierPropertyForKey)(self, selector, key) : nil;
    if (CTBUIActive() && !gInspectingSpecifier && [key isKindOfClass:[NSString class]] &&
        ([(NSString *)key caseInsensitiveCompare:S("hidden")] == NSOrderedSame ||
         [(NSString *)key caseInsensitiveCompare:S("isHidden")] == NSOrderedSame)) {
        gInspectingSpecifier = YES;
        BOOL warning = specifierContainsBatteryWarning(self);
        gInspectingSpecifier = NO;
        if (warning) return [NSNumber numberWithBool:YES];
    }
    } @catch (__unused NSException *e) {}
    return result;
}

static void specifierSetPropertyHook(id self, SEL selector, id value, id key) {
    id patchedValue = value;
    if (gOrigSpecifierSetPropertyForKey) {
        ((void (*)(id, SEL, id, id))gOrigSpecifierSetPropertyForKey)(self, selector, patchedValue, key);
    }
}

static void installSpecifierHooks(void) {
    Class cls = objc_getClass("PSSpecifier");
    if (!cls) return;
    SEL getSelector = sel_registerName("propertyForKey:");
    SEL setSelector = sel_registerName("setProperty:forKey:");
    if (!gOrigSpecifierPropertyForKey && class_getInstanceMethod(cls, getSelector)) {
        MSHookMessageEx(cls, getSelector, (IMP)specifierPropertyHook, &gOrigSpecifierPropertyForKey);
    }
    if (!gOrigSpecifierSetPropertyForKey && class_getInstanceMethod(cls, setSelector)) {
        MSHookMessageEx(cls, setSelector, (IMP)specifierSetPropertyHook, &gOrigSpecifierSetPropertyForKey);
    }
}

static BOOL specifierContainsBatteryWarning(id specifier) {
    if (!specifier) {
        return NO;
    }

    if (stringContainsBatteryWarningToken(NSStringFromClass([specifier class]))) {
        return YES;
    }

    id identifier = callObjectNoArgument(specifier, "identifier");
    id name = callObjectNoArgument(specifier, "name");
    if (valueContainsBatteryWarning(identifier) || valueContainsBatteryWarning(name)) {
        return YES;
    }

    static const char *propertyKeys[] = {
        "id",
        "identifier",
        "name",
        "label",
        "title",
        "text",
        "detailText",
        "footerText",
        "headerText",
        "cellClass",
        "headerCellClass",
        "footerCellClass",
        "url",
        "URL",
        "link",
    };

    for (NSUInteger index = 0; index < sizeof(propertyKeys) / sizeof(propertyKeys[0]); index++) {
        id value = callObjectWithObject(specifier, "propertyForKey:", S(propertyKeys[index]));
        if (valueContainsBatteryWarning(value)) {
            return YES;
        }
    }

    return NO;
}

static id filteredBatteryHealthSpecifiers(id result) {
    if (![result isKindOfClass:[NSArray class]]) {
        return result;
    }

    NSArray *specifiers = (NSArray *)result;
    NSMutableArray *filtered = [NSMutableArray arrayWithCapacity:[specifiers count]];
    BOOL removedWarning = NO;

    for (id specifier in specifiers) {
        if (CTBUIActive() && specifierContainsBatteryWarning(specifier)) {
            removedWarning = YES;
            continue;
        }
        [filtered addObject:specifier];
    }

    if (removedWarning) {
        syslog(LOG_NOTICE, "[屏蔽] removed Important Battery Information specifiers");
        return filtered;
    }

    return result;
}

static id invokeObjectHook(NSUInteger index, id self, SEL selector) {
    @try {
    if (index >= gHookRecordCount) {
        return nil;
    }

    CTBUIHookRecord *record = &gHookRecords[index];
    IMP original = record->original;

    if (record->kind == CTBUIHookKindFilterSpecifiers) {
        id result = original ? ((id (*)(id, SEL))original)(self, selector) : nil;
        return CTBUIActive() ? filteredBatteryHealthSpecifiers(result) : result;
    }

    if (CTBUIActive()) {
        if (record->kind == CTBUIHookKindEmptyArray) {
            return [NSArray array];
        }
        return nil;
    }

    return original ? ((id (*)(id, SEL))original)(self, selector) : nil;
    } @catch (__unused NSException *e) { return nil; }
}

#define DEFINE_OBJECT_HOOK(index) \
    static id objectHook##index(id self, SEL selector) { \
        return invokeObjectHook(index, self, selector); \
    }

DEFINE_OBJECT_HOOK(0)
DEFINE_OBJECT_HOOK(1)
DEFINE_OBJECT_HOOK(2)
DEFINE_OBJECT_HOOK(3)
DEFINE_OBJECT_HOOK(4)
DEFINE_OBJECT_HOOK(5)
DEFINE_OBJECT_HOOK(6)
DEFINE_OBJECT_HOOK(7)
DEFINE_OBJECT_HOOK(8)
DEFINE_OBJECT_HOOK(9)
DEFINE_OBJECT_HOOK(10)
DEFINE_OBJECT_HOOK(11)
DEFINE_OBJECT_HOOK(12)
DEFINE_OBJECT_HOOK(13)
DEFINE_OBJECT_HOOK(14)
DEFINE_OBJECT_HOOK(15)
DEFINE_OBJECT_HOOK(16)
DEFINE_OBJECT_HOOK(17)
DEFINE_OBJECT_HOOK(18)
DEFINE_OBJECT_HOOK(19)
DEFINE_OBJECT_HOOK(20)
DEFINE_OBJECT_HOOK(21)
DEFINE_OBJECT_HOOK(22)
DEFINE_OBJECT_HOOK(23)

static IMP gObjectHookImplementations[] = {
    (IMP)objectHook0,
    (IMP)objectHook1,
    (IMP)objectHook2,
    (IMP)objectHook3,
    (IMP)objectHook4,
    (IMP)objectHook5,
    (IMP)objectHook6,
    (IMP)objectHook7,
    (IMP)objectHook8,
    (IMP)objectHook9,
    (IMP)objectHook10,
    (IMP)objectHook11,
    (IMP)objectHook12,
    (IMP)objectHook13,
    (IMP)objectHook14,
    (IMP)objectHook15,
    (IMP)objectHook16,
    (IMP)objectHook17,
    (IMP)objectHook18,
    (IMP)objectHook19,
    (IMP)objectHook20,
    (IMP)objectHook21,
    (IMP)objectHook22,
    (IMP)objectHook23,
};





static Method copyOwnInstanceMethod(Class targetClass, SEL selector) {
    unsigned int methodCount = 0;
    Method *methods = class_copyMethodList(targetClass, &methodCount);
    Method result = NULL;

    for (unsigned int index = 0; index < methodCount; index++) {
        if (method_getName(methods[index]) == selector) {
            result = methods[index];
            break;
        }
    }

    free(methods);
    return result;
}

static BOOL methodReturnsObjectWithoutArguments(Method method) {
    if (!method || method_getNumberOfArguments(method) != 2) {
        return NO;
    }

    const char *typeEncoding = method_getTypeEncoding(method);
    if (!typeEncoding) {
        return NO;
    }

    while (*typeEncoding && strchr("rnNoORV", *typeEncoding)) {
        typeEncoding++;
    }

    return *typeEncoding == '@';
}

static BOOL hookAlreadyInstalled(Class targetClass, SEL selector) {
    for (NSUInteger index = 0; index < gHookRecordCount; index++) {
        if (gHookRecords[index].targetClass == targetClass && gHookRecords[index].selector == selector) {
            return YES;
        }
    }
    return NO;
}

static BOOL installObjectHook(Class targetClass, SEL selector, CTBUIHookKind kind) {
    if (!targetClass || !selector || hookAlreadyInstalled(targetClass, selector)) {
        return NO;
    }

    Method method = copyOwnInstanceMethod(targetClass, selector);
    if (!methodReturnsObjectWithoutArguments(method)) {
        return NO;
    }

    NSUInteger capacity = sizeof(gHookRecords) / sizeof(gHookRecords[0]);
    if (gHookRecordCount >= capacity) {
        syslog(LOG_ERR, "[屏蔽] hook record capacity reached");
        return NO;
    }

    NSUInteger index = gHookRecordCount++;
    gHookRecords[index].targetClass = targetClass;
    gHookRecords[index].selector = selector;
    gHookRecords[index].kind = kind;
    gHookRecords[index].original = NULL;

    MSHookMessageEx(
        targetClass,
        selector,
        gObjectHookImplementations[index],
        &gHookRecords[index].original
    );

    syslog(
        LOG_NOTICE,
        "[屏蔽] hooked %s.%s",
        class_getName(targetClass),
        sel_getName(selector)
    );
    return YES;
}


static BOOL isBatteryHealthControllerClass(Class targetClass) {
    const char *className = class_getName(targetClass);
    if (!className) {
        return NO;
    }

    if (cStringContainsInsensitive(className, "batteryhealth")) {
        return YES;
    }

    return cStringContainsInsensitive(className, "battery") &&
           cStringContainsInsensitive(className, "health") &&
           cStringContainsInsensitive(className, "controller");
}


static BOOL isWarningSpecifierFactorySelector(const char *selectorName) {
    if (!selectorName || strchr(selectorName, ':') ||
        !cStringEndsWithInsensitive(selectorName, "specifiers")) {
        return NO;
    }

    if (strcasecmp(selectorName, "headerSpecifiers") == 0) {
        return YES;
    }

    return cStringContainsInsensitive(selectorName, "importantbattery") ||
           cStringContainsInsensitive(selectorName, "batteryservice") ||
           cStringContainsInsensitive(selectorName, "servicerecommend") ||
           cStringContainsInsensitive(selectorName, "nongenuine") ||
           cStringContainsInsensitive(selectorName, "recalibration") ||
           cStringContainsInsensitive(selectorName, "unknownheader") ||
           cStringContainsInsensitive(selectorName, "datacollectionnotice");
}

static BOOL isBatteryServiceSuggestionSelector(const char *selectorName) {
    if (!selectorName || strchr(selectorName, ':')) {
        return NO;
    }

    return strcasecmp(selectorName, "getBatteryServiceSuggestion") == 0 ||
           cStringContainsInsensitive(selectorName, "batteryservicesuggestion") ||
           cStringContainsInsensitive(selectorName, "servicebatterysuggestion");
}

static void installHooksForClass(Class targetClass) {
    const char *className = class_getName(targetClass);
    if (!className) return;
    BOOL batteryController = cStringContainsInsensitive(className, "battery");
    BOOL aboutController = cStringContainsInsensitive(className, "about") ||
                           cStringContainsInsensitive(className, "general") ||
                           cStringContainsInsensitive(className, "parts") ||
                           cStringContainsInsensitive(className, "warranty") ||
                           cStringContainsInsensitive(className, "deviceinfo");
    if (!batteryController && !aboutController) return;

    BOOL batteryHealthController = isBatteryHealthControllerClass(targetClass);
    if (batteryController || aboutController) {
        installObjectHook(
            targetClass,
            sel_registerName("specifiers"),
            CTBUIHookKindFilterSpecifiers
        );
    }

    unsigned int methodCount = 0;
    Method *methods = class_copyMethodList(targetClass, &methodCount);
    for (unsigned int index = 0; index < methodCount; index++) {
        Method method = methods[index];
        SEL selector = method_getName(method);
        const char *selectorName = sel_getName(selector);

        if (batteryHealthController && isWarningSpecifierFactorySelector(selectorName)) {
            installObjectHook(targetClass, selector, CTBUIHookKindEmptyArray);
        } else if (selectorName && !strchr(selectorName, ':') && cStringEndsWithInsensitive(selectorName, "specifiers")) {
            installObjectHook(targetClass, selector, CTBUIHookKindFilterSpecifiers);
        } else if (isBatteryServiceSuggestionSelector(selectorName)) {
            installObjectHook(targetClass, selector, CTBUIHookKindSuppressObject);
        }
    }
    free(methods);
}

static void installBatteryHooks(void) {
    @autoreleasepool {
        int classCount = objc_getClassList(NULL, 0);
        if (classCount <= 0) {
            return;
        }

        Class *classes = (Class *)calloc((size_t)classCount, sizeof(Class));
        if (!classes) {
            return;
        }

        int loadedClassCount = objc_getClassList(classes, classCount);
        int scanCount = loadedClassCount < classCount ? loadedClassCount : classCount;
        for (int index = 0; index < scanCount; index++) {
            installHooksForClass(classes[index]);
        }

        free(classes);
    }
}

static long long hookedGenuineBatteryStatus(id self, SEL selector) {
    return CTBUIActive() ? 0 : (origGenuineBatteryStatus ? origGenuineBatteryStatus(self, selector) : 0);
}

static long long hookedBatteryHealthServiceState(id self, SEL selector) {
    return CTBUIActive() ? 0 : (origBatteryHealthServiceState ? origBatteryHealthServiceState(self, selector) : 0);
}

static id hookedBatteryServiceSuggestion(id self, SEL selector, id argument) {
    return CTBUIActive() ? nil : (origBatteryServiceSuggestion ? origBatteryServiceSuggestion(self, selector, argument) : nil);
}

static id hookedCurrentSystemHealthInfoSpecifiers(id self, SEL selector) {
    return CTBUIActive() ? nil : (origCurrentSystemHealthInfoSpecifiers ? origCurrentSystemHealthInfoSpecifiers(self, selector) : nil);
}

static BOOL hookedIsVaildCAA(id self, SEL selector, id argument) {
    return CTBUIActive() ? YES : (origIsVaildCAA ? origIsVaildCAA(self, selector, argument) : YES);
}

static BOOL hookedIsValidCAA(id self, SEL selector, id argument) {
    return CTBUIActive() ? YES : (origIsValidCAA ? origIsValidCAA(self, selector, argument) : YES);
}

static BOOL objectLooksLikeBatteryRepair(id object) {
    if (!object) return NO;
    if (valueContainsBatteryWarning(object)) return YES;
    static const char *selectors[] = {"applicationBundleID", "clientIdentifier", "containerPath", "title", "subtitle", "localizedTitle"};
    for (NSUInteger i = 0; i < sizeof(selectors)/sizeof(selectors[0]); i++) {
        id value = callObjectNoArgument(object, selectors[i]);
        NSString *text = inspectionStringForValue(value);
        if (stringContainsBatteryWarningToken(text)) return YES;
        if ([text isKindOfClass:[NSString class]] &&
            ([text rangeOfString:S("battery") options:NSCaseInsensitiveSearch].location != NSNotFound ||
             [text containsString:S("电池")])) return YES;
    }
    return NO;
}

static void hookedFollowUpAddItem(id self, SEL selector, id item) {
    if (CTBUIActive() && objectLooksLikeBatteryRepair(item)) return;
    if (origFollowUpAddItem) origFollowUpAddItem(self, selector, item);
}

static BOOL hookedAllowsBadgingForIcon(id self, SEL selector, id icon) {
    if (CTBUIActive()) {
        id bundleID = callObjectNoArgument(icon, "applicationBundleID");
        if ([bundleID isKindOfClass:[NSString class]] &&
            [(NSString *)bundleID isEqualToString:S("com.apple.Preferences")]) return NO;
    }
    return origAllowsBadgingForIcon ? origAllowsBadgingForIcon(self, selector, icon) : YES;
}

static void installReferenceRepairHooks(void) {
        Class resource = objc_getClass("BatteryUIResourceClass");
        Class resourceMeta = resource ? object_getClass(resource) : Nil;
        if (resourceMeta) {
            SEL genuine = sel_registerName("genuineBatteryStatus");
            SEL state = sel_registerName("getBatteryHealthServiceState");
            SEL suggestion = sel_registerName("getBatteryServiceSuggestion:");
            if (!origGenuineBatteryStatus && class_getInstanceMethod(resourceMeta, genuine)) MSHookMessageEx(resourceMeta, genuine, (IMP)hookedGenuineBatteryStatus, (IMP *)&origGenuineBatteryStatus);
            if (!origBatteryHealthServiceState && class_getInstanceMethod(resourceMeta, state)) MSHookMessageEx(resourceMeta, state, (IMP)hookedBatteryHealthServiceState, (IMP *)&origBatteryHealthServiceState);
            if (!origBatteryServiceSuggestion && class_getInstanceMethod(resourceMeta, suggestion)) MSHookMessageEx(resourceMeta, suggestion, (IMP)hookedBatteryServiceSuggestion, (IMP *)&origBatteryServiceSuggestion);
        }
        Class systemHealth = objc_getClass("SystemHealthUI");
        SEL healthSpecifiers = sel_registerName("getCurrentSystemHealthInfoSpecifiers");
        if (!origCurrentSystemHealthInfoSpecifiers && systemHealth && class_getInstanceMethod(systemHealth, healthSpecifiers))
            MSHookMessageEx(systemHealth, healthSpecifiers, (IMP)hookedCurrentSystemHealthInfoSpecifiers, (IMP *)&origCurrentSystemHealthInfoSpecifiers);
        if (systemHealth) {
            SEL misspelled = sel_registerName("isVaildCAA:");
            Method misspelledMethod = class_getInstanceMethod(systemHealth, misspelled);
            if (!origIsVaildCAA && misspelledMethod && method_getNumberOfArguments(misspelledMethod) == 3)
                MSHookMessageEx(systemHealth, misspelled, (IMP)hookedIsVaildCAA, (IMP *)&origIsVaildCAA);
            SEL corrected = sel_registerName("isValidCAA:");
            Method correctedMethod = class_getInstanceMethod(systemHealth, corrected);
            if (!origIsValidCAA && correctedMethod && method_getNumberOfArguments(correctedMethod) == 3)
                MSHookMessageEx(systemHealth, corrected, (IMP)hookedIsValidCAA, (IMP *)&origIsValidCAA);
        }
        Class followUp = objc_getClass("FLGroupViewModelImpl");
        SEL addItem = sel_registerName("addItem:");
        if (!origFollowUpAddItem && followUp && class_getInstanceMethod(followUp, addItem))
            MSHookMessageEx(followUp, addItem, (IMP)hookedFollowUpAddItem, (IMP *)&origFollowUpAddItem);
        Class iconController = objc_getClass("SBIconController");
        SEL allowsBadge = sel_registerName("allowsBadgingForIcon:");
        if (!origAllowsBadgingForIcon && iconController && class_getInstanceMethod(iconController, allowsBadge))
            MSHookMessageEx(iconController, allowsBadge, (IMP)hookedAllowsBadgingForIcon, (IMP *)&origAllowsBadgingForIcon);
}

static void onSettingsChanged(CFNotificationCenterRef center,
                              void *observer,
                              CFStringRef name,
                              const void *object,
                              CFDictionaryRef userInfo) {
    (void)center;
    (void)observer;
    (void)name;
    (void)object;
    (void)userInfo;
    loadPrefs();
    installSpecifierHooks();
    installBatteryHooks();
    installReferenceRepairHooks();
    syslog(LOG_NOTICE, "[屏蔽] settings reloaded, warnings=%d", CTBUIActive());
}

static void onBundleDidLoad(CFNotificationCenterRef center,
                            void *observer,
                            CFStringRef name,
                            const void *object,
                            CFDictionaryRef userInfo) {
    (void)center;
    (void)observer;
    (void)name;
    (void)userInfo;
    NSBundle *bundle = (__bridge NSBundle *)object;
    NSString *bundleIdentifier = [bundle bundleIdentifier];
    installReferenceRepairHooks();
    if (![bundleIdentifier isKindOfClass:[NSString class]]) {
        return;
    }

    if ([bundleIdentifier rangeOfString:S("battery") options:NSCaseInsensitiveSearch].location != NSNotFound ||
        [bundleIdentifier rangeOfString:S("powerui") options:NSCaseInsensitiveSearch].location != NSNotFound ||
        [bundleIdentifier rangeOfString:S("preferences") options:NSCaseInsensitiveSearch].location != NSNotFound) {
        installBatteryHooks();
    }
}

%hook PSListController
- (NSArray *)specifiers {
    NSArray *result = %orig;
    return CTBUIActive() ? filteredBatteryHealthSpecifiers(result) : result;
}
- (void)setSpecifiers:(NSArray *)specifiers {
    NSArray *patched = CTBUIActive() ? filteredBatteryHealthSpecifiers(specifiers) : specifiers;
    %orig(patched);
}
%end

%hook PSTableCell
- (void)layoutSubviews {
    %orig;
    id specifier = nil;
    if ([self respondsToSelector:@selector(specifier)]) specifier = [self specifier];
    if (CTBUIActive() && specifierContainsBatteryWarning(specifier)) {
        self.tag = 0x435054;
        self.hidden = YES;
        self.contentView.hidden = YES;
        return;
    }
    if (self.tag == 0x435054) {
        self.tag = 0;
        self.hidden = NO;
        self.contentView.hidden = NO;
    }

    // ★ 2.0.91：不再改写任何数值——容量/百分比一律照实显示（只按「维修」类提示）
}
%end

%ctor {
    @autoreleasepool {
        loadPrefs();

        if (!gNotifCFName) {
            gNotifCFName = CFStringCreateWithCString(
                kCFAllocatorDefault,
                kCTHermesSettingsChangedNotifC,
                kCFStringEncodingUTF8
            );
        }

        CFNotificationCenterAddObserver(
            CFNotificationCenterGetLocalCenter(),
            NULL,
            onBundleDidLoad,
            (__bridge CFStringRef)NSBundleDidLoadNotification,
            NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately
        );

        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            NULL,
            onSettingsChanged,
            gNotifCFName,
            NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately
        );

        installSpecifierHooks();
        installBatteryHooks();
        installReferenceRepairHooks();
        syslog(LOG_NOTICE, "[屏蔽] loaded, warnings=%d", CTBUIActive());
    }
}
