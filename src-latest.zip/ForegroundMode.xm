// ObjC++ 组件：不引入 IOKit（CI 的 -fmodules 下 IOKit 在 extern "C" 会报错）
#define CT_NO_IOKIT 1

#include <stdio.h>
#include <sys/stat.h>
#import <CTHermesPaths.h>   // ★ 2.0.38：兜底目录走容器（隐根检测面收口）
#import <CTHardening.h>

// ===== 唯一新增（2026-09-16）：解锁瞬间重发"模式变更"通知 = 锁频不丢 =====
#include <notify.h>
#include <sys/time.h>   // ★ 2.0.52：唤醒记录时间戳需要（提前包含，勿依赖下方第 84 行）
static BOOL g_ctFgUninstalled = NO;   // ★ 1.4.94：收到「卸载中」通知后停止本组件一切写盘
static void CTFgWakeLog(const char *msg) {
    if (g_ctFgUninstalled) return;
    FILE *fp = CTDiagLogOpenForAppend();   // ★ 2.0.38：统一闸门
    if (!fp) {   // ★ 0930-0207：主日志写不进 → 兜底日志（前台组件会搬回主日志）※纯 C 版
        const char *ctdirs[] = {CTSharedRunDirC(), CTCacheDirC(), NULL};
        for (int i = 0; ctdirs[i]; i++) {
            char lp[256];
            snprintf(lp, sizeof(lp), "%s/CTHermesFallback.log", ctdirs[i]);
            mkdir(ctdirs[i], 0755);
            fp = fopen(lp, "a");
            if (fp) break;
        }
    }
    if (!fp) return;
    {   // ★ 2.0.52：补时间戳（以后一眼看出是哪一次唤醒）
        struct timeval tv; gettimeofday(&tv, NULL);
        struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
        char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        fprintf(fp, "[%s][解锁] %s\n", ts, msg);
    }
    fclose(fp);
}
#import "ctdefer.h"
static CFAbsoluteTime g_ctAppBoostAt = 0;   // ★ 1.4.75：开合提速共享闸（谁先到谁发 ✓）
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <notify.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <CTHermesPaths.h>
#import <CTHermesSmart.h>
#import <AVFoundation/AVFoundation.h>
#import <VideoToolbox/VideoToolbox.h>
#import <substrate.h>

// ★ T7r 诊断：上报源溯源（顶部前置声明，供 App 自身上报处使用）
static void CTFLog(const char *fmt, ...);
static void CTFLogPostForeground(NSString *bundleID, const char *who);
// ★ 2.0.76：颜色快速通道——"先于确认窗"补发信号（快速切换时窗口颜色也能跟上；不影响模式逻辑）
static void CTFColorNudge(void) {
    @try { notify_post(kCTHermesColorRefreshNotifC); } @catch (__unused NSException *e) {}
}
static void CTFLogClearForeground(NSString *bundleID, const char *who);
static BOOL CTAuthActivatedForMenu(void);   // ★ 2.0.41：前置（提速门用）

static NSString *CTHermesOwnBundleID(void) {
    return [[NSBundle mainBundle] bundleIdentifier];
}

static NSString *CTHermesStringFromObject(id object, const char **selectors) {
    for (int i = 0; object && selectors[i]; i++) {
        SEL selector = sel_registerName(selectors[i]);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

static void CTHermesReportCurrentApplication(void) {
    UIApplication *application = [UIApplication sharedApplication];
    if (application.applicationState != UIApplicationStateActive) return;
    CTFLogPostForeground(CTHermesOwnBundleID(), "应用");
}

static void CTHermesClearCurrentApplication(void) {
    // ★ T7v：不再由 App 自身清空前台状态（沙盒 App 的进出场信号会误清——
    //   表现为"切 App 瞬间变无应用"）；统一交给 SpringBoard 侧监控裁定。
}

// 由 SBApplication activate/deactivate 维护的"当前激活应用"，作为私有接口失效时的兜底真值源。
static NSString *g_trackedFrontmostBundleID = nil;

#define kCTFTag "前台插件 build 2.0.96"
// ★ 诊断（临时）：把"前台检测"每一步写进日志 —— 定位"回桌面再进 QQ 认不出来"的问题
#include <sys/stat.h>
#include <sys/time.h>
#import <CTLit.h>
#import <CTHardening.h>
#import <CTNotifyState.h>   // ★ 0930-0207：通知数据通道
static void CTFLog(const char *fmt, ...);
static void CTFLog(const char *fmt, ...) {
    if (g_ctFgUninstalled) return;   // ★ 1.4.94：卸载后停止写盘
    // ★ T6 修复：改为"每次写都重新打开"——旧版持有句柄，日志文件被清空/轮换后写入全部丢失（实机踩坑）
    FILE *fp = CTDiagLogOpenForAppend();   // ★ 2.0.38：统一闸门
    if (!fp) {   // ★ 0930-0207：主日志写不进 → 兜底日志（前台组件会搬回主日志）
        for (NSString *d in CTStateWriteDirs()) {
            NSString *lp = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
            mkdir([d UTF8String], 0755);
            fp = fopen([lp UTF8String], "a");
            if (fp) break;
        }
    }
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][前台] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

// ★ T7q 诊断：上报前台时把"真实包名字符串"也写进日志（变化时 + 每 30 秒重写一次）。
//   用于定位"同一个 App 前台指纹对不上"的问题（例如：开英雄联盟被报成未知 hash）。
static void CTFLogPostForeground(NSString *bundleID, const char *who) {
    // ★ T7u：系统组件（小组件渲染器等）不参与前台判定
    if (CTHermesIsSystemComponentBundleID(bundleID)) {
        static BOOL sCTCompLogged = NO;
        if (!sCTCompLogged) { sCTCompLogged = YES; CTFLog("组件进程 %s → 不参与前台判定（已过滤）", bundleID.UTF8String); }
        return;
    }
    static NSString *sCTLastPostID = nil;
    static CFAbsoluteTime sCTLastPostTime = 0;
    CFAbsoluteTime nowT = CFAbsoluteTimeGetCurrent();
    BOOL same = ((bundleID == nil && sCTLastPostID == nil) ||
                 (bundleID != nil && sCTLastPostID != nil && [bundleID isEqualToString:sCTLastPostID]));
    if (!same || (nowT - sCTLastPostTime) > 30.0) {
        sCTLastPostID = [bundleID copy];
        sCTLastPostTime = nowT;
        CTFLog("上报(%s)=%s hash=%llu proc=%s", who, (bundleID.length ? bundleID.UTF8String : "(无)"),
               (unsigned long long)CTHermesBundleIDHash(bundleID),
               [[NSProcessInfo processInfo].processName UTF8String] ?: "?");
    }
    CTHermesPostForegroundBundleID(bundleID);
}
static void CTFLogClearForeground(NSString *bundleID, const char *who) {
    if (CTHermesIsSystemComponentBundleID(bundleID)) return;
    BOOL cleared = CTHermesClearForegroundBundleIDIfCurrent(bundleID);
    if (cleared) {
        CTFLog("清空(%s) proc=%s", who, [[NSProcessInfo processInfo].processName UTF8String] ?: "?");
    }
}

// ★ 解锁瞬间防丢：锁屏期间记住"上一个真正的 App"，解锁后几秒内若前台被报成锁屏/桌面，先用它顶上。
//   否则会被误判成"退出了名单 App" → 撤销低功耗 → 一直等到 2~4 秒后 SpringBoard 才交回真实 App。
static NSString *g_ctLastRealAppBundleID = nil;
static CFAbsoluteTime g_ctDeactivatedStamp = 0;   // ★ T7m：最近一次"退出应用"时刻
// ★ "最近一次被 activate 过的 App"：锁屏会把 g_trackedFrontmostBundleID 清掉，
//   而解锁时 iOS 不会重新 activate → 只有这个变量还留着 QQ。
static NSString *g_ctLastActivatedApp = nil;
static CFAbsoluteTime g_ctUnlockStamp = 0;

static BOOL CTHermesLockScreenVisible(void) {
    Class lsmClass = objc_getClass("SBLockScreenManager");
    SEL sharedSel = sel_registerName("sharedInstance");
    if (![lsmClass respondsToSelector:sharedSel]) return NO;
    id lsm = ((id (*)(id, SEL))objc_msgSend)(lsmClass, sharedSel);
    const char *visSel[] = {"isLockScreenVisible", "isLockScreenActive", "isUILocked", NULL};
    for (int i = 0; lsm && visSel[i]; i++) {
        SEL s = sel_registerName(visSel[i]);
        if ([lsm respondsToSelector:s]) return ((BOOL (*)(id, SEL))objc_msgSend)(lsm, s);
    }
    return NO;
}

// 部分 RootHide 注入配置会阻止目标应用加载通用 dylib；SpringBoard 作为系统级
// 真值源轮询当前前台应用，确保指定应用功能不依赖目标应用自身成功注入。
static NSString *CTHermesSpringBoardFrontmostBundleID(void) {
    id springBoard = [UIApplication sharedApplication];
    id application = nil;
    const char *frontSelectors[] = {"_accessibilityFrontMostApplication", "accessibilityFrontMostApplication", "frontmostApplication", NULL};
    for (int i = 0; frontSelectors[i] && !application; i++) {
        SEL selector = sel_registerName(frontSelectors[i]);
        if ([springBoard respondsToSelector:selector]) application = ((id (*)(id, SEL))objc_msgSend)(springBoard, selector);
    }
    if (!application) {
        Class controllerClass = objc_getClass("SBApplicationController");
        SEL sharedSelector = sel_registerName("sharedInstance");
        id controller = [controllerClass respondsToSelector:sharedSelector] ? ((id (*)(id, SEL))objc_msgSend)(controllerClass, sharedSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([controller respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(controller, frontSelector);
    }
    if (!application) {
        // 再兜一层：SBWorkspace 在部分系统版本上持有前台应用。
        Class workspaceClass = objc_getClass("SBWorkspace");
        SEL mainSelector = sel_registerName("mainWorkspace");
        id workspace = [workspaceClass respondsToSelector:mainSelector] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, mainSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([workspace respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(workspace, frontSelector);
    }
    const char *idSelectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *identifier = CTHermesStringFromObject(application, idSelectors);
    if (identifier.length) return identifier;
    // 私有接口全部取不到时，退回 activate/deactivate 维护的当前应用，避免上报 nil→0。
    return g_trackedFrontmostBundleID;
}

// 多任务（卡片）界面是 SpringBoard 的浮层，此时 App 仍算"前台"但用户并没有在用。
// 命中多种可能的私有接口，全部取不到就返回 NO，保持原有行为。
static BOOL CTHermesAppSwitcherVisible(void) {
    SEL sharedSelector = sel_registerName("sharedInstance");
    Class coordinatorClass = objc_getClass("SBMainSwitcherControllerCoordinator");
    if ([coordinatorClass respondsToSelector:sharedSelector]) {
        id coordinator = ((id (*)(id, SEL))objc_msgSend)(coordinatorClass, sharedSelector);
        const char *selectors[] = {"isAnySwitcherVisible", "hasAnySwitcherVisible", "isSwitcherVisible", NULL};
        for (int i = 0; coordinator && selectors[i]; i++) {
            SEL selector = sel_registerName(selectors[i]);
            if ([coordinator respondsToSelector:selector]) return ((BOOL (*)(id, SEL))objc_msgSend)(coordinator, selector);
        }
    }
    Class controllerClass = objc_getClass("SBAppSwitcherController");
    if ([controllerClass respondsToSelector:sharedSelector]) {
        id controller = ((id (*)(id, SEL))objc_msgSend)(controllerClass, sharedSelector);
        const char *selectors[] = {"isMainSwitcherVisible", "isVisible", "_isVisible", NULL};
        for (int i = 0; controller && selectors[i]; i++) {
            SEL selector = sel_registerName(selectors[i]);
            if ([controller respondsToSelector:selector]) return ((BOOL (*)(id, SEL))objc_msgSend)(controller, selector);
        }
    }
    return NO;
}

static void CTHermesStartSpringBoardMonitor(void) {
    __block uint64_t lastHash = UINT64_MAX;
    __block NSString *lastBundleID = nil;
    __block CFAbsoluteTime lastPost = 0;
    // ★ T7s：启动 2 秒后强制上报一次真实前台——盖掉可能残留的旧值（跳 respring）
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *ctT7sBid1 = CTHermesSpringBoardFrontmostBundleID();
        CTFLogPostForeground(ctT7sBid1.length ? ctT7sBid1 : nil, "启动盖残留");
    });
    void (^poll)(void) = ^{
        static CFAbsoluteTime sCtNilHoldSince = 0;   // ★ 270：读空顶住计时
        {   // ★ 每 0.1 秒都跑：用"轮询时间跳变"检测唤醒（熄屏挂起 → 时间必然跳变）
            static CFAbsoluteTime sLastTick = 0;
            CFAbsoluteTime tickNow = CFAbsoluteTimeGetCurrent();
            if (sLastTick > 0 && (tickNow - sLastTick) > 3.0) {
                notify_post("com.qq391160.cpucore/powerModeChanged");
                CTFgWakeLog("已重发模式变更通知（检测到唤醒）");
            }
            sLastTick = tickNow;
        }
        // 卡片（多任务）界面：前台应用虽然还是它，但用户并没在使用 →
        // 立刻上报"无应用"，让 thermalmonitord 切到「原生」。
        {
            static BOOL sCTSwWasVisible = NO;
            BOOL ctSwVis = CTHermesAppSwitcherVisible();
            if (ctSwVis != sCTSwWasVisible) {
                sCTSwWasVisible = ctSwVis;
                CTFLog(ctSwVis ? "多任务界面=可见 → 上报无应用" : "多任务界面=已关闭");
                if (ctSwVis) {
                {   // ★ 1.4.58：回桌面/卡片 ⇒ 也提速（同样机制+防抖 ✓）
                    static CFAbsoluteTime sABx = 0; static BOOL sABoff = NO; static CFAbsoluteTime sABchk = 0;
                    CFAbsoluteTime abn = CFAbsoluteTimeGetCurrent();
                    if (abn - sABchk > 2.0) { sABchk = abn; sABoff = ![CTHermesReadPrefs()[S("appBoostEnabled")] boolValue]; }
                    if (!sABoff && abn - sABx > 1.0) {
                        sABx = abn;
                        NSDictionary *abp2 = CTHermesReadPrefs();
                        double secs2 = [abp2[S("appBoostSecs")] ?: @3.0 doubleValue];
                        if (secs2 < 2.0) secs2 = 2.0; if (secs2 > 5.0) secs2 = 5.0;
                        int n2 = (int)((secs2 - 0.6) / 0.4); if (n2 < 2) n2 = 2; if (n2 > 14) n2 = 14;
                        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                            for (int i2 = 0; i2 < n2; i2++) { notify_post(kCTHermesAppBoostNotifC); usleep(400 * 1000); }
                        });
                        CTFLog("[开合] 触发（回桌面/卡片 ✓）");
                    }
                }
                }
            }
            if (ctSwVis) {
                if (lastBundleID.length || g_trackedFrontmostBundleID.length) {
                    g_trackedFrontmostBundleID = nil;
                    lastHash = 0;
                    lastBundleID = nil;
                    lastPost = CFAbsoluteTimeGetCurrent();
                    CTFLogPostForeground(nil, "监控");
                }
                return;
            }
        }
        NSString *bundleID = CTHermesSpringBoardFrontmostBundleID();
        // ★★ 解锁回 App 时，私有接口常常仍返回"SpringBoard（锁屏界面）"——
        //    此时优先用 activate/deactivate 钩子跟踪到的当前 App（可靠通知链，用户实测"切一下 App 就对了"）。
        if (!bundleID.length || [bundleID isEqualToString:S("com.apple.springboard")]) {
            // ★ 2026-09-17：兜底映射只在"锁屏中 / 解锁后 8 秒内"生效（它本来就是为解锁防误判做的）；
            //   其余时间（真回到桌面/长时间在桌面）如实上报 → thermalmonitord 自动降回低功耗。
            BOOL ctProtectWindow = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 8.0);
            if (ctProtectWindow || CTHermesLockScreenVisible()) {
                if (g_trackedFrontmostBundleID.length) {
                    bundleID = g_trackedFrontmostBundleID;
                } else if (g_ctLastActivatedApp.length) {
                    bundleID = g_ctLastActivatedApp;
                }
            }
        }
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (!bundleID.length) {
            // ★ 锁屏/解锁瞬间系统常常"取不到前台"（返回空）—— 此时如果是锁屏界面或刚解锁，
            //   先用缓存的"上一个真实 App"顶上，避免被误判成"退出了名单 App"而撤销低功耗。
            if (g_ctLastRealAppBundleID.length) {
                BOOL withinUnlockWindow2 = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 6.0);
                if (CTHermesLockScreenVisible() || withinUnlockWindow2) {
                    uint64_t h2 = CTHermesBundleIDHash(g_ctLastRealAppBundleID);
                    if (h2 != lastHash || (CFAbsoluteTimeGetCurrent() - lastPost) >= 2.0) {
                        lastHash = h2;
                        lastBundleID = g_ctLastRealAppBundleID;
                        lastPost = CFAbsoluteTimeGetCurrent();
                        CTFLogPostForeground(g_ctLastRealAppBundleID, "兜底");
                    }
                    return;
                }
            }
            // 取不到前台应用（私有接口偶发返回 nil，例如全屏视频/转场瞬间）时不能上报 0，
            // 否则 thermalmonitord 会误判为"已退出指定应用"并撤销低功耗。
            if (lastBundleID.length) {
                if (g_trackedFrontmostBundleID.length) {
                    // SpringBoard 侧仍认为该应用处于激活状态：沿用上次结果（心跳重发）。
                    if ([g_trackedFrontmostBundleID isEqualToString:lastBundleID] && (now - lastPost) >= 2.0) {
                        lastPost = now;
                        CTFLogPostForeground(lastBundleID, "心跳");
                        {   // ★ T7n 诊断：心跳重发计数（同一 App 被反复重发 = 卡住的线索）
                            static int sCTHB = 0;
                            static uint64_t sCTHBHash = 0;
                            uint64_t hbH = CTHermesBundleIDHash(lastBundleID);
                            if (hbH != sCTHBHash) { sCTHBHash = hbH; sCTHB = 0; }
                            sCTHB++;
                            if (sCTHB == 1 || sCTHB == 5 || (sCTHB % 15) == 0) {
                                CTFLog("心跳重发 %s ×%d（前台接口为空，疑似卡住）", lastBundleID.UTF8String ?: "?", sCTHB);
                            }
                        }
                    }
                } else {
                    // ★ 270：读接口返回空时，先"顶住上次真实 App"最多 2 秒（心跳重发）——
                    //   修"每 ~20 秒模式小抖"；同时保留快响应：真正回桌面走 springboard 读取通道（不受影响）。
                    if (sCtNilHoldSince == 0) sCtNilHoldSince = now;
                    if ((now - sCtNilHoldSince) < 2.0) {
                        if ((now - lastPost) >= 2.0) {
                            lastPost = now;
                            CTFLogPostForeground(lastBundleID, "心跳");
                        }
                    } else if ((now - lastPost) >= 0.6) {
                        lastHash = 0;
                        lastBundleID = nil;
                        lastPost = now;
                        CTFLogPostForeground(nil, "监控");
                    }
                }
            }
            return;
        }
        sCtNilHoldSince = 0;   // ★ 270：读正常了，清空"读空顶住"计时
        BOOL isSpringBoard = [bundleID isEqualToString:S("com.apple.springboard")];
        if (bundleID.length && !isSpringBoard) {
            g_ctLastRealAppBundleID = bundleID;          // 记住真实 App
        } else if (bundleID.length && isSpringBoard && g_ctLastRealAppBundleID.length) {
            BOOL withinUnlockWindow = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 6.0);
            if (CTHermesLockScreenVisible() || withinUnlockWindow) {
                bundleID = g_ctLastRealAppBundleID;      // 顶上，避免误判"退出名单 App"
            }
        }
        {   // ★ 2.0.76：颜色快速通道——读到的前台一变就先补发（哪怕稍后会被"确认窗"拦截；颜色先跟上）
            static NSString *sCtColorLast = nil;
            if (!(sCtColorLast == bundleID || [sCtColorLast isEqualToString:bundleID])) {
                sCtColorLast = [bundleID copy];
                CTFColorNudge();
            }
        }
        // ★★ T7k 修复"回桌面残留"：SpringBoard 私有接口在退到桌面后，常会继续返回"上一个 App"。
        //    若 activate/deactivate 跟踪显示"当前没有活动 App"，确认 0.8 秒后按"无应用"上报，
        //    让 thermalmonitord 正确切到「原生」。（锁屏 / 解锁 8 秒保护窗 / 卡片界面除外）
        // ★ T7v：读到的前台连续稳定计时（残留只会闪 0.1~0.2 秒；稳定 ≥2 秒视为真实前台）
        static NSString *sCtT7vReadBid = nil;
        static CFAbsoluteTime sCtT7vReadSince = 0;
        if (bundleID.length && !isSpringBoard) {
            if (![bundleID isEqualToString:sCtT7vReadBid]) { sCtT7vReadBid = [bundleID copy]; sCtT7vReadSince = CFAbsoluteTimeGetCurrent(); }
        } else {
            sCtT7vReadBid = nil; sCtT7vReadSince = 0;
        }
        BOOL ctT7vReadStable = (sCtT7vReadBid.length && (CFAbsoluteTimeGetCurrent() - sCtT7vReadSince) >= 2.0);
        {
            static CFAbsoluteTime sCTStaleSince = 0;
            if (!isSpringBoard && !g_trackedFrontmostBundleID && !ctT7vReadStable) {
                BOOL ctProtected = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 8.0)
                                   || CTHermesLockScreenVisible() || CTHermesAppSwitcherVisible();
                if (ctProtected) {
                    sCTStaleSince = 0;
                } else {
                    if (sCTStaleSince == 0) sCTStaleSince = CFAbsoluteTimeGetCurrent();
                    if ((CFAbsoluteTimeGetCurrent() - sCTStaleSince) < 0.35) {
                        return;   // 0.35 秒确认窗口：先不上报（等 activate，或确认确实无应用）
                    }
                    if (lastBundleID.length || lastHash != 0) {
                        lastHash = 0;
                        lastBundleID = nil;
                        lastPost = CFAbsoluteTimeGetCurrent();
                        CTFLogPostForeground(nil, "监控");
                        CTFLog("残留前台=%s（无活动App）→ 上报无应用", bundleID.UTF8String ?: "?");
                {   // ★ 1.4.58：回桌面/卡片 ⇒ 也提速（同样机制+防抖 ✓）
                    static CFAbsoluteTime sABx = 0; static BOOL sABoff = NO; static CFAbsoluteTime sABchk = 0;
                    CFAbsoluteTime abn = CFAbsoluteTimeGetCurrent();
                    if (abn - sABchk > 2.0) { sABchk = abn; sABoff = ![CTHermesReadPrefs()[S("appBoostEnabled")] boolValue]; }
                    if (!sABoff && abn - sABx > 1.0) {
                        sABx = abn;
                        NSDictionary *abp2 = CTHermesReadPrefs();
                        double secs2 = [abp2[S("appBoostSecs")] ?: @3.0 doubleValue];
                        if (secs2 < 2.0) secs2 = 2.0; if (secs2 > 5.0) secs2 = 5.0;
                        int n2 = (int)((secs2 - 0.6) / 0.4); if (n2 < 2) n2 = 2; if (n2 > 14) n2 = 14;
                        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                            for (int i2 = 0; i2 < n2; i2++) { notify_post(kCTHermesAppBoostNotifC); usleep(400 * 1000); }
                        });
                        CTFLog("[开合] 触发（回桌面/卡片 ✓）");
                    }
                }

                    }
                    return;
                }
            } else {
                sCTStaleSince = 0;
            }
        }
        uint64_t hash = CTHermesBundleIDHash(bundleID);

        // ★ 1.4.53：开合 App 提速（桌面⇄App ⇒ 复用"滑动提速"ping ✓ 只用底座现成零件 ✓）
        {
            static CFAbsoluteTime sCtABLast = 0;
            static uint64_t sCtABLastHash = 0;
            CFAbsoluteTime abNow = CFAbsoluteTimeGetCurrent();
            NSDictionary *abp = CTHermesReadPrefs();
            // ★ 1.4.56：任何前台变化都提（进入 ✓ 退出回桌面 ✓ 切换 App ✓ 一视同仁 ✓）
            if (CTAuthActivatedForMenu() && [abp[S("appBoostEnabled")] boolValue] && hash != sCtABLastHash && (CFAbsoluteTimeGetCurrent() - g_ctAppBoostAt) >= 0.5) {   // ★ 2.0.41：安全红线
                sCtABLastHash = hash;
                g_ctAppBoostAt = CFAbsoluteTimeGetCurrent();   // ★ 1.4.75：占住共享闸 ✓
                CTFLog("[开合] 触发（hash=%llu ✓）", (unsigned long long)hash);   // ★ 1.4.56：触发日志（一眼可查 ✓）
                double secs = [abp[S("appBoostSecs")] ?: @3.0 doubleValue];
                if (secs < 2.0) secs = 2.0; if (secs > 5.0) secs = 5.0;
                if (abNow - sCtABLast > 1.0) {
                    sCtABLast = abNow;
                    int n = (int)((secs - 0.6) / 0.4); if (n < 2) n = 2; if (n > 14) n = 14;
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                        for (int i = 0; i < n; i++) { notify_post(kCTHermesAppBoostNotifC); usleep(400 * 1000); }
                    });
                }
            }
        }
        // ★ 诊断：记录最终上报了什么（含原始值/跟踪值/最近激活）
        {
            static uint64_t sLastLogged = 0;
            if (hash != sLastLogged) {
                sLastLogged = hash;
                CTFLog("proc=%s 最终上报=%s (跟踪值=%s 最近激活=%s)",
                       [NSProcessInfo processInfo].processName.UTF8String,
                       bundleID.UTF8String ?: "(空)",
                       g_trackedFrontmostBundleID.UTF8String ?: "(空)",
                       g_ctLastActivatedApp.UTF8String ?: "(空)");
            }
        }
        // 哈希变化立即上报；哈希不变时每 2 秒心跳重发一次，避免 thermalmonitord
        // 侧因通知丢失（进程重启、被唤醒逻辑覆盖等）长期停留在错误模式。
        BOOL heartbeat = (now - lastPost) >= 2.0;
        if (hash == lastHash && !heartbeat) return;
        lastHash = hash;
        lastBundleID = bundleID;
        lastPost = now;
        CTFLogPostForeground(bundleID, "监控");
    };
    static int ctLockToken = -1;
    notify_register_dispatch("com.apple.springboard.lockstate", &ctLockToken, dispatch_get_main_queue(), ^(int token) {
        uint64_t st = UINT64_MAX;
        if (notify_get_state(token, &st) == NOTIFY_STATUS_OK && st == 0) {
            g_ctUnlockStamp = CFAbsoluteTimeGetCurrent();
            // ★ T7s：解锁后 1.5 秒强制上报一次真实前台（盖掉锁屏/残留旧值）
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                NSString *ctT7sBid2 = CTHermesSpringBoardFrontmostBundleID();
                CTFLogPostForeground(ctT7sBid2.length ? ctT7sBid2 : nil, "解锁盖残留");
            });
        }
    });
    // ★ T7l 自检：多任务检测的类/方法到底哪个能用（写进日志，一次就够）
    {
        Class c1 = objc_getClass("SBMainSwitcherControllerCoordinator");
        Class c2 = objc_getClass("SBAppSwitcherController");
        SEL sh = sel_registerName("sharedInstance");
        id o1 = (c1 && [c1 respondsToSelector:sh]) ? ((id (*)(id, SEL))objc_msgSend)(c1, sh) : nil;
        id o2 = (c2 && [c2 respondsToSelector:sh]) ? ((id (*)(id, SEL))objc_msgSend)(c2, sh) : nil;
        CTFLog("多任务检测自检: coordinator类=%s 实例=%s isAny=%d hasAny=%d isSwitcher=%d | controller类=%s 实例=%s isMain=%d isVisible=%d | SBApplication.isActive=%d isFrontmost=%d",
               c1 ? "有" : "无", o1 ? "有" : "无",
               (int)[o1 respondsToSelector:sel_registerName("isAnySwitcherVisible")],
               (int)[o1 respondsToSelector:sel_registerName("hasAnySwitcherVisible")],
               (int)[o1 respondsToSelector:sel_registerName("isSwitcherVisible")],
               c2 ? "有" : "无", o2 ? "有" : "无",
               (int)[o2 respondsToSelector:sel_registerName("isMainSwitcherVisible")],
               (int)[o2 respondsToSelector:sel_registerName("isVisible")],
               (int)[objc_getClass("SBApplication") instancesRespondToSelector:sel_registerName("isActive")],
               (int)[objc_getClass("SBApplication") instancesRespondToSelector:sel_registerName("isFrontmost")]);
    }
    poll();
    // 100ms 兜底轮询；应用激活 Hook 仍是主路径，RootHide 阻止目标 App 注入时也能快速识别。
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(__unused NSTimer *timer) { poll(); }];
}

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
- (NSString *)displayIdentifier;
@end

// ★ 未授权 → 不注入桌面长按菜单（与浮窗同一套判定：prefs 优先、兜底读授权状态文件）
static BOOL CTAuthActivatedForMenu(void) {
    // ③ 校验分散（0930-0183）：能独立验签即放行（异常/无码 → 走原逻辑，绝不影响正常用户）
    {
        NSDictionary *__p = CTHermesReadPrefs();
        NSString *__c = [__p objectForKey:kCTKeyActivationCode];
        NSString *__dv = [__p objectForKey:kCTKeyDevCode];
        if ([__c isKindOfClass:[NSString class]] && __c.length > 0 &&
            [__dv isKindOfClass:[NSString class]] && __dv.length > 0 &&
            CTAuthVerifySignature(__dv, __c)) return YES;
    }
    NSDictionary *d = CTHermesReadPrefs();
    id st = [d objectForKey:kCTKeyAuthState];
    if (st) return [st boolValue];
    NSString *s = [NSString stringWithContentsOfFile:kCTPathAuthFile
                                            encoding:NSUTF8StringEncoding error:NULL];
    // ★ 1.4.11：授权文件内容 = 授权码本身 → 独立验签才算数（不再认裸 "1"）
    if (s.length == 0) return NO;
    return CTAuthFileAuthorized();
}

%hook SBApplication
- (void)activate {
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CTHermesStringFromObject(self, selectors);
    if (bundleID.length) { g_trackedFrontmostBundleID = bundleID; g_ctLastActivatedApp = bundleID; }
    // ★ T7m：多任务界面（滑动卡片）里的 activate 不上报 —— 避免"划到哪张卡片就跟着哪个 App"。
    if (CTHermesAppSwitcherVisible()) {
        %orig;
        return;
    }
    // activate 前先发布，thermalmonitord 可与应用前台切换并行套用低功耗；完成后再确认一次。
    if (bundleID.length) CTFLogPostForeground(bundleID, "钩子");
    %orig;
    if (bundleID.length) CTFLogPostForeground(bundleID, "钩子");
}
- (void)deactivate {
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CTHermesStringFromObject(self, selectors);
    CTFLog("deactivate: %s (tracked=%s)", bundleID.UTF8String ?: "?", g_trackedFrontmostBundleID.UTF8String ?: "空");
    if (bundleID.length && g_trackedFrontmostBundleID && [g_trackedFrontmostBundleID isEqualToString:bundleID]) {
        g_trackedFrontmostBundleID = nil;
        g_ctDeactivatedStamp = CFAbsoluteTimeGetCurrent();   // ★ T7m：记录"刚退出去"的时刻
    }
    %orig;
    // 退到桌面/切到别处时清掉状态（只有当前状态确实是它才会清），
    // 避免"回到桌面后仍被当作停留在指定应用"。
    if (bundleID.length) CTFLogClearForeground(bundleID, "钩子");
}
%end

// ★ T7z6：用户操作探针（无操作深度降频）——任何触摸立即上报；滑动限频 0.25 秒
//   ★ 1.4.126：手指"按下去"那一刻走快车道（限频 0.05 秒）——把"触摸→提速"链路压短，开合瞬间更跟手
static void CTFUserActivityPing(BOOL urgent) {
    static CFAbsoluteTime sCtLastUA = 0;
    CFAbsoluteTime ctNowUA = CFAbsoluteTimeGetCurrent();
    if (ctNowUA - sCtLastUA < (urgent ? 0.05 : 0.25)) return;
    sCtLastUA = ctNowUA;
    notify_post(kCTHermesUserActivityNotifC);
}

// ★ 2.0.92：滑动/拖动探针——只认"手指移动"（Moved）；点按/按住不触发；限频 0.2 秒
static void CTFDragPing(void) {
    static CFAbsoluteTime sCtLastDragP = 0;
    CFAbsoluteTime ctNowDP = CFAbsoluteTimeGetCurrent();
    if (ctNowDP - sCtLastDragP < 0.20) return;
    sCtLastDragP = ctNowDP;
    notify_post(kCTHermesDragNotifC);
}

// ★ 1.4.74：手势那一刻的提速（打开=didBecomeActive；离开=willResignActive ✓）
static void CTFAppBoostNow(void) {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (!CTAuthActivatedForMenu()) { CTFLog("[开合·诊断] 未授权 → 跳过"); return; }   // ★ 2.0.41：安全红线
    if (now - g_ctAppBoostAt < 0.5) { CTFLog("[开合·诊断] 被闸跳过"); return; }   // ★ 1.4.124：闸 1.2→0.5 秒（连密切换不再漏提速）
    g_ctAppBoostAt = now;
    NSDictionary *p = CTHermesReadPrefs();
    if (![p[S("appBoostEnabled")] boolValue]) { CTFLog("[开合·诊断] 开关关"); return; }
    CTFLog("[开合] 手势触发（上滑/激活 ✓）");   // ★ 1.4.76：记账 ✓
    double secs = [p[S("appBoostSecs")] ?: @3.0 doubleValue];
    if (secs < 2.0) secs = 2.0; if (secs > 5.0) secs = 5.0;
    int n = (int)((secs - 0.6) / 0.4); if (n < 2) n = 2; if (n > 14) n = 14;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        for (int i = 0; i < n; i++) { notify_post(kCTHermesAppBoostNotifC); usleep(400 * 1000); }
    });
}
%hook UIApplication
- (void)didBecomeActive {
    %orig;
    if (![CTHermesOwnBundleID() isEqualToString:S("com.apple.springboard")]) { CTFLog("[开合·诊断] didBecomeActive"); CTHermesReportCurrentApplication(); CTFAppBoostNow(); }
}
- (void)willResignActive {
    %orig;
    if (![CTHermesOwnBundleID() isEqualToString:S("com.apple.springboard")]) { CTFLog("[开合·诊断] willResignActive"); CTFAppBoostNow(); }   // ★ 1.4.74：上滑瞬间 ⇒ 先提 ✓
}
- (void)didEnterBackground {
    %orig;
    if (![CTHermesOwnBundleID() isEqualToString:S("com.apple.springboard")]) CTHermesClearCurrentApplication();
}
- (void)sendEvent:(UIEvent *)event {
    %orig;
    if (event.type == UIEventTypeTouches) {
        BOOL ctSB = [CTHermesOwnBundleID() isEqualToString:S("com.apple.springboard")];
        for (UITouch *ctT6 in event.allTouches) {
            if (ctT6.phase == UITouchPhaseBegan) {
                // ★ 1.4.80：App 里【屏幕底部 12% 起手】⇒ 大概率是"上滑离开" ⇒ 立刻提速（上滑那一刻 ✓）
                if (!ctSB) {
                    @try {
                        CGPoint ctP = [ctT6 locationInView:nil];
                        CGFloat ctH = [UIScreen mainScreen].bounds.size.height;
                        if (ctH > 0 && ctP.y >= ctH * 0.88) { CTFAppBoostNow(); }
                    } @catch (__unused NSException *e) {}
                }
                // ★ 1.4.81（a 档）：桌面里【点在 App 图标上】⇒ 预判"马上要开 App" ⇒ 先提一发（带日志 ✓）
                if (ctSB) {
                    @try {
                        CGPoint ctP2 = [ctT6 locationInView:nil];
                        UIWindow *ctW = nil;
                        for (UIWindow *w in [UIApplication sharedApplication].windows) { if (w.isKeyWindow) { ctW = w; break; } }
                        UIView *ctHit = ctW ? [ctW hitTest:ctP2 withEvent:event] : nil;
                        BOOL ctOnIcon = NO;
                        UIView *ctV = ctHit;
                        for (int ctD = 0; ctV && ctD < 8; ctD++) {
                            NSString *cn = NSStringFromClass([ctV class]);
                            if ([cn containsString:S("Icon")]) { ctOnIcon = YES; break; }
                            ctV = ctV.superview;
                        }
                        if (ctOnIcon) { CTFLog("[开合·图标预判] 触发"); CTFAppBoostNow(); }
                    } @catch (__unused NSException *e) {}
                }
            }
            if (ctT6.phase == UITouchPhaseBegan || ctT6.phase == UITouchPhaseMoved) { CTFUserActivityPing(ctT6.phase == UITouchPhaseBegan); if (ctT6.phase == UITouchPhaseMoved) CTFDragPing(); break; }
        }
    }
}
%end

// ★ T7z6：视频/直播探针——AVPlayer 事件 + VideoToolbox 解码时间戳（自研播放器如抖音走 VT）
static CFAbsoluteTime sCtVTDLast = 0;
static BOOL sCtAVPlaying = NO;
static BOOL sCtVideoOn = NO;
static dispatch_source_t sCtVidTimer = NULL;
static void CTFVideoEvaluate(void) {
    CFAbsoluteTime ctVN = CFAbsoluteTimeGetCurrent();
    BOOL ctActive = sCtAVPlaying || (sCtVTDLast > 0 && (ctVN - sCtVTDLast) < 2.0);
    if (ctActive == sCtVideoOn) return;
    sCtVideoOn = ctActive;
    if (ctActive) {
        notify_post(kCTHermesVideoOnNotifC);
        if (!sCtVidTimer) {
            sCtVidTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
            dispatch_source_set_timer(sCtVidTimer, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC), 1ull * NSEC_PER_SEC, 300ull * NSEC_PER_MSEC);
            dispatch_source_set_event_handler(sCtVidTimer, ^{ CTFVideoEvaluate(); });
            dispatch_resume(sCtVidTimer);
        }
    } else {
        notify_post(kCTHermesVideoOffNotifC);
        if (sCtVidTimer) { dispatch_source_cancel(sCtVidTimer); sCtVidTimer = NULL; }
    }
}
%hook AVPlayer
- (void)play {
    %orig;
    sCtAVPlaying = YES;
    CTFVideoEvaluate();
}
- (void)pause {
    %orig;
    sCtAVPlaying = NO;
    CTFVideoEvaluate();
}
- (void)setRate:(float)rate {
    %orig;
    sCtAVPlaying = (rate > 0.01f);
    CTFVideoEvaluate();
}
%end
// VideoToolbox 解码探针（C 函数，手动 MSHookFunction；两种变体都挂；热路径只写时间戳）
typedef OSStatus (*CTVTDF)(VTDecompressionSessionRef, CMSampleBufferRef, VTDecodeFrameFlags, void *, VTDecodeInfoFlags *);
typedef OSStatus (*CTVTDFH)(VTDecompressionSessionRef, CMSampleBufferRef, VTDecodeFrameFlags, VTDecodeInfoFlags *, id);
static CTVTDF  g_ctOrigVTDF  = NULL;
static CTVTDFH g_ctOrigVTDFH = NULL;
static OSStatus ctHookVTDF(VTDecompressionSessionRef session, CMSampleBufferRef sampleBuffer, VTDecodeFrameFlags flags, void *sourceFrameRefCon, VTDecodeInfoFlags *infoFlagsOut) {
    sCtVTDLast = CFAbsoluteTimeGetCurrent();
    if (!sCtVideoOn) { static CFAbsoluteTime sL1 = 0; if (sCtVTDLast - sL1 > 2.0) { sL1 = sCtVTDLast; CTFVideoEvaluate(); } }
    return g_ctOrigVTDF ? g_ctOrigVTDF(session, sampleBuffer, flags, sourceFrameRefCon, infoFlagsOut) : -1;
}
static OSStatus ctHookVTDFH(VTDecompressionSessionRef session, CMSampleBufferRef sampleBuffer, VTDecodeFrameFlags flags, VTDecodeInfoFlags *infoFlagsOut, id completionHandler) {
    sCtVTDLast = CFAbsoluteTimeGetCurrent();
    if (!sCtVideoOn) { static CFAbsoluteTime sL2 = 0; if (sCtVTDLast - sL2 > 2.0) { sL2 = sCtVTDLast; CTFVideoEvaluate(); } }
    return g_ctOrigVTDFH ? g_ctOrigVTDFH(session, sampleBuffer, flags, infoFlagsOut, completionHandler) : -1;
}
static void CTFInstallVTHooks(void) {
    static BOOL ctDone = NO;
    if (ctDone) return;
    ctDone = YES;
    MSHookFunction((void *)VTDecompressionSessionDecodeFrame, (void *)ctHookVTDF, (void **)&g_ctOrigVTDF);
    MSHookFunction((void *)VTDecompressionSessionDecodeFrameWithOutputHandler, (void *)ctHookVTDFH, (void **)&g_ctOrigVTDFH);
}

// ★ T7x2：滑动提速信号——只认"手指真的在滑"：
//   · 手指拖动中（isDragging）：发
//   · 松手后的惯性滑行（isDecelerating）：最多再发 0.6 秒
//   · 其余（App 自己动画/收消息自动滚/列表布局调整等"幽灵滚动"）：不发
//   修：停手后提速被幽灵滚动反复续期（实测拖到 ~6 秒才回落）；现在停手约 1 秒出头就回落。
static void CTFScrollBoostPingForView(UIScrollView *sv) {
    if (!sv) return;
    BOOL ctDragging = sv.isDragging;
    static CFAbsoluteTime sCtLastDrag = 0;
    CFAbsoluteTime ctNowB = CFAbsoluteTimeGetCurrent();
    if (ctDragging) sCtLastDrag = ctNowB;
    if (!ctDragging) {
        if (!sv.isDecelerating) return;                     // 幽灵滚动 → 不算数
        if (ctNowB - sCtLastDrag > 0.60) return;            // 松手惯性最多再带 0.6 秒
    }
    static CFAbsoluteTime sCtLastBoostPost = 0;
    if (ctNowB - sCtLastBoostPost < 0.20) return;           // 限频 0.2 秒
    sCtLastBoostPost = ctNowB;
    if ([CTHermesOwnBundleID() isEqualToString:S("com.apple.springboard")]) return;
    notify_post(kCTHermesScrollBoostNotifC);
}
%hook UIScrollView
- (void)setContentOffset:(CGPoint)contentOffset {
    %orig;
    CTFScrollBoostPingForView(self);
}
- (void)setContentOffset:(CGPoint)contentOffset animated:(BOOL)animated {
    %orig;
    CTFScrollBoostPingForView(self);
}
%end

// ============================================================================
// ★ T7x7：桌面长按菜单——「温控频率：<当前档>」→ 点按弹出四选一（高性能/低频率/原生/自动）
//   挂钩写法参考 Choicy（开源）：hook SBIconView 的 applicationShortcutItems 追加一项；
//   点选回调 +[SBIconView activateShortcut:withBundleIdentifier:forIconView:]。仅 SpringBoard 内生效。
// ============================================================================

@interface SBIconView : UIView
- (NSString *)applicationBundleIdentifier;
- (NSString *)applicationBundleIdentifierForShortcuts;
@end

@interface SBSApplicationShortcutItem : NSObject
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *localizedTitle;
@property (nonatomic, copy) NSString *bundleIdentifierToLaunch;
@end

static NSString *ctMenuTierName(NSString *v) {
    if ([v isEqualToString:S("full")]) return S("高性能");
    if ([v isEqualToString:S("low")]) return S("低频率");
    if ([v isEqualToString:S("native")]) return S("原生");
    return S("自动");
}

static NSString *ctMenuAppName(NSString *appID) {
    @try {
        Class proxyClass = NSClassFromString(S("LSApplicationProxy"));
        SEL sel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
        if (proxyClass && [proxyClass respondsToSelector:sel] && appID.length) {
            id proxy = ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, sel, appID);
            if (proxy) {
                const char *ctSels[] = {"localizedName", "itemName", "localizedShortName", NULL};
                for (int i = 0; ctSels[i]; i++) {
                    SEL s2 = sel_registerName(ctSels[i]);
                    if (![proxy respondsToSelector:s2]) continue;
                    id v = ((id (*)(id, SEL))objc_msgSend)(proxy, s2);
                    if ([v isKindOfClass:[NSString class]] && [v length] > 0) return v;
                }
            }
        }
    } @catch (__unused NSException *e) {}
    return appID;
}

static void ctMenuWriteTier(NSString *appID, NSString *value) {
    @try {
        NSMutableDictionary *prefs = CTHermesReadMutablePrefs() ?: [NSMutableDictionary dictionary];
        NSMutableDictionary *tiers = [prefs[S("appTiers")] isKindOfClass:[NSDictionary class]] ? [prefs[S("appTiers")] mutableCopy] : [NSMutableDictionary dictionary];
        if (value.length == 0 || [value isEqualToString:S("auto")]) [tiers removeObjectForKey:appID];
        else tiers[appID] = value;
        prefs[S("appTiers")] = tiers;
        prefs[S("appTiersMigrated")] = @YES;
        CTHermesWritePrefs(prefs);
        notify_post(kCTHermesSettingsChangedNotifC);
        CTFLog("[菜单] 已设置 %s → %s（即时生效）", appID.UTF8String ?: "?", ctMenuTierName(value).UTF8String);
    } @catch (__unused NSException *e) {
        CTFLog("[菜单] 写入档位异常");
    }
}

static void ctMenuPresentPicker(NSString *appID, id iconView) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try {
            NSDictionary *prefs = CTHermesReadPrefs();
            NSDictionary *tiers = [prefs[S("appTiers")] isKindOfClass:[NSDictionary class]] ? prefs[S("appTiers")] : nil;
            NSString *cur = tiers[appID] ?: S("auto");
            NSString *appName = ctMenuAppName(appID);
            UIAlertController *ac = [UIAlertController alertControllerWithTitle:S("温控频率") message:[NSString stringWithFormat:S("为「%@」选择频率（对三种模式都生效）"), appName] preferredStyle:UIAlertControllerStyleActionSheet];
            NSArray *opts = @[ @[S("高性能"), S("full")], @[S("低频率"), S("low")], @[S("原生"), S("native")], @[S("自动"), S("auto")] ];
            for (NSArray *opt in opts) {
                NSString *val = opt[1];
                BOOL isCur = [cur isEqualToString:val];
                NSString *title = isCur ? [NSString stringWithFormat:S("✓ %@"), opt[0]] : opt[0];
                [ac addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { ctMenuWriteTier(appID, val); }]];
            }
            [ac addAction:[UIAlertAction actionWithTitle:S("取消") style:UIAlertActionStyleCancel handler:nil]];
            UIViewController *root = nil;
            @try { if ([iconView respondsToSelector:@selector(window)]) root = [(UIWindow *)[iconView window] rootViewController]; } @catch (__unused NSException *e2) {}
            if (!root) {
                for (UIWindow *w in [UIApplication sharedApplication].windows) { if (w.isKeyWindow) { root = w.rootViewController; break; } }
            }
            while (root.presentedViewController) root = root.presentedViewController;
            if (root) {
                [root presentViewController:ac animated:YES completion:nil];
                CTFLog("[菜单] 弹窗已弹出（%s）", appID.UTF8String ?: "?");
            } else {
                CTFLog("[菜单] 弹窗失败：找不到宿主控制器");
            }
        } @catch (NSException *e) {
            CTFLog("[菜单] 弹窗异常: %s", e.reason.UTF8String ?: "?");
        }
    });
}

%hook SBIconView

- (NSArray *)applicationShortcutItems {
    NSArray *ctOrig = %orig;
        if (!CTAuthActivatedForMenu()) return ctOrig;   // ★ 未授权 → 不出菜单
    @try {
        NSString *appID = nil;
        if ([self respondsToSelector:@selector(applicationBundleIdentifier)]) appID = [self applicationBundleIdentifier];
        else if ([self respondsToSelector:@selector(applicationBundleIdentifierForShortcuts)]) appID = [self applicationBundleIdentifierForShortcuts];
        if (appID.length && ![appID hasPrefix:S("com.apple.springboard")]) {
            NSDictionary *prefs = CTHermesReadPrefs();
            NSDictionary *tiers = [prefs[S("appTiers")] isKindOfClass:[NSDictionary class]] ? prefs[S("appTiers")] : nil;
            NSString *cur = ctMenuTierName(tiers[appID]);
            Class itemClass = NSClassFromString(S("SBSApplicationShortcutItem"));
            if (itemClass) {
                SBSApplicationShortcutItem *item = [[itemClass alloc] init];
                item.type = S("com.qq391160.cpucore.tierpick");
                item.localizedTitle = [NSString stringWithFormat:S("温控频率：%@"), cur];
                item.bundleIdentifierToLaunch = appID;
                static NSString *sCtMenuLogged = nil;
                if (![appID isEqualToString:sCtMenuLogged]) { sCtMenuLogged = [appID copy]; CTFLog("[菜单] 长按 %s → 已加「温控频率：%s」", appID.UTF8String, cur.UTF8String); }
                if (!ctOrig) return @[item];
                return [ctOrig arrayByAddingObject:item];
            }
        }
    } @catch (__unused NSException *e) {}
    return ctOrig;
}

+ (void)activateShortcut:(id)item withBundleIdentifier:(NSString *)bundleID forIconView:(id)iconView {
    @try {
        NSString *ctType = nil;
        SBSApplicationShortcutItem *ctItem = (SBSApplicationShortcutItem *)item;
        if ([ctItem respondsToSelector:@selector(type)]) ctType = ctItem.type;
        if ([ctType isEqualToString:S("com.qq391160.cpucore.tierpick")]) {
            if (!CTAuthActivatedForMenu()) return;   // ★ 未授权 → 不处理点选
            CTFLog("[菜单] 点选「温控频率」appID=%s", bundleID.UTF8String ?: "?");
            ctMenuPresentPicker(bundleID, iconView);
            return;   // 不走 %orig（避免系统按默认逻辑去启动该 App）
        }
    } @catch (__unused NSException *e) {}
    %orig;
}

%end

%ctor {
    CTNotifyStateStart();   // ★ 0930-0207：订阅核心的"通知"数据
    // ★ 1.4.94：收到「卸载中」通知 → 停止本组件一切写入（卸载后不留任何被重写的文件）
    {
        static int ctFgByeTok = 0;
        notify_register_dispatch("com.qq391160.cpucore/uninstalling", &ctFgByeTok, dispatch_get_main_queue(), ^(int t) {
            (void)t;
            g_ctFgUninstalled = YES;
            CTHermesWipeLeftovers();   // ★ 1.4.102：本层残留自清
        });
    }
    {   // 每 60 秒把通知收到的核心状态写进主日志（诊断：核心数据到底通没通）
        dispatch_queue_t q = dispatch_queue_create("com.qq391160.cpucore.nslog", NULL);
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
        dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 20ull * NSEC_PER_SEC), 60ull * NSEC_PER_SEC, 5ull * NSEC_PER_SEC);
        dispatch_source_set_event_handler(t, ^{
            if (g_ctFgUninstalled) return;   // ★ 1.4.94：卸载后停止一切写入
            CTNotifyStateEnsure();   // ★ 0930-0207：没收到数据就重试订阅
            {   // ★ 0930-0207：持续刷新外观代传（不只启动那一刻）
                UIUserInterfaceStyle s3 = UIUserInterfaceStyleUnspecified;
                @try {
                    for (UIWindow *w3 in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
                        s3 = w3.traitCollection.userInterfaceStyle;
                        if (s3 != UIUserInterfaceStyleUnspecified) break;
                    }
                } @catch (__unused NSException *e) {}
                if (s3 != UIUserInterfaceStyleUnspecified)
                    CTStateWrite(@"CTHermesAppearance.txt", (s3 == UIUserInterfaceStyleDark) ? @"dark" : @"light");
            }
            if (gCTNSFreq >= 0 || gCTNSMode >= 0 || gCTNSTemp >= 0)
                CTFLog("[通知] 核心数据: 频率=%d00MHz 模式=%d 温度=%d°C 网速档=%d 结论=%d ｜ 版本令牌=%d 状态心跳=%d(%ds前)", gCTNSFreq, gCTNSMode, gCTNSTemp, gCTNSNet, gCTNSVerdict, gCTNSBuildToken, gCTNSStk, (int)(CFAbsoluteTimeGetCurrent() - gCTNSStkAt));
        });
        dispatch_resume(t);
    }
    @autoreleasepool {
        CTFInstallVTHooks();   // ★ T7z6：安装 VideoToolbox 解码探针（C 函数钩子）
        NSString *ownBundleID = CTHermesOwnBundleID();
        // 诊断：确认本进程是否真的载入 CTHermesForeground.dylib（判定过滤器是否命中）。
        CTLOG(S("[CTHermes] Foreground 载入 proc=%@ bundle=%@"), [[NSProcessInfo processInfo] processName], ownBundleID);
        {   // ★ 0930-0207：把"系统外观"写给浮窗（前台在 SpringBoard 里，读系统键最准 ✓）
            BOOL dark = NO;
            CFPropertyListRef sv = CFPreferencesCopyAppValue(CFSTR("AppleInterfaceStyle"), kCFPreferencesAnyApplication);
            if (sv && CFGetTypeID(sv) == CFStringGetTypeID() &&
                CFStringCompare((CFStringRef)sv, CFSTR("Dark"), 0) == kCFCompareEqualTo) dark = YES;
            if (sv) CFRelease(sv);
            CTStateWrite(@"CTHermesAppearance.txt", dark ? @"dark" : @"light");
        }
        CTFLog("======== %s 启动 proc=%s ========", kCTFTag, [NSProcessInfo processInfo].processName.UTF8String);
        {   // ★ 0930-0207：记"核心自报的可写目录"，并把兜底日志内容搬回主日志
            NSString *cp = CTStateRead(@"core-paths.txt");
            if (cp.length) CTFLog("[路径] 核心自报: %s", [cp stringByReplacingOccurrencesOfString:@"\n" withString:@" | "].UTF8String);
            CTCarryFallbackLogToMain();   // ★ 2.0.52：逐候选搬全+清源（治"旧兜底内容反复重播"）
        }
        // ★ 0930-0207：跨权限心跳 —— 收主插件经"通知"通道发来的"已注入"心跳，记一行日志（进程内只记一次）。
        //   用途：某些机器（16.5/16.6 隐根）里主插件写不进 /var/mobile/Library/Logs/，靠这条通道才看得见它有没有跑。
        {
            static int ctHbTok = 0;
            notify_register_dispatch("com.qq391160.cpucore/coreAlive", &ctHbTok, dispatch_get_main_queue(), ^(int t) {
                static BOOL ctHbOnce = NO;
                if (ctHbOnce) return;
                ctHbOnce = YES;
                CTFLog("★ [核心] 心跳已收到（通知通道）→ 主插件在本机已注入 ✓ proc=%s", [NSProcessInfo processInfo].processName.UTF8String);
            });
        }
        CTDeferToMainRunLoop(^{
            if ([ownBundleID isEqualToString:S("com.apple.springboard")]) {
                CTHermesStartSpringBoardMonitor();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            CTFLog("存活心跳(5s) proc=%s", [NSProcessInfo processInfo].processName.UTF8String);
        });
                // ★ T7x7 诊断：长按菜单挂钩能力自检（一次性写日志，方便确认钩子是否可用）
                {
                    Class ctIV = objc_getClass("SBIconView");
                    CTFLog("[菜单] 诊断: SBIconView=%s 快捷项=%d 点选回调=%d 物品类=%d", ctIV ? "有" : "无",
                           ctIV && [ctIV instancesRespondToSelector:sel_registerName("applicationShortcutItems")],
                           ctIV && [ctIV respondsToSelector:sel_registerName("activateShortcut:withBundleIdentifier:forIconView:")],
                           NSClassFromString(S("SBSApplicationShortcutItem")) != nil);
                }
                // ★ T7o：备用智能扫描（SpringBoard 侧）——挂载工具不可用时也能产出分类缓存
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                        @autoreleasepool {
                            NSDictionary *ctP7 = [NSDictionary dictionaryWithContentsOfFile:CTHermesCurrentPrefPath()];
                            if (![ctP7 isKindOfClass:[NSDictionary class]] || ![ctP7[S("powerMode")] isEqualToString:S("smart")]) {
                                CTFLog("[前台] 智能扫描(备用)：非智能模式，跳过");
                                return;
                            }
                            NSDictionary *ctCache7 = ([ctP7[S("smartClasses")] isKindOfClass:[NSDictionary class]]) ? ctP7[S("smartClasses")] : nil;
                            NSDate *ctOldTs7 = ctCache7[S("ts")];
                            if ([ctOldTs7 isKindOfClass:[NSDate class]] && (-([ctOldTs7 timeIntervalSinceNow])) < 120.0) {
                                CTFLog("[前台] 智能扫描(备用)：缓存较新，跳过");
                                return;
                            }
                            NSString *ctSum7 = nil;
                            BOOL ctWrote7 = CTHermesSmartScanToCache(&ctSum7, NULL);
                            CTFLog("[前台] 智能扫描(备用)：%s → %s", ctSum7.UTF8String ?: "?", ctWrote7 ? "已写缓存" : "未写（本进程读不到容器）");
                            if (ctWrote7) notify_post(kCTHermesSettingsChangedNotifC);
                        }
                    });
                });
                CTLOG(S("[CTHermes] SpringBoard 前台监控已启动"));
                return;
            }
            NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
            [center addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CTHermesReportCurrentApplication(); }];
            [center addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) {
                CTFLog("======== %s 启动 proc=%s ========", kCTFTag, [NSProcessInfo processInfo].processName.UTF8String);
        {   // ★ 0930-0207：记"核心自报的可写目录"，并把兜底日志内容搬回主日志
            NSString *cp = CTStateRead(@"core-paths.txt");
            if (cp.length) CTFLog("[路径] 核心自报: %s", [cp stringByReplacingOccurrencesOfString:@"\n" withString:@" | "].UTF8String);
            CTCarryFallbackLogToMain();   // ★ 2.0.52：逐候选搬全+清源（治"旧兜底内容反复重播"）
        }
        CTDeferToMainRunLoop(^{ CTHermesReportCurrentApplication(); });
            }];
            [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CTHermesClearCurrentApplication(); }];
            CTHermesReportCurrentApplication();
        });
    }
}
