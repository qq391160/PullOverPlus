// ============================================================================
// CTNotifyState.h —— ★ 0930-0200：用"通知"当数据通道（最后一个不依赖文件系统的通道）
//
//   背景（2026-10-01）：在部分机器上，温控进程（核心）**既写不进日志目录、也写不进
//   我们所有候选目录**（沙盒），但它发通知是通的（心跳就是证据）。
//   ⇒ 于是把"小数据"编码进**固定名字**的通知里：频率按 100MHz 分桶、模式 3 种、
//     温度按 1℃ 分桶、自检结论 3 种。观察方（前台/浮窗/设置页）每个进程各自订阅
//     这套固定名字（通知不支持通配符，所以必须"名字可枚举"），收到后更新本地状态：
//       · 浮窗：文件/prefs 都没有数据时 → 直接用通知来的数值显示
//       · 设置页：拿不到完整报告时 → 用结论通知显示"摘要"
//       · 前台：把每次变化写进日志（诊断）
// ============================================================================
#ifndef CT_NOTIFY_STATE_H
#define CT_NOTIFY_STATE_H

#import <Foundation/Foundation.h>
#import <notify.h>

// 高频桶：f0..f40（fN = N*100 MHz）
#define CT_NS_FREQ_N 41
// 温度桶：t0..t70（tN = N ℃）
#define CT_NS_TEMP_N 71
// 网速桶：0,1,10,100,1K,10K,100K,1M,10M（兆倍率分桶）
static inline int CTNSNetBucket(long long bps) {
    if (bps <= 0) return 0;
    long long v = bps; int b = 1;
    while (v >= 10 && b < 6) { v /= 10; b++; }
    return b;   // 1..6
}
#define CT_NS_NET_N 7
// 模式桶：m0..m2（0=原生 1=低功耗 2=高性能，与内核内部序号一致）
#define CT_NS_MODE_N 3
// 自检结论：v0=压制生效 v1=压力偏大 v2=未生效 v3=采样中断
#define CT_NS_VERDICT_N 4
// ★ 0930-0200：核心"版本令牌"与"状态心跳"（证明核心跑的是新代码、且状态节拍在跑）
#define CT_NS_BUILDTOK "build0200"
#define CT_NS_STK_N 8

static volatile int gCTNSFreq = -1;     // 收到的频率桶（-1=还没收到）
static volatile int gCTNSTemp = -1;
static volatile int gCTNSMode = -1;
static volatile int gCTNSNet = -1;
static volatile int gCTNSVerdict = -1;
static volatile double gCTNSAt = 0;      // 最近一次收到状态通知的时间

static volatile BOOL gCTNSBuildToken = NO;   // 收到核心的"版本令牌"= 核心跑的是 0200 版代码
static volatile int gCTNSStk = -1;            // 状态心跳（0..7 循环）
static volatile double gCTNSStkAt = 0;

static inline NSString *CTNSName(NSString *suffix) {
    return [NSString stringWithFormat:@"com.qq391160.cpucore/%@", suffix];
}

static inline void CTNotifyStateStartEx(BOOL force);   // 前置声明

// 若一直没收到任何数据 → 每 30 秒重试一次订阅（%ctor 早期注册在某些机器上可能失败）
static inline void CTNotifyStateEnsure(void) {
    static CFAbsoluteTime sLastTry = 0;
    if (gCTNSAt > 0) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - sLastTry < 30.0) return;
    sLastTry = now;
    CTNotifyStateStartEx(YES);
}
static inline void CTNotifyStateStart(void);   // 前置声明

// 每个进程调用一次（%ctor 里）：订阅整套固定名字
static inline void CTNotifyStateStartEx(BOOL force) {
    static BOOL started = NO;
    if (started && !force) return;
    started = YES;
    int tok = 0;
    for (int i = 0; i < CT_NS_FREQ_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"f%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSFreq = i; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
    for (int i = 0; i < CT_NS_TEMP_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"t%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSTemp = i; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
    for (int i = 0; i < CT_NS_MODE_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"m%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSMode = i; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
    for (int i = 0; i < CT_NS_NET_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"n%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSNet = i; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
    {
        NSString *n = CTNSName(@CT_NS_BUILDTOK);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSBuildToken = YES; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
    for (int i = 0; i < CT_NS_STK_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"stk%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSStk = i; gCTNSStkAt = CFAbsoluteTimeGetCurrent();
        });
    }
    for (int i = 0; i < CT_NS_VERDICT_N; i++) {
        NSString *n = CTNSName([NSString stringWithFormat:@"v%d", i]);
        notify_register_dispatch(n.UTF8String, &tok, dispatch_get_global_queue(0, 0), ^(int t) {
            gCTNSVerdict = i; gCTNSAt = CFAbsoluteTimeGetCurrent();
        });
    }
}

// 给"浮窗"用：把状态拼成和状态文件同格式的一行（没有数据返回 nil）
static inline NSString *CTNotifyStateStatusLine(void) {
    if (gCTNSFreq < 0 && gCTNSMode < 0) return nil;
    int mhz = gCTNSFreq >= 0 ? gCTNSFreq * 100 : 0;
    int mode = gCTNSMode >= 0 ? gCTNSMode : 0;
    int temp = gCTNSFreq >= 0 ? gCTNSTemp : -1;
    if (temp < 0) return [NSString stringWithFormat:@"freq=%d;mode=%d;", mhz, mode];
    return [NSString stringWithFormat:@"freq=%d;mode=%d;temp=%d;", mhz, mode, temp];
}

static inline void CTNotifyStateStart(void) { CTNotifyStateStartEx(NO); }

// ★ 2.0.39：最近一次收到"状态通知"的时刻（浮窗保鲜链用；0=还没收到过）
static inline double CTNotifyStateLastAt(void) { return gCTNSAt; }

// ============================================================================
// ★ 2.0.48：浮窗"位置总线" —— 位置改走通知通道（不依赖文件系统）
//   背景（2026-10-08 客户机 16 实证）：SpringBoard 侧浮窗组件"写不出任何文件"
//   （同版 2.0.47：用户机 [浮窗] 记录 28 条 / 客户机 0 条），但 notify 通道
//   完全可用（心跳实锤）。⇒ 位置由浮窗经通知发给 root 核心 → 核心代写文件；
//   核心再把"最后已知位置"回传 → 浮窗启动时文件读不到也能落回原位。
//   全旁路：文件路径一行未动；最坏情况 = 消息没送到 → 与本版之前行为完全一致。
// ============================================================================
#define CT_POSBUS_CH_SAVE  "com.qq391160.cpucore/winpos"      // 浮窗→核心：保存位置
#define CT_POSBUS_CH_BCAST "com.qq391160.cpucore/winpos_bc"   // 核心→浮窗：回传位置
#define CT_POSBUS_CH_REQ   "com.qq391160.cpucore/winposreq"   // 浮窗→核心：请回传
#define CT_POSBUS_CH_ACT   "com.qq391160.cpucore/winact"      // 浮窗→核心：动作转报（写日志）
#define CT_POSBUS_CH_SAVE_L  "com.qq391160.cpucore/winposL"      // ★ 2.0.49 浮窗→核心：保存横屏位
#define CT_POSBUS_CH_BCAST_L "com.qq391160.cpucore/winposL_bc"   // ★ 2.0.49 核心→浮窗：回传横屏位

#define CT_POSBUS_ACT_SAVED    1ULL   // 窗口保存完成（文件可写；总线已同步）
#define CT_POSBUS_ACT_SAVEFAIL 2ULL   // 窗口文件全不可写（总线已兜）
#define CT_POSBUS_ACT_LOADBUS  3ULL   // 启动落位来自"通知回传"
#define CT_POSBUS_ACT_SAVED_L     4ULL   // ★ 2.0.49 横屏位保存完成（总线已同步）
#define CT_POSBUS_ACT_SAVEFAIL_L  5ULL   // ★ 2.0.49 横屏位文件全不可写（总线已兜）
#define CT_POSBUS_ACT_LOADBUS_L   6ULL   // ★ 2.0.49 横屏位来自"通知回传"

// 打包：x*10 / y*10 / 锁定，0.1pt 精度（坐标恒为正）
static inline uint64_t CTPosBusPack(double x, double y, int locked) {
    if (x < 0.0) x = 0.0;
    if (y < 0.0) y = 0.0;
    uint64_t xi = (uint64_t)(x * 10.0 + 0.5);
    uint64_t yi = (uint64_t)(y * 10.0 + 0.5);
    if (xi > 0xFFFFFFFFULL) xi = 0xFFFFFFFFULL;
    if (yi > 0x7FFFFFFFULL) yi = 0x7FFFFFFFULL;
    return (xi << 32) | (yi << 1) | (locked ? 1ULL : 0ULL);
}
static inline void CTPosBusUnpack(uint64_t st, double *x, double *y, int *locked) {
    if (x) *x = (double)((st >> 32) & 0xFFFFFFFFULL) / 10.0;
    if (y) *y = (double)((st >> 1) & 0x7FFFFFFFULL) / 10.0;
    if (locked) *locked = (int)(st & 1ULL);
}
static inline void CTPosBusSend(const char *ch, uint64_t st) {
    if (!ch) return;
    int tk = 0;
    if (notify_register_check(ch, &tk) != NOTIFY_STATUS_OK) return;
    notify_set_state(tk, st);
    notify_post(ch);
    notify_cancel(tk);
}
static inline uint64_t CTPosBusGet(const char *ch) {
    if (!ch) return 0ULL;
    int tk = 0; uint64_t st = 0;
    if (notify_register_check(ch, &tk) != NOTIFY_STATUS_OK) return 0ULL;
    if (notify_get_state(tk, &st) != NOTIFY_STATUS_OK) st = 0ULL;
    notify_cancel(tk);
    return st;
}

#endif
