// ============================================================
// CTCrashLog.h —— 崩溃捕手：未捕获异常 → 写进 CPUthermalDiag.log
//   安装一次即可（任意进程内）：崩溃瞬间记录 异常名/原因/完整调用栈
//   ⚠️ 本文件内不使用 @"..." 字面量（roothide 重映射兼容）
// ============================================================
#ifndef CTCRASHLOG_H
#define CTCRASHLOG_H
#import <Foundation/Foundation.h>
#include <stdio.h>

static const char *g_ctCrashTag = "?";

static void CTCrashHandler(NSException *e) {
    @try {
        NSString *nl = [NSString stringWithUTF8String:"\n"];
        NSArray *cs = [NSThread callStackSymbols];
        NSString *frames = [cs componentsJoinedByString:nl];
        NSString *fmt = [NSString stringWithUTF8String:"[%s] [崩溃] 未捕获异常：%@ — %@\n%@\n"];
        NSString *txt = [[NSString alloc] initWithFormat:fmt, g_ctCrashTag, e.name, e.reason, frames];
        FILE *f = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
        if (f) { fputs(txt.UTF8String, f); fclose(f); }
    } @catch (__unused NSException *e2) {}
}

static inline void CTCrashLogInstall(const char *tag) {
    static int sDone = 0;
    if (sDone) return;
    sDone = 1;
    if (tag) g_ctCrashTag = tag;
    NSSetUncaughtExceptionHandler(&CTCrashHandler);
}
#endif
