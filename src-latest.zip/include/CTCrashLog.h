// ============================================================
// CTCrashLog.h —— 崩溃捕手 v2（1.4.122）：
//   ① 未捕获异常 → 写日志（主路径写不进 → 自动写兜底路径，前台组件会搬回主日志）
//   ② 信号崩溃（SIGSEGV/SIGBUS/SIGABRT…）也会留痕（旧版完全抓不到这类）
//   ⚠️ 本文件内不使用 @"..." 字面量（roothide 重映射兼容）；信号处理器只用 C 接口
// ============================================================
#ifndef CTCRASHLOG_H
#define CTCRASHLOG_H
#import <Foundation/Foundation.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>

#import <CTHermesPaths.h>   // ★ 2.0.38：日志/兜底目录走容器（隐根检测面收口）
#ifdef CT_SCHEME_ROOTHIDE
static const char *CTCrashFallbackDir(int i) {
    static char s0[512] = {0}, s1[512] = {0}, s2[512] = {0};
    if (s0[0] == 0) {
        NSString *rh = CTHermesCurrentRootHideRoot();
        if (rh.length > 0) {
            snprintf(s0, sizeof(s0), "%s/var/tmp/CTHermes/run", rh.UTF8String);
            snprintf(s1, sizeof(s1), "%s/var/mobile/Library/Caches/CTHermes", rh.UTF8String);
            snprintf(s2, sizeof(s2), "%s/Library/CTHermesState/run", rh.UTF8String);   // ★ 2.0.50：第三级也改层内
        }
        // ★ 2.0.50：容器不可得 → 不写（绝不产生 var 文件；/dev/null 下必然失败）
        if (s0[0] == 0) snprintf(s0, sizeof(s0), "%s", "/dev/null");
        if (s1[0] == 0) snprintf(s1, sizeof(s1), "%s", "/dev/null");
        if (s2[0] == 0) snprintf(s2, sizeof(s2), "%s", "/dev/null");
    }
    return (i == 0) ? s0 : ((i == 1) ? s1 : s2);
}
#endif

static const char *g_ctCrashTag = "?";
static const char *g_ctCrashDiagPath = NULL;   // ★ 2.0.38：安装时预解析（信号处理器安全）

// 依次尝试：主日志 → 兜底日志（前台组件会自动搬回主日志）
static void CTCrashWriteRaw(const char *txt) {
    if (!txt) return;
    FILE *f = fopen(CTDiagLogPathC(), "a");
    if (!f) {
#ifdef CT_SCHEME_ROOTHIDE
        const char *fbDirs[3] = {CTCrashFallbackDir(0), CTCrashFallbackDir(1), CTCrashFallbackDir(2)};
#else
        const char *fbDirs[] = {"/var/tmp/CTHermes/run", "/tmp/CTHermes", "/var/mobile/Library/Caches/CTHermes"};
#endif
        for (int i = 0; i < 3 && !f; i++) {
            mkdir(fbDirs[i], 0777);
            char fbPath[256];
            snprintf(fbPath, sizeof(fbPath), "%s/CTHermesFallback.log", fbDirs[i]);
            f = fopen(fbPath, "a");
        }
    }
    if (f) { fputs(txt, f); fclose(f); }
}

static void CTCrashHandler(NSException *e) {
    @try {
        NSString *nl = [NSString stringWithUTF8String:"\n"];
        NSArray *cs = [NSThread callStackSymbols];
        NSString *frames = [cs componentsJoinedByString:nl];
        NSString *fmt = [NSString stringWithUTF8String:"[%s] [崩溃] 未捕获异常：%@ — %@\n%@\n"];
        NSString *txt = [[NSString alloc] initWithFormat:fmt, g_ctCrashTag, e.name, e.reason, frames];
        CTCrashWriteRaw(txt.UTF8String);
    } @catch (__unused NSException *e2) {}
}

static void CTCrashSignalHandler(int sig) {
    // 只使用异步信号安全接口
    char buf[192];
    int n = snprintf(buf, sizeof(buf), "[%s] [崩溃] 信号崩溃：捕获信号 %d（11=SEGV 10=BUS 6=ABRT 4=ILL 8=FPE 5=TRAP）\n", g_ctCrashTag, sig);
    if (n > 0) {
        int fd = g_ctCrashDiagPath ? open(g_ctCrashDiagPath, O_WRONLY | O_APPEND) : -1;   // ★ 2.0.50：只写层内主日志；失败=不留痕（绝不落 var）
        if (fd >= 0) { ssize_t w = write(fd, buf, (size_t)n); (void)w; close(fd); }
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static inline void CTCrashLogInstall(const char *tag) {
    static int sDone = 0;
    if (sDone) return;
    sDone = 1;
    if (tag) g_ctCrashTag = tag;
    g_ctCrashDiagPath = CTDiagLogPathC();
    NSSetUncaughtExceptionHandler(&CTCrashHandler);
}

static inline void CTCrashLogInstallSignals(const char *tag) {
    static int sDoneS = 0;
    if (sDoneS) return;
    sDoneS = 1;
    if (tag) g_ctCrashTag = tag;
    g_ctCrashDiagPath = CTDiagLogPathC();
    int sigs[] = {SIGSEGV, SIGBUS, SIGABRT, SIGILL, SIGFPE, SIGTRAP};
    for (unsigned i = 0; i < sizeof(sigs) / sizeof(sigs[0]); i++) signal(sigs[i], CTCrashSignalHandler);
}
#endif
