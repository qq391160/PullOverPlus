// ============================================================
// CTObf.h v2 —— 字符串密码（cipher v2 · "零件钥匙"体系）
//   · 存储：hex( salt[4] || ciphertext[N] )
//   · 密钥流：ks(salt, blk) = SHA256(S || salt || blk_u32le)，S = 32B 零件钥匙
//   · 未解锁（缺零件）：解出 nil 或无效串 → 找不到任何类/方法 → 核心功能物理缺席
//   · 解锁：激活码验签通过后解出 S → CTObfUnlock(S)
// ============================================================
#ifndef CTOBF_H
#define CTOBF_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <CommonCrypto/CommonDigest.h>

static uint8_t g_ctObfKey[32];
static BOOL g_ctObfReady = NO;

static inline void CTObfUnlock(const uint8_t *key32) {
    if (!key32) return;
    memcpy(g_ctObfKey, key32, 32);
    g_ctObfReady = YES;
}
static inline BOOL CTObfReady(void) { return g_ctObfReady; }
static inline void CTObfScrub(void) { memset(g_ctObfKey, 0, sizeof(g_ctObfKey)); g_ctObfReady = NO; }

static inline int CTObfHexVal(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// 解码（未解锁时为确定性垃圾 → 返回 nil/无效串，绝不崩溃）
static inline NSString *CTObfDecode(const char *hex) {
    if (!hex) return nil;
    size_t n = strlen(hex);
    if (n < 8 || (n % 2) != 0) return nil;   // 至少 4B salt（空串场景）
    size_t blen = n / 2;
    uint8_t *raw = (uint8_t *)malloc(blen);
    if (!raw) return nil;
    for (size_t i = 0; i < blen; i++) {
        int hi = CTObfHexVal(hex[i * 2]), lo = CTObfHexVal(hex[i * 2 + 1]);
        if (hi < 0 || lo < 0) { free(raw); return nil; }
        raw[i] = (uint8_t)((hi << 4) | lo);
    }
    uint8_t salt[4];
    memcpy(salt, raw, 4);
    size_t dlen = blen - 4;
    uint8_t ks[32];
    for (size_t i = 0; i < dlen; i++) {
        size_t blk = i / 32, off = i % 32;
        if (off == 0) {
            uint8_t in[40];
            memcpy(in, g_ctObfKey, 32);      // 未解锁时 = 全 0（确定性）
            memcpy(in + 32, salt, 4);
            uint32_t b = (uint32_t)blk;
            in[36] = (uint8_t)b; in[37] = (uint8_t)(b >> 8);
            in[38] = (uint8_t)(b >> 16); in[39] = (uint8_t)(b >> 24);
            CC_SHA256(in, 40, ks);
        }
        raw[4 + i] ^= ks[off];
    }
    NSString *s = [[NSString alloc] initWithBytes:raw + 4 length:dlen encoding:NSUTF8StringEncoding];
    free(raw);
    return s;
}

static inline NSString *CTObfStr(const char *hex) { return CTObfDecode(hex); }
static inline SEL CTObfSel(const char *hex) {
    NSString *s = CTObfDecode(hex);
    return (s.length > 0) ? NSSelectorFromString(s) : (SEL)0;
}
static inline Class CTObfCls(const char *hex) {
    NSString *s = CTObfDecode(hex);
    return (s.length > 0) ? NSClassFromString(s) : Nil;
}
#endif // CTOBF_H
