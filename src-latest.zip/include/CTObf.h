// ============================================================
// CTObf.h —— 敏感字符串混淆（发布加固）
//   · 存储形式：明文每个字节 XOR 0x5A 后转成 hex 文本（源码里看不到明文、
//     编译产物里也搜不到可读字符串）
//   · 运行时解密：CTObfStr / CTObfSel / CTObfCls
//   · 明文与 hex 的对照由本地脚本生成并校验（不进包）
// ============================================================
#ifndef CTOBF_H
#define CTOBF_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static inline NSString *CTObfStr(const char *hex) {
    if (!hex) return nil;
    size_t n = strlen(hex);
    if (n == 0 || (n % 2) != 0) return nil;
    n /= 2;
    char *buf = (char *)malloc(n + 1);
    if (!buf) return nil;
    for (size_t i = 0; i < n; i++) {
        char b[3];
        b[0] = hex[i * 2];
        b[1] = hex[i * 2 + 1];
        b[2] = 0;
        unsigned int v = 0;
        if (sscanf(b, "%x", &v) != 1) { free(buf); return nil; }
        buf[i] = (char)((v ^ 0x5A) & 0xFF);
    }
    buf[n] = 0;
    NSString *s = [[NSString alloc] initWithBytes:buf length:n encoding:NSUTF8StringEncoding];
    free(buf);
    return s;
}

static inline SEL CTObfSel(const char *hex) {
    NSString *s = CTObfStr(hex);
    return (s.length > 0) ? NSSelectorFromString(s) : (SEL)0;
}

static inline Class CTObfCls(const char *hex) {
    NSString *s = CTObfStr(hex);
    return (s.length > 0) ? NSClassFromString(s) : Nil;
}

#endif // CTOBF_H
