#include <sys/stat.h>
// CTHardening.h —— 三层加固（③ 校验分散 / ④ 自校验·抗改包 / ⑤ 去可搜关键词）
// 0930-0185 新增。均为 fail-safe：检测不到异常绝不误伤正版用户。
#ifndef CT_HARDENING_H
#define CT_HARDENING_H

#import <Foundation/Foundation.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>   // ★ 2.0.52：truncate()（兜底日志搬完清源用）
#import <CTLit.h>
#import "CTActivation.h"
#import "CTHermesPaths.h"

// ============ ⑤ 去可搜关键词 ============
// 固定密钥轻量混淆：目的不是"加密"（密钥就在下面，能逆出来），
// 而是让二进制里**搜不到** activationCode / ctAuthState / CTHermesAuth.txt 这类路标，
// 把"grep 找门 → 改判断"的流水线打断（破解者只能上动态分析）。
// 注意：这些字面量在**未激活时也要能用**，所以不能用"零件钥匙"体系（②只用于功能串）。

// 常用路标（见上方说明）

// ============ ④ 自校验：抗改包 / 抗 inline hook ============
// 原理：arm64 正常函数入口是 stp/sub/pacibsp/bti 之类的**非跳转**指令。
// 若入口变成"无条件跳转"或"ldr xN,#lit; br xN"（hook 与打补丁的典型手法）→ 判定被改。
// 误判风险极低（编译器只在"整个函数体=尾调用"时才用 b，故只挑有实体逻辑的函数做探针）。

// ============ ③ 校验分散：任何组件都能自行独立校验 ============
// 不再信任"标记文件/布尔开关"（写个 1 就能骗过）。要求：激活码签名验签 + 零件块解出 + 设备码匹配。
// 三个条件缺一 → NO。这样"改一处判断/伪造一个文件"就无效了。
// ③ 独立验签（不依赖设备码实现 → ObjC++ 组件也可用）
// ★ 1.4.11：授权文件内容 = 「授权码」本身 → 统一判定：内容能独立验签才算授权（不再认裸 "1"）
// ★ 0930-0200：prefs 通道——已证明跨进程可用（设置页 / root 守护 / 温控核心 都能读写配置）
static inline NSString *CTPrefsStr(NSString *key) {
    id v = [CTHermesReadPrefs() objectForKey:key];
    if ([v isKindOfClass:[NSString class]]) return v;
    if ([v respondsToSelector:@selector(stringValue)]) return [v stringValue];
    return nil;
}
static inline double CTPrefsNum(NSString *key) {
    id v = [CTHermesReadPrefs() objectForKey:key];
    return [v respondsToSelector:@selector(doubleValue)] ? [v doubleValue] : 0.0;
}
static inline void CTPrefsSet(NSDictionary *kv) {
    if (!kv.count) return;
    NSMutableDictionary *p = [CTHermesReadPrefs() mutableCopy];
    if (!p) p = [NSMutableDictionary dictionary];
    [p addEntriesFromDictionary:kv];
    CTHermesWritePrefs(p);
}

// ★ 0930-0200：授权文件的"多路"候选——设置页写哪一份、守护/核心就读哪一份
//   根治："设置页显示已激活，但 root 守护/温控核心说未授权"（两个进程看不见同一份文件）
static inline NSArray *CTStateDirs(void);              // 定义见下方「多路兜底」一节
static inline NSArray *CTStateWriteDirs(void);         // ★ 2.0.6：写入用目录（隐根=容器内；无根=同 CTStateDirs）
static inline NSString *CTAuthTrimText(NSString *s);   // 定义见下方
static inline NSArray *CTAuthFilePaths(void) {
    NSMutableArray *a = [NSMutableArray array];
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：新家置顶（唯一写入点）；旧位仅作只读兼容/迁移来源
    NSString *__s = CTHermesRootStateDir();
    if (__s.length > 0) [a addObject:[__s stringByAppendingPathComponent:S("CTHermesAuth.txt")]];
#endif
    [a addObject:kCTPathAuthFile];
    for (NSString *d in CTStateDirs()) {
        NSString *p = [d stringByAppendingPathComponent:@"CTHermesAuth.txt"];
        if (![a containsObject:p]) [a addObject:p];
    }
    return a;
}
static inline NSString *CTAuthReadCodeAnyPath(void) {
    for (NSString *p in CTAuthFilePaths()) {
        NSString *s = CTAuthTrimText([NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL]);
        if (s.length > 0) return s;
    }
    return nil;
}
// ★ 2.0.6：授权码"可写"路径 —— 隐根干净版只写容器副本；无根版与原行为一致
static inline NSArray *CTAuthWritableFilePaths(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：只认唯一写盘（工作目录内一条）
    NSMutableArray *a = [NSMutableArray array];
    NSString *__s = CTHermesRootStateDir();
    if (__s.length > 0) [a addObject:[__s stringByAppendingPathComponent:S("CTHermesAuth.txt")]];
    if (a.count == 0) [a addObject:@"/dev/null/CTHermesAuth.nowrite"];   // 拿不到根=写必然失败（哨兵；绝不落 var）
    return a;
#else
    return CTAuthFilePaths();
#endif
}
static inline void CTAuthWriteCodeAllPaths(NSString *code) {
    if (!code.length) return;
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *p in CTAuthWritableFilePaths()) {
        NSString *dir = [p stringByDeletingLastPathComponent];
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        NSString *__line = [code stringByAppendingString:@"\n"];
        BOOL __w = [__line writeToFile:p atomically:YES encoding:NSUTF8StringEncoding error:NULL];
#ifdef CT_SCHEME_ROOTHIDE
        if (!__w) __w = [__line writeToFile:p atomically:NO encoding:NSUTF8StringEncoding error:NULL];   // ★ 2.0.110b：粘滞目录退化直写
        if (__w) { chmod(p.fileSystemRepresentation, 0666); chown(p.fileSystemRepresentation, 501, 501); }
#else
        (void)__w;
        chmod(p.fileSystemRepresentation, 0644);
#endif
    }
}
static inline void CTAuthRemoveAllPaths(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *p in CTAuthFilePaths()) [fm removeItemAtPath:p error:NULL];
}

static inline BOOL CTAuthFileAuthorized(void) {
    NSString *tok = CTAuthReadCodeAnyPath();   // ★ 0930-0200：多路读（原路径 + 各候选目录）
    if (tok.length == 0) return NO;
#ifdef CT_NO_IOKIT
    // ObjC++ 组件（前台 / 浮窗）不引入 IOKit → 设备码取主插件发布的值
    NSString *dv = [CTHermesReadPrefs() objectForKey:kCTKeyDevCode];
#else
    NSString *dv = CTAuthDeviceCode();
#endif
    if (![dv isKindOfClass:[NSString class]] || dv.length == 0) return NO;
    return CTAuthVerifyCode(dv, tok) ? YES : NO;
}

static inline BOOL CTAuthVerifySignature(NSString *devCode, NSString *code) {
    if (devCode.length == 0 || code.length == 0) return NO;
    return CTAuthVerifyCode(devCode, code) ? YES : NO;
}

static inline BOOL CTAuthVerifyCodeFull(NSString *deviceCode, NSString *code, uint8_t outS[32]) {
    if (!deviceCode.length || !code.length) return NO;
    if (!CTAuthVerifyCode(deviceCode, code)) return NO;
    uint8_t s[32];
    memset(s, 0, sizeof(s));
    if (!CTAuthExtractParts(deviceCode, code, s)) return NO;
    if (outS) memcpy(outS, s, 32);
    memset(s, 0, sizeof(s));
    return YES;
}

// ============================================================================
// ★ 0930-0195：跨权限授权票据 + 心跳（兼容"温控进程读不到 /var/mobile/…"的机器）
//   背景：某些机器（如 16.5/16.6 的隐根环境）里，注入温控进程的插件读不到
//         /var/mobile/Library/…（进程权限/隐根视图不同）→ 授权判定退化成"未激活"
//         → 核心全程待命（日志里一行都不出、浮窗显示 —，但不崩不报错）。
//   方案：root 守护进程把授权码另存一份到"任何进程都读得到"的路径；主插件优先读它。
//         票据内容 = 我们私钥签发的授权码 ⇒ 没有授权码的人伪造不了，安全性不降。
// ============================================================================
#include <notify.h>
#include <sys/stat.h>
#include <unistd.h>

static inline NSString *CTAuthTicketDir(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：票据收口到工作目录（同一条根）
    NSString *__s = CTHermesRootStateDir();
    return __s.length ? __s : @"/dev/null";   // 容器不可得 → 不创建任何目录（绝不落 var）
#endif
    return @"/var/tmp/CTHermes";
}

static inline NSArray<NSString *> *CTAuthTicketPaths(void) {
#ifdef CT_SCHEME_ROOTHIDE
    NSMutableArray *a = [NSMutableArray array];
    NSString *__s = CTHermesRootStateDir();
    if (__s.length > 0) {
        [a addObject:[__s stringByAppendingPathComponent:S("auth.ticket")]];   // ★ 2.0.110：唯一写入点
    } else {
        [a addObject:@"/dev/null/CTHermesAuth.nowrite"];   // 哨兵（绝不落 var）
    }
    NSString *__rh = CTHermesResolvedRootOnce();
    if (__rh.length > 0) {
        [a addObject:[__rh stringByAppendingPathComponent:S("var/tmp/CTHermes/auth.ticket")]];   // 旧位（只读兼容/迁移）
    }
    [a addObject:@"/var/tmp/CTHermes/auth.ticket"];
    [a addObject:@"/private/var/tmp/CTHermes/auth.ticket"];
    return a;
#else
    return @[ @"/var/tmp/CTHermes/auth.ticket",
              @"/private/var/tmp/CTHermes/auth.ticket" ];
#endif
}

static inline NSString *CTAuthTrimText(NSString *s) {
    if (![s isKindOfClass:[NSString class]]) return nil;
    return [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

static inline NSString *CTAuthTicketRead(void) {
    for (NSString *p in CTAuthTicketPaths()) {
        NSString *s = CTAuthTrimText([NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL]);
        if (s.length > 0) return s;
    }
    return nil;
}

static inline BOOL CTAuthTicketWrite(NSString *code) {
    if (![code isKindOfClass:[NSString class]] || code.length == 0) return NO;
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm createDirectoryAtPath:CTAuthTicketDir() withIntermediateDirectories:YES
                   attributes:@{NSFilePosixPermissions: @(0755)} error:NULL];
    chmod(CTAuthTicketDir().fileSystemRepresentation, 0755);
    NSData *d = [code dataUsingEncoding:NSUTF8StringEncoding];
    NSString *__tp = CTAuthTicketPaths().firstObject;
    BOOL ok = [d writeToFile:__tp options:NSDataWritingAtomic error:NULL];
#ifdef CT_SCHEME_ROOTHIDE
    if (!ok) ok = [d writeToFile:__tp options:0 error:NULL];   // ★ 2.0.110b：粘滞目录退化直写
    if (ok) { chmod(__tp.fileSystemRepresentation, 0666); chown(__tp.fileSystemRepresentation, 501, 501); }
#else
    chmod(__tp.fileSystemRepresentation, 0644);
#endif
    return ok;
}

// 授权码的"最佳来源"：授权文件内容（= 授权码本身）优先，其次配置里的激活码
static inline NSString *CTAuthBestCodeText(void) {
    NSString *s = CTAuthReadCodeAnyPath();   // ★ 0930-0200：多路读
    if (s.length > 0) return s;
    return nil;
}

// 心跳：经"通知"通道上报（沙盒/权限都拦不住），由移动侧组件记进日志 → 诊断用
static inline void CTAuthHeartbeatPost(void) {
    notify_post("com.qq391160.cpucore/coreAlive");
}

// ============================================================================
// ★ 0930-0196：核心 ↔ 界面的"双通道"数据桥
//   背景：温控进程（_thermalmonitord）常常**没有权限进 /var/mobile/Library/**（那是 mobile 700），
//         ⇒ 它写的状态文件/自检报告界面看不到、界面写的自检请求它也读不到
//         ⇒ 现象：核心照常在压温控，但"浮窗 / 一键质检"全是空的。
//   方案：这些文件**同时**写/读一份到 /var/tmp/CTHermes/run/（真实路径、任何进程都能进，postinst 建 1777）。
//         写入方：能写原路径就写原路径，写不了就落共享目录；读取方：两边都看，取"较新的那份"。
// ============================================================================
#include <stdio.h>
#include <string.h>

static inline const char *CTSharedRunDirC(void) {
#ifdef CT_SCHEME_ROOTHIDE
    static char sCTSRun[512] = {0};
    if (sCTSRun[0] == 0) {
        // ★ 2.0.110：共享目录 = 工作目录内（单根）
        NSString *__s = CTHermesRootRunDir();
        if (__s.length > 0) snprintf(sCTSRun, sizeof(sCTSRun), "%s", __s.UTF8String);
        if (sCTSRun[0] == 0) return "/dev/null";   // 容器不可得 → 不写（绝不产生 var 文件）
    }
    return sCTSRun;
#else
    return "/var/tmp/CTHermes/run";
#endif
}

// ★ 2.0.38：隐根版兜底缓存目录（不落真 /var/mobile/Library/Caches；容器不可得时退回共享 run 目录）
static inline const char *CTCacheDirC(void) {
#ifdef CT_SCHEME_ROOTHIDE
    static char sCTCacheC[512] = {0};
    if (sCTCacheC[0] == 0) {
        // ★ 2.0.110：缓存也收口到工作目录（单根）
        NSString *__s = CTHermesRootRunDir();
        if (__s.length > 0) snprintf(sCTCacheC, sizeof(sCTCacheC), "%s", __s.UTF8String);
        if (sCTCacheC[0] == 0) return CTSharedRunDirC();
    }
    return sCTCacheC;
#else
    return "/var/mobile/Library/Caches/CTHermes";
#endif
}

// ★ 0930-0200：多路兜底——核心/界面各自能访问的目录可能不同（沙盒），所以：
//   写：往"能写的每一个目录"都写一份；读：把每个目录都读一遍，取最新非空的那份。
static inline NSArray *CTStateDirs(void) {
    static NSArray *dirs = nil;
    if (!dirs) {
#ifdef CT_SCHEME_ROOTHIDE
        // ★ 2.0.110：首选项=工作目录内的 run/logs（单根）；旧位置只读兼容（迁移后为空气）
        NSMutableArray *m = [NSMutableArray array];
        NSString *__s = CTHermesRootStateDir();
        if (__s.length > 0) {
            [m addObject:[__s stringByAppendingPathComponent:S("run")]];
            [m addObject:[__s stringByAppendingPathComponent:S("logs")]];
        }
        NSString *rh = CTHermesResolvedRootOnce();
        if (rh.length > 0) {
            [m addObject:[rh stringByAppendingPathComponent:S("var/mobile/Library/Logs")]];
            [m addObject:[rh stringByAppendingPathComponent:S("var/tmp/CTHermes/run")]];
            [m addObject:[rh stringByAppendingPathComponent:S("tmp/CTHermes")]];
            [m addObject:[rh stringByAppendingPathComponent:S("var/mobile/Library/Caches/CTHermes")]];
        }
        [m addObjectsFromArray:@[@"/var/mobile/Library/Logs",
                                 @"/var/tmp/CTHermes/run",
                                 @"/tmp/CTHermes",
                                 @"/var/mobile/Library/Caches/CTHermes"]];
        CTHermesConsolidateLegacyOnce();
        dirs = m;
#else
        dirs = @[@"/var/mobile/Library/Logs",
                 @"/var/tmp/CTHermes/run",
                 @"/tmp/CTHermes",
                 @"/var/mobile/Library/Caches/CTHermes"];
#endif
    }
    return dirs;
}

// ★ 2.0.6：写入用目录 —— 隐根干净版只写容器的对应目录（读仍用全候选，兼容迁移）
static inline NSArray *CTStateWriteDirs(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：唯一写入点 = 工作目录内 run（单根；不再按进程视角分叉）
    static NSArray *wdirs = nil;
    if (!wdirs) {
        NSMutableArray *m = [NSMutableArray array];
        NSString *wd = CTHermesRootRunDir();
        if (wd.length > 0) {
            NSFileManager *fm = [NSFileManager defaultManager];
            NSString *__s = CTHermesRootStateDir();
            if (__s.length > 0) {
                [fm createDirectoryAtPath:__s withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
                chmod(__s.fileSystemRepresentation, 01777);   // ★ 2.0.110：工作目录 01777
            }
            [fm createDirectoryAtPath:wd withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
            chmod(wd.fileSystemRepresentation, 01777);
            [m addObject:wd];
        }
        if (m.count == 0) [m addObject:S("/dev/null")];   // 容器不可得 → 不写（绝不产生 var 文件）
        wdirs = m;
    }
    return wdirs;
#else
    return CTStateDirs();
#endif
}

// ★ 2.0.52：兜底日志"搬全清源"——逐候选读取：每条非空的旧内容都搬进主日志，搬完立即清空该文件。
//   治"同一段旧内容被无限重播"（此前前台侧搬运器只搬不清源；核心侧清的又是另一份文件）。
static inline void CTCarryFallbackLogToMain(void) {
    NSMutableArray *__fbd = [NSMutableArray array];
    for (NSString *d in CTStateDirs()) if (d.length && ![__fbd containsObject:d]) [__fbd addObject:d];
    {   NSString *s1 = [NSString stringWithUTF8String:CTSharedRunDirC()];
        if (s1.length && ![__fbd containsObject:s1]) [__fbd addObject:s1]; }
    {   NSString *s2 = [NSString stringWithUTF8String:CTCacheDirC()];
        if (s2.length && ![__fbd containsObject:s2]) [__fbd addObject:s2]; }
    for (NSString *d in __fbd) {
        NSString *p = [d stringByAppendingPathComponent:S("CTHermesFallback.log")];
        NSString *s = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL];
        if (!s.length) continue;
        BOOL carried = NO;
        FILE *mf = fopen(CTDiagLogPathC(), "a");
        if (mf) { fprintf(mf, "\n---- [兜底日志搬运] ----\n%s\n---- [搬运结束] ----\n", s.UTF8String); fclose(mf); carried = YES; }
        if (carried) truncate(p.fileSystemRepresentation, 0);   // ★ 搬成功才清源（一次搬完，不再重播）
    }
}

static inline BOOL CTStateWrite(NSString *name, NSString *content) {
    if (!name.length || !content.length) return NO;
    if (CTHermesUninstalling()) return YES;   // ★ 1.4.102：卸载中 → 全组件停写状态文件（防"复活"）
    NSData *d = [content dataUsingEncoding:NSUTF8StringEncoding];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL any = NO;
    for (NSString *dir in CTStateWriteDirs()) {
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        NSString *p = [dir stringByAppendingPathComponent:name];
        if ([d writeToFile:p options:NSDataWritingAtomic error:NULL]) {
            chmod(p.fileSystemRepresentation, 0644);
            any = YES;
        }
    }
    return any;
}

// ★ 2.0.39：按文件名读（同 CTStateRead），并带回"所选文件"的修改时刻（0=没读到/无时间戳）——浮窗保鲜链用
static inline NSString *CTStateReadTimed(NSString *name, double *outAt) {
    if (outAt) *outAt = 0.0;
    NSString *best = nil; NSDate *bestT = nil;
    for (NSString *dir in CTStateDirs()) {
        NSString *p = [dir stringByAppendingPathComponent:name];
        NSString *s = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL];
        s = CTAuthTrimText(s);
        if (!s.length) continue;
        NSDate *t = [[[NSFileManager defaultManager] attributesOfItemAtPath:p error:NULL] fileModificationDate];
        if (!best || (t && bestT && [t compare:bestT] == NSOrderedDescending)) { best = s; bestT = t; }
    }
    if (best && outAt) *outAt = bestT ? [bestT timeIntervalSinceReferenceDate] : 0.0;
    return best;
}

// 按文件名读：所有目录里取"非空且最新"的那份
static inline NSString *CTStateRead(NSString *name) { return CTStateReadTimed(name, NULL); }

// 按文件名：任一路径存在/删除
static inline BOOL CTStateExists(NSString *name) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *dir in CTStateDirs())
        if ([fm fileExistsAtPath:[dir stringByAppendingPathComponent:name]]) return YES;
    return NO;
}
static inline void CTStateRemove(NSString *name) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *dir in CTStateDirs())
        [fm removeItemAtPath:[dir stringByAppendingPathComponent:name] error:NULL];
}

// ★ 2.0.46：浮窗位置"多路"套件——位置文件原来只认一条路（CTDiagLogDir），16 上该路一旦岔掉
//   （写入/读取落在不同层或不同目录）→ 注销后读不到 → 回默认位。现在：读=全部候选（状态目录 +
//   主日志目录 + 所有 .jbroot-* 层）取最新；写=统一写目录+主日志目录双落盘（原子→非原子）；清=全候选。
static inline NSArray<NSString *> *CTAllLayerStateDirs(void) {
    // ★ 2.0.110：退役——不再跨层扫描（单根时代；旧层残留由迁移引擎一次性清理）
    return @[];
}
static inline NSArray<NSString *> *CTFloatReadDirs(void) {
    NSMutableArray *a = [NSMutableArray array];
    for (NSString *d in CTStateDirs()) if (d.length && ![a containsObject:d]) [a addObject:d];
    NSString *lg = CTDiagLogDir();
    if (lg.length && ![a containsObject:lg]) [a addObject:lg];
    for (NSString *d in CTAllLayerStateDirs()) if (d.length && ![a containsObject:d]) [a addObject:d];
    return a;
}
static inline NSArray<NSString *> *CTFloatWriteDirs(void) {
    NSMutableArray *a = [NSMutableArray array];
    for (NSString *d in CTStateWriteDirs()) if (d.length && ![a containsObject:d]) [a addObject:d];
    NSString *lg = CTDiagLogDir();
    if (lg.length && ![a containsObject:lg]) [a addObject:lg];
    return a;
}
static inline NSString *CTFloatReadNewest(NSString *name, double *outAt) {
    if (outAt) *outAt = 0.0;
    NSString *best = nil; NSDate *bestT = nil;
    NSArray *names = @[name, [name stringByAppendingString:S(".own")]];   // ★ 2.0.47：标准名 + "自己名下"备用名
    for (NSString *dir in CTFloatReadDirs()) {
        for (NSString *nm in names) {
            NSString *p = [dir stringByAppendingPathComponent:nm];
            NSString *s = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL];
            s = CTAuthTrimText(s);
            if (!s.length || [s rangeOfString:S(",")].location == NSNotFound) continue;
            NSDate *t = [[[NSFileManager defaultManager] attributesOfItemAtPath:p error:NULL] fileModificationDate];
            if (!best || (t && bestT && [t compare:bestT] == NSOrderedDescending)) { best = s; bestT = t; }
        }
    }
    if (best && outAt) *outAt = bestT ? [bestT timeIntervalSinceReferenceDate] : 0.0;
    return best;
}
static inline BOOL CTFloatWriteAll(NSString *name, NSString *s) {
    if (!name.length || !s.length) return NO;
    if (CTHermesUninstalling()) return YES;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *altName = [name stringByAppendingString:S(".own")];   // ★ 2.0.47：备用名（自己建=自己拥有）
    BOOL any = NO;
    for (NSString *dir in CTFloatWriteDirs()) {
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        NSString *p = [dir stringByAppendingPathComponent:name];
        BOOL ok = [s writeToFile:p atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        if (!ok) ok = [s writeToFile:p atomically:NO encoding:NSUTF8StringEncoding error:NULL];
        if (ok) { chmod(p.fileSystemRepresentation, 0666); any = YES; continue; }
        // ★ 2.0.47：标准名写不进（典型：安装时 root 预建空壳 + 粘滞目录，mobile 改不了也删不掉）
        //   → 改写"自己名下的新文件"（谁建谁拥有，原子替换也放行）；读取端两处都扫、取最新
        NSString *pa = [dir stringByAppendingPathComponent:altName];
        ok = [s writeToFile:pa atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        if (!ok) ok = [s writeToFile:pa atomically:NO encoding:NSUTF8StringEncoding error:NULL];
        if (ok) { chmod(pa.fileSystemRepresentation, 0666); any = YES; }
    }
    return any;
}
static inline void CTFloatRemoveAll(NSString *name) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *names = @[name, [name stringByAppendingString:S(".own")]];   // ★ 2.0.47：两处都清
    for (NSString *dir in CTFloatReadDirs())
        for (NSString *nm in names)
            [fm removeItemAtPath:[dir stringByAppendingPathComponent:nm] error:NULL];
}

// 判断"这个具体文件能不能写进去"（供核心自报路径用）
static inline BOOL CTFileWritable(const char *path) {
    if (!path || !path[0]) return NO;
    FILE *t = fopen(path, "a");
    if (!t) return NO;
    fclose(t);
    return YES;
}

// 挑选"可写"的落地路径：原路径能写就用它，否则退回共享目录（name 传文件名）
static inline const char *CTWritableOrSharedPath(const char *primary, const char *name) {
    static char buf[256];
    buf[0] = '\0';
    if (primary && primary[0]) {
        FILE *t = fopen(primary, "a");          // 用 "a" 试探，不会清空已有内容
        if (t) { fclose(t); strncpy(buf, primary, sizeof(buf) - 1); buf[sizeof(buf) - 1] = '\0'; return buf; }
    }
    snprintf(buf, sizeof(buf), "%s/%s", CTSharedRunDirC(), name ? name : "state.txt");
    return buf;
}

// 把一个"原路径"的内容镜像到共享目录（供写原路径成功时也补一份）
static inline void CTSharedMirrorFile(const char *primary) {
    if (!primary || !primary[0]) return;
    NSString *srcP = [NSString stringWithUTF8String:primary];
    NSData *d = [NSData dataWithContentsOfFile:srcP];
    if (!d.length) return;
    NSString *dst = [NSString stringWithFormat:@"%s/%@", CTSharedRunDirC(), [srcP lastPathComponent]];
    [d writeToFile:dst options:NSDataWritingAtomic error:NULL];
}

// 读：两边都看，返回"非空且较新"的那份
static inline NSString *CTSharedReadNewest(NSString *primary) {
    NSString *shared = [NSString stringWithFormat:@"%s/%@", CTSharedRunDirC(), [primary lastPathComponent]];
    NSString *a = [NSString stringWithContentsOfFile:primary encoding:NSUTF8StringEncoding error:NULL];
    NSString *b = [NSString stringWithContentsOfFile:shared encoding:NSUTF8StringEncoding error:NULL];
    a = CTAuthTrimText(a); b = CTAuthTrimText(b);
    if (!a.length) return b;
    if (!b.length) return a;
    NSDictionary *fa = [[NSFileManager defaultManager] attributesOfItemAtPath:primary error:NULL];
    NSDictionary *fb = [[NSFileManager defaultManager] attributesOfItemAtPath:shared error:NULL];
    NSDate *ta = fa[NSFileModificationDate], *tb = fb[NSFileModificationDate];
    if (ta && tb && [tb compare:ta] == NSOrderedDescending) return b;
    return a;
}

// 某文件在"原路径或共享目录"是否存在（任一处有即算有）
static inline BOOL CTSharedExistsEither(NSString *primary) {
    NSString *shared = [NSString stringWithFormat:@"%s/%@", CTSharedRunDirC(), [primary lastPathComponent]];
    NSFileManager *fm = [NSFileManager defaultManager];
    return [fm fileExistsAtPath:primary] || [fm fileExistsAtPath:shared];
}

// 删掉两处（自检请求用过就删）
static inline void CTSharedRemoveEither(NSString *primary) {
    NSString *shared = [NSString stringWithFormat:@"%s/%@", CTSharedRunDirC(), [primary lastPathComponent]];
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm removeItemAtPath:primary error:NULL];
    [fm removeItemAtPath:shared error:NULL];
}


// ============================================================================
// ★ 2.0.110：一次性迁移引擎（守护启动调用）——单根收敛的"搬家 + 大扫除"
//   ① 导入：旧配置/授权码/票据/浮窗位置 → 工作目录 S
//   ② 清理：只认自家白名单名字、只删文件、目录空了才删、sameFile 守卫、绝不全局 find
//   ③ 标记：S/migrate.ok（只跑一次）；全程 @try；报告=S/迁移报告.txt（摘要进主日志）
// ============================================================================
static inline BOOL CTHermesNameIsOurs(NSString *name) {
    if (!name.length) return NO;
    NSArray *pfx = @[@"CTHermes", @"CPUthermal", @"cpusentry", @"core-paths", @"com.qq391160."];
    for (NSString *p in pfx) { if ([name hasPrefix:p]) return YES; }
    return NO;
}

static inline NSString *CTHermesMigrateOnce(void) {
#ifndef CT_SCHEME_ROOTHIDE
    return nil;   // 无根：本版不动
#else
    @try {
        if (CTHermesUninstalling()) return @"迁移跳过：卸载中";
        NSString *S = CTHermesRootStateDir();
        if (!S.length) return @"迁移跳过：容器不可得";
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *mark = [S stringByAppendingPathComponent:S("migrate.ok")];
        if ([fm fileExistsAtPath:mark]) return @"迁移已完成过（migrate.ok 在）";

        NSMutableString *rep = [NSMutableString string];
        [rep appendFormat:@"==== CPU智能温控 · 单根迁移报告 ====\n时间：%@\n", [NSDate date]];
        NSString *logsS = [S stringByAppendingPathComponent:S("logs")];
        NSString *runS = [S stringByAppendingPathComponent:S("run")];
        [fm createDirectoryAtPath:logsS withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        [fm createDirectoryAtPath:runS withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        chmod(logsS.fileSystemRepresentation, 01777);
        chmod(runS.fileSystemRepresentation, 01777);

        // —— ① 导入：配置（★ 2.0.111：合并——旧键全补、S 值优先；任何一方残缺都不丢）
        {
            NSString *dst = [S stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")];
            NSDictionary *cur = [NSDictionary dictionaryWithContentsOfFile:dst];
            NSMutableDictionary *merged = [NSMutableDictionary dictionary];
            NSMutableDictionary *kt = [NSMutableDictionary dictionary];
            for (NSString *p in CTHermesLegacyPrefPaths()) {
                NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p];
                if (![d isKindOfClass:[NSDictionary class]] || !d.count) continue;
                NSDate *t2 = [[fm attributesOfItemAtPath:p error:NULL] fileModificationDate] ?: [NSDate distantPast];
                for (id k in d) { NSDate *old = kt[k]; if (!old || [t2 compare:old] == NSOrderedDescending) { kt[k] = t2; merged[k] = d[k]; } }
            }
            NSUInteger oldN = merged.count;
            if ([cur isKindOfClass:[NSDictionary class]]) { for (id k in cur) merged[k] = cur[k]; }
            if (merged.count && merged.count > cur.count) {
                BOOL __w = [merged writeToFile:dst atomically:YES];
                if (!__w) __w = [merged writeToFile:dst atomically:NO];
                if (__w) { chmod(dst.fileSystemRepresentation, 0666); chown(dst.fileSystemRepresentation, 501, 501); }
                [rep appendFormat:@"[导入] 配置 ← 合并（旧%lu键 + S%lu键 → %lu键）\n", (unsigned long)oldN, (unsigned long)cur.count, (unsigned long)merged.count];
            } else {
                [rep appendString:@"[导入] 配置：已合并（无新增）\n"];
            }
        }
        // —— ② 导入：授权码（旧位取最新非空 → S/CTHermesAuth.txt；S 已有则不覆盖）
        {
            NSString *dst = [S stringByAppendingPathComponent:S("CTHermesAuth.txt")];
            BOOL haveS = CTAuthTrimText([NSString stringWithContentsOfFile:dst encoding:NSUTF8StringEncoding error:NULL]).length > 0;
            if (!haveS) {
                NSString *best = nil; NSDate *bestT = nil;
                for (NSString *p in CTAuthFilePaths()) {
                    if ([p isEqualToString:dst]) continue;
                    NSString *s = CTAuthTrimText([NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL]);
                    if (!s.length) continue;
                    NSDate *t = [[fm attributesOfItemAtPath:p error:NULL] fileModificationDate] ?: [NSDate distantPast];
                    if (!best || (bestT && [t compare:bestT] == NSOrderedDescending)) { best = s; bestT = t; }
                }
                if (best.length) {
                    NSString *__line = [best stringByAppendingString:@"\n"];
                    BOOL __w = [__line writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:NULL];
                    if (!__w) __w = [__line writeToFile:dst atomically:NO encoding:NSUTF8StringEncoding error:NULL];   // ★ 2.0.110b
                    if (__w) { chmod(dst.fileSystemRepresentation, 0666); chown(dst.fileSystemRepresentation, 501, 501); }
                    [rep appendString:@"[导入] 授权码 ← 旧位\n"];
                } else [rep appendString:@"[导入] 授权码：无旧码\n"];
            } else [rep appendString:@"[导入] 授权码：S 已有\n"];
        }

        // —— ③ 导入：票据（旧位 → S/auth.ticket）
        {
            NSString *dst = [S stringByAppendingPathComponent:S("auth.ticket")];
            if (![fm fileExistsAtPath:dst]) {
                for (NSString *p in CTAuthTicketPaths()) {
                    if ([p isEqualToString:dst]) continue;
                    NSString *s = CTAuthTrimText([NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL]);
                    if (s.length) {
                        NSString *__line2 = [s stringByAppendingString:@"\n"];
                        BOOL __w2 = [__line2 writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:NULL];
                        if (!__w2) __w2 = [__line2 writeToFile:dst atomically:NO encoding:NSUTF8StringEncoding error:NULL];   // ★ 2.0.110b
                        if (__w2) { chmod(dst.fileSystemRepresentation, 0666); chown(dst.fileSystemRepresentation, 501, 501); }
                        [rep appendString:@"[导入] 票据 ← 旧位\n"];
                        break;
                    }
                }
            } else [rep appendString:@"[导入] 票据：S 已有\n"];
        }

        // —— ④ 导入：浮窗位置（两个档案）
        {
            for (NSString *nm in @[@"CTHermesFloat.pos", @"CTHermesFloat.land"]) {
                NSString *v = CTFloatReadNewest(nm, NULL);
                if (v.length) { CTFloatWriteAll(nm, v); [rep appendFormat:@"[导入] %@ ← 最新位\n", nm]; }
            }
        }

        // —— ⑤ 兜底日志搬运（并入主日志后清源）
        CTCarryFallbackLogToMain();
        [rep appendString:@"[清理] 兜底日志已搬运并清源\n"];

        // —— ⑥ 清理：旧位置（四道锁）
        NSInteger del = 0, skip = 0;
        NSString *rh = CTHermesResolvedRootOnce();
        NSString *prefName = S("com.qq391160.cpucore.plist");
        NSString *prefS = [S stringByAppendingPathComponent:prefName];
        BOOL sPrefOK = (([NSDictionary dictionaryWithContentsOfFile:prefS] ?: @{}).count > 0);
        BOOL sAuthOK = CTAuthTrimText([NSString stringWithContentsOfFile:[S stringByAppendingPathComponent:S("CTHermesAuth.txt")] encoding:NSUTF8StringEncoding error:NULL]).length > 0;
        NSMutableArray *locs = [NSMutableArray array];
        {
            NSArray *bases = @[@"/var/mobile/Containers/Shared/AppGroup",
                               @"/var/containers/Bundle/Application",
                               @"/var/containers/Shared/SystemGroup",
                               @"/var/mobile/Library",
                               @"/var/mobile/Containers/Data/Application"];
            NSArray *subs = @[@"var/mobile/Library/Logs", @"var/tmp/CTHermes/run", @"tmp/CTHermes",
                              @"var/mobile/Library/Caches/CTHermes", @"Library/CTHermesState/logs",
                              @"Library/CTHermesState/run", @"Library/CTKeptLogs"];
            for (NSString *b in bases) {
                for (NSString *e in ([fm contentsOfDirectoryAtPath:b error:NULL] ?: @[])) {
                    if (![e hasPrefix:S(".jbroot-")]) continue;
                    NSString *L = [b stringByAppendingPathComponent:e];
                    if (rh.length && [L isEqualToString:rh]) continue;   // 当前层单独处理
                    for (NSString *sub in subs) [locs addObject:[L stringByAppendingPathComponent:sub]];
                    [locs addObject:[[L stringByAppendingPathComponent:S("var/mobile/Library/Preferences")] stringByAppendingPathComponent:prefName]];
                }
            }
            if (rh.length) {   // 当前层内的旧位（搬完后清）
                for (NSString *sub in @[@"var/mobile/Library/Logs", @"var/tmp/CTHermes/run", @"tmp/CTHermes", @"var/mobile/Library/Caches/CTHermes"]) {
                    [locs addObject:[rh stringByAppendingPathComponent:sub]];
                }
                [locs addObject:[[rh stringByAppendingPathComponent:S("var/mobile/Library/Preferences")] stringByAppendingPathComponent:prefName]];
            }
            [locs addObjectsFromArray:@[@"/var/mobile/Library/Logs",
                                        @"/var/tmp/CTHermes/run",
                                        @"/tmp/CTHermes",
                                        @"/var/mobile/Library/Caches/CTHermes",
                                        @"/var/tmp/CPUthermal",
                                        @"/var/mobile/Library/Preferences/com.qq391160.cpucore.plist",
                                        @"/var/jb/Library/Preferences/com.qq391160.cpucore.plist",
                                        @"/var/jb/var/mobile/Library/Preferences/com.qq391160.cpucore.plist"]];
        }
        for (NSString *loc in locs) {
            BOOL isDir = NO;
            if (![fm fileExistsAtPath:loc isDirectory:&isDir]) continue;
            NSMutableArray *files = [NSMutableArray array];
            if (isDir) {
                for (NSString *n in ([fm contentsOfDirectoryAtPath:loc error:NULL] ?: @[])) {
                    if (!CTHermesNameIsOurs(n)) continue;
                    [files addObject:[loc stringByAppendingPathComponent:n]];
                }
            } else if (CTHermesNameIsOurs(loc.lastPathComponent)) {
                [files addObject:loc];
            }
            for (NSString *p in files) {
                NSString *n = p.lastPathComponent;
                // 安全护栏：配置/授权旧件——只有 S 里已有有效件才准删
                if ([n isEqualToString:prefName] && !sPrefOK) { skip++; continue; }
                if (([n isEqualToString:S("CTHermesAuth.txt")] || [n isEqualToString:S("CPUthermalAuth.txt")]) && !sAuthOK) { skip++; continue; }
                // sameFile 守卫：与 S 内同名文件为同一物理文件 → 跳过
                if (CTHermesSameFile(p, [logsS stringByAppendingPathComponent:n])
                    || CTHermesSameFile(p, [runS stringByAppendingPathComponent:n])
                    || CTHermesSameFile(p, [S stringByAppendingPathComponent:n])) { skip++; continue; }
                NSDictionary *at = [fm attributesOfItemAtPath:p error:NULL];
                if (![at[NSFileType] isEqual:NSFileTypeRegular]) { skip++; continue; }   // 非普通文件绝不碰
                if ([fm removeItemAtPath:p error:NULL]) {
                    del++;
                    if (del <= 60) [rep appendFormat:@"[清理] %@\n", p];
                }
            }
        }
        for (NSString *d in @[@"/var/tmp/CTHermes/run", @"/var/tmp/CTHermes", @"/tmp/CTHermes", @"/var/tmp/CPUthermal"]) {
            rmdir(d.fileSystemRepresentation);   // 只删空目录；失败忽略
        }
        [rep appendFormat:@"[清理] 共删 %ld 个文件（跳过 %ld 个：同文件/非普通/保护）\n", (long)del, (long)skip];

        // —— ⑦ 写标记 + 报告
        NSString *okc = [NSString stringWithFormat:@"2.0.110 %@\n", [NSDate date]];
        [okc writeToFile:mark atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        chmod(mark.fileSystemRepresentation, 0644);
        NSString *repPath = [S stringByAppendingPathComponent:S("迁移报告.txt")];
        FILE *rf = fopen(repPath.fileSystemRepresentation, "a");
        if (rf) { fputs(rep.UTF8String, rf); fclose(rf); chmod(repPath.fileSystemRepresentation, 0644); }
        {
            FILE *mf = fopen(CTDiagLogPathC(), "a");
            if (mf) { fprintf(mf, "\n---- [迁移报告] ----\n%s---- [迁移结束] ----\n", rep.UTF8String); fclose(mf); }
        }
        return [NSString stringWithFormat:S("迁移完成：删 %ld 跳过 %ld；报告=迁移报告.txt"), (long)del, (long)skip];
    } @catch (__unused NSException *e) {
        return @"迁移异常（已捕获，不影响功能）";
    }
#endif
}

#endif
