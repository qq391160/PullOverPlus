// ============================================================================
// CTHermes 授权模块（CTAuth）  ★ 2026-09-30
//   · 设备码：SHA256(盐 | 序列号 | UUID | 版本) 前 10 字节 → 定制 Base32
//             形如 CT-7K3M-9Q2X-4W8V（发给作者换取激活码）
//   · 激活码：作者私钥（ECDSA P-256）对 "ct1|<设备码>" 的 X9.62 DER 签名 → Base58
//   · 验签：Security.framework 系统验签；插件内只有公钥 → 数学上造不出码
//   · 试用期：kCTAuthTrialDays 天全功能（常量，随时可改）
// ============================================================================
#ifndef CT_AUTH_H
#define CT_AUTH_H

#import <Foundation/Foundation.h>
#import <Security/Security.h>
#ifndef CT_NO_IOKIT
#import <IOKit/IOKitLib.h>
#endif
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>
#include <CommonCrypto/CommonKeyDerivation.h>
#include <string.h>
#include <stdlib.h>

#define kCTAuthTrialDays  0          // 试用天数（0 = 不要试用期，直接要求激活）
#define kCTAuthMsgTag     "ct1|"     // 签名消息前缀（版本标记）

// 内嵌公钥（P-256 未压缩点，65 字节）——只能验签，无法签名
static const uint8_t kCTAuthPubKey[65] = {
    0x04, 0xcd, 0xc8, 0xfe, 0xb1, 0x62, 0x4b, 0xe3, 0x54, 0xaa, 0x2b, 0x51, 0x08, 0x8e, 0xa2, 0xbb,
    0x38, 0x6a, 0x91, 0xfd, 0xc7, 0xf7, 0x6c, 0xff, 0x4e, 0x0f, 0x00, 0x05, 0xd3, 0x42, 0x00, 0xf3,
    0x40, 0x27, 0x81, 0x1c, 0xe6, 0x47, 0x1a, 0xc6, 0xa6, 0xb4, 0xb8, 0x18, 0x83, 0x33, 0xb7, 0x61,
    0x25, 0xe5, 0xfa, 0x91, 0xd6, 0xd1, 0x64, 0xa0, 0x60, 0xbb, 0xd6, 0xcb, 0xfd, 0x2f, 0xff, 0x7a,
    0xb0
};

// 备用公钥 K2（★ 双公钥铺路：将来切网站/换钥时启用；现在只做储备、不签发）
static const uint8_t kCTAuthPubKey2[65] = {
    0x04, 0xee, 0x9f, 0xf2, 0x89, 0x05, 0x90, 0xa3, 0x15, 0xfd, 0xdb, 0xee, 0x4e, 0xea, 0x8e, 0xac,
    0x24, 0xb4, 0xf2, 0xd2, 0xa5, 0x33, 0x53, 0x93, 0x09, 0xe7, 0xe1, 0x5b, 0x10, 0xf5, 0x87, 0x5e,
    0x93, 0xd0, 0x7d, 0x15, 0x71, 0x50, 0x0b, 0x05, 0x46, 0x30, 0xe6, 0x10, 0x54, 0x4e, 0xa0, 0xc9,
    0xbb, 0x13, 0x4c, 0x36, 0x71, 0x2e, 0xbb, 0x33, 0x56, 0x56, 0xc2, 0xae, 0xc6, 0xc9, 0xc1, 0xea,
    0x60
};

// 设备码盐（16 字节，构建期常量）
static const uint8_t kCTAuthSalt[16] = {
    0x03, 0x46, 0x44, 0xad, 0x8f, 0xa9, 0x9f, 0xfc, 0x78, 0xc4, 0xd0, 0xa2, 0x5b, 0xbc, 0xfe, 0x50
};

// ---------- Base58 解码（激活码 → DER 签名字节） ----------
static const char *kCTAuthB58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

static NSData *CTAuthBase58Decode(NSString *s) {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return nil;
    NSMutableString *clean = [NSMutableString stringWithCapacity:s.length];
    for (NSUInteger i = 0; i < s.length; i++) {
        unichar c = [s characterAtIndex:i];
        if (c < 128 && strchr(kCTAuthB58, (char)c)) [clean appendFormat:@"%c", (char)c];
    }
    NSUInteger len = clean.length;
    if (len < 40 || len > 300) return nil;   // ★ v2 授权码 = 签名 + 零件块（约 184 字符），上限须放到 300
    const char *chars = clean.UTF8String;
    uint8_t *buf = (uint8_t *)calloc(len, 1);
    if (!buf) return nil;
    NSUInteger outLen = 0;
    for (NSUInteger i = 0; i < len; i++) {
        const char *p = strchr(kCTAuthB58, chars[i]);
        if (!p) continue;
        int carry = (int)(p - kCTAuthB58);
        for (NSUInteger j = 0; j < outLen; j++) {
            carry += 58 * buf[j];
            buf[j] = (uint8_t)(carry & 0xff);
            carry >>= 8;
        }
        while (carry) { buf[outLen++] = (uint8_t)(carry & 0xff); carry >>= 8; }
    }
    NSUInteger zeros = 0;
    while (zeros < len && chars[zeros] == '1') zeros++;
    NSMutableData *out = [NSMutableData dataWithCapacity:outLen + zeros];
    for (NSUInteger i = 0; i < zeros; i++) { uint8_t z = 0; [out appendBytes:&z length:1]; }
    for (NSUInteger i = outLen; i > 0; i--) [out appendBytes:&buf[i - 1] length:1];
    free(buf);
    return out;
}

// ---------- 定制 Base32（设备码用；不含 I/O/0/1，防抄错） ----------
static NSString *CTAuthBase32Code(const uint8_t *d, size_t n, int wantChars) {
    static const char *alpha = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    NSMutableString *s = [NSMutableString stringWithCapacity:wantChars];
    uint32_t acc = 0; int bits = 0; size_t i = 0;
    while ((int)s.length < wantChars) {
        if (bits < 5) {
            if (i >= n) break;
            acc = (acc << 8) | d[i++];
            bits += 8;
        }
        int idx = (int)((acc >> (bits - 5)) & 0x1F);
        bits -= 5;
        [s appendFormat:@"%c", alpha[idx]];
    }
    return s;
}

// ---------- 设备码 ----------
#ifndef CT_NO_IOKIT
static NSString *CTAuthDeviceCode(void) {
    static NSString *cached = nil;
    if (cached) return cached;
    NSString *serial = nil, *uuid = nil;
    io_service_t platform = IOServiceGetMatchingService(kIOMasterPortDefault,
                                IOServiceMatching("IOPlatformExpertDevice"));
    if (platform) {
        CFTypeRef sv = IORegistryEntryCreateCFProperty(platform, CFSTR("IOPlatformSerialNumber"),
                                                       kCFAllocatorDefault, 0);
        if (sv) {
            if (CFGetTypeID(sv) == CFStringGetTypeID()) serial = CFBridgingRelease(sv); else CFRelease(sv);
        }
        CFTypeRef uv = IORegistryEntryCreateCFProperty(platform, CFSTR("IOPlatformUUID"),
                                                       kCFAllocatorDefault, 0);
        if (uv) {
            if (CFGetTypeID(uv) == CFStringGetTypeID()) uuid = CFBridgingRelease(uv); else CFRelease(uv);
        }
        IOObjectRelease(platform);
    }
    if (serial.length == 0 && uuid.length == 0) return nil;
    NSString *material = [NSString stringWithFormat:@"%@|%@|%@",
                          serial.length ? serial : @"-", uuid.length ? uuid : @"-", @"ct1"];
    NSData *m = [material dataUsingEncoding:NSUTF8StringEncoding];
    uint8_t digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256_CTX ctx;
    CC_SHA256_Init(&ctx);
    CC_SHA256_Update(&ctx, kCTAuthSalt, sizeof(kCTAuthSalt));
    CC_SHA256_Update(&ctx, m.bytes, (CC_LONG)m.length);
    CC_SHA256_Final(digest, &ctx);
    NSString *core = CTAuthBase32Code(digest, sizeof(digest), 12);
    if (core.length < 12) return nil;
    cached = [NSString stringWithFormat:@"CT-%@-%@-%@",
              [core substringWithRange:NSMakeRange(0, 4)],
              [core substringWithRange:NSMakeRange(4, 4)],
              [core substringWithRange:NSMakeRange(8, 4)]];
    return cached;
}
#else
// ObjC++ 组件（不引入 IOKit）：只留声明，设备码从 prefs（ctDevCode）取
static NSString *CTAuthDeviceCode(void);
#endif

// ---------- 验签：激活码是否对应该设备（双公钥：K1 现役 / K2 储备，任一通过即有效） ----------
static BOOL CTAuthVerifyWithKey(const uint8_t *pubKey, NSData *msg, NSData *sig) {
    NSDictionary *attrs = @{ (__bridge id)kSecAttrKeyType: (__bridge id)kSecAttrKeyTypeECSECPrimeRandom,
                             (__bridge id)kSecAttrKeyClass: (__bridge id)kSecAttrKeyClassPublic };
    CFErrorRef cerr = NULL;
    // ★ 0930-0195：Security 已改为弱链接 —— 遇到加载不到它的受限环境时做空指针兜底（绝不因调用而崩）
    if (!SecKeyCreateWithData || !SecKeyVerifySignature) return NO;
    SecKeyRef pub = SecKeyCreateWithData((__bridge CFDataRef)[NSData dataWithBytes:pubKey length:65],
                                         (__bridge CFDictionaryRef)attrs, &cerr);
    if (!pub) return NO;
    CFErrorRef verr = NULL;
    BOOL ok = SecKeyVerifySignature(pub, kSecKeyAlgorithmECDSASignatureMessageX962SHA256,
                                    (__bridge CFDataRef)msg, (__bridge CFDataRef)sig, &verr);
    CFRelease(pub);
    return ok;
}

// ★ 从「DER 签名 + 零件块」里切出签名部分：DER 长度可变（70~72B），不能按固定长度切
static NSData *CTAuthSigPortion(NSData *raw) {
    if (raw.length < 2) return nil;
    const uint8_t *b = (const uint8_t *)raw.bytes;
    if (b[0] != 0x30) return nil;
    NSUInteger len = b[1], off = 2;
    if (len & 0x80) {
        NSUInteger n = len & 0x7f;
        if (n == 0 || n > 3 || raw.length < off + n) return nil;
        len = 0;
        for (NSUInteger i = 0; i < n; i++) len = (len << 8) | b[off + i];
        off += n;
    }
    if (len == 0 || raw.length < off + len) return nil;
    return [raw subdataWithRange:NSMakeRange(0, off + len)];
}

static BOOL CTAuthVerifyCode(NSString *deviceCode, NSString *code) {
    if (![deviceCode isKindOfClass:[NSString class]] || deviceCode.length == 0) return NO;
    if (![code isKindOfClass:[NSString class]] || code.length < 40) return NO;
    NSData *raw = CTAuthBase58Decode(code);
    if (!raw) return NO;
    NSData *sig = CTAuthSigPortion(raw);                          // ★ 只取签名段（其后是零件块）
    if (!sig || sig.length < 60 || sig.length > 80) return NO;   // P-256 DER 签名约 70-72B
    NSString *full = [NSString stringWithFormat:@"%s%@", kCTAuthMsgTag, deviceCode];
    NSData *msg = [full dataUsingEncoding:NSUTF8StringEncoding];
    // ★ 双公钥：K1（现役）或 K2（储备）任一验签通过即有效——为将来切网站/换钥铺路
    if (CTAuthVerifyWithKey(kCTAuthPubKey, msg, sig)) return YES;
    if (CTAuthVerifyWithKey(kCTAuthPubKey2, msg, sig)) return YES;
    return NO;
}

// ---------- 零件钥匙发放（与 gen.py _blob_open 逐字节同构） ----------
//   激活码尾部 64B = enc(32) || mac(32)；k = PBKDF2(deviceCode, salt2, 100000)
static const uint8_t kCTAuthSalt2[16] = {
    0xe4, 0xcd, 0xab, 0xd5, 0xee, 0xd6, 0x10, 0x8f,
    0x76, 0x32, 0xe9, 0x4e, 0xee, 0xeb, 0xeb, 0x4d
};

static BOOL CTAuthExtractParts(NSString *deviceCode, NSString *code, uint8_t outS[32]) {
    if (![deviceCode isKindOfClass:[NSString class]] || deviceCode.length == 0) return NO;
    if (![code isKindOfClass:[NSString class]]) return NO;
    NSData *raw = CTAuthBase58Decode(code);
    if (!raw || raw.length < 70 || raw.length < 64 + 40) return NO;
    const uint8_t *bp = (const uint8_t *)raw.bytes;
    const uint8_t *enc = bp + (raw.length - 64);
    const uint8_t *mac = enc + 32;
    const char *pw = deviceCode.UTF8String;
    if (!pw) return NO;
    uint8_t k[32];
    int r = CCKeyDerivationPBKDF(kCCPBKDF2, pw, strlen(pw),
                                 kCTAuthSalt2, sizeof(kCTAuthSalt2),
                                 kCCPRFHmacAlgSHA256, 100000, k, 32);
    if (r != 0) return NO;   // 0 = success (kCCSuccess)
    uint8_t kEnc[32], kMac[32], macCalc[32];
    {
        uint8_t in[33];
        memcpy(in, k, 32);
        in[32] = 'E'; CC_SHA256(in, 33, kEnc);
        in[32] = 'M'; CC_SHA256(in, 33, kMac);
    }
    CCHmac(kCCHmacAlgSHA256, kMac, 32, enc, 32, macCalc);
    BOOL ok = (memcmp(macCalc, mac, 32) == 0);
    if (ok) {
        for (int i = 0; i < 32; i++) outS[i] = enc[i] ^ kEnc[i];
    }
    memset(k, 0, sizeof(k)); memset(kEnc, 0, sizeof(kEnc));
    memset(kMac, 0, sizeof(kMac)); memset(macCalc, 0, sizeof(macCalc));
    return ok;
}

#endif // CT_AUTH_H
