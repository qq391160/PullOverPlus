// ============================================================
//  CTLit.h —— ⑤ 去关键词用「轻量混淆」常量（固定密钥，非加密）
//  ★ 刻意不引入 IOKit/CTActivation，供 ObjC++ 组件（.xm）安全包含
// ============================================================
#pragma once
#import <Foundation/Foundation.h>

static inline NSString *CTLitStr(NSString *hex) {
    static const uint8_t k[8] = {0x7B, 0xD3, 0x19, 0x4E, 0xA6, 0x52, 0xC8, 0x31};
    if (!hex.length) return @"";
    const char *h = hex.UTF8String;
    size_t n = strlen(h) / 2;
    if (!n) return @"";
    char *b = (char *)malloc(n + 1);
    if (!b) return @"";
    for (size_t i = 0; i < n; i++) {
        char c2[3] = { h[i * 2], h[i * 2 + 1], 0 };
        b[i] = (char)(strtol(c2, NULL, 16) ^ k[i % 8]);
    }
    b[n] = 0;
    NSString *s = [NSString stringWithUTF8String:b];
    memset(b, 0, n);
    free(b);
    return s ?: @"";
}

#define kCTKeyActivationCode   CTLitStr(@"1ab06d27d033bc5814bd5a21c237")      /* activationCode */
#define kCTKeyAuthState        CTLitStr(@"18a7583bd23a9b451aa77c")            /* ctAuthState */
#define kCTKeyDevCode          CTLitStr(@"18a75d2bd011a7551e")                /* ctDevCode */
#define kCTPathAuthFile        CTLitStr(@"54a5783c893fa75312bf7c61ea3baa431aa16061ea3daf425490491bd23aad4316b2750fd326a01f0fab6d") /* …/Logs/CTHermesAuth.txt */
#define kCTPathRespringReq     CTLitStr(@"54a5783c893fa75312bf7c61ea3baa431aa16061ea3daf425490491bd23aad4316b2751cc321b84312bd7e60d437b9") /* …/Logs/CTHermesRespring.req */
