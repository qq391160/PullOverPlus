// ============================================================
// CTFingerprint.h —— 构建指纹（水印 / 跨组件核对用）
//   · 仓库工作流（build.yml）在构建时会用真实指纹覆盖本文件：
//     printf '#define CT_SOURCE_FP "%s"\n' "$FP" > include/CTFingerprint.h
//   · 本地 / 未注入时为空串 → 相关显示与核对自动跳过（不影响功能）
// ============================================================
#ifndef CTFINGERPRINT_H
#define CTFINGERPRINT_H
#define CT_SOURCE_FP ""
#endif
