#ifndef CPUTHERMAL_SMART_H
#define CPUTHERMAL_SMART_H

// ★ T7o：智能分类"跨进程扫描 + 偏好缓存"
//   背景（T7n 诊断实锤）：分类扫描原本在 thermalmonitord 里做文件系统读取，
//   但它的沙箱看不到 /var/containers/Bundle/Application（三个扫描根全部 0 项），
//   所以"游戏识别"永远为 0（英雄联盟≈识别不到→原生，而不是满频）。
//   方案：由有权限的进程（挂载工具=root / SpringBoard）扫描应用目录，
//   结果存进插件偏好文件的 smartClasses 键（偏好同步链路已被"设置/面板改模式"验证可靠）；
//   thermalmonitord 重建分类时直接从自己读到的偏好里取，不再依赖自身文件系统权限。

#import <Foundation/Foundation.h>
#import <notify.h>
#import <stdint.h>
#import <stdio.h>
#import <sys/stat.h>
#import "CPUthermalPaths.h"

static const char *kCPUthermalSmartScanReqNotifC = "com.huayuarc.cputhermal/scanRequest";
static const char *kCPUthermalSmartCacheKeyC = "smartClasses";
static const char *kCPUthermalSmartDiagLogPathC = "/var/mobile/Library/Logs/CPUthermalDiag.log";

// 诊断日志：与主插件写同一份 CPUthermalDiag.log（用户一次导出即可）
static inline void CPUthermalSmartDiagLog(NSString *message) {
    if (![message isKindOfClass:[NSString class]] || message.length == 0) return;
    @try {
        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"HH:mm:ss.SSS";
        NSString *line = [NSString stringWithFormat:@"[%@] %@\n", [fmt stringFromDate:[NSDate date]], message];
        mkdir("/var/mobile/Library/Logs", 0755);
        FILE *fp = fopen(kCPUthermalSmartDiagLogPathC, "a");
        if (fp) { fputs(line.UTF8String, fp); fclose(fp); }
    } @catch (__unused NSException *e) { }
}

// 分类：2=游戏 / 1=可识别 / 0=认不出（与主插件 CTSmartAppClassAtPath 同规则）
// metaInOut / metaBesideOut：累计"包内 / 包旁"读到 iTunesMetadata 的次数（诊断用）
static inline NSInteger CPUthermalSmartClassAtAppPath(NSString *appPath, NSInteger *metaInOut, NSInteger *metaBesideOut) {
    if (![appPath isKindOfClass:[NSString class]] || appPath.length == 0) return 0;
    NSInteger cls = 0;
    @try {
        NSDictionary *meta = [NSDictionary dictionaryWithContentsOfFile:
            [appPath stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
        if ([meta isKindOfClass:[NSDictionary class]]) {
            if (metaInOut) (*metaInOut)++;
        } else {
            // 有些环境元数据放在包"旁边"（同一父目录）
            meta = [NSDictionary dictionaryWithContentsOfFile:
                [[appPath stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
            if ([meta isKindOfClass:[NSDictionary class]]) { if (metaBesideOut) (*metaBesideOut)++; }
        }
        if ([meta isKindOfClass:[NSDictionary class]]) {
            cls = 1;
            id gid = meta[S("genreId")];
            NSInteger g = [gid respondsToSelector:@selector(integerValue)] ? [gid integerValue] : -1;
            if (g == 6014 || (g >= 7001 && g <= 7019)) cls = 2;             // 「游戏」主类 / 子类
            id genre = meta[S("genre")];
            if ([genre isKindOfClass:[NSString class]] &&
                ([genre containsString:S("游戏")] || [genre caseInsensitiveCompare:S("Games")] == NSOrderedSame)) cls = 2;
        }
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:
            [appPath stringByAppendingPathComponent:S("Info.plist")]];
        id cat = [info isKindOfClass:[NSDictionary class]] ? info[S("LSApplicationCategoryType")] : nil;
        if ([cat isKindOfClass:[NSString class]] && [cat length] > 0) {
            if (cls == 0) cls = 1;
            if ([cat rangeOfString:S("games")].location != NSNotFound) cls = 2;
        }
    } @catch (__unused NSException *e) { }
    return cls;
}

// 把分类结果写进偏好 smartClasses 键（只有"有效结果"才写，避免空结果覆盖好缓存）
static inline BOOL CPUthermalSmartCacheStore(NSMutableSet *games, NSMutableSet *known, NSInteger bundles) {
    if (bundles <= 0 || (games.count + known.count) <= 0) return NO;
    @try {
        NSMutableDictionary *prefs = CPUthermalReadMutablePrefs() ?: [NSMutableDictionary dictionary];
        prefs[S("smartClasses")] = @{ S("ts"): [NSDate date],
                                      S("v"): @1,
                                      S("games"): games.allObjects,
                                      S("known"): known.allObjects,
                                      S("bundles"): @(bundles) };
        return CPUthermalWritePrefs(prefs);
    } @catch (__unused NSException *e) { return NO; }
}

// 读缓存（供展示/判断新旧；thermalmonitord 侧直接读偏好字典里的同名键）
static inline void CPUthermalSmartCacheLoad(NSMutableSet *games, NSMutableSet *known, NSString **tsDesc) {
    @try {
        NSDictionary *prefs = CPUthermalReadPrefs();
        NSDictionary *cache = [prefs isKindOfClass:[NSDictionary class]] ? prefs[S("smartClasses")] : nil;
        if (![cache isKindOfClass:[NSDictionary class]]) { if (tsDesc) *tsDesc = @"无"; return; }
        for (id v in cache[S("games")]) if ([v isKindOfClass:[NSNumber class]]) { [games addObject:v]; [known addObject:v]; }
        for (id v in cache[S("known")]) if ([v isKindOfClass:[NSNumber class]]) [known addObject:v];
        if (tsDesc) *tsDesc = [cache[S("ts")] description] ?: @"?";
    } @catch (__unused NSException *e) { if (tsDesc) *tsDesc = @"读失败"; }
}

// 扫描全部应用目录并写缓存。返回 YES=本次已写出（有效）缓存。
// summaryOut：如 "bundle 263（元数据 包内 0 + 包旁 250）/ 游戏 23 / 可识别 201"
// sampleOut ：目录样例（首个 App + lolm 的容器目录实况）
static inline BOOL CPUthermalSmartScanToCache(NSString **summaryOut, NSString **sampleOut) {
    NSMutableSet *games = [NSMutableSet set];
    NSMutableSet *known = [NSMutableSet set];
    NSMutableSet *seenBids = [NSMutableSet set];
    NSInteger bundles = 0, metaIn = 0, metaBeside = 0;
    NSMutableString *samples = [NSMutableString string];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *roots = @[S("/var/containers/Bundle/Application"),
                       S("/var/mobile/Containers/Bundle/Application"),
                       S("/private/var/containers/Bundle/Application"),
                       S("/Applications")];
    for (NSString *root in roots) {
        NSArray *children = [fm contentsOfDirectoryAtPath:root error:nil];
        for (NSString *child in children) {
            NSString *full = [root stringByAppendingPathComponent:child];
            NSArray *apps = nil;
            if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) apps = @[full];
            else apps = [fm contentsOfDirectoryAtPath:full error:nil] ?: @[];
            for (NSString *entry in apps) {
                NSString *appPath = [entry isAbsolutePath] ? entry : [full stringByAppendingPathComponent:entry];
                if ([[appPath pathExtension] caseInsensitiveCompare:S("app")] != NSOrderedSame) continue;
                NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:
                    [appPath stringByAppendingPathComponent:S("Info.plist")]];
                NSString *bid = [info isKindOfClass:[NSDictionary class]] ? info[S("CFBundleIdentifier")] : nil;
                if (![bid isKindOfClass:[NSString class]] || bid.length == 0) continue;
                if ([seenBids containsObject:bid]) continue;                 // /var 与 /private/var 同目录去重
                [seenBids addObject:bid];
                bundles++;
                NSInteger ctMi0 = metaIn, ctMb0 = metaBeside;
                NSInteger cls = CPUthermalSmartClassAtAppPath(appPath, &metaIn, &metaBeside);
                // ★ T7t 探针：找出"17580 幽灵指纹"的真身——把每个可读字符串都算一遍哈希
                {
                    NSMutableArray *ctT7tCands = [NSMutableArray array];
                    if ([bid isKindOfClass:[NSString class]] && bid.length) [ctT7tCands addObject:bid];
                    id ctT7tInfoObj = info;
                    NSString *ctT7tDN = [ctT7tInfoObj isKindOfClass:[NSDictionary class]] ? ctT7tInfoObj[S("CFBundleDisplayName")] : nil;
                    if ([ctT7tDN isKindOfClass:[NSString class]] && ctT7tDN.length) [ctT7tCands addObject:ctT7tDN];
                    NSString *ctT7tBN = [ctT7tInfoObj isKindOfClass:[NSDictionary class]] ? ctT7tInfoObj[S("CFBundleName")] : nil;
                    if ([ctT7tBN isKindOfClass:[NSString class]] && ctT7tBN.length) [ctT7tCands addObject:ctT7tBN];
                    NSString *ctT7tExec = [ctT7tInfoObj isKindOfClass:[NSDictionary class]] ? ctT7tInfoObj[S("CFBundleExecutable")] : nil;
                    if ([ctT7tExec isKindOfClass:[NSString class]] && ctT7tExec.length) [ctT7tCands addObject:ctT7tExec];
                    NSString *ctT7tFolder = [appPath lastPathComponent];
                    if (ctT7tFolder.length) [ctT7tCands addObject:ctT7tFolder];
                    for (NSString *ctT7tOne in ctT7tCands) {
                        if (CPUthermalBundleIDHash(ctT7tOne) == 17580759639135809648ULL ||
                            CPUthermalBundleIDHash([ctT7tOne lowercaseString]) == 17580759639135809648ULL ||
                            CPUthermalBundleIDHash([ctT7tOne uppercaseString]) == 17580759639135809648ULL) {
                            CPUthermalSmartDiagLog([NSString stringWithFormat:@"[17580探针] ★命中★ %@（app=%@）", ctT7tOne, appPath]);
                        }
                    }
                    NSArray *ctT7tPlug = [fm contentsOfDirectoryAtPath:[appPath stringByAppendingPathComponent:S("PlugIns")] error:nil];
                    for (NSString *ctT7tEx in ctT7tPlug) {
                        if ([[ctT7tEx pathExtension] caseInsensitiveCompare:S("appex")] != NSOrderedSame) continue;
                        NSString *ctT7tExPath = [[appPath stringByAppendingPathComponent:S("PlugIns")] stringByAppendingPathComponent:ctT7tEx];
                        NSDictionary *ctT7tExInfo = [NSDictionary dictionaryWithContentsOfFile:[ctT7tExPath stringByAppendingPathComponent:S("Info.plist")]];
                        NSString *ctT7tExBid = [ctT7tExInfo isKindOfClass:[NSDictionary class]] ? ctT7tExInfo[S("CFBundleIdentifier")] : nil;
                        if ([ctT7tExBid isKindOfClass:[NSString class]] && CPUthermalBundleIDHash(ctT7tExBid) == 17580759639135809648ULL) {
                            CPUthermalSmartDiagLog([NSString stringWithFormat:@"[17580探针] ★命中★ 扩展 %@（宿主 %@）", ctT7tExBid, appPath]);
                        }
                    }
                }
                if ([[appPath lowercaseString] rangeOfString:S("lolm")].location != NSNotFound) {
                    CPUthermalSmartDiagLog([NSString stringWithFormat:@"[扫描诊断] %@ bid=%@ cls=%ld 元数据(包内%ld/包旁%ld)",
                        [appPath lastPathComponent], bid, (long)cls,
                        (long)(metaIn - ctMi0), (long)(metaBeside - ctMb0)]);
                }
                if (cls >= 1) [known addObject:@(CPUthermalBundleIDHash(bid))];
                if (cls == 2) [games addObject:@(CPUthermalBundleIDHash(bid))];
                if (samples.length < 420 &&
                    (samples.length == 0 || [appPath rangeOfString:S("lolm")].location != NSNotFound)) {
                    NSArray *siblings = [fm contentsOfDirectoryAtPath:[appPath stringByDeletingLastPathComponent] error:nil];
                    [samples appendFormat:@"%@ → %@; ", [appPath lastPathComponent],
                     siblings ? [siblings componentsJoinedByString:@" | "] : @"(读不到)"];
                }
            }
        }
    }
    if (summaryOut) {
        *summaryOut = [NSString stringWithFormat:@"bundle %ld（元数据 包内 %ld + 包旁 %ld）/ 游戏 %lu / 可识别 %lu",
                       (long)bundles, (long)metaIn, (long)metaBeside,
                       (unsigned long)games.count, (unsigned long)known.count];
    }
    if (sampleOut && samples.length) *sampleOut = samples;
    return CPUthermalSmartCacheStore(games, known, bundles);
}

#endif
