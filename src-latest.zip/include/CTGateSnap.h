// ============================================================================
// CTGateSnap.h —— 门控快照（★ 2.0.115：热路径零磁盘 IO）
//   背景（2026-10-15 backboardd 案）：门控“授权/开关”判定原先在热路径上每 ≤5s
//   同步读配置 + 读授权文件（多候选路径）。现改为：
//     · 热路径：只读进程内原子缓存（无锁、无 IO、不阻塞）
//     · 刷新：真实读取（磁盘 IO）在后台队列异步执行
//     · 失效：设置/授权变更通知一到 → 级联重取（handler 内同步重取一次）
//   护栏：未知态=NO（fail-safe 直通/待命）；全 @try；不建线程（GCD 全局队列）。
// ============================================================================
#ifndef CT_GATE_SNAP_H
#define CT_GATE_SNAP_H

#import <Foundation/Foundation.h>
#include <stdatomic.h>

typedef struct {
    _Atomic(int)       v;     // 0=未知 1=真 2=假
    _Atomic(long long) at;    // 上次刷新完成（毫秒）
    _Atomic(int)       busy;  // 1=后台刷新进行中
    _Atomic(int)       gen;   // 代际：失效时 +1 → 丢弃在途旧刷新结果
} CTGateCell;

#define CT_GATE_TTL_DEFAULT 30.0   // 秒（配合通知失效；原为 5s 同步轮询）

// 热路径读取：有有效缓存直接返回；过期/未知 → 触发一次后台刷新，本次返回旧值（未知=NO）
static inline BOOL CTGateReadC(CTGateCell *c, double ttl, BOOL (^io)(void)) {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    int v  = atomic_load_explicit(&c->v, memory_order_relaxed);
    long long at = atomic_load_explicit(&c->at, memory_order_relaxed);
    if (v != 0 && ((now * 1000.0) - (double)at) < (ttl * 1000.0)) return (v == 1);
    int g0 = atomic_load_explicit(&c->gen, memory_order_relaxed);
    int expected = 0;
    if (atomic_compare_exchange_strong_explicit(&c->busy, &expected, 1, memory_order_acq_rel, memory_order_relaxed)) {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            BOOL r = NO;
            @try { r = io() ? YES : NO; } @catch (__unused NSException *e) { r = NO; }
            if (atomic_load_explicit(&c->gen, memory_order_acquire) == g0) {
                atomic_store_explicit(&c->v, r ? 1 : 2, memory_order_relaxed);
                atomic_store_explicit(&c->at, (long long)(CFAbsoluteTimeGetCurrent() * 1000.0), memory_order_release);
            }
            atomic_store_explicit(&c->busy, 0, memory_order_release);
        });
    }
    return (v == 1);   // 本次返回旧值（未知=NO，fail-safe）
}

// 通知处理（非热路径）里用：立即同步重取一次 + 作废在途刷新
static inline void CTGateRefreshNowC(CTGateCell *c, BOOL (^io)(void)) {
    atomic_fetch_add_explicit(&c->gen, 1, memory_order_acq_rel);
    BOOL r = NO;
    @try { r = io() ? YES : NO; } @catch (__unused NSException *e) { r = NO; }
    atomic_store_explicit(&c->v, r ? 1 : 2, memory_order_relaxed);
    atomic_store_explicit(&c->at, (long long)(CFAbsoluteTimeGetCurrent() * 1000.0), memory_order_release);
}

#endif
