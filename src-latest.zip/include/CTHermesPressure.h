#ifndef CPUTHERMAL_THERMAL_PRESSURE_H
#define CPUTHERMAL_THERMAL_PRESSURE_H

#import <Foundation/Foundation.h>
#import <notify.h>
#import <dlfcn.h>
#import <os/base.h>

// ============================================================================
// 热压力级别枚举（对应 OSThermalPressureLevel）
// 移植自 Battman thermal.h
// ============================================================================
typedef NS_ENUM(NSInteger, CTHermesPressureLevel) {
    CTHermesPressureLevelError    = -1,
    CTHermesPressureLevelNominal  = 0,   // 正常
    CTHermesPressureLevelLight    = 10,  // 轻微
    CTHermesPressureLevelModerate = 20,  // 中等
    CTHermesPressureLevelHeavy    = 30,  // 严重
    CTHermesPressureLevelTrapping = 40,  // 临界
    CTHermesPressureLevelSleeping = 50,  // 休眠

    CTHermesPressureLevelUnknown  = 999
};

// ============================================================================
// 热通知级别枚举（对应 OSThermalNotificationLevel）
// 移植自 Battman thermal.h
// ============================================================================
typedef NS_ENUM(NSInteger, CTHermesNotifLevel) {
    CTHermesNotifLevelAny             = -1,
    CTHermesNotifLevelNormal          = 0,
    CTHermesNotifLevel70PercentTorch  = 1,
    CTHermesNotifLevel70PercentBL     = 2,
    CTHermesNotifLevel50PercentTorch  = 3,
    CTHermesNotifLevel50PercentBL     = 4,
    CTHermesNotifLevelDisableTorch    = 5,
    CTHermesNotifLevel25PercentBL     = 6,
    CTHermesNotifLevelDisableMapsHalo = 7,
    CTHermesNotifLevelAppTerminate    = 8,
    CTHermesNotifLevelDeviceRestart   = 9,
    CTHermesNotifLevelReady           = 10,

    CTHermesNotifLevelUnknown         = 999
};

// ============================================================================
// 系统通知名称
// ============================================================================
// kOSThermalNotificationPressureLevelName (系统导出符号)
// 实际值: "com.apple.system.thermalpressurelevel"
__OSX_AVAILABLE_STARTING(__MAC_10_10, __IPHONE_7_0)
extern const char *const kOSThermalNotificationPressureLevelName;

// ============================================================================
// 获取热压力字符串描述
// ============================================================================
static inline const char *CTHermesPressureString(CTHermesPressureLevel pressure) {
    switch (pressure) {
        case CTHermesPressureLevelNominal:  return "Nominal";
        case CTHermesPressureLevelLight:    return "Light";
        case CTHermesPressureLevelModerate: return "Moderate";
        case CTHermesPressureLevelHeavy:    return "Heavy";
        case CTHermesPressureLevelTrapping: return "Trapping";
        case CTHermesPressureLevelSleeping: return "Sleeping";
        default:                              return "Unknown";
    }
}

// ============================================================================
// 获取当前热压力级别
// 移植自 Battman thermal.c -> thermal_pressure()
// ============================================================================
static inline CTHermesPressureLevel CTHermesGetPressureLevel(void) {
    int token;
    uint64_t level;

    if (notify_register_check(kOSThermalNotificationPressureLevelName, &token)) {
        return CTHermesPressureLevelError;
    }
    if (notify_get_state(token, &level)) {
        notify_cancel(token);
        return CTHermesPressureLevelError;
    }
    notify_cancel(token);

    if (level == 0)
        return CTHermesPressureLevelNominal;

    if (level < 10) {
        // macOS 风格 (1-4)
        switch (level) {
            case 1:  return CTHermesPressureLevelModerate;
            case 2:  return CTHermesPressureLevelHeavy;
            case 3:  return CTHermesPressureLevelTrapping;
            case 4:  return CTHermesPressureLevelSleeping;
            default: return CTHermesPressureLevelUnknown;
        }
    } else {
        // iOS 风格 (10-50)
        switch (level) {
            case 10: return CTHermesPressureLevelLight;
            case 20: return CTHermesPressureLevelModerate;
            case 30: return CTHermesPressureLevelHeavy;
            case 40: return CTHermesPressureLevelTrapping;
            case 50: return CTHermesPressureLevelSleeping;
            default: return CTHermesPressureLevelUnknown;
        }
    }
}

// ============================================================================
// 强制设置热压力级别
// 移植自 Battman thermal.c -> set_thermal_pressure()
//
// 通过 notify_set_state + notify_post 直接修改系统热压力通知状态，
// 所有监听 kOSThermalNotificationPressureLevelName 的组件都会收到变化。
// ============================================================================
static inline int CTHermesSetPressureLevel(CTHermesPressureLevel pressure) {
    uint64_t level = 0;
    uint64_t currentLevel = UINT64_MAX;
    int token = 0;

    if (notify_register_check(kOSThermalNotificationPressureLevelName, &token))
        return -1; // 不支持

    // iOS 风格编码 (10, 20, 30, 40, 50)
    switch (pressure) {
        case CTHermesPressureLevelLight:    level = 10; break;
        case CTHermesPressureLevelModerate: level = 20; break;
        case CTHermesPressureLevelHeavy:    level = 30; break;
        case CTHermesPressureLevelTrapping: level = 40; break;
        case CTHermesPressureLevelSleeping: level = 50; break;
        default:                              level = 0;  break; // Nominal
    }

    // 状态未变化时不重复广播，避免唤醒所有热状态监听者。
    if (notify_get_state(token, &currentLevel) == 0 && currentLevel == level) {
        notify_cancel(token);
        return 0;
    }
    if (notify_set_state(token, level)) {
        notify_cancel(token);
        return 1; // 设置失败
    }

    if (notify_post(kOSThermalNotificationPressureLevelName)) {
        notify_cancel(token);
        return 2; // 设置成功但通知发送失败
    }

    notify_cancel(token);
    return 0;
}

// ============================================================================
// 强制热压力为 Nominal（一键调用）
// ============================================================================
static inline int CTHermesForceNominalPressure(void) {
    return CTHermesSetPressureLevel(CTHermesPressureLevelNominal);
}

// ============================================================================
// 读取最大触发温度（thermalmonitord 设置的值）
// 移植自 Battman thermal.c -> thermal_max_trigger_temperature()
// 单位：摄氏度
// ============================================================================
static inline float CTHermesGetMaxTriggerTemperature(void) {
    int token;
    uint64_t level;

    if (notify_register_check("com.apple.system.maxthermalsensorvalue", &token))
        return -1.0f;
    if (notify_get_state(token, &level)) {
        notify_cancel(token);
        return -1.0f;
    }
    notify_cancel(token);

    return (float)level / 100.0f;
}

// ============================================================================
// 读取阳光暴露状态
// 移植自 Battman thermal.c -> thermal_solar_state()
// 返回值: 0=无暴露, 1=车窗暴露, 2=直接阳光暴露
// ============================================================================
static inline int CTHermesGetSolarState(void) {
    int token;
    uint64_t level;

    if (notify_register_check("com.apple.system.thermalsunlightstate", &token))
        return 0;
    if (notify_get_state(token, &level)) {
        notify_cancel(token);
        return 0;
    }
    notify_cancel(token);

    return (int)level;
}

// ============================================================================
// 热通知级别控制（通过 dlopen 调用私有 SPI）
// 移植自 Battman thermal.c
// ============================================================================

// 动态解析热通知函数
static inline void *CTHermesLoadThermalNotificationLib(void) {
    static void *handle = NULL;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        handle = dlopen("/System/Library/PrivateFrameworks/ThermalNotification.framework/ThermalNotification", RTLD_NOW | RTLD_LOCAL);
        if (!handle) {
            // 回退: 可能在 libSystem 中
            handle = dlopen("/usr/lib/libThermalNotification.dylib", RTLD_NOW | RTLD_LOCAL);
        }
    });
    return handle;
}

// 获取当前热通知级别
static inline int CTHermesGetCurrentNotifLevel(void) {
    static int (*func)(void) = NULL;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        void *handle = CTHermesLoadThermalNotificationLib();
        if (handle) {
            func = dlsym(handle, "OSThermalNotificationCurrentLevel");
        }
    });
    if (!func) return -1;
    return func();
}

// 获取指定行为的热通知级别
static inline int CTHermesNotifLevelForBehavior(int behavior) {
    static int (*func)(int) = NULL;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        void *handle = CTHermesLoadThermalNotificationLib();
        if (handle) {
            func = dlsym(handle, "_OSThermalNotificationLevelForBehavior");
        }
    });
    if (!func) return -1;
    return func(behavior);
}

// 设置指定行为的热通知级别
static inline void CTHermesSetNotifLevelForBehavior(int level) {
    static void (*func)(int) = NULL;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        void *handle = CTHermesLoadThermalNotificationLib();
        if (handle) {
            func = dlsym(handle, "_OSThermalNotificationSetLevelForBehavior");
        }
    });
    if (func) {
        func(level);
    }
}

// 获取当前通知级别对应的枚举值
static inline CTHermesNotifLevel CTHermesGetNotifLevel(void) {
    int rawLevel = CTHermesGetCurrentNotifLevel();
    if (rawLevel < 0) return CTHermesNotifLevelUnknown;

    // 查询所有已知行为对应的通知级别
    for (int i = 0; i < CTHermesNotifLevelUnknown; i++) {
        if (CTHermesNotifLevelForBehavior(i) == rawLevel)
            return (CTHermesNotifLevel)i;
    }

    return CTHermesNotifLevelUnknown;
}

// 强制热通知级别为 Normal
static inline void CTHermesForceNormalNotifLevel(void) {
    int token = 0;
    uint64_t currentLevel = UINT64_MAX;
    if (notify_register_check("com.apple.system.thermalnotification", &token) == 0) {
        if (notify_get_state(token, &currentLevel) != 0 || currentLevel != 0) {
            notify_set_state(token, 0);  // Normal
            notify_post("com.apple.system.thermalnotification");
        }
        notify_cancel(token);
    }
}

// ============================================================================
// 组合调用：同时强制压力 Nominal + 通知 Normal
// ============================================================================
static inline void CTHermesForceNominalCombined(void) {
    CTHermesForceNominalPressure();
    CTHermesForceNormalNotifLevel();
}

// ============================================================================
// 热压力检查 & 日志（用于调试）
// ============================================================================
static inline void CTHermesLogPressureStatus(void) {
    CTHermesPressureLevel pressure = CTHermesGetPressureLevel();
    float maxTemp = CTHermesGetMaxTriggerTemperature();
    int solarState = CTHermesGetSolarState();
    int notifLevel = CTHermesGetCurrentNotifLevel();

    NSLog(@"[CTHermesPressure] 压力=%s(%ld) 最高触发温度=%.1f°C 阳光暴露=%d 通知级别=%d",
          CTHermesPressureString(pressure), (long)pressure,
          maxTemp, solarState, notifLevel);
}

#endif /* CPUTHERMAL_THERMAL_PRESSURE_H */
