// 本地构建桩：仅用于编译（运行时使用设备上的真实 Preferences 框架）
#import <UIKit/UIKit.h>
@class PSSpecifier;

typedef NSInteger PSCellType;
enum {
    PSGroupCell = 0,
    PSLinkCell = 1,
    PSTitleValueCell = 4,
    PSSwitchCell = 6,
    PSStaticTextCell = 7,
    PSButtonCell = 13,
};

@interface PSListController : UIViewController {
    NSMutableArray *_specifiers;
}
@property (nonatomic, retain) NSArray *specifiers;
@property (nonatomic, retain) NSString *bundleID;
@property (nonatomic, retain) UITableView *table;
- (NSMutableArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target;
- (void)reloadSpecifiers;
- (void)reloadSpecifier:(PSSpecifier *)specifier;
- (void)reloadSpecifierID:(NSString *)identifier;
- (PSSpecifier *)specifierForID:(NSString *)identifier;
- (id)readPreferenceValue:(PSSpecifier *)specifier;
- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier;
- (void)setPreferenceValue:(id)value forSpecifier:(PSSpecifier *)specifier;
- (id)getPreferenceValue:(PSSpecifier *)specifier;
- (NSArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target bundle:(NSBundle *)bundle;
@end
