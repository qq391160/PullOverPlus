// 本地构建桩：仅用于编译（运行时使用设备上的真实 Preferences 框架）
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PSListController.h"

@interface PSSpecifier : NSObject {
@public
    SEL action;
    id target;
}
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *identifier;
@property (nonatomic, retain) id cellType;
@property (nonatomic, retain) NSMutableDictionary *properties;
+ (PSSpecifier *)groupSpecifierWithName:(NSString *)name;
+ (PSSpecifier *)emptyGroupSpecifier;
+ (PSSpecifier *)preferenceSpecifierNamed:(NSString *)name
                                   target:(id)target
                                      set:(SEL)set
                                      get:(SEL)get
                                   detail:(Class)detail
                                     cell:(PSCellType)cell
                                     edit:(Class)edit;
- (void)setProperty:(id)value forKey:(NSString *)key;
- (id)propertyForKey:(NSString *)key;
- (void)removePropertyForKey:(NSString *)key;
- (id)performGetter;
- (void)performSetterWithValue:(id)value;
@end
