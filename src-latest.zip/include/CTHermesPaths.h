#ifndef CPUTHERMAL_PATHS_H
#define CPUTHERMAL_PATHS_H

#import <Foundation/Foundation.h>
#import <notify.h>
#include <stdint.h>
#include <roothide.h>

#define S(str) [NSString stringWithUTF8String:(str)]

static const char *kCTHermesPrefRootFSPathC = "/var/mobile/Library/Preferences/com.qq391160.cpucore.plist";
static const char *kCTHermesOldJBPrefRelativePathC = "Library/Preferences/com.qq391160.cpucore.plist";
static const char *kCTHermesSettingsChangedNotifC = "com.qq391160.cpucore/settingsChanged";
static const char *kCTHermesPowerModeChangedNotifC = "com.qq391160.cpucore/powerModeChanged";
static const char *kCTHermesForegroundAppNotifC = "com.qq391160.cpucore/foregroundApp";
static const char *kCTHermesColorRefreshNotifC = "com.qq391160.cpucore/colorRefresh";   // ★ 2.0.76：颜色快速通道
static const char *kCTHermesScrollBoostNotifC = "com.qq391160.cpucore/scrollBoost";   // ★ T7w：滑动升频
static const char *kCTHermesAppBoostNotifC = "com.qq391160.cpucore/appBoost";   // ★ 2.0.1：开合通道（图标/底部起手/切换瞬间）
static const char *kCTHermesUserActivityNotifC = "com.qq391160.cpucore/userActivity";   // ★ T7z6：操作探针（深度降频）
static const char *kCTHermesVideoOnNotifC  = "com.qq391160.cpucore/videoStart";         // ★ T7z6：视频播放开始
static const char *kCTHermesVideoOffNotifC = "com.qq391160.cpucore/videoStop";          // ★ T7z6：视频播放结束
static const char *kCTHermesDragNotifC    = "com.qq391160.cpucore/dragMove";           // ★ 2.0.92：滑动/拖动探针（只认手指移动；点按不触发）
static const char *kCTHermesDeepAlive1NotifC = "com.qq391160.cpucore/deepAlive1";      // ★ 2.0.94：深层1(backboardd)心跳
static const char *kCTHermesDeepAlive2NotifC = "com.qq391160.cpucore/deepAlive2";      // ★ 2.0.94：深层2(网页)心跳
// bit 编码：bit0-7 保留(未用)；bit9=满血快充；bit10=禁止系统高温停充/高温停充保护
static const char *kCTHermesLowPowerModeC = "lowPower";
static const char *kCTHermesFullPowerModeC = "fullPower";
static const char *kCTHermesSmartModeC = "smart";

static inline uint64_t CTHermesBundleIDHash(NSString *bundleID) {
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return 0;
    const unsigned char *bytes = (const unsigned char *)[bundleID UTF8String];
    uint64_t hash = 1469598103934665603ULL;
    for (; bytes && *bytes; bytes++) { hash ^= *bytes; hash *= 1099511628211ULL; }
    return hash ?: 1;
}

// ★ T7u：系统组件进程（小组件渲染器等）不参与"前台应用"判定——
//   它们会自报自己为前台（如 com.apple.chrono.WidgetRenderer-Default，
//   指纹 17580759639135809648），造成"幽灵前台指纹"干扰。
static inline BOOL CTHermesIsSystemComponentBundleID(NSString *bundleID) {
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return NO;
    if ([bundleID hasPrefix:S("com.apple.chrono")]) return YES;   // 覆盖 chrono.* 与 chronod 等全家族
    if ([bundleID rangeOfString:S("WidgetRenderer")].location != NSNotFound) return YES;
    if ([bundleID rangeOfString:S("CallAudioService")].location != NSNotFound) return YES;
    return NO;
}

static inline int CTHermesPostForegroundBundleID(NSString *bundleID) {
    int token = 0;
    if (notify_register_check(kCTHermesForegroundAppNotifC, &token) != NOTIFY_STATUS_OK) return -1;
    int result = notify_set_state(token, CTHermesBundleIDHash(bundleID));
    if (result == NOTIFY_STATUS_OK) result = notify_post(kCTHermesForegroundAppNotifC);
    notify_cancel(token);
    return result;
}

static inline BOOL CTHermesClearForegroundBundleIDIfCurrent(NSString *bundleID) {
    uint64_t ownHash = CTHermesBundleIDHash(bundleID);
    if (ownHash == 0) return NO;
    int token = 0;
    uint64_t currentHash = 0;
    if (notify_register_check(kCTHermesForegroundAppNotifC, &token) != NOTIFY_STATUS_OK) return NO;
    int result = notify_get_state(token, &currentHash);
    if (result == NOTIFY_STATUS_OK && currentHash == ownHash) {
        result = notify_set_state(token, 0);
        if (result == NOTIFY_STATUS_OK) result = notify_post(kCTHermesForegroundAppNotifC);
    }
    notify_cancel(token);
    return result == NOTIFY_STATUS_OK && currentHash == ownHash;
}

static inline uint64_t CTHermesReadForegroundBundleHash(void) {
    int token = 0;
    uint64_t state = 0;
    if (notify_register_check(kCTHermesForegroundAppNotifC, &token) != NOTIFY_STATUS_OK) return 0;
    int result = notify_get_state(token, &state);
    notify_cancel(token);
    return result == NOTIFY_STATUS_OK ? state : 0;
}

static inline NSString *CTHermesStringFromCPath(const char *path) {
    return path ? [NSString stringWithUTF8String:path] : nil;
}

static inline NSString *CTHermesCurrentRootHideRoot(void);   // ★ 2.0.6：前置声明（JBRootPath 内嵌根分支要用）

static inline NSString *CTHermesJBRootPathForRootFSPath(const char *path) {
    if (!path) return nil;

    // 优先尝试通过 jbroot 转换路径
    const char *jbPath = jbroot(path);
    if (jbPath && strlen(jbPath) > 0) {
        NSString *converted = [NSString stringWithUTF8String:jbPath];
        if ([[NSFileManager defaultManager] fileExistsAtPath:converted]) {
            return converted;
        }
#ifdef CT_SCHEME_ROOTHIDE
        // ★ 2.0.6 隐根干净版：不落 /var/jb——直接用 jbroot() 的转换结果（容器内），不做 /var/jb 兜底
        if ([converted containsString:S("/.jbroot-")] || [converted containsString:S("/Containers/")]) {
            return converted;
        }
        NSString *rhRoot = CTHermesCurrentRootHideRoot();
        if (rhRoot.length > 0) {
            return [rhRoot stringByAppendingPathComponent:[NSString stringWithUTF8String:path]];
        }
        return converted.length > 0 ? converted : [NSString stringWithUTF8String:path];
#else
        // 兜底 1: 检查 /var/jb 相对路径
        NSString *varJBPath = [S("/var/jb") stringByAppendingPathComponent:[NSString stringWithUTF8String:path]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:varJBPath]) {
            return varJBPath;
        }

        // 兜底 2: 返回原始路径
        return [NSString stringWithUTF8String:path];
#endif
    }
#ifdef CT_SCHEME_ROOTHIDE
    NSString *rhRoot2 = CTHermesCurrentRootHideRoot();
    if (rhRoot2.length > 0) {
        return [rhRoot2 stringByAppendingPathComponent:[NSString stringWithUTF8String:path]];
    }
    return [NSString stringWithUTF8String:path];
#else
    // 兜底 1: 检查 /var/jb 相对路径
    NSString *varJBPath = [S("/var/jb") stringByAppendingPathComponent:[NSString stringWithUTF8String:path]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:varJBPath]) {
        return varJBPath;
    }
    // 兜底 2: 返回原始路径
    return [NSString stringWithUTF8String:path];
#endif
}

static inline NSString *CTHermesCurrentRootHideRoot(void) {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    // ★ 2.0.38：多基底扫描——某些进程读不到 AppGroup，却能读到其他布局；一律只认 .jbroot-*（评分挑最优）
    NSArray<NSString *> *bases = @[@"/var/mobile/Containers/Shared/AppGroup",
                                   @"/var/containers/Bundle/Application",
                                   @"/var/containers/Shared/SystemGroup",
                                   @"/var/mobile/Library",
                                   @"/var/mobile/Containers/Data/Application"];
    NSString *bestRoot = nil;
    NSInteger bestScore = NSIntegerMin;
    NSDate *bestDate = nil;

    for (NSString *base in bases) {
    NSArray<NSString *> *entries = [fileManager contentsOfDirectoryAtPath:base error:nil];
    for (NSString *entry in entries) {
        if (![entry hasPrefix:S(".jbroot-")]) continue;
        NSString *root = [base stringByAppendingPathComponent:entry];
        BOOL isDirectory = NO;
        if (![fileManager fileExistsAtPath:root isDirectory:&isDirectory] || !isDirectory) continue;

        NSInteger score = 0;
        NSString *tweakPath = [root stringByAppendingPathComponent:S("Library/MobileSubstrate/DynamicLibraries/CTHermes.dylib")];
        NSString *substratePath = [root stringByAppendingPathComponent:S("Library/MobileSubstrate")];
        NSString *usrLibPath = [root stringByAppendingPathComponent:S("usr/lib")];
        if ([fileManager fileExistsAtPath:tweakPath]) score += 1000;
        if ([fileManager fileExistsAtPath:substratePath]) score += 100;
        if ([fileManager fileExistsAtPath:usrLibPath]) score += 10;

        NSDictionary *attributes = [fileManager attributesOfItemAtPath:root error:nil];
        NSDate *date = attributes[NSFileModificationDate] ?: [NSDate distantPast];
        if (!bestRoot || score > bestScore || (score == bestScore && [date compare:bestDate] == NSOrderedDescending)) {
            bestRoot = root;
            bestScore = score;
            bestDate = date;
        }
    }
    }
    return bestRoot;
}

// ============================================================================
// ★ 2.0.110：单根解析——每进程只探测一次并缓存；全局只认这一条
//   隐根=动态扫描（见上）；无根=/var/jb；失败=保命链（jbroot 反推）+留痕，绝不静默死
// ============================================================================
static inline NSString *CTHermesResolvedRootOnce(void) {
    static NSString *sRoot = nil;
    static BOOL sProbed = NO;
    if (sProbed) return sRoot;
    sProbed = YES;
    @try {
#ifdef CT_SCHEME_ROOTHIDE
        sRoot = CTHermesCurrentRootHideRoot();
        if (sRoot.length == 0) {
            const char *jb = jbroot("/Library/CTHermesState");
            if (jb && strlen(jb) > 0) {
                NSString *c = [NSString stringWithUTF8String:jb];
                NSRange r = [c rangeOfString:@"/Library/CTHermesState"];
                if (r.location != NSNotFound) sRoot = [c substringToIndex:r.location];
            }
        }
#else
        {
            NSFileManager *fm = [NSFileManager defaultManager];
            sRoot = [fm fileExistsAtPath:@"/var/jb"] ? @"/var/jb" : @"";
        }
#endif
    } @catch (__unused NSException *e) { sRoot = nil; }
    return sRoot;
}

// ★ 2.0.110：唯一工作目录 = <根>/Library/CTHermesState（无根环境返回 nil，沿用既有布局）
static inline NSString *CTHermesRootStateDir(void) {
#ifdef CT_SCHEME_ROOTHIDE
    NSString *r = CTHermesResolvedRootOnce();
    return r.length ? [r stringByAppendingPathComponent:S("Library/CTHermesState")] : nil;
#else
    return nil;
#endif
}
static inline NSString *CTHermesRootLogsDir(void) {
    NSString *s = CTHermesRootStateDir();
    return s.length ? [s stringByAppendingPathComponent:S("logs")] : nil;
}
static inline NSString *CTHermesRootRunDir(void) {
    NSString *s = CTHermesRootStateDir();
    return s.length ? [s stringByAppendingPathComponent:S("run")] : nil;
}

// ★ 2.0.38：路径"安全阀"——候选目录若"实际解析到容器外"（例如 var/tmp / tmp 是外指软链），一律剔除。
//   做法：对候选找出"最长的已存在前缀"做 realpath，检查其是否仍在容器根的实路径之下。
#include <stdlib.h>
#include <sys/stat.h>
static inline BOOL CTHermesPathStaysInContainer(NSString *rh, NSString *candidate) {
    if (!rh.length || !candidate.length) return NO;
    char rrh[1024];
    if (!realpath([rh fileSystemRepresentation], rrh)) return NO;
    NSString *rrhS = [NSString stringWithUTF8String:rrh];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *probe = candidate;
    for (int i = 0; i < 24 && probe.length > rh.length; i++) {
        if ([fm fileExistsAtPath:probe]) {
            char rr[1024];
            if (!realpath([probe fileSystemRepresentation], rr)) return NO;
            NSString *rrS = [NSString stringWithUTF8String:rr];
            return [rrS hasPrefix:rrhS];
        }
        probe = [probe stringByDeletingLastPathComponent];
    }
    return YES;   // 尚未触到更深层 → 将由容器内新建，天然安全
}

// ★ 2.0.38：同一文件识别——清理"宿主副本"前，先确认它与"容器副本"确非同一文件。
//   背景：隐根视角下 /var/mobile/... 会解析进容器，两者其实是同一个文件；
//   旧逻辑"先并入、校验后清宿主"在这种视角下会直接把容器真身删掉（本次设置丢失的事故根因）。
static inline BOOL CTHermesSameFile(NSString *a, NSString *b) {
    if (!a.length || !b.length) return NO;
    struct stat sa, sb;
    if (stat([a fileSystemRepresentation], &sa) != 0) return NO;
    if (stat([b fileSystemRepresentation], &sb) != 0) return NO;
    return (sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino);
}


static inline NSString *CTHermesCurrentPrefPath(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：配置唯一新家 = 工作目录内一条路（旧位置只作只读迁移来源）
    NSString *s = CTHermesRootStateDir();
    return s.length ? [s stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")] : nil;
#else
    // 无根：原逻辑原样（本版不动无根）
    NSString *rootHideRoot = CTHermesCurrentRootHideRoot();
    if (rootHideRoot.length > 0) {
        return [[rootHideRoot stringByAppendingPathComponent:S("var/mobile/Library/Preferences")]
            stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")];
    }

    const char *convertedPath = jbroot(kCTHermesPrefRootFSPathC);
    if (convertedPath && strlen(convertedPath) > 0) {
        NSString *converted = [NSString stringWithUTF8String:convertedPath];
        if ([converted containsString:S("/Containers/Shared/AppGroup/.jbroot-")]) return converted;
    }
    return CTHermesJBRootPathForRootFSPath(kCTHermesPrefRootFSPathC);
#endif
}

// ============================================================================
// ★ 2.0.38：诊断日志/状态文件 —— 隐根版全部走容器（"越狱指纹"收口）
//   无根版行为完全不变。惰性初始化时顺带把"宿主旧文件"并入容器并清掉宿主副本。
// ============================================================================
#include <stdio.h>
#include <string.h>
static inline BOOL CTHermesUninstalling(void);   // 前置声明（定义见下方）

// ============================================================================
// ★ 2.0.39：旧路径"一次合并"——把历史遗留目录里的自家文件并入统一目录（Library/CTHermesState），
//   然后清掉旧副本。只碰自家名字；sameFile/容器守卫；幂等（标记文件 .consolidated246）。
// ============================================================================
static inline void CTHermesConsolidateLegacyOnce(void) {
    static BOOL ran = NO;
    if (ran) return;
    ran = YES;
    @try {
        if (CTHermesUninstalling()) return;
        NSString *rh = CTHermesCurrentRootHideRoot();
        if (!rh.length) return;
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *base = [rh stringByAppendingPathComponent:S("Library/CTHermesState")];
        NSString *lgDir = [base stringByAppendingPathComponent:S("logs")];
        NSString *rnDir = [base stringByAppendingPathComponent:S("run")];
        NSString *mark = [base stringByAppendingPathComponent:S(".consolidated246")];
        if ([fm fileExistsAtPath:mark]) return;
        [fm createDirectoryAtPath:lgDir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        [fm createDirectoryAtPath:rnDir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        NSMutableArray *legacy = [NSMutableArray arrayWithArray:@[[rh stringByAppendingPathComponent:S("var/mobile/Library/Logs")],
                            [rh stringByAppendingPathComponent:S("var/tmp/CTHermes/run")],
                            [rh stringByAppendingPathComponent:S("tmp/CTHermes")],
                            [rh stringByAppendingPathComponent:S("var/mobile/Library/Caches/CTHermes")],
                            [rh stringByAppendingPathComponent:S("Library/Logs")],
                            @"/var/mobile/Library/Logs",
                            @"/var/tmp/CTHermes/run",
                            @"/tmp/CTHermes",
                            @"/var/mobile/Library/Caches/CTHermes"]];
#ifdef CT_SCHEME_ROOTHIDE
        {   // ★ 2.0.46：把"其他 .jbroot-* 层"的自家文件也纳入合并（治 16"搜出一堆日志 / 位置丢"）
            NSArray *__bases = @[@"/var/mobile/Containers/Shared/AppGroup",
                                 @"/var/containers/Bundle/Application",
                                 @"/var/containers/Shared/SystemGroup",
                                 @"/var/mobile/Library",
                                 @"/var/mobile/Containers/Data/Application"];
            for (NSString *__b in __bases) {
                for (NSString *__e in ([fm contentsOfDirectoryAtPath:__b error:NULL] ?: @[])) {
                    if (![__e hasPrefix:S(".jbroot-")]) continue;
                    NSString *__L = [__b stringByAppendingPathComponent:__e];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("var/mobile/Library/Logs")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("var/tmp/CTHermes/run")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("tmp/CTHermes")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("var/mobile/Library/Caches/CTHermes")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("Library/Logs")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("Library/CTHermesState/logs")]];
                    [legacy addObject:[__L stringByAppendingPathComponent:S("Library/CTHermesState/run")]];
                }
            }
        }
#endif
        NSArray *logNames = @[@"CTHermesDiag.log", @"CTHermesInstall.log", @"CTHermesFallback.log"];
        NSArray *stateNames = @[@"CTHermesStatus.txt", @"CTHermesNet.txt", @"CTHermesDirect.txt",
                                @"CTHermesSelfTest.txt", @"CTHermesSelfTest.req", @"CTHermesRespring.req",
                                @"CTHermesFloat.pos", @"CTHermesFloat.land", @"CTHermesAuth.txt",
                                @"CTHermesAppearance.txt", @"CTHermesSuspects.plist", @"CTHermesTables.txt",
                                @"CTHermesFreqProbe.txt", @"CTHermesCleanup.done", @"core-paths.txt"];
        NSString *rhSlash = [rh stringByAppendingString:@"/"];
        for (NSString *ld in legacy) {
            BOOL inLayer = [ld hasPrefix:rhSlash];
            for (NSString *n in logNames) {
                NSString *src = [ld stringByAppendingPathComponent:n];
                if (![fm fileExistsAtPath:src]) continue;
                NSString *dst = [lgDir stringByAppendingPathComponent:n];
                if (CTHermesSameFile(src, dst)) continue;
                if (!inLayer && CTHermesPathStaysInContainer(rh, src)) continue;   // 宿主路径实为容器真身 → 不动
                NSDictionary *at = [fm attributesOfItemAtPath:src error:NULL];
                if (![at[NSFileType] isEqual:NSFileTypeRegular]) continue;          // 非普通文件（软链等）绝不碰
                NSData *d = [NSData dataWithContentsOfFile:src];
                if (d.length) {
                    FILE *f = fopen(dst.fileSystemRepresentation, "a");
                    if (f) { fwrite(d.bytes, 1, d.length, f); fclose(f); }
                }
                if (!CTHermesSameFile(src, dst)) [fm removeItemAtPath:src error:NULL];
            }
            for (NSString *n in stateNames) {
                NSString *src = [ld stringByAppendingPathComponent:n];
                if (![fm fileExistsAtPath:src]) continue;
                NSString *dst = [rnDir stringByAppendingPathComponent:n];
                if (CTHermesSameFile(src, dst)) continue;
                if (!inLayer && CTHermesPathStaysInContainer(rh, src)) continue;
                NSDictionary *at = [fm attributesOfItemAtPath:src error:NULL];
                if (![at[NSFileType] isEqual:NSFileTypeRegular]) continue;
                if (![fm fileExistsAtPath:dst]) [fm copyItemAtPath:src toPath:dst error:NULL];
                if ([fm fileExistsAtPath:dst] && !CTHermesSameFile(src, dst)) [fm removeItemAtPath:src error:NULL];
            }
        }
        FILE *mf = fopen(mark.fileSystemRepresentation, "w");
        if (mf) { fputs("2.0.39\n", mf); fclose(mf); chmod(mark.fileSystemRepresentation, 0644); }
    } @catch (__unused NSException *e) {}
}


static inline NSString *CTDiagLogDir(void) {
    static NSString *dir = nil;
    if (dir) return dir;
#ifdef CT_SCHEME_ROOTHIDE
    {
        // ★ 2.0.39：统一主日志目录 = 隐根层 Library/CTHermesState/logs（16/17 同一条路，任何进程同一物理文件）
        // ★ 2.0.110：改用"单根解析（缓存一次）"
        NSString *rh = CTHermesResolvedRootOnce();
        if (rh.length > 0) {
            dir = [rh stringByAppendingPathComponent:S("Library/CTHermesState/logs")];
            if (!CTHermesUninstalling()) {
                NSFileManager *fm = [NSFileManager defaultManager];
                NSString *__s = [rh stringByAppendingPathComponent:S("Library/CTHermesState")];
                [fm createDirectoryAtPath:__s withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
                chmod(__s.fileSystemRepresentation, 01777);   // ★ 2.0.110：工作目录 01777
                [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
                chmod(dir.fileSystemRepresentation, 01777);
                CTHermesConsolidateLegacyOnce();
            }
        }
        if (!dir) dir = S("/dev/null");   // ★ 2.0.50：容器不可得 → 不再落任何位置（/dev/null 下必然写不出来；绝不产生 var 文件）
    }
#else
    dir = @"/var/mobile/Library/Logs";
#endif
    return dir;
}

static inline const char *CTDiagLogDirC(void) { return CTDiagLogDir().UTF8String; }
static inline NSString *CTDiagLogPath(void) {
    static NSString *p = nil;
    if (!p) p = [CTDiagLogDir() stringByAppendingPathComponent:S("CTHermesDiag.log")];
    return p;
}
static inline const char *CTDiagLogPathC(void) { return CTDiagLogPath().UTF8String; }
// 按文件名拼日志目录下的完整路径（返回线程安全的小缓冲；仅短期持有）
static inline const char *CTDiagFileC(const char *name) {
    static char bufs[8][512];
    static int idx = 0;
    int my = __sync_fetch_and_add(&idx, 1);
    char *b = bufs[my & 7];
    snprintf(b, 512, "%s/%s", CTDiagLogDirC(), name ? name : "state.txt");
    return b;
}

// ★ 2.0.38：日志"瘦身"统一闸门——超限不再一刀清空：保留"最后 96KB"（近期历史仍在，128KB 封顶）。
//   不 unlink：其它进程持有的追加（O_APPEND）句柄依旧有效，只会往新 EOF 继续写。
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#define CT_DIAG_LOG_LIMIT (512 * 1024)   // ★ 2.0.109 体检版：放宽保留窗口（原 128K）
#define CT_DIAG_LOG_KEEP  (384 * 1024)   // ★ 2.0.109 体检版（原 96K）
static inline void CTDiagLogBound(void) {
    const char *path = CTDiagLogPathC();
    if (!path || !path[0]) return;
    struct stat st;
    if (stat(path, &st) != 0 || st.st_size <= (off_t)CT_DIAG_LOG_LIMIT) return;
    long sz = (long)st.st_size;
    long start = (sz > (long)CT_DIAG_LOG_KEEP) ? (sz - (long)CT_DIAG_LOG_KEEP) : 0;
    int fd = open(path, O_RDONLY);
    if (fd < 0) return;
    long n = sz - start;
    char *buf = (char *)malloc((size_t)n);
    if (!buf) { close(fd); return; }
    lseek(fd, start, SEEK_SET);
    ssize_t got = read(fd, buf, (size_t)n);
    close(fd);
    if (got > 0) {
        int wd = open(path, O_WRONLY | O_TRUNC);
        if (wd >= 0) { ssize_t wr = write(wd, buf, (size_t)got); (void)wr; close(wd); }
    }
    free(buf);
}
static inline FILE *CTDiagLogOpenForAppend(void) {
    mkdir(CTDiagLogDirC(), 0755);
    CTDiagLogBound();
    return fopen(CTDiagLogPathC(), "a");
}

static inline NSString *CTHermesOldJBRootPrefPath(void) {
#ifdef CT_SCHEME_ROOTHIDE
    return nil;   // ★ 2.0.6 隐根干净版：不碰 /var/jb（迁移靠 .jbroot-* 副本与宿主副本兜底）
#else
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *resolvedJBRoot = [fileManager destinationOfSymbolicLinkAtPath:S("/var/jb") error:nil];
    if (resolvedJBRoot.length > 0) {
        return [resolvedJBRoot stringByAppendingPathComponent:S(kCTHermesOldJBPrefRelativePathC)];
    }
    return [S("/var/jb") stringByAppendingPathComponent:S(kCTHermesOldJBPrefRelativePathC)];
#endif
}

static inline NSArray<NSString *> *CTHermesLegacyPrefPaths(void) {
    NSMutableArray<NSString *> *paths = [NSMutableArray array];
    NSFileManager *fileManager = [NSFileManager defaultManager];

    // ★ 2.0.110：扫全部 5 个基底下的所有 .jbroot-* 层（旧版只扫 AppGroup → 迁移来源不全）
    NSArray *__bases = @[S("/var/mobile/Containers/Shared/AppGroup"),
                         S("/var/containers/Bundle/Application"),
                         S("/var/containers/Shared/SystemGroup"),
                         S("/var/mobile/Library"),
                         S("/var/mobile/Containers/Data/Application")];
    for (NSString *__b in __bases) {
        NSArray<NSString *> *entries = [fileManager contentsOfDirectoryAtPath:__b error:nil];
        for (NSString *entry in entries) {
            if (![entry hasPrefix:S(".jbroot-")]) continue;
            NSString *candidate = [[[__b stringByAppendingPathComponent:entry]
                stringByAppendingPathComponent:S("var/mobile/Library/Preferences")]
                stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")];
            if (![paths containsObject:candidate]) [paths addObject:candidate];
        }
    }

    NSString *oldJBPath = CTHermesOldJBRootPrefPath();
    if (oldJBPath.length > 0) {
        [paths addObject:oldJBPath];
    }
    NSString *rootFSPath = CTHermesStringFromCPath(kCTHermesPrefRootFSPathC);
    if (rootFSPath.length > 0 && ![paths containsObject:rootFSPath]) {
        [paths addObject:rootFSPath];
    }
    return paths;
}

// ★ 2.0.6：可写候选——隐根干净版只写"容器内的副本"（不写宿主、不写 /var/jb）；无根版与原行为一致
static inline NSArray<NSString *> *CTHermesWritablePrefPaths(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110：只承认唯一写盘（工作目录内一条路）
    NSMutableArray<NSString *> *paths = [NSMutableArray array];
    NSString *path = CTHermesCurrentPrefPath();
    if (path.length) [paths addObject:path];
    return paths;
#else
    NSMutableArray<NSString *> *paths = [NSMutableArray array];
    NSString *path = CTHermesCurrentPrefPath();
    if (path.length) [paths addObject:path];
    for (NSString *p in CTHermesLegacyPrefPaths()) { if (![paths containsObject:p]) [paths addObject:p]; }
    return paths;
#endif
}

static inline NSString *CTHermesExistingExecutablePath(const char *rootFSPath, NSArray<NSString *> *fallbackPaths) {
    if (!rootFSPath) return nil;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *resolvedPath = CTHermesJBRootPathForRootFSPath(rootFSPath);
    if (resolvedPath.length > 0 && [fileManager isExecutableFileAtPath:resolvedPath]) {
        return resolvedPath;
    }

    for (NSString *path in fallbackPaths) {
        if (path.length > 0 && [fileManager isExecutableFileAtPath:path]) {
            return path;
        }
    }
    return nil;
}

static inline NSString *CTHermesLaunchctlPath(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.6 隐根干净版：jbroot() 解析容器内路径（无 /var/jb 候选）
    return CTHermesExistingExecutablePath("/usr/bin/launchctl", @[
        S("/usr/bin/launchctl"),
        S("/bin/launchctl")
    ]);
#else
    return CTHermesExistingExecutablePath("/usr/bin/launchctl", @[
        S("/var/jb/usr/bin/launchctl"),
        S("/var/jb/bin/launchctl"),
        S("/usr/bin/launchctl"),
        S("/bin/launchctl")
    ]);
#endif
}

static inline NSString *CTHermesToolPath(void) {
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.6 隐根干净版：jbroot() 解析容器内路径（无 /var/jb 候选）
    NSArray *ctToolCandidates = @[
        S("/usr/local/bin/CTHermesTool"),
        S("/usr/bin/CTHermesTool")
    ];
#else
    // ★ T7p：rootless/RootHide 下工具的实际位置是 /var/jb/usr/bin/（实机验证），
    //   之前只查 /usr/local/bin 导致设置页/主插件调用工具全部静默失败。
    NSArray *ctToolCandidates = @[
        S("/var/jb/usr/bin/CTHermesTool"),
        S("/var/jb/usr/local/bin/CTHermesTool"),
        S("/usr/local/bin/CTHermesTool"),
        S("/usr/bin/CTHermesTool")
    ];
#endif
    NSFileManager *ctToolFM = [NSFileManager defaultManager];
    for (NSString *ctToolPath in ctToolCandidates) {
        if ([ctToolFM isExecutableFileAtPath:ctToolPath]) return ctToolPath;
        NSString *ctToolResolved = CTHermesJBRootPathForRootFSPath(ctToolPath.UTF8String);   // ★ 2.0.108：每个候选都走 jbroot 解析（工具实际在 /usr/bin，此前兜底只解析 /usr/local/bin → 隐根机找不到）
        if (ctToolResolved.length > 0 && [ctToolFM isExecutableFileAtPath:ctToolResolved]) return ctToolResolved;
    }
    NSString *ctToolR1 = CTHermesExistingExecutablePath("/usr/bin/CTHermesTool", nil);
    if (ctToolR1.length > 0) return ctToolR1;
    return CTHermesExistingExecutablePath("/usr/local/bin/CTHermesTool", nil);
}

// ★ 1.4.102：卸载墓碑 —— 卸载流程一开始就立碑（多候选全立），所有组件立即停止写盘（防"配置/状态复活"）
#ifndef CT_SCHEME_ROOTHIDE
static const char *kCTHermesTombstonePathsC[5] = {
    "/var/tmp/.ctHermesUninstalling",
    "/tmp/.ctHermesUninstalling",
    "/var/mobile/Library/Logs/.ctHermesUninstalling",
    "/var/jb/var/mobile/Library/Logs/.ctHermesUninstalling",
    "/var/jb/Library/Logs/.ctHermesUninstalling"
};
#endif
static inline BOOL CTHermesUninstalling(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSMutableArray<NSString *> *ps = [NSMutableArray array];
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.6 隐根干净版：墓碑 = 容器内（脚本把碑立在容器里）+ 旧宿主路径（跨版本容错）
    NSString *rh = CTHermesCurrentRootHideRoot();
    if (rh.length > 0) {
        [ps addObject:[rh stringByAppendingPathComponent:S("var/tmp/.ctHermesUninstalling")]];
        [ps addObject:[rh stringByAppendingPathComponent:S("var/mobile/Library/Logs/.ctHermesUninstalling")]];
        [ps addObject:[rh stringByAppendingPathComponent:S("Library/Logs/.ctHermesUninstalling")]];
    }
    [ps addObject:S("/var/tmp/.ctHermesUninstalling")];
    [ps addObject:S("/tmp/.ctHermesUninstalling")];
    [ps addObject:S("/var/mobile/Library/Logs/.ctHermesUninstalling")];
#else
    for (int i = 0; i < 5; i++) [ps addObject:[NSString stringWithUTF8String:kCTHermesTombstonePathsC[i]]];
#endif
    for (NSString *p in ps) {
        if (![fm fileExistsAtPath:p]) continue;
        NSDictionary *attrs = [fm attributesOfItemAtPath:p error:nil];
        NSDate *mtime = attrs[NSFileModificationDate];
        if (mtime && [[NSDate date] timeIntervalSinceDate:mtime] > 12.0 * 3600.0) continue;   // 陈旧墓碑自动失效
        return YES;
    }
    return NO;
}

// ★ 1.4.102：卸载"自清" —— 由活着的组件（本进程所在这一层 = 用户可见层）删除本插件的全部残留
static inline void CTHermesWipeLeftovers(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSMutableArray *dirs = [NSMutableArray arrayWithArray:@[
        @"/var/mobile/Library/Logs",
        @"/var/mobile/Library/Preferences",
        @"/var/mobile/Library/Preferences/ByHost",
        @"/var/mobile/Library/Caches",
        @"/var/mobile/Library",
        @"/var/tmp", @"/var/tmp/CTHermes", @"/tmp"
    ]];
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.6 隐根干净版：容器内的家目录排最前（卸载清残留 = 容器 + 宿主两层都扫）
    {
        NSString *rh = CTHermesCurrentRootHideRoot();
        if (rh.length > 0) {
            NSArray *rel = @[@"var/mobile/Library/Logs", @"var/mobile/Library/Preferences",
                             @"var/mobile/Library/Preferences/ByHost", @"var/mobile/Library/Caches",
                             @"var/mobile/Library", @"var/tmp", @"var/tmp/CTHermes", @"tmp"];
            NSMutableArray *m = [NSMutableArray array];
            for (NSString *r in rel) [m addObject:[rh stringByAppendingPathComponent:r]];
            [m addObjectsFromArray:dirs];
            dirs = m;
        }
    }
#endif
    // ★ 安全红线：只认"我们自己的名字"（白名单前缀）—— 绝不碰任何第三方/其他插件的文件
    NSArray *prefixes = @[
        @"CTHermes", @"CPUthermal", @"core-paths.txt", @"com.qq391160.cpucore",
        @"com.qq391160.cpusentry", @"com.qq391160.thermal"
    ];
    for (NSString *dir in dirs) {
        NSArray *items = [fm contentsOfDirectoryAtPath:dir error:nil];
        for (NSString *name in items) {
            if ([name hasSuffix:@".deb"]) continue;
            BOOL hit = NO;
            for (NSString *p in prefixes) { if ([name hasPrefix:p]) { hit = YES; break; } }
            if (!hit) continue;
            [fm removeItemAtPath:[dir stringByAppendingPathComponent:name] error:nil];
        }
    }
}

static inline void CTHermesEnsurePrefDirectory(void) {
    NSString *path = CTHermesCurrentPrefPath();
    if (!path.length) return;
    NSString *directory = [path stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:nil];
#ifdef CT_SCHEME_ROOTHIDE
    chmod(directory.fileSystemRepresentation, 01777);   // ★ 2.0.110：工作目录跨进程可写（与 run/logs 同权）
#endif
}

static inline NSMutableDictionary *CTHermesReadMutablePrefs(void) {
    NSString *path = CTHermesCurrentPrefPath();
    NSFileManager *fileManager = [NSFileManager defaultManager];
    // ★ 2.0.38：全副本"取最新"——某些进程视图里"主路径"可能是陈旧/空副本，
    //   旧逻辑"主路径存在就直接用"会误判（跨进程配置不一致 / 核心误待命）。
    NSMutableArray<NSString *> *ctCand = [NSMutableArray array];
    if (path.length) [ctCand addObject:path];
    for (NSString *p in CTHermesLegacyPrefPaths()) {
        if (p.length && ![ctCand containsObject:p]) [ctCand addObject:p];
    }
    NSString *ctBestPath = nil;
    NSDictionary *ctBestPrefs = nil;
    NSDate *ctBestDate = nil;
    NSMutableArray *ctAll = [NSMutableArray array];   // ★ 2.0.111：读取端合并
    for (NSString *p in ctCand) {
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p];
        if (![d isKindOfClass:[NSDictionary class]] || !d.count) continue;
        NSDate *m = [[fileManager attributesOfItemAtPath:p error:NULL] fileModificationDate] ?: [NSDate distantPast];
        [ctAll addObject:@[d, m]];
        if (!ctBestPrefs || [m compare:ctBestDate] == NSOrderedDescending) {
            ctBestPrefs = d;
            ctBestDate = m;
            ctBestPath = p;
        }
    }
    if (ctBestPrefs) {
        // ★ 2.0.111：合并——每个键取"拥有它的最新副本"的值（任意副本残缺都不会丢键）
        NSMutableDictionary *prefs = [NSMutableDictionary dictionary];
        NSMutableDictionary *ctKeyTime = [NSMutableDictionary dictionary];
        for (NSArray *ctE in ctAll) {
            NSDictionary *ctD = ctE[0]; NSDate *ctM = ctE[1];
            for (id ctK in ctD) {
                NSDate *ctOld = ctKeyTime[ctK];
                if (!ctOld || [ctM compare:ctOld] == NSOrderedDescending) { ctKeyTime[ctK] = ctM; prefs[ctK] = ctD[ctK]; }
            }
        }
        // ★ 1.4.9：迁移到主路径后**保留**旧副本（不再删除）——删除是授权码丢失的元凶
        if (![ctBestPath isEqualToString:path] && !CTHermesUninstalling()) {
            CTHermesEnsurePrefDirectory();
            BOOL __w = [prefs writeToFile:path atomically:YES];   // ★ 1.4.102：卸载中不迁移
#ifdef CT_SCHEME_ROOTHIDE
            if (!__w) __w = [prefs writeToFile:path atomically:NO];   // ★ 2.0.110b：粘滞目录退化直写
            if (__w) { chmod(path.fileSystemRepresentation, 0666); chown(path.fileSystemRepresentation, 501, 501); }
#endif
        }
        return prefs;
    }
    return nil;
}

// ★ 2.0.112：写盘兜底——主家（Library/CTHermesState）写不进时（16.x 桌面侧沙盒），
//   补写一份到 97 时代"桌面侧写得进"的老路（<隐根>/var/mobile/Library/Preferences/…）；
//   读端 CTHermesLegacyPrefPaths 本就扫它并按"最新合并"，补写即全网可见、不丢任何键。
static inline BOOL CTHermesBridgePrefsCopy(NSDictionary *prefs) {
#ifdef CT_SCHEME_ROOTHIDE
    if (![prefs isKindOfClass:[NSDictionary class]] || !prefs.count) return NO;
    @try {
        NSString *rh = CTHermesCurrentRootHideRoot();
        if (!rh.length) return NO;
        NSString *dir = [rh stringByAppendingPathComponent:S("var/mobile/Library/Preferences")];
        NSString *alt = [dir stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")];
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
        BOOL ok = [prefs writeToFile:alt atomically:YES];
        if (!ok) ok = [prefs writeToFile:alt atomically:NO];
        if (ok) {
            chmod(alt.fileSystemRepresentation, 0666);
            chown(alt.fileSystemRepresentation, 501, 501);
        }
        return ok;
    } @catch (__unused NSException *e) { return NO; }
#else
    (void)prefs;
    return NO;
#endif
}

// ★ 2.0.111：直写版（仅供"重置授权"——允许真正清空；其它一切写入一律走合并版 WritePrefs）
static inline BOOL CTHermesWritePrefsReplace(NSDictionary *prefs) {
    if (!prefs) return NO;
    if (CTHermesUninstalling()) return YES;
    NSString *path = CTHermesCurrentPrefPath();
    if (!path.length) return NO;
    CTHermesEnsurePrefDirectory();
    BOOL ok = [prefs writeToFile:path atomically:YES];
#ifdef CT_SCHEME_ROOTHIDE
    if (!ok) ok = [prefs writeToFile:path atomically:NO];
    if (ok) { chmod(path.fileSystemRepresentation, 0666); chown(path.fileSystemRepresentation, 501, 501); }
#endif
    return ok;
}

static inline NSDictionary *CTHermesReadPrefs(void) {
    return CTHermesReadMutablePrefs();
}

static inline BOOL CTHermesWritePrefs(NSDictionary *prefs) {
    if (!prefs) {
        return NO;
    }
    if (CTHermesUninstalling()) return YES;   // ★ 1.4.102：卸载中 → 全组件停写（防"复活"）

    NSString *path = CTHermesCurrentPrefPath();
    if (!path.length) return NO;
    CTHermesEnsurePrefDirectory();
    NSDictionary *__wrkPrefs = prefs;
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.111：写端防清空——落盘前与"现存配置"合并（空的/残缺的写入不可能再清掉设置）
    {
        NSMutableDictionary *ctCF = [NSMutableDictionary dictionary];
        NSMutableDictionary *ctKT = [NSMutableDictionary dictionary];
        NSMutableArray *ctWS = [NSMutableArray arrayWithObject:path];
        for (NSString *p in CTHermesLegacyPrefPaths()) { if (p.length && ![ctWS containsObject:p]) [ctWS addObject:p]; }
        NSFileManager *ctFM = [NSFileManager defaultManager];
        for (NSString *p in ctWS) {
            NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p];
            if (![d isKindOfClass:[NSDictionary class]] || !d.count) continue;
            NSDate *m = [[ctFM attributesOfItemAtPath:p error:NULL] fileModificationDate] ?: [NSDate distantPast];
            for (id k in d) { NSDate *old = ctKT[k]; if (!old || [m compare:old] == NSOrderedDescending) { ctKT[k] = m; ctCF[k] = d[k]; } }
        }
        for (id k in prefs) ctCF[k] = prefs[k];
        if (ctCF.count) __wrkPrefs = ctCF;
    }
#endif
    BOOL ok = [__wrkPrefs writeToFile:path atomically:YES];
#ifdef CT_SCHEME_ROOTHIDE
    // ★ 2.0.110/111：单一写盘；原子失败退化直写；属主交给 mobile
    if (!ok) ok = [__wrkPrefs writeToFile:path atomically:NO];
    if (ok) {
        chmod(path.fileSystemRepresentation, 0666);
        chown(path.fileSystemRepresentation, 501, 501);
    } else {
        // ★ 2.0.112：主家写不进（16.x 桌面侧沙盒）→ 兜底写"老路"副本（读端合并清单已含它）
        ok = CTHermesBridgePrefsCopy(__wrkPrefs);
    }
    return ok;
#else
    if (!ok) return NO;
    // 无根：维持原有"多份互备"行为（本版不动无根）
    NSFileManager *fileManager = [NSFileManager defaultManager];
    for (NSString *legacyPath in CTHermesWritablePrefPaths()) {
        if ([legacyPath isEqualToString:path]) continue;
        NSString *dir = [legacyPath stringByDeletingLastPathComponent];
        if (dir.length > 0) {
            [fileManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
        }
        [prefs writeToFile:legacyPath atomically:YES];
    }
    return YES;
#endif
}



// ============================================================================
// ★ 2.0.109 体检版：路径自检 + 干跑清单（只读；不删/不迁/不动任何文件）
// ============================================================================
static inline NSString *CTHermesAuditReport(NSString *comp) {
    @try {
#ifdef CT_SCHEME_ROOTHIDE
        NSString *scheme = S("roothide");
#else
        NSString *scheme = S("rootless");
#endif
        const char *jbp = jbroot("/usr/bin/CTHermesTool");
        NSString *rh = CTHermesCurrentRootHideRoot();
        NSString *tool = CTHermesToolPath();
        NSString *pref = CTHermesCurrentPrefPath();
        NSString *dd = CTDiagLogDir();
        return [NSString stringWithFormat:
            S("[路径体检] 组件=%@ proc=%s 方案=%@ jbroot=%s 根=%@ 工具=%@ 配置=%@ 日志=%@"),
            comp.length ? comp : S("-"), getprogname(), scheme,
            (jbp && jbp[0]) ? jbp : "(null)",
            rh.length ? rh : S("-"),
            tool.length ? tool : S("未找到"),
            pref.length ? pref : S("-"),
            dd.length ? dd : S("-")];
    } @catch (__unused NSException *e) {
        return [NSString stringWithFormat:S("[路径体检] 组件=%@ 报告失败(异常捕获)"), comp.length ? comp : S("-")];
    }
}

// 干跑清单：把"已知旧位置"里的自家文件盘点写进独立文件（CTHermesPathAudit.txt；不轮转、不删任何东西）
static inline NSString *CTHermesDryRunAuditWrite(void) {
    @try {
        if (CTHermesUninstalling()) return S("[路径体检] 干跑清单跳过（卸载中）");
        NSFileManager *fm = [NSFileManager defaultManager];
        NSMutableArray<NSString *> *roots = [NSMutableArray array];
        NSString *rh = CTHermesCurrentRootHideRoot();
        if (rh.length) [roots addObject:rh];
        NSArray *bases = @[S("/var/mobile/Containers/Shared/AppGroup"),
                           S("/var/containers/Bundle/Application"),
                           S("/var/containers/Shared/SystemGroup"),
                           S("/var/mobile/Library"),
                           S("/var/mobile/Containers/Data/Application")];
        for (NSString *b in bases) {
            for (NSString *e in ([fm contentsOfDirectoryAtPath:b error:NULL] ?: @[])) {
                if (![e hasPrefix:S(".jbroot-")]) continue;
                NSString *r = [b stringByAppendingPathComponent:e];
                if (![roots containsObject:r]) [roots addObject:r];
            }
        }
        NSArray *relDirs = @[S("Library/CTHermesState/logs"), S("Library/CTHermesState/run"),
                             S("Library/CTKeptLogs"), S("Library/Logs"),
                             S("var/mobile/Library/Logs"), S("var/mobile/Library/Caches/CTHermes"),
                             S("var/tmp/CTHermes/run"), S("tmp/CTHermes")];
        NSArray *names = @[S("CTHermesDiag.log"), S("CTHermesFallback.log"), S("CTHermesInstall.log"),
                           S("CTHermesBright.log"), S("CTHermesStatus.txt"), S("CTHermesNet.txt"),
                           S("CTHermesDirect.txt"), S("CTHermesSelfTest.txt"), S("CTHermesSelfTest.req"),
                           S("CTHermesAppearance.txt"), S("CTHermesSuspects.plist"), S("CTHermesTables.txt"),
                           S("CTHermesFreqProbe.txt"), S("CTHermesCleanup.done"), S("core-paths.txt")];
        NSMutableArray<NSString *> *lines = [NSMutableArray array];
        NSInteger nSelf = 0, nOther = 0, nHost = 0;
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = @"MM-dd HH:mm";
        for (NSString *r in roots) {
            BOOL inSelf = [r isEqualToString:rh];
            for (NSString *rd in relDirs) {
                NSString *d = [r stringByAppendingPathComponent:rd];
                BOOL isDir = NO;
                if (![fm fileExistsAtPath:d isDirectory:&isDir] || !isDir) continue;
                for (NSString *n in ([fm contentsOfDirectoryAtPath:d error:NULL] ?: @[])) {
                    BOOL own = NO;
                    for (NSString *p in names) { if ([n hasPrefix:p]) { own = YES; break; } }
                    if (!own) continue;
                    NSString *full = [d stringByAppendingPathComponent:n];
                    NSDictionary *at = [fm attributesOfItemAtPath:full error:NULL];
                    [lines addObject:[NSString stringWithFormat:@"[存在] %@ | %lldB | %@ | %@",
                                      full, [at[NSFileSize] longLongValue], [df stringFromDate:(at[NSFileModificationDate] ?: [NSDate distantPast])],
                                      inSelf ? @"本层" : @"其它层"]];
                    if (inSelf) nSelf++; else nOther++;
                }
            }
        }
        NSArray *hostDirs = @[S("/var/mobile/Library/Logs"), S("/var/mobile/Library/Caches/CTHermes"),
                              S("/var/tmp/CTHermes/run"), S("/tmp/CTHermes")];
        for (NSString *d in hostDirs) {
            BOOL isDir = NO;
            if (![fm fileExistsAtPath:d isDirectory:&isDir] || !isDir) continue;
            for (NSString *n in ([fm contentsOfDirectoryAtPath:d error:NULL] ?: @[])) {
                BOOL own = NO;
                for (NSString *p in names) { if ([n hasPrefix:p]) { own = YES; break; } }
                if (!own) continue;
                NSDictionary *at = [fm attributesOfItemAtPath:[d stringByAppendingPathComponent:n] error:NULL];
                [lines addObject:[NSString stringWithFormat:@"[存在] %@ | %lldB | 宿主层",
                                  [d stringByAppendingPathComponent:n], [at[NSFileSize] longLongValue]]];
                nHost++;
            }
        }
        NSArray *hostFiles = @[S("/var/mobile/Library/Preferences/com.qq391160.cpucore.plist"),
                               S("/var/jb/Library/Preferences/com.qq391160.cpucore.plist"),
                               S("/var/jb/var/mobile/Library/Preferences/com.qq391160.cpucore.plist")];
        for (NSString *f in hostFiles) {
            if (![fm fileExistsAtPath:f]) continue;
            NSDictionary *at = [fm attributesOfItemAtPath:f error:NULL];
            [lines addObject:[NSString stringWithFormat:@"[存在] %@ | %lldB | 宿主/旧根", f, [at[NSFileSize] longLongValue]]];
            nHost++;
        }
        NSDateFormatter *dfH = [[NSDateFormatter alloc] init];
        dfH.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSMutableString *out = [NSMutableString string];
        [out appendString:@"\n==== CPU智能温控 · 路径干跑清单（2.0.110）====\n"];
        [out appendFormat:@"时间：%@ | proc=%s | 本进程根：%@\n", [dfH stringFromDate:[NSDate date]], getprogname(), rh.length ? rh : @"-"];
        [out appendString:@"说明：只读盘点——不删除、不迁移、不改动任何文件；系统正身（SystemConfiguration）不在本清单内。\n"];
        [out appendFormat:@"--- 发现（共 %lu 条：本层 %ld / 其它层 %ld / 宿主 %ld）---\n",
                          (unsigned long)lines.count, (long)nSelf, (long)nOther, (long)nHost];
        for (NSString *l in lines) [out appendFormat:@"%@\n", l];
        if (lines.count == 0) [out appendString:@"（干净：已知旧位置未发现自家文件）\n"];
        [out appendString:@"==== END ====\n"];
        NSString *outPath = [CTDiagLogDir() stringByAppendingPathComponent:S("CTHermesPathAudit.txt")];
        NSDictionary *exist = [fm attributesOfItemAtPath:outPath error:NULL];
        if (exist && [exist[NSFileSize] longLongValue] > 512 * 1024) [fm removeItemAtPath:outPath error:NULL];
        FILE *f = fopen(outPath.fileSystemRepresentation, "a");
        if (f) { fputs(out.UTF8String, f); fclose(f); chmod(outPath.fileSystemRepresentation, 0644); }
        return [NSString stringWithFormat:S("[路径体检] 干跑清单已写入（共 %lu 条：本层 %ld / 其它层 %ld / 宿主 %ld）→ %@"),
                (unsigned long)lines.count, (long)nSelf, (long)nOther, (long)nHost, outPath];
    } @catch (__unused NSException *e) {
        return S("[路径体检] 干跑清单异常（已捕获，不影响功能）");
    }
}

#endif
