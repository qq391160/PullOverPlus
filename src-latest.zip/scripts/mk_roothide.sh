#!/bin/sh
# ============================================================
# CPU 智能温控 · 2.0.99 隐根干净版 —— roothide 构建前置转换
#   ★ 只在"隐根构建"步骤里执行；无根（rootless）构建完全不受影响
#   做什么：
#     1) 全局惰性化 /var/jb 字符串（隐根不需要该路径；防"运行即创建宿主 /var/jb"）
#     2) Makefile 调整：去掉 /var/jb rpath、补 roothide 库与 CT_SCHEME_ROOTHIDE 宏
#     3) 布局 plist 去 /var/jb；DEBIAN 脚本换用隐根专用三件套
#     4) 审计：全树 /var/jb 必须清零，否则中止构建
# ============================================================
set -e
cd "$(dirname "$0")/.."

# sed -i 便携封装（macOS=BSD / Linux=GNU；函数式避免引号陷阱）
if sed --version >/dev/null 2>&1; then
    SEDI() { sed -i "$@"; }
else
    SEDI() { sed -i '' "$@"; }
fi

echo "== [1/4] 惰性化源码里的 /var/jb =="
for f in Tweak.x ForegroundMode.xm StatusWindow.xm FaceDownLock.xm CCRegistration.xm ProMotion.xm BatteryUI.xm CTHermesDisplay.xm \
         include/*.h Settings/*.m Settings/*.plist Tools/*.m ControlCenter/*.m *.plist \
         scripts/postinst.in scripts/prerm.in; do
    [ -f "$f" ] || continue
    SEDI 's|var/jb|vaXjb|g' "$f" 2>/dev/null || true
done

echo "== [1.5/4] 权限修复（BSD sed -i 在 macOS 会丢权限：plist 变 600 → mobile 注入被跳过）=="
chmod 644 *.plist 2>/dev/null || true
chmod 644 Settings/*.plist 2>/dev/null || true

echo "== [2/4] Makefile：隐根链接调整 =="
SEDI 's|^RPR = .*|RPR =|' Makefile
SEDI 's|^TWEAKL = .*|TWEAKL = -Wl,-undefined,dynamic_lookup -L$(THEOS_VENDOR_LIBRARY_PATH)/iphone/roothide -lroothide|' Makefile
SEDI 's|^ROOTL = .*|ROOTL = -Wl,-undefined,dynamic_lookup -L$(THEOS_VENDOR_LIBRARY_PATH)/iphone/roothide -lroothide|' Makefile
SEDI 's|^PTFLAGS.*$|PTFLAGS = -DCT_SCHEME_ROOTHIDE=1|' Makefile
SEDI 's|var/jb|vaXjb|g' Makefile   # 注释等剩余字样一并惰性化
TH="${THEOS:-$HOME/theos}"
mkdir -p "$TH/vendor/lib/iphone/roothide" 2>/dev/null || true
cp "$TH/lib/iphone/libroothide.tbd" "$TH/vendor/lib/iphone/roothide/" 2>/dev/null || true
cp "$TH/lib/iphone/libsubstrate.tbd" "$TH/vendor/lib/iphone/roothide/" 2>/dev/null || true

echo "== [3/4] 布局：plist 去 /var/jb；换隐根专用 DEBIAN 脚本 =="
SEDI 's|/var/jb/|/|g' layout/Library/LaunchDaemons/*.plist 2>/dev/null || true
SEDI 's|var/jb|vaXjb|g' layout/Library/LaunchDaemons/*.plist 2>/dev/null || true
cp -f layout-roothide/DEBIAN/postinst layout/DEBIAN/postinst
cp -f layout-roothide/DEBIAN/prerm    layout/DEBIAN/prerm
cp -f layout-roothide/DEBIAN/postrm   layout/DEBIAN/postrm
chmod 755 layout/DEBIAN/postinst layout/DEBIAN/prerm layout/DEBIAN/postrm

echo "== [3.5/4] 兜底清扫：任何仍含 var/jb 的文本文件一并惰性化 =="
grep -rIl -- "var/jb" . 2>/dev/null | grep -v "mk_roothide.sh" | while read -r f; do
    SEDI 's|var/jb|vaXjb|g' "$f" 2>/dev/null || true
done

echo "== [4/4] 审计：全树 /var/jb 必须为零 =="
CNT=$(grep -rn "var/jb" . 2>/dev/null | grep -v "Binary" | grep -v "mk_roothide" | wc -l)
echo "剩余 /var/jb 出现 = $CNT（应为 0）"
if [ "$CNT" -ne 0 ]; then
    echo "!! 仍有残留："; grep -rn "var/jb" . 2>/dev/null | grep -v "Binary" | grep -v "mk_roothide" | head -20
    exit 1
fi
echo "OK 隐根转换完成（0 处 /var/jb）"
