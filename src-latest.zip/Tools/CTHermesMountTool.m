#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <errno.h>
#import <sys/mount.h>
#import <sys/stat.h>
#import <sys/sysctl.h>
#import <spawn.h>
#import <stdlib.h>
#import <sys/wait.h>
#import <unistd.h>
#import <CTHermesPaths.h>
#import <CTHermesSmart.h>

typedef int (*StealUcredFn)(uint64_t, uint64_t *);
typedef int (*InitPPLRWFn)(void);
static NSString *MountListPath(void) {
    NSString *currentPref=CTHermesCurrentPrefPath();
    NSString *current=[[currentPref stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("CTHermesMounts.plist")];
    NSFileManager *fm=[NSFileManager defaultManager];
    if ([fm fileExistsAtPath:current]) return current;
    // RootHide UUID 变化时，挂载记录与偏好相邻存储；从所有旧 UUID 根中取最新有效记录迁移。
    NSString *newest=nil; NSDate *newestDate=nil;
    for (NSString *oldPref in CTHermesLegacyPrefPaths()) {
        NSString *candidate=[[oldPref stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("CTHermesMounts.plist")];
        NSDictionary *list=[NSDictionary dictionaryWithContentsOfFile:candidate];
        if (![list[S("paths")] isKindOfClass:[NSArray class]]) continue;
        NSDate *date=[fm attributesOfItemAtPath:candidate error:nil][NSFileModificationDate]?:[NSDate distantPast];
        if (!newest || [date compare:newestDate]==NSOrderedDescending) { newest=candidate; newestDate=date; }
    }
    if (newest) { [fm createDirectoryAtPath:[current stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil]; [fm copyItemAtPath:newest toPath:current error:nil]; }
    return current;
}
static NSString *StandardPath(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return nil;
    NSString *p = [[raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] stringByStandardizingPath];
    if (![p hasPrefix:S("/")] || [p isEqualToString:S("/")] || [p hasPrefix:S("/var/mobile/Containers/Shared/AppGroup/.jbroot-")]) return nil;
    NSArray *blocked = @[S("/System"), S("/private/preboot"), S("/var/jb"), S("/Applications")];
    for (NSString *root in blocked) if ([p isEqualToString:root]) return nil;
    return p;
}
static NSMutableArray *LoadPaths(void) {
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:MountListPath()];
    NSArray *a = [d[S("paths")] isKindOfClass:[NSArray class]] ? d[S("paths")] : nil;
    return a ? [a mutableCopy] : [NSMutableArray array];
}
static BOOL SavePaths(NSArray *paths) {
    NSString *file = MountListPath();
    if (!file) return NO;
    [[NSFileManager defaultManager] createDirectoryAtPath:[file stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
    return [@{S("paths"): paths ?: @[]} writeToFile:file atomically:YES];
}
static NSString *MountStorageRoot(void) {
#ifdef CPUTHERMAL_ROOTLESS_MOUNT
    return S("/var/jb");
#else
    return CTHermesCurrentRootHideRoot();
#endif
}
static NSString *StoragePath(NSString *path) {
    NSString *root = MountStorageRoot();
    if (!root.length || ![path hasPrefix:S("/")]) return nil;
    return [[root stringByAppendingPathComponent:S("var/lib/cputhermal-mount")] stringByAppendingPathComponent:[path substringFromIndex:1]];
}
static BOOL IsMounted(NSString *path, BOOL ownOnly) {
    struct statfs info = {0};
    if (statfs(path.fileSystemRepresentation, &info) != 0) return NO;
    BOOL point = strcmp(info.f_mntonname, path.fileSystemRepresentation) == 0;
    if (!ownOnly) return point;
    NSString *src = [NSString stringWithUTF8String:info.f_mntfromname];
    NSString *storage = StoragePath(path);
    return point && strcmp(info.f_fstypename, "bindfs") == 0 && storage.length && [[src stringByStandardizingPath] isEqualToString:[storage stringByStandardizingPath]];
}
static int MakeStorageWritable(NSString *storage) {
    NSFileManager *fm=[NSFileManager defaultManager]; NSArray *items=[@[storage] arrayByAddingObjectsFromArray:[fm subpathsAtPath:storage]?:@[]];
    for(NSString *relative in items) {
        NSString *item=[relative isEqualToString:storage]?storage:[storage stringByAppendingPathComponent:relative]; struct stat st={0};
        if(lstat(item.fileSystemRepresentation,&st)!=0)continue; if(S_ISLNK(st.st_mode))continue;
        mode_t mode=st.st_mode&07777; mode|=S_IWUSR|S_IWGRP|S_IWOTH; if(S_ISDIR(st.st_mode))mode|=S_IXUSR|S_IXGRP|S_IXOTH;
        if(chmod(item.fileSystemRepresentation,mode)!=0)return errno;
    }
    return 0;
}
static int PrepareStorage(NSString *path) {
    NSString *storage = StoragePath(path);
    if (!storage.length) return 80;
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL directory = NO;
    if (![fm fileExistsAtPath:path isDirectory:&directory] || !directory) return ENOENT;
    if ([fm fileExistsAtPath:storage]) return MakeStorageWritable(storage);
    NSError *error = nil;
    if (![fm createDirectoryAtPath:[storage stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&error]) return (int)(error.code ?: EIO);
    NSString *tmp = [storage stringByAppendingString:S(".mounting")];
    [fm removeItemAtPath:tmp error:nil];
    if (![fm copyItemAtPath:path toPath:tmp error:&error]) return (int)(error.code ?: EIO);
    int permissions=MakeStorageWritable(tmp); if(permissions){[fm removeItemAtPath:tmp error:nil];return permissions;}
    if (![fm moveItemAtPath:tmp toPath:storage error:&error]) { [fm removeItemAtPath:tmp error:nil]; return (int)(error.code ?: EIO); }
    return 0;
}
static void *OpenLibjailbreak(void) {
    const char *candidates[] = { jbroot("/basebin/libjailbreak.dylib"), jbroot("/usr/lib/libjailbreak.dylib"), "/var/jb/basebin/libjailbreak.dylib", "/var/jb/usr/lib/libjailbreak.dylib", NULL };
    for (int i=0; candidates[i]; i++) if (access(candidates[i], R_OK)==0) { void *h=dlopen(candidates[i],RTLD_NOW|RTLD_LOCAL); if(h) return h; }
    return NULL;
}
static int WithKernelCredentials(int (^op)(void)) {
    void *h=OpenLibjailbreak(); if(!h) return 90;
    InitPPLRWFn init=(InitPPLRWFn)dlsym(h,"jbdInitPPLRW"); if(init) init();
    StealUcredFn steal=(StealUcredFn)dlsym(h,"jbclient_root_steal_ucred"); if(!steal){dlclose(h);return 91;}
    uint64_t old=0; int r=steal(0,&old); if(r==0){r=op(); int rr=steal(old,NULL); if(r==0&&rr)r=92;} dlclose(h); return r;
}
static NSString *JbctlPath(void) {
    const char *candidates[]={jbroot("/basebin/jbctl"),jbroot("/usr/bin/jbctl"),"/var/jb/basebin/jbctl","/var/jb/usr/bin/jbctl",NULL};
    for(int i=0;candidates[i];i++)if(access(candidates[i],X_OK)==0)return S(candidates[i]); return nil;
}
static int RunJbctl(NSString *command,NSString *path) {
    NSString *tool=JbctlPath(); if(!tool.length)return 230; pid_t pid=0; int status=0;
    char *args[]={(char*)"jbctl",(char*)"internal",(char*)command.UTF8String,(char*)path.fileSystemRepresentation,NULL};
    int r=posix_spawn(&pid,tool.fileSystemRepresentation,NULL,NULL,args,NULL); if(r)return 231; if(waitpid(pid,&status,0)<0)return 232;
    return WIFEXITED(status)?WEXITSTATUS(status):233;
}
static BOOL IsBindfsMounted(NSString *path) { struct statfs i={0}; return statfs(path.fileSystemRepresentation,&i)==0&&strcmp(i.f_mntonname,path.fileSystemRepresentation)==0&&strcmp(i.f_fstypename,"bindfs")==0; }
static int UnmountPath(NSString *path);
static int MountPath(NSString *path) {
    if (!MountStorageRoot().length) return 79;
    if (IsBindfsMounted(path)) {
        struct statfs current={0}; statfs(path.fileSystemRepresentation,&current);
        NSString *source=S(current.f_mntfromname); NSString *expected=StoragePath(path);
        // UUID 变化后旧 bindfs 后备源不能继续沿用：先卸载并在当前动态根重建。
        BOOL sourceMatches=source.length&&expected.length&&[[source stringByStandardizingPath] isEqualToString:[expected stringByStandardizingPath]];
        if ((current.f_flags&MNT_RDONLY)||!sourceMatches) { int u=UnmountPath(path); if(u)return u; }
        else { int p=MakeStorageWritable(expected); return p?100+p:0; }
    }
    if (IsMounted(path,NO)) return EBUSY;
    NSString *storage=StoragePath(path);
    int direct=WithKernelCredentials(^int{ int p=PrepareStorage(path); if(p)return 100+p; int m=mount("bindfs",path.fileSystemRepresentation,0,(void *)storage.fileSystemRepresentation); return m==0?0:200+errno; });
    return (direct==0&&IsBindfsMounted(path))?0:direct;
}
static int UnmountPath(NSString *path) {
    if (!IsMounted(path,NO)) return 0; if(!IsBindfsMounted(path))return EBUSY;
    int official=RunJbctl(S("unmount"),path); if(official==0&&!IsMounted(path,NO))return 0;
    int direct=WithKernelCredentials(^int{ return unmount(path.fileSystemRepresentation,MNT_FORCE)==0?0:200+errno; });
    if(direct==0)return 0; if(official==255||official==64||official==42||official==230)return direct; return official;
}
static int AddPath(NSString *path) { NSMutableArray *a=LoadPaths(); if(![a containsObject:path])[a addObject:path]; if(!SavePaths(a))return EIO; return MountPath(path); }
static int RemovePath(NSString *path) { int r=UnmountPath(path); if(r)return r; NSMutableArray *a=LoadPaths(); [a removeObject:path]; return SavePaths(a)?0:EIO; }

// ★ 2.0.92：任务退役兜底——老"温控表挂载"记录若有：逐条卸下 + 清零 + 清自家存储；无记录=完全静默跳过
static int RetireStaleMounts(void) {
    NSMutableArray *paths = LoadPaths();
    if (paths.count > 0) {
        int failed = 0;
        for (NSString *p in paths) { if (UnmountPath(p) != 0) failed++; }
        SavePaths(@[]);
        NSString *root = MountStorageRoot();
        if (root.length) {
            NSFileManager *fm = [NSFileManager defaultManager];
            [fm removeItemAtPath:[root stringByAppendingPathComponent:S("var/lib/cputhermal-mount")] error:nil];
            [fm removeItemAtPath:[root stringByAppendingPathComponent:S("var/lib/cputhermal-scheduler-backup")] error:nil];
        }
        CTHermesSmartDiagLog([NSString stringWithFormat:S("[退役] 老挂载记录清理：卸下=%lu 失败=%d"), (unsigned long)paths.count, failed]);
    } else {
        NSString *thermal = S("/System/Library/ThermalMonitor");
        if (IsMounted(thermal, YES)) {
            UnmountPath(thermal);
            CTHermesSmartDiagLog(S("[退役] 记录为空但发现遗留挂载：已卸下"));
        }
    }
    return 0;
}
static int RemountAll(void) { int last=0; for(NSString *p in LoadPaths()){int r=MountPath(p);if(r)last=r;} return last; }
static NSString *RequestDirectory(void) { return [[MountListPath() stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("CTHermesMountRequests")]; }
static NSString *KillallPath(void) {
    return CTHermesExistingExecutablePath("/usr/bin/killall", @[
        S("/var/jb/usr/bin/killall"), S("/var/jb/bin/killall"),
        S("/usr/bin/killall"), S("/bin/killall")
    ]);
}
static int RestartThermalMonitor(void){
    NSString *tool=KillallPath(); if(!tool.length)return 2;
    pid_t p=0; char*a[]={(char*)"killall",(char*)"-q",(char*)"thermalmonitord",NULL};
    int r=posix_spawn(&p,tool.fileSystemRepresentation,NULL,NULL,a,NULL);
    // 调度文件已原子写入；只需成功派发重启，不能在守护自身请求线程 waitpid。
    return r;
}

static NSString *SchedulerBackupRoot(void){NSString *root=MountStorageRoot();return root.length?[root stringByAppendingPathComponent:S("var/lib/cputhermal-scheduler-backup")]:nil;}
static BOOL BackupOnce(NSString*f,NSString*n){NSString*d=SchedulerBackupRoot();if(!d.length)return NO;NSFileManager*fm=NSFileManager.defaultManager;[fm createDirectoryAtPath:d withIntermediateDirectories:YES attributes:nil error:nil];NSString*b=[d stringByAppendingPathComponent:n];return [fm fileExistsAtPath:b]||[fm copyItemAtPath:f toPath:b error:nil];}
static NSString *CurrentHardwareModel(void) {
    size_t size=0; if(sysctlbyname("hw.model",NULL,&size,NULL,0)!=0 || size<2)return nil;
    char *buffer=calloc(1,size); if(!buffer)return nil;
    NSString *model=nil; if(sysctlbyname("hw.model",buffer,&size,NULL,0)==0 && buffer[0])model=S(buffer);
    free(buffer); return model;
}
static NSString *ModelFile(NSString*t){
    NSFileManager *fm=NSFileManager.defaultManager;
    NSArray *names=[fm contentsOfDirectoryAtPath:t error:nil];
    NSString *hardware=CurrentHardwareModel();
    if(hardware.length) {
        NSString *exact=[hardware stringByAppendingString:S("-Info.plist")];
        if([names containsObject:exact])return[t stringByAppendingPathComponent:exact];
    }
    NSMutableArray *matches=[NSMutableArray array];
    for(NSString*n in names)if([n hasSuffix:S("AP-Info.plist")])[matches addObject:n];
    return matches.count==1?[t stringByAppendingPathComponent:matches.firstObject]:nil;
}
static void SetExisting(NSMutableDictionary *dictionary, NSString *key, id value) {
    if ([dictionary isKindOfClass:[NSMutableDictionary class]] && dictionary[key] != nil) dictionary[key] = value;
}
static id MutableTree(id value) {
    if ([value isKindOfClass:[NSDictionary class]]) { NSMutableDictionary *d=[NSMutableDictionary dictionary]; for(id k in value)d[k]=MutableTree(value[k])?:[NSNull null]; return d; }
    if ([value isKindOfClass:[NSArray class]]) { NSMutableArray *a=[NSMutableArray array]; for(id x in value)[a addObject:MutableTree(x)?:[NSNull null]]; return a; }
    return value;
}
static NSMutableArray *FilledNumericArray(NSArray *source, NSNumber *value, BOOL preserveNonPositive) {
    NSMutableArray *result=[NSMutableArray arrayWithCapacity:source.count];
    for(id item in source) {
        if([item isKindOfClass:[NSNumber class]] && (!preserveNonPositive || [item doubleValue]>0.0)) [result addObject:value];
        else [result addObject:item?:[NSNull null]];
    }
    return result;
}
static void TuneMountedPerformance(id value) {
    if ([value isKindOfClass:[NSMutableDictionary class]]) {
        NSMutableDictionary *d=value;
        for(NSString *key in @[S("CPUMaxPower"),S("GPUMaxPower"),S("PackageMaxPower")]) SetExisting(d,key,@65000);
        SetExisting(d,S("dtThermalLevel"),@0);
        SetExisting(d,S("usesPackageControl"),@NO);
        if (d[S("target")] != nil && (d[S("kp")] != nil || d[S("ki")] != nil)) { SetExisting(d,S("kp"),@0); SetExisting(d,S("ki"),@0); }
        if ([d[S("controlEfforts")] isKindOfClass:[NSArray class]]) d[S("controlEfforts")]=FilledNumericArray(d[S("controlEfforts")],@0,NO);
        for (id rawKey in [d.allKeys copy]) if ([rawKey isKindOfClass:[NSString class]]) {
            NSString *key=rawKey,*lower=[key lowercaseString]; id field=d[key]; BOOL numeric=[field isKindOfClass:[NSNumber class]];
            BOOL batteryChem=[lower containsString:S("wra")] || [lower containsString:S("chem")];
            BOOL powerTarget=!batteryChem && [lower containsString:S("power")] &&
                ([lower containsString:S("target")] || [lower containsString:S("limit")] || [lower containsString:S("maximum")] || [lower containsString:S("maxpower")]);
            if (numeric && powerTarget) d[key]=@65000;
            BOOL frameRate=([lower containsString:S("framerate")] || [lower containsString:S("refresh")] || [lower containsString:S("fps")]) &&
                ([lower containsString:S("limit")] || [lower containsString:S("max")] || [lower containsString:S("min")] || [lower containsString:S("target")]);
            if (numeric && frameRate) d[key]=@120;
        }
        if (d[S("level")] != nil && (d[S("up")] != nil || d[S("down")] != nil)) { SetExisting(d,S("up"),@101); SetExisting(d,S("down"),@101); SetExisting(d,S("level"),@101); }
        for(id child in [d.allValues copy]) TuneMountedPerformance(child);
    } else if ([value isKindOfClass:[NSArray class]]) for(id child in value) TuneMountedPerformance(child);
}
static BOOL WriteBinaryPlistAtomically(id plist, NSString *path) {
    NSError *error=nil; NSData *data=[NSPropertyListSerialization dataWithPropertyList:plist format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    return data && [data writeToFile:path options:NSDataWritingAtomic error:&error];
}
static void SetRuntimePerformancePreference(BOOL enabled) {
    NSMutableDictionary *prefs=CTHermesReadMutablePrefs()?:[NSMutableDictionary dictionary];
    prefs[S("powerMode")]=S("fullPower"); CTHermesWritePrefs(prefs);
    notify_post(kCTHermesPowerModeChangedNotifC); notify_post(kCTHermesSettingsChangedNotifC);
}
static int ApplyMountedPerformancePatch(void) {
    NSString *thermal=S("/System/Library/ThermalMonitor"),*storage=StoragePath(thermal);
    if(!IsBindfsMounted(thermal))return 70; NSString *model=ModelFile(storage); if(!model)return 71;
    if(!BackupOnce(model,S("ThermalModel.original.plist")))return 73;
    id tree=MutableTree([NSDictionary dictionaryWithContentsOfFile:model]); if(![tree isKindOfClass:[NSMutableDictionary class]])return 74;
    TuneMountedPerformance(tree); if(!WriteBinaryPlistAtomically(tree,model))return 75;
    MakeStorageWritable(storage); SetRuntimePerformancePreference(YES); return RestartThermalMonitor();
}
static NSString *BundledD64Path(void){const char*c=jbroot("/usr/local/share/CTHermes/D64AP-Info.plist");NSMutableArray*a=[NSMutableArray array];if(c&&strlen(c))[a addObject:S(c)];[a addObjectsFromArray:@[S("/var/jb/usr/local/share/CTHermes/D64AP-Info.plist"),S("/usr/local/share/CTHermes/D64AP-Info.plist")]];for(NSString*p in a)if([NSFileManager.defaultManager fileExistsAtPath:p])return p;return nil;}
static int ReplaceWithBundledD64(void){NSString*t=StoragePath(S("/System/Library/ThermalMonitor"));if(!IsBindfsMounted(S("/System/Library/ThermalMonitor")))return 70;NSString*m=ModelFile(t),*src=BundledD64Path();if(!m)return 71;if(!src)return 80;NSDictionary*v=[NSDictionary dictionaryWithContentsOfFile:src];if(!v[S("DecisionTreeTable")]||!v[S("Sensors")])return 81;if(!BackupOnce(m,S("ThermalModel.original.plist")))return 73;NSFileManager*fm=NSFileManager.defaultManager;NSString*tmp=[m stringByAppendingString:S(".cputhermal-new")];[fm removeItemAtPath:tmp error:nil];if(![fm copyItemAtPath:src toPath:tmp error:nil])return 85;if(![fm removeItemAtPath:m error:nil]||![fm moveItemAtPath:tmp toPath:m error:nil]){[fm removeItemAtPath:tmp error:nil];return 85;}MakeStorageWritable(t);return RestartThermalMonitor();}
static int RestoreThermalSchedule(void){NSString*d=SchedulerBackupRoot(),*t=StoragePath(S("/System/Library/ThermalMonitor")),*m=ModelFile(t),*b=[d stringByAppendingPathComponent:S("ThermalModel.original.plist")];if(!m||![NSFileManager.defaultManager fileExistsAtPath:b])return 78;[NSFileManager.defaultManager removeItemAtPath:m error:nil];if(![NSFileManager.defaultManager copyItemAtPath:b toPath:m error:nil])return 79;MakeStorageWritable(t);SetRuntimePerformancePreference(NO);return RestartThermalMonitor();}

static void CTHermesToolScanSmartCache(const char *why) {
    static CFAbsoluteTime sLastScan = 0;
    CFAbsoluteTime scanNow = CFAbsoluteTimeGetCurrent();
    if (sLastScan > 0 && (scanNow - sLastScan) < 4.0) return;
    sLastScan = scanNow;
    @autoreleasepool {
        NSString *summary = nil;
        NSString *sample = nil;
        BOOL wrote = CTHermesSmartScanToCache(&summary, &sample);
        NSString *whyStr = why ? [NSString stringWithUTF8String:why] : @"?";
        CTHermesSmartDiagLog([NSString stringWithFormat:@"[缓存工具] 智能分类扫描(%@)：%@ → %@", whyStr, summary ?: S("(无结果)"), wrote ? S("已写缓存") : S("未写（读不到应用目录）")]);
        if (sample.length) CTHermesSmartDiagLog([NSString stringWithFormat:@"[缓存工具] 目录样例：%@", sample]);
        if (wrote) notify_post(kCTHermesSettingsChangedNotifC);
    }
}
static void SmartScanRequestNotify(CFNotificationCenterRef c, void *o, CFStringRef n, const void *x, CFDictionaryRef u) {
    (void)c; (void)o; (void)n; (void)x; (void)u;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{ CTHermesToolScanSmartCache("请求"); });
}
static int ExecuteCommand(NSString *cmd, NSString *rawPath) {
    if ([cmd isEqualToString:S("scan-cache")]) { CTHermesToolScanSmartCache("手动"); return 0; }
    if ([cmd isEqualToString:S("restart-thermal-monitor")]) return RestartThermalMonitor();
    if ([cmd isEqualToString:S("remount-all")]) return RemountAll();
    if ([cmd isEqualToString:S("apply-mounted-performance")]) return ApplyMountedPerformancePatch();
    if ([cmd isEqualToString:S("replace-bundled-d64")]) return ReplaceWithBundledD64();
    if ([cmd isEqualToString:S("restore-thermal-schedule")]) return RestoreThermalSchedule();
    NSString *p=StandardPath(rawPath); if(!p)return EINVAL;
    if([cmd isEqualToString:S("storage-path")])return StoragePath(p).length?0:ENOENT;
    if([cmd isEqualToString:S("add")])return AddPath(p); if([cmd isEqualToString:S("remove")])return RemovePath(p);
    if([cmd isEqualToString:S("mount")])return MountPath(p); if([cmd isEqualToString:S("unmount")])return UnmountPath(p);
    if([cmd isEqualToString:S("status")])return IsMounted(p,YES)?0:1; return 64;
}
static void ProcessRequests(void) {
    NSFileManager *fm=[NSFileManager defaultManager]; NSString *dir=RequestDirectory();
    [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0777} error:nil]; chmod(dir.fileSystemRepresentation,0777);
    for(NSString *name in [fm contentsOfDirectoryAtPath:dir error:nil]) {
        if(![name hasSuffix:S(".request.plist")])continue; NSString *request=[dir stringByAppendingPathComponent:name];
        NSDictionary *d=[NSDictionary dictionaryWithContentsOfFile:request]; if(!d)continue;
        NSString *cmd=[d[S("command")] isKindOfClass:[NSString class]]?d[S("command")]:nil;
        NSString *path=[d[S("path")] isKindOfClass:[NSString class]]?d[S("path")]:nil;
        int result=ExecuteCommand(cmd,path); NSString *base=[name substringToIndex:name.length-[S(".request.plist") length]];
        NSString *response=[dir stringByAppendingPathComponent:[base stringByAppendingString:S(".response.plist")]];
        NSMutableDictionary *reply=[@{S("result"):@(result)} mutableCopy]; if(path.length)reply[S("storagePath")]=StoragePath(path)?:S("");
        [reply writeToFile:response atomically:YES]; chmod(response.fileSystemRepresentation,0666); [fm removeItemAtPath:request error:nil];
    }
}
static void RequestNotification(CFNotificationCenterRef c,void *o,CFStringRef n,const void *x,CFDictionaryRef u){ ProcessRequests(); }
static int Serve(void) {
    if(geteuid()!=0)return EPERM;
    NSFileManager *fm=[NSFileManager defaultManager]; NSString *parent=[RequestDirectory() stringByDeletingLastPathComponent];
    [fm createDirectoryAtPath:parent withIntermediateDirectories:YES attributes:nil error:nil]; chmod(parent.fileSystemRepresentation,0777);
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),NULL,RequestNotification,(__bridge CFStringRef)S("com.qq391160.cpucore/mountRequest"),NULL,CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),NULL,SmartScanRequestNotify,(__bridge CFStringRef)S(kCTHermesSmartScanReqNotifC),NULL,CFNotificationSuspensionBehaviorDeliverImmediately);
    // 先接收设置页请求，再后台恢复旧记录；首次大目录复制不阻塞 IPC 监听。
    ProcessRequests();
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0), ^{ RemountAll(); });
    CTHermesSmartDiagLog(@"[缓存工具] T7p serve 运行中：智能分类扫描就绪");
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0), ^{ CTHermesToolScanSmartCache("启动"); });
    dispatch_source_t smartCacheTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (smartCacheTimer) {
        dispatch_source_set_timer(smartCacheTimer, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(300ull * NSEC_PER_SEC)), (uint64_t)(300ull * NSEC_PER_SEC), (uint64_t)(5ull * NSEC_PER_SEC));
        dispatch_source_set_event_handler(smartCacheTimer, ^{ CTHermesToolScanSmartCache("周期"); });
        dispatch_resume(smartCacheTimer);
    }
    CFRunLoopRun(); return 0;
}
int main(int argc,char *argv[]){ @autoreleasepool {
    if(argc<2)return 64; NSString *cmd=S(argv[1]); if([cmd isEqualToString:S("serve")])return Serve();
    if(geteuid()!=0)return EPERM;
    if([cmd isEqualToString:S("list")]){for(NSString *p in LoadPaths())printf("%s\t%s\n",IsMounted(p,YES)?"mounted":"saved",p.UTF8String);return 0;}
    if([cmd isEqualToString:S("remount-all")])return RemountAll(); if([cmd isEqualToString:S("retire")])return RetireStaleMounts(); if(argc!=3)return 64; return ExecuteCommand(cmd,S(argv[2]));
} }
