// ============================================================================
// CPUthermalChargeTool v2 —— 充电控制守护进程（独立跑、拿私有权限签名）
//   2026-09-28 重建：
//   · 根因：电池属性写入（IsCharging / PredictiveChargingInhibit / ExternalConnected）
//     需要私有权限 com.apple.private.powersource-write(-all)（ChargeLimiter 同款，
//     它的 README 原话"需要特殊签名"）；不带权限的进程一律被拒 kIOReturnNotPermitted。
//   · 本工具 = 专用"肌肉进程"：构建时用 Tools/CPUthermalChargeTool.entitlements
//     签名（CODESIGN_FLAGS），由 LaunchDaemon 常驻，负责所有停充/恢复写入。
//   · 行为：读 prefs（chargeLimitEnabled / chargeLimitValue）→ 到点停、低 2% 恢复；
//     每 5 秒巡视 + 设置变化通知即时执行；停充在岗反复重申（防系统放开）。
//   · 全程写日志（带服务号/错误码），一眼可诊断。
// ============================================================================
#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <notify.h>
#import <signal.h>
#import <string.h>
#import <stdio.h>
#import <stdarg.h>
#import <time.h>
#import <sys/time.h>
#import <unistd.h>
#import <CPUthermalPaths.h>

static const char *kChargeLogPath = "/var/mobile/Library/Logs/CPUthermalDiag.log";
static const char *kToolTag = "v2 (build 0928-2340)";

// ---------- 日志 ----------
static void ctlog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; localtime_r(&tv.tv_sec, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    FILE *f = fopen(kChargeLogPath, "a");
    if (f) {
        fprintf(f, "[%s.%03d][充电·守护] %s\n", ts, (int)(tv.tv_usec / 1000), msg.UTF8String);
        fclose(f);
    }
    NSLog(@"[充电·守护] %@", msg);
}

// ---------- 电池服务 ----------
static io_service_t BatteryService(BOOL preferSmart) {
    io_service_t service = IO_OBJECT_NULL;
    if (preferSmart)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    if (service == IO_OBJECT_NULL)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOPMPowerSource"));
    if (service == IO_OBJECT_NULL && !preferSmart)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    return service;
}

static NSDictionary *BatteryProperties(void) {
    io_service_t service = BatteryService(YES);
    if (service == IO_OBJECT_NULL) return nil;
    CFMutableDictionaryRef raw = NULL;
    NSDictionary *out = nil;
    if (IORegistryEntryCreateCFProperties(service, &raw, kCFAllocatorDefault, 0) == KERN_SUCCESS && raw)
        out = CFBridgingRelease(raw);
    IOObjectRelease(service);
    return out;
}

static BOOL AdapterConnected(NSDictionary *properties) {
    NSDictionary *adapter = [properties[S("AdapterDetails")] isKindOfClass:[NSDictionary class]] ? properties[S("AdapterDetails")] : nil;
    NSString *description = [adapter[S("Description")] isKindOfClass:[NSString class]] ? adapter[S("Description")] : nil;
    if (adapter.count && ![description isEqualToString:S("batt")]) return YES;
    return [properties[S("ExternalConnected")] boolValue] || [properties[S("ExternalChargeCapable")] boolValue];
}

// ---------- 写入（双服务尝试；1=AppleSmartBattery 2=IOPMPowerSource 0=全败） ----------
static BOOL WriteToOneService(BOOL preferSmart, NSDictionary *props, int *outErr) {
    io_service_t service = BatteryService(preferSmart);
    if (service == IO_OBJECT_NULL) { *outErr = 1; return NO; }
    kern_return_t r = IORegistryEntrySetCFProperties(service, (__bridge CFTypeRef)props);
    IOObjectRelease(service);
    *outErr = (r == KERN_SUCCESS) ? 0 : (int)r;
    return r == KERN_SUCCESS;
}

// 返回：成功=YES 且 outSvc 记住赢家；失败 outSvc=0、outErr=最后错误
static BOOL WriteCascade(NSDictionary *props, int *outSvc, int *outErr) {
    int err = 0;
    if (WriteToOneService(YES, props, &err)) { *outSvc = 1; *outErr = 0; return YES; }
    int lastErr = err;
    if (WriteToOneService(NO, props, &err)) { *outSvc = 2; *outErr = 0; return YES; }
    lastErr = err;
    *outSvc = 0; *outErr = lastErr;
    return NO;
}

// ---------- 通道封装（与主插件语义对齐） ----------
// 停充主通道：IsCharging=YES + PredictiveChargingInhibit=YES（ChargeLimiter 实证组合）
static BOOL PressStopMain(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @YES;
    p[S("PredictiveChargingInhibit")] = @YES;
    return WriteCascade(p, svc, err);
}
// 禁流通道：ExternalConnected=NO
static BOOL PressStopInflow(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("ExternalConnected")] = @NO;
    return WriteCascade(p, svc, err);
}
// 备用形态：直写 IsCharging=NO
static BOOL PressStopDirect(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @NO;
    return WriteCascade(p, svc, err);
}
// 恢复
static BOOL PressAllowInflow(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("ExternalConnected")] = @YES;
    return WriteCascade(p, svc, err);
}
static BOOL PressAllowMain(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @YES;
    p[S("PredictiveChargingInhibit")] = @NO;
    return WriteCascade(p, svc, err);
}

// ---------- 状态 ----------
static BOOL gOwnsStop = NO;         // 我们当前按着"停"
static BOOL gFeatureWasOn = NO;
static CFAbsoluteTime gStoppedAt = 0;
static CFAbsoluteTime gLastFailLog = 0;
static int gLastSig = -9999;
static int gLastAbsMA = -1;   // 上轮电流（用于"被放开"边沿检测）

// ---------- 自检探针（启动时各跑一次） ----------
static void RunWriteProbe(void) {
    // 探针1：把 ExternalConnected 的原值原样写回（真实键、无副作用）
    NSDictionary *props = BatteryProperties();
    BOOL extVal = props ? [props[S("ExternalConnected")] boolValue] : YES;
    NSMutableDictionary *p1 = [NSMutableDictionary dictionary];
    p1[S("ExternalConnected")] = @(extVal);
    int svc = 0, err = 0;
    BOOL ok1 = WriteCascade(p1, &svc, &err);
    // 探针2：自定义键（看是否"全禁"）
    NSMutableDictionary *p2 = [NSMutableDictionary dictionary];
    p2[S("CPUthermalProbe")] = @(1);
    int svc2 = 0, err2 = 0;
    BOOL ok2 = WriteCascade(p2, &svc2, &err2);
    ctlog(@"写入探针：真实键回写=%s（服务%d 错误%d）自定义键=%s（服务%d 错误%d）",
          ok1 ? "成功" : "失败", svc, err, ok2 ? "成功" : "失败", svc2, err2);
}

// ---------- 核心评估 ----------
static void EvaluateBattery(void) {
    NSDictionary *prefs = CPUthermalReadPrefs() ?: @{};
    BOOL enabled = [prefs[S("chargeLimitEnabled")] respondsToSelector:@selector(boolValue)] ? [prefs[S("chargeLimitEnabled")] boolValue] : NO;
    int limit = [prefs[S("chargeLimitValue")] respondsToSelector:@selector(intValue)] ? [prefs[S("chargeLimitValue")] intValue] : 80;
    if (limit < 50) limit = 50; if (limit > 100) limit = 100;
    int resumeLevel = limit - 2; if (resumeLevel < 40) resumeLevel = 40;

    if (!enabled) {
        if (gFeatureWasOn || gOwnsStop) {
            int svc = 0, err = 0;
            PressAllowInflow(&svc, &err);
            PressAllowMain(&svc, &err);
            gOwnsStop = NO; gStoppedAt = 0;
            ctlog(@"功能关闭 → 已发出恢复充电");
        }
        gFeatureWasOn = NO;
        return;
    }
    gFeatureWasOn = YES;

    NSDictionary *props = BatteryProperties();
    if (!props) return;
    NSInteger capacity = [props[S("CurrentCapacity")] integerValue];
    double amp = [props[S("InstantAmperage")] doubleValue];
    if (![props[S("InstantAmperage")] isKindOfClass:[NSNumber class]])
        amp = [props[S("Amperage")] doubleValue];
    int absMA = (int)(amp < 0 ? -amp : amp);
    BOOL connected = AdapterConnected(props);
    if (capacity < 0 || !connected) return;

    if ((NSInteger)capacity >= (NSInteger)limit) {
        // 到点：停充（主通道 + 禁流），双双重申；都失败再换直写形态
        int svcM = 0, errM = 0, svcI = 0, errI = 0;
        BOOL okM = PressStopMain(&svcM, &errM);
        BOOL okI = PressStopInflow(&svcI, &errI);
        int svcD = 0, errD = 0; BOOL okD = NO;
        if (!okM && !okI) okD = PressStopDirect(&svcD, &errD);

        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        BOOL newlyStopped = !gOwnsStop;
        BOOL released = NO;
        if (gOwnsStop && gLastAbsMA >= 0 && gLastAbsMA <= 150 && absMA > 150) released = YES;   // 由"已切断"变"又有电流"= 被系统放开（边沿）
        gLastAbsMA = absMA;
        gOwnsStop = YES; if (gStoppedAt <= 0) gStoppedAt = now;

        // 日志：状态变化必记；稳态 60 秒一条；新按下/被放开立即记
        int sig = (okM ? 100 : 0) + (okI ? 10 : 0) + (absMA > 150 ? 1 : 0);
        if (newlyStopped || released || sig != gLastSig || (now - gLastFailLog) > 60.0) {
            gLastSig = sig; gLastFailLog = now;
            if (released)
                ctlog(@"⚠️ 被系统放开 → 已重新按（主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA）",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
            else if (newlyStopped && (okM || okI || okD))
                ctlog(@"已咬合：主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
            else
                ctlog(@"停充重申：主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
        }
    } else if ((NSInteger)capacity <= (NSInteger)resumeLevel) {
        if (gOwnsStop) {
            int svc = 0, err = 0;
            PressAllowInflow(&svc, &err);
            PressAllowMain(&svc, &err);
            gOwnsStop = NO; gStoppedAt = 0; gLastSig = -9999;
            ctlog(@"恢复充电（电量=%d%%）", (int)capacity);
        }
    }
}

// ---------- 退出时恢复 ----------
static void RestoreBeforeExit(void) {
    if (gOwnsStop) {
        int svc = 0, err = 0;
        PressAllowInflow(&svc, &err);
        PressAllowMain(&svc, &err);
        gOwnsStop = NO;
        ctlog(@"退出：已恢复充电");
    }
}
static void SignalHandler(int sig) {
    (void)sig;
    RestoreBeforeExit();
    _exit(0);
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc > 1 && strcmp(argv[1], "probe") == 0) { RunWriteProbe(); return 0; }
        if (argc > 1 && strcmp(argv[1], "reset") == 0) { RestoreBeforeExit(); return 0; }

        ctlog(@"启动 %s", kToolTag);
        signal(SIGTERM, SignalHandler); signal(SIGINT, SignalHandler); signal(SIGHUP, SignalHandler);
        RunWriteProbe();

        int token = 0;
        notify_register_dispatch(kCPUthermalSettingsChangedNotifC, &token, dispatch_get_main_queue(), ^(int t) {
            (void)t; @autoreleasepool { EvaluateBattery(); }
        });
        [NSTimer scheduledTimerWithTimeInterval:5.0 repeats:YES block:^(__unused NSTimer *timer) {
            @autoreleasepool { EvaluateBattery(); }
        }];
        EvaluateBattery();
        [[NSRunLoop mainRunLoop] run];
    }
    return 0;
}
