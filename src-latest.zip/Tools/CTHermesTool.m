#import <Foundation/Foundation.h>
#import <spawn.h>
#import <sys/wait.h>
#import <notify.h>
#import <dlfcn.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <IOKit/IOKitLib.h>
#import <pwd.h>
#import <unistd.h>
#import <CTHermesPaths.h>
#import <CTHermesPressure.h>

static int runExecutable(NSString *path, char *const argv[]) {
    if (path.length == 0 || !argv || !argv[0]) return 127;
    pid_t pid = 0;
    int status = 0;
    if (posix_spawn(&pid, [path fileSystemRepresentation], NULL, NULL, argv, NULL) != 0) return 126;
    if (waitpid(pid, &status, 0) < 0) return 125;
    return WIFEXITED(status) ? WEXITSTATUS(status) : status;
}

static int rebootUserspace(void) {
    NSString *launchctlPath = CTHermesLaunchctlPath();
    char *args[] = {(char *)"launchctl", (char *)"reboot", (char *)"userspace", NULL};
    return runExecutable(launchctlPath, args);
}

static int PostUninstallingNotice(void) {
    // ★ 1.4.94：通知各界面组件"正在卸载"（浮窗等即时隐藏；不落盘，重装不受影响）
    return notify_post("com.qq391160.cpucore/uninstalling") == NOTIFY_STATUS_OK ? 0 : 1;
}

static int restoreFullPower(void) {
    NSString *prefPath = CTHermesCurrentPrefPath();
    if (prefPath.length == 0) return 1;
    NSString *directory = [prefPath stringByDeletingLastPathComponent];
    if (directory.length == 0) return 1;
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:nil];

    NSMutableDictionary *prefs = [NSMutableDictionary dictionaryWithContentsOfFile:prefPath];
    if (!prefs) prefs = [NSMutableDictionary dictionary];
    prefs[S("powerMode")] = S("fullPower");
    if (![prefs writeToFile:prefPath atomically:YES]) return 1;
    return notify_post(kCTHermesPowerModeChangedNotifC) == NOTIFY_STATUS_OK ? 0 : 1;
}

static int SetThermalPreference(NSString *key, id value, NSString *persistentKey, BOOL persist) {
    typedef CFTypeRef (*CreateFn)(CFAllocatorRef, CFStringRef, CFStringRef);
    typedef Boolean (*SetFn)(CFTypeRef, CFStringRef, CFPropertyListRef);
    typedef Boolean (*RemoveFn)(CFTypeRef, CFStringRef);
    typedef Boolean (*ApplyFn)(CFTypeRef);
    void *framework = dlopen("/System/Library/Frameworks/SystemConfiguration.framework/SystemConfiguration", RTLD_NOW | RTLD_LOCAL);
    if (!framework) return 1;
    CreateFn create = (CreateFn)dlsym(framework, "SCPreferencesCreate");
    SetFn setValue = (SetFn)dlsym(framework, "SCPreferencesSetValue");
    RemoveFn removeValue = (RemoveFn)dlsym(framework, "SCPreferencesRemoveValue");
    ApplyFn commit = (ApplyFn)dlsym(framework, "SCPreferencesCommitChanges");
    ApplyFn apply = (ApplyFn)dlsym(framework, "SCPreferencesApplyChanges");
    if (!create || !setValue || !removeValue || !commit || !apply) { dlclose(framework); return 1; }
    CFTypeRef preferences = create(kCFAllocatorDefault, CFSTR("CTHermes"), CFSTR("OSThermalStatus.plist"));
    if (!preferences) { dlclose(framework); return 1; }
    if (value) setValue(preferences, (__bridge CFStringRef)key, (__bridge CFPropertyListRef)value);
    else removeValue(preferences, (__bridge CFStringRef)key);
    if (persistentKey) {
        if (value) setValue(preferences, (__bridge CFStringRef)persistentKey, persist ? kCFBooleanTrue : kCFBooleanFalse);
        else removeValue(preferences, (__bridge CFStringRef)persistentKey);
    }
    BOOL ok = commit(preferences) && apply(preferences);
    CFRelease(preferences); dlclose(framework);
    return ok ? 0 : 2;
}

// ★ 2.0.111：「锁屏模拟口袋过热 / 锁定阳光暴晒」两功能已删除；
//   仅保留清理——无条件移除历史版本可能遗留的全部持久化假热键（不清=系统持续假热→拒充+压亮度）。
static int ClearFakeThermalKeys(void) {
    int first  = SetThermalPreference(S("hipOverride"), nil, S("hipPersistentlyEnabled"), NO);
    int second = SetThermalPreference(S("simulateHip"), nil, nil, NO);
    int third  = SetThermalPreference(S("sunlightOverride"), nil, S("sunlightOverridePersistentlyEnabled"), NO);
    // ★ 2.0.111-add：补"家族漏网键"——此前只清 5 个，漏了 engageBehavior 系与 forceHIP
    SetThermalPreference(S("engageBehavior"), nil, S("engageBehaviorPersistentlyEnabled"), NO);
    SetThermalPreference(S("forceHIPWhenConnected"), nil, nil, NO);
    return first ? first : (second ? second : third);
}


// ★ 2.0.111：battery-dump —— 一条命令看真相（只读）：电池底层状态 + 系统"未充电原因" + 有没有卡住的键 + 本插件开关值
// ★ 2.0.113：前置声明——补"SMC 阻断位"读数段（SBCPU 一类工具就是在这一层按停的）
static int CTSMCOpen(void);
static uint32_t K4(char a, char b, char c, char d);
static void SmcDumpKey(const char *name, uint32_t key);
static int BatteryDump(void) {
    @autoreleasepool {
        printf("===== CTHermes battery-dump (read-only) =====\n");
        @try {
            io_service_t svc = IOServiceGetMatchingService(MACH_PORT_NULL, IOServiceMatching("AppleSmartBattery"));
            if (svc) {
                CFMutableDictionaryRef props = NULL;
                kern_return_t kr = IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0);
                if (kr == KERN_SUCCESS && props) {
                    NSDictionary *d = (__bridge_transfer NSDictionary *)props;
                    NSArray *keys = @[@"IsCharging", @"IsCharged", @"FullyCharged", @"CurrentCapacity", @"MaxCapacity", @"DesignCapacity",
                                      @"Temperature", @"Voltage", @"Amperage", @"InstantAmperage", @"ExternalConnected",
                                      @"ExternalChargeCapable", @"PredictiveChargingInhibit", @"ChargingCurrentLimit",
                                      @"CycleCount", @"TimeRemaining", @"AtCriticalLevel"];
                    for (NSString *k in keys) {
                        id v = d[k];
                        if (v) printf("%s = %s\n", k.UTF8String, [NSString stringWithFormat:@"%@", v].UTF8String);
                    }
                    if (!d[@"PredictiveChargingInhibit"]) printf("PredictiveChargingInhibit = (absent)\n");   // ★ 2.0.113：不存在也显式打出（分"按停"vs"热"）
                    id cd = d[@"ChargerData"];
                    if (cd) printf("-- ChargerData --\n%s\n", [NSString stringWithFormat:@"%@", cd].UTF8String);
                    id bd = d[@"BatteryData"];
                    if (bd) {
                        NSString *bs = [NSString stringWithFormat:@"%@", bd];
                        if (bs.length > 1500) bs = [bs substringToIndex:1500];
                        printf("-- BatteryData (truncated 1500) --\n%s\n", bs.UTF8String);
                    }
                } else {
                    printf("AppleSmartBattery read failed kr=0x%x\n", kr);
                }
                IOObjectRelease(svc);
            } else {
                printf("AppleSmartBattery service NOT FOUND\n");
            }
        } @catch (__unused NSException *e) {}
        printf("-- OSThermalStatus.plist --\n");
        @try {
            NSDictionary *th = [NSDictionary dictionaryWithContentsOfFile:@"/var/preferences/SystemConfiguration/OSThermalStatus.plist"];
            if ([th isKindOfClass:[NSDictionary class]]) {
                for (NSString *k in [[th allKeys] sortedArrayUsingSelector:@selector(compare:)])
                    printf("%s = %s\n", k.UTF8String, [NSString stringWithFormat:@"%@", th[k]].UTF8String);
            } else printf("(cannot read)\n");
        } @catch (__unused NSException *e) {}
        printf("-- SMC 充电阻断位（打不开就跳过）--\n");
        @try {
            if (!CTSMCOpen()) {
                SmcDumpKey("CH0C", K4('C','H','0','C'));
                SmcDumpKey("CH0I", K4('C','H','0','I'));
                SmcDumpKey("CH0R", K4('C','H','0','R'));
                SmcDumpKey("CH0B", K4('C','H','0','B'));
            } else printf("（AppleSMC 打不开——这台机读不到）\n");
        } @catch (__unused NSException *e) {}
        printf("-- plugin charge switches --\n");
        @try {
            NSDictionary *pf = [NSDictionary dictionaryWithContentsOfFile:CTHermesCurrentPrefPath()];
            NSArray *pk = @[@"chargeLimitEnabled", @"chargeLimitValue", @"chargeTempThreshold", @"hipLockedEnabled", @"sunlightLockedEnabled"];
            for (NSString *k in pk)
                printf("%s = %s\n", k.UTF8String, [NSString stringWithFormat:@"%@", pf[k] ?: @"(unset)"].UTF8String);
        } @catch (__unused NSException *e) {}
        printf("===== DUMP END =====\n");
        return 0;
    }
}


// ===================== 2.0.111（试验）：SMC 迷你客户端（自研实现） =====================
// 协议：公开的 AppleSMC user-client 接口。用途：诊断“谁按住充电”+“松开按住”。不做自动对抗。
typedef struct { uint8_t major, minor, build; uint16_t release; } CTSMCVers;
typedef struct { uint16_t version, length; uint32_t cpuPLimit, gpuPLimit, memPLimit; } CTSMCPLim;
typedef struct { uint32_t dataSize; uint32_t dataType; uint8_t dataAttributes; } CTSMCKI;
typedef struct {
    uint32_t key;
    struct { CTSMCVers vers; CTSMCPLim pLimit; CTSMCKI ki;
             uint8_t result, status, data8; uint32_t data32; uint8_t bytes[120]; } param;
} CTSMCParam;

static io_connect_t gSMCConn = 0;
static int CTSMCOpen(void) {
    if (gSMCConn) return 0;
    const char *names[2] = {"AppleSMC", "AppleSMCClient"};
    for (int i = 0; i < 2; i++) {
        io_service_t svc = IOServiceGetMatchingService(MACH_PORT_NULL, IOServiceMatching(names[i]));
        if (!svc) continue;
        kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &gSMCConn);
        IOObjectRelease(svc);
        if (kr == KERN_SUCCESS) { printf("SMC：%s 已打开\n", names[i]); return 0; }
        printf("SMC：%s IOServiceOpen kr=0x%x\n", names[i], kr);
        gSMCConn = 0;
    }
    return 1;
}
static int CTSMCCall2(uint32_t idx, CTSMCParam *in, CTSMCParam *out) {
    size_t osz = sizeof(CTSMCParam);
    return IOConnectCallStructMethod(gSMCConn, idx, in, sizeof(CTSMCParam), out, &osz) == KERN_SUCCESS ? 0 : 1;
}
static int CTSMCInfo(uint32_t k, CTSMCKI *ki) {
    CTSMCParam in = {0}; CTSMCParam out = {0};
    in.key = k; in.param.data8 = 9;
    if (CTSMCCall2(2, &in, &out)) return 1;
    if (out.param.ki.dataSize == 0) return 2;
    *ki = out.param.ki; return 0;
}
static int CTSMCReadKey(uint32_t k, void *buf, uint32_t cap, uint32_t *nOut, uint32_t *typeOut) {
    CTSMCKI ki; if (CTSMCInfo(k, &ki)) return 1;
    CTSMCParam in = {0}; CTSMCParam out = {0};
    in.key = k; in.param.ki = ki; in.param.data8 = 5;
    if (CTSMCCall2(2, &in, &out)) return 2;
    uint32_t n = ki.dataSize <= cap ? ki.dataSize : cap;
    if (buf) memcpy(buf, out.param.bytes, n);
    if (nOut) *nOut = n;
    if (typeOut) *typeOut = ki.dataType;
    return 0;
}
static int CTSMCWriteKey(uint32_t k, const void *bytes, uint32_t size) {
    CTSMCKI ki; if (CTSMCInfo(k, &ki)) return 1;
    if (ki.dataSize > size) return 2;
    CTSMCParam in = {0}; CTSMCParam out = {0};
    in.key = k; in.param.data8 = 6;
    memcpy(in.param.bytes, bytes, ki.dataSize);
    return CTSMCCall2(2, &in, &out) ? 3 : 0;
}
static uint32_t K4(char a, char b, char c, char d) {
    return ((uint32_t)(uint8_t)a << 24) | ((uint32_t)(uint8_t)b << 16) |
           ((uint32_t)(uint8_t)c << 8) | (uint32_t)(uint8_t)d;
}
static void SmcDumpKey(const char *name, uint32_t key) {
    uint8_t buf[16] = {0}; uint32_t n = 0, t = 0;
    int r = CTSMCReadKey(key, buf, sizeof(buf), &n, &t);
    if (r) { printf("%-4s: 读取失败(r=%d)\n", name, r); return; }
    char tb[5] = {0}; tb[0] = (char)(t >> 24); tb[1] = (char)(t >> 16); tb[2] = (char)(t >> 8); tb[3] = (char)t;
    printf("%-4s: size=%u type=%.4s data=", name, n, tb);
    for (uint32_t i = 0; i < n && i < 16; i++) printf("%02x", buf[i]);
    printf("\n");
}

static int TopoffRead(void);
static int SmcProbe(void) {
    printf("===== CTHermes smc-probe（只读）=====\n");
    printf("sizeof(CTSMCParam)=%zu（预期 168）\n", sizeof(CTSMCParam));
    if (!CTSMCOpen()) {
        SmcDumpKey("RGEN", K4('R','G','E','N'));
        SmcDumpKey("CHCE", K4('C','H','C','E'));
        SmcDumpKey("CH0R", K4('C','H','0','R'));
        SmcDumpKey("CH0C", K4('C','H','0','C'));
        SmcDumpKey("CH0B", K4('C','H','0','B'));
        SmcDumpKey("CH0I", K4('C','H','0','I'));
        SmcDumpKey("CH0J", K4('C','H','0','J'));
        SmcDumpKey("CH0K", K4('C','H','0','K'));
        SmcDumpKey("CHNC", K4('C','H','N','C'));
        SmcDumpKey("CHSC", K4('C','H','S','C'));
    } else {
        printf("（AppleSMC 打不开——entitlement 或设备不支持）\n");
    }
    printf("-- ioreg 电池 --\n");
    @try {
        io_service_t svc = IOServiceGetMatchingService(MACH_PORT_NULL, IOServiceMatching("AppleSmartBattery"));
        if (svc) {
            CFMutableDictionaryRef props = NULL;
            if (IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
                NSDictionary *d = (__bridge_transfer NSDictionary *)props;
                printf("IsCharging=%s Ext=%s PCI=%s Cap=%s Temp=%s\n",
                       [NSString stringWithFormat:@"%@", d[@"IsCharging"]].UTF8String,
                       [NSString stringWithFormat:@"%@", d[@"ExternalConnected"]].UTF8String,
                       [NSString stringWithFormat:@"%@", d[@"PredictiveChargingInhibit"]].UTF8String,
                       [NSString stringWithFormat:@"%@", d[@"CurrentCapacity"]].UTF8String,
                       [NSString stringWithFormat:@"%@", d[@"Temperature"]].UTF8String);
            }
            IOObjectRelease(svc);
        } else printf("未找到 AppleSmartBattery\n");
    } @catch (__unused NSException *e) {}
    printf("-- topoff 保护偏好 --\n");
    int tp = TopoffRead();
    if (tp < 0) {
        @try {
            NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.smartcharging.topoffprotection.plist"];
            id ev = d[@"enabled"];
            if (ev) tp = [ev boolValue] ? 1 : 0;
        } @catch (__unused NSException *e) {}
    }
    printf("topoffprotection.enabled = %s\n", tp < 0 ? "(读不到)" : (tp ? "true（保护在=默认）" : "false（保护已关=越坎状态）"));
    return 0;
}

static int TopoffRead(void) {
    int tp = -1;
    @try {
        CFPropertyListRef v = CFPreferencesCopyValue(CFSTR("enabled"), CFSTR("com.apple.smartcharging.topoffprotection"), CFSTR("mobile"), kCFPreferencesAnyHost);
        if (v) {
            if (CFGetTypeID(v) == CFBooleanGetTypeID()) tp = CFBooleanGetValue((CFBooleanRef)v) ? 1 : 0;
            else if (CFGetTypeID(v) == CFNumberGetTypeID()) { int x = 0; CFNumberGetValue((CFNumberRef)v, kCFNumberIntType, &x); tp = x ? 1 : 0; }
            CFRelease(v);
        }
    } @catch (__unused NSException *e) {}
    return tp;
}

static int TopoffProtect(int on) {
    struct passwd *pw = getpwnam("mobile");
    if (!pw) { printf("找不到 mobile 用户\n"); return 1; }
    uid_t oe = geteuid(); gid_t og = getegid();
    if (setegid(pw->pw_gid) != 0 || seteuid(pw->pw_uid) != 0) { printf("切换 mobile 身份失败\n"); return 2; }
    int val = on ? 1 : 0;
    CFNumberRef v = CFNumberCreate(kCFAllocatorDefault, kCFNumberIntType, &val);
    CFPreferencesSetValue(CFSTR("enabled"), v, CFSTR("com.apple.smartcharging.topoffprotection"), kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    CFRelease(v);
    Boolean ok = CFPreferencesSynchronize(CFSTR("com.apple.smartcharging.topoffprotection"), kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    if (seteuid(oe) != 0 || setegid(og) != 0) printf("警告：恢复身份失败\n");
    notify_post("com.apple.smartcharging.defaultschanged");
    int rb = TopoffRead();
    printf("topoff-protect %s：sync=%s，读回=%s\n",
           on ? "1（恢复保护）" : "0（关闭保护=越坎）",
           ok ? "ok" : "失败",
           rb < 0 ? "读不到" : (rb ? "true" : "false"));
    return 0;
}

static int SmcEnsureZero(const char *name, uint32_t key) {
    uint8_t cur = 0xFF; uint32_t n = 0;
    if (CTSMCReadKey(key, &cur, 1, &n, NULL)) { printf("      %s 读失败，跳过\n", name); return 1; }
    if (cur == 0) { printf("      %s 已是 00（跳过写）\n", name); return 0; }
    uint8_t z = 0;
    int w = CTSMCWriteKey(key, &z, 1);
    uint8_t rb = 0xEE; CTSMCReadKey(key, &rb, 1, &n, NULL);
    printf("      %s %02x → 00（写r=%d 读回=%02x）\n", name, cur, w, rb);
    return 0;
}

static int ChargeRestore(void) {
    printf("===== CTHermes charge-restore（松开一切“按住”，一次性）=====\n");
    int cf = ClearFakeThermalKeys();
    printf("[1/4] 假热键清理：%s\n", cf ? "部分失败" : "完成");
    io_service_t b = IOServiceGetMatchingService(MACH_PORT_NULL, IOServiceMatching("AppleSmartBattery"));
    if (b) {
        IORegistryEntrySetCFProperty(b, CFSTR("PredictiveChargingInhibit"), kCFBooleanFalse);
        IOObjectRelease(b);
        printf("[2/4] ioreg：PredictiveChargingInhibit=0 已写\n");
    } else printf("[2/4] 未找到 AppleSmartBattery\n");
    if (CTSMCOpen()) { printf("[3/4] AppleSMC 打不开，跳过 SMC\n"); }
    else {
        uint8_t chce = 0; CTSMCReadKey(K4('C','H','C','E'), &chce, 1, NULL, NULL);
        uint32_t ch0r = 0; CTSMCReadKey(K4('C','H','0','R'), &ch0r, 4, NULL, NULL);
        printf("      CHCE=%u CH0R=0x%08x\n", chce, ch0r);
        if (chce == 0) printf("[3/4] 未接适配器，按安全规则跳过 SMC 写\n");
        else if (ch0r & (1u << 1)) printf("[3/4] CH0R 显示无 VBUS，按安全规则跳过 SMC 写\n");
        else {
            printf("      —— 开始清（只清非 0 的）——\n");
            SmcEnsureZero("CH0C", K4('C','H','0','C'));
            SmcEnsureZero("CH0B", K4('C','H','0','B'));
            SmcEnsureZero("CH0I", K4('C','H','0','I'));
        }
    }
    printf("[4/4] 完成\n");
    return 0;
}

static int ResetThermalLevels(void) {
    int pressure = CTHermesForceNominalPressure();
    CTHermesForceNormalNotifLevel();
    return pressure < 0 ? 1 : 0;
}

int main(int argc, char *argv[]) {
    @autoreleasepool {
        {   // ★ 2.0.109 体检版：路径自检（每次调用记一行；只读）
            @try {
                NSString *ctRep = CTHermesAuditReport(@"工具");
                FILE *ctAF = CTDiagLogOpenForAppend();
                if (ctAF) { fputs(ctRep.UTF8String, ctAF); fputc('\n', ctAF); fclose(ctAF); }
            } @catch (__unused NSException *e) {}
        }
        if (argc > 1 && argv[1]) {
            NSString *command = [NSString stringWithUTF8String:argv[1]];
            if ([command isEqualToString:S("userspace-reboot")]) return rebootUserspace();
            if ([command isEqualToString:S("uninstall-bye")]) return PostUninstallingNotice();
            if ([command isEqualToString:S("restore-fullpower")]) return restoreFullPower();
            if ([command isEqualToString:S("thermal-reset")]) return ResetThermalLevels();
            if ([command isEqualToString:S("thermal-clear")]) return ClearFakeThermalKeys();
            if ([command isEqualToString:S("battery-dump")]) return BatteryDump();
            if ([command isEqualToString:S("smc-probe")]) return SmcProbe();
            if ([command isEqualToString:S("topoff-protect")] && argc > 2) return TopoffProtect(atoi(argv[2]) != 0);
            if ([command isEqualToString:S("charge-restore")]) return ChargeRestore();
            return 64;
        }
        printf("CTHermesTool commands:\n");
        printf("  userspace-reboot\n");
        printf("  restore-fullpower\n");
        printf("  battery-dump\n");
        printf("  smc-probe / topoff-protect 0|1 / charge-restore\n");
        return 0;
    }
}
