// ============================================================================
// CTHermesChargeTool v2 —— 充电控制守护进程（独立跑、拿私有权限签名）
//   2026-09-28 重建：
//   · 根因：电池属性写入（IsCharging / PredictiveChargingInhibit / ExternalConnected）
//     需要私有权限 com.apple.private.powersource-write(-all)（ChargeLimiter 同款，
//     它的 README 原话"需要特殊签名"）；不带权限的进程一律被拒 kIOReturnNotPermitted。
//   · 本工具 = 专用"肌肉进程"：构建时用 Tools/CTHermesChargeTool.entitlements
//     签名（CODESIGN_FLAGS），由 LaunchDaemon 常驻，负责所有停充/恢复写入。
//   · 行为：读 prefs（chargeLimitEnabled / chargeLimitValue）→ 到点停、低 5% 恢复；
//     每 5 秒巡视 + 设置变化通知即时执行；停充在岗反复重申（防系统放开）。
//   · 全程写日志（带服务号/错误码），一眼可诊断。
// ============================================================================
#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <notify.h>
#import <signal.h>
#import <sys/wait.h>
#import <sys/sysctl.h>
#import <string.h>
#import <stdio.h>
#import <stdarg.h>
#import <time.h>
#import <sys/time.h>
#import <unistd.h>
#import <CTHermesPaths.h>

#define kChargeLogPath CTDiagLogPathC()   // ★ 2.0.38：隐根版走容器
#include <ifaddrs.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <net/if_var.h>
#import <CTHardening.h>
#import <CTNotifyState.h>   // ★ 0930-0207：核心数据桥（通知桶）


static void ctlog(NSString *fmt, ...);
static double CTDirectFreqMHz(void);
// ★ 0930-0207：外观代传（root 守护必在跑；读系统键 → 写共享文件，供浮窗使用）
static void ctAppearanceRelay(void) {
    static int last = -1;
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("AppleInterfaceStyle"), kCFPreferencesAnyApplication);
    BOOL dark = (v && CFGetTypeID(v) == CFStringGetTypeID() &&
                 CFStringCompare((CFStringRef)v, CFSTR("Dark"), 0) == kCFCompareEqualTo);
    if (v) CFRelease(v);
    int now = dark ? 1 : 0;
    if (now == last) return;
    last = now;
    CTStateWrite(@"CTHermesAppearance.txt", dark ? @"dark" : @"light");
    ctlog(@"[外观] 系统=%s 已写共享文件", dark ? "dark" : "light");
}
   // ★ 0930-0207 前置声明
static double CTDirectTempC(void);
static int CTDirectCurrentmA(void);
static const char *kToolTag = "v2 (build 2.0.96)";

// ---------- 日志 ----------
static void ctlog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; localtime_r(&tv.tv_sec, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    FILE *f = CTDiagLogOpenForAppend();   // ★ 2.0.38：统一闸门
    if (!f) {   // ★ 0930-0207：主日志写不进 → 兜底日志（前台组件/中转站会搬回）
        for (NSString *d in CTStateWriteDirs()) {
            NSString *lp = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
            mkdir([d UTF8String], 0755);
            f = fopen([lp UTF8String], "a");
            if (f) break;
        }
    }
    if (f) {
        fprintf(f, "[%s.%03d][充电·守护] %s\n", ts, (int)(tv.tv_usec / 1000), msg.UTF8String);
        fclose(f);
    }
    NSLog(@"[充电·守护] %@", msg);
}

// ★ 0930-0207：中转站——root 守护把"核心 ↔ 界面"的数据在多个候选目录之间搬运
//   （核心能写的目录 ≠ 界面能读的目录时，由本守护补齐：它两边都能碰）
static void ctRelayBridge(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *logsDir = CTDiagLogDir();
    [fm createDirectoryAtPath:logsDir withIntermediateDirectories:YES attributes:nil error:NULL];
    NSString *names[3] = {@"CTHermesStatus.txt", @"CTHermesNet.txt", @"CTHermesSelfTest.txt"};
    for (int i = 0; i < 3; i++) {
        NSString *v = CTStateRead(names[i]);
        if (!v.length) continue;
        NSString *dst = [logsDir stringByAppendingPathComponent:names[i]];
        NSString *cur = [NSString stringWithContentsOfFile:dst encoding:NSUTF8StringEncoding error:NULL];
        if (![cur isEqualToString:v]) {
            [v writeToFile:dst atomically:YES encoding:NSUTF8StringEncoding error:NULL];
            chmod([dst UTF8String], 0644);
        }
    }
    // 自检请求：分发到所有候选目录（核心在哪个目录能读，就在哪读得到）
    NSString *req = CTStateRead(@"CTHermesSelfTest.req");
    if (req.length) CTStateWrite(@"CTHermesSelfTest.req", req);
    // 核心自报的"可写目录"→ 记进主日志（这样导出日志就能看到）
    static NSTimeInterval lastCP = 0;
    NSString *cp = CTStateRead(@"core-paths.txt");
    NSTimeInterval now = CFAbsoluteTimeGetCurrent();
    if (cp.length && now - lastCP > 300) {
        lastCP = now;
        ctlog(@"[路径] 核心自报可写目录 = %@", [cp stringByReplacingOccurrencesOfString:@"\n" withString:@" | "]);
    }
}

// ★ 0930-0207：核心数据桥——root 守护收到核心的"桶通知"后，**替核心写状态文件/prefs**
//   原因：温控进程在部分机器上写不进任何文件（沙盒），但它发的通知能到（心跳为证）；
//   而本守护是 root、网速就是它写的（已证明能写）⇒ 由它把核心数据落到界面读得到的地方。
static void ctCoreDataBridge(void) {
    static int sF = -2, sM = -2, sT = -2, sN = -2;
    if (gCTNSAt <= 0) return;                       // 还没收到核心任何"桶通知"
    // ★ 安全红线：**只在"核心自己的数据不可用/过期"时才替写**——
    //   正常机器上核心每秒都在写状态 ⇒ 这里永远不插手 ⇒ 对其他用户零影响。
    // ★ 0930-0207 收紧：只要"状态文件里已经有任何数据"（核心在写 ✓），守护一律不动 ✗
    //   只在"完全没数据"时才补直读（顽固机场景），避免把核心的 深度/提速/视频 档位状态盖成 0
    {
        NSString *cur = CTPrefsStr(@"ctStatus");
        double curAt = CTPrefsNum(@"ctStatusAt");
        if (cur.length > 0 && (CFAbsoluteTimeGetCurrent() - curAt) < 60.0) return;
    }
    if (gCTNSFreq == sF && gCTNSMode == sM && gCTNSTemp == sT && gCTNSNet == sN) return;
    sF = gCTNSFreq; sM = gCTNSMode; sT = gCTNSTemp; sN = gCTNSNet;
    // ★ 0201：用 UTF-8 字节码写模式名（不依赖文件编码，杜绝乱码）
    const char *mn = (gCTNSMode == 0) ? "\xe9\xab\x98\xe6\x80\xa7\xe8\x83\xbd"
                   : ((gCTNSMode == 1) ? "\xe4\xbd\x8e\xe5\x8a\x9f\xe8\x80\x97"
                                       : "\xe5\x8e\x9f\xe7\x94\x9f");
    int mhz = (gCTNSFreq >= 0) ? gCTNSFreq * 100 : 0;
    int temp = (gCTNSTemp >= 0) ? gCTNSTemp : 0;
    // ★ 0930-0207：核心通知没有的，守护【自己直接读】补上（只读 ✓ 不影响别的）
    if (mhz <= 0) { double df = CTDirectFreqMHz(); if (df > 0) mhz = (int)df; }
    if (temp <= 0) { double dt = CTDirectTempC(); if (dt > 0) temp = (int)dt; }
    int nb = 0;   // 网速另有独立文件，这里不重复
    // 模式名：优先沿用现有状态文件里的（避免乱码 ✗）；没有就不带 mode 字段
    NSString *prevMode = nil;
    {
        NSString *old = CTStateRead(@"CTHermesStatus.txt");
        if (old.length) {
            NSRange r = [old rangeOfString:@"mode="];
            if (r.location != NSNotFound) {
                NSString *tail = [old substringFromIndex:r.location + 5];
                NSRange semi = [tail rangeOfString:@";"];
                NSRange sp = [tail rangeOfString:@" "];
                NSUInteger cut = MIN(semi.location == NSNotFound ? tail.length : semi.location,
                                     sp.location == NSNotFound ? tail.length : sp.location);
                prevMode = [tail substringToIndex:cut];
            }
        }
    }
    int dcur = CTDirectCurrentmA();
    // ★ 0930-0207：没有核心的模式名时，用"直读频率"推断模式（低功耗/智能/高性能）
    NSString *modeShow = prevMode;   // ★ 只写 ASCII 代号：LP/SMART/HP（中文交给浮窗翻，杜绝乱码）
    if (!modeShow.length && mhz > 0) {
        if (mhz <= 900.0)       modeShow = @"LP";
        else if (mhz <= 1900.0) modeShow = @"SMART";
        else                    modeShow = @"HP";
    }
    // ★ 0930-0207：档位也做个"推断版"（只在这条兜底路径里用；正常机用核心真值 ✓）
    int dDeep = (mhz > 0 && mhz <= 600)  ? 1 : 0;   // 频率很低 ⇒ 深度降频中（绿点）
    int dBoost = (mhz >= 2000)           ? 1 : 0;   // 频率飙高 ⇒ 提速中（橙点）
    NSString *st = [NSString stringWithFormat:@"freq=%d mode=%@ deep=%d boost=%d video=0 chg=0 pw=0 cap=0 cr=- cur=%d net=%d temp=%d",
                    mhz, modeShow ?: @"", dDeep, dBoost, dcur, nb, temp];
    CTStateWrite(@"CTHermesDirect.txt", st);      // ★ 0930-0207：直读写"专属文件"，绝不碰核心的状态文件
    CTPrefsSet(@{@"ctDirect": st, @"ctDirectAt": @(CFAbsoluteTimeGetCurrent())});   // 专属配置键，不碰 ctStatus
    ctlog(@"[桥] 用核心通知数据更新状态：freq=%d mode=%@ temp=%d", mhz, modeShow, temp);
    static int sV = -2;
    if (gCTNSVerdict >= 0 && gCTNSVerdict != sV) {
        sV = gCTNSVerdict;
        CTPrefsSet(@{@"ctVerdict": @(gCTNSVerdict), @"ctVerdictAt": @(CFAbsoluteTimeGetCurrent())});
        ctlog(@"[桥] 收到核心结论：v%d", gCTNSVerdict);
    }
}


// ===== ★ 0930-0207：直读（不依赖核心）—— 频率(IOReport)，整段搬自核心 =====
#include <dlfcn.h>
#include <string.h>
typedef CFMutableDictionaryRef (*CTIOR_CopyChannelsInGroup)(CFStringRef, CFStringRef, uint64_t, uint64_t, uint64_t);
typedef CFMutableDictionaryRef (*CTIOR_CreateSubscription)(void *, CFMutableDictionaryRef, CFMutableDictionaryRef *, uint64_t, CFTypeRef);
typedef CFDictionaryRef (*CTIOR_CreateSamples)(CFMutableDictionaryRef, CFMutableDictionaryRef, CFTypeRef);
typedef int (*CTIOR_Iterate)(CFDictionaryRef, int (^)(CFDictionaryRef));
typedef CFStringRef (*CTIOR_ChannelGetChannelName)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_ChannelGetSubGroup)(CFDictionaryRef);
typedef int (*CTIOR_StateGetCount)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_StateGetNameForIndex)(CFDictionaryRef, int);
typedef int64_t (*CTIOR_StateGetResidency)(CFDictionaryRef, int);

static void *g_ctIOReport = NULL;
static BOOL g_ctIOReportTried = NO;
static CTIOR_CopyChannelsInGroup g_ctCopyChannels = NULL;
static CTIOR_CreateSubscription g_ctCreateSubscription = NULL;
static CTIOR_CreateSamples g_ctCreateSamples = NULL;
static CTIOR_Iterate g_ctIterate = NULL;
static CTIOR_ChannelGetChannelName g_ctChannelName = NULL;
static CTIOR_ChannelGetSubGroup g_ctChannelSubGroup = NULL;
static CTIOR_StateGetCount g_ctStateCount = NULL;
static CTIOR_StateGetNameForIndex g_ctStateName = NULL;
static CTIOR_StateGetResidency g_ctStateResidency = NULL;
static CFMutableDictionaryRef g_ctSub = NULL;
static CFMutableDictionaryRef g_ctSubbed = NULL;
static BOOL g_ctProbeDumped __attribute__((unused)) = NO;
static NSInteger g_ctFreqErrCode = 0;
static int g_ctFreqMaxStates = 0;
static NSMutableString *g_ctFreqScanLog = nil;
static NSInteger g_ctFreqRelChans = 0;       // 本次采样里「CPU 相关通道」的个数
static int g_ctProbeWrites = 0;              // 探针最多写 3 次（加载时1次 + 失败时2次）
static int g_ctFreqStateChans = 0;     // 有状态的通道个数
static NSString *g_ctFreqStateName = nil;   // 选中状态的名字（诊断用）   // 0正常 1dlopen失败 2无通道 3订阅失败 4采样失败 5读不到状态
static double g_ctLastMHz = -1.0;
static NSMutableDictionary *g_ctPrevRes = nil;
static double g_ctTopActiveMHz = 0.0;

static double CTFreqNormalizeMHz(long long raw) {
    double v = (double)raw;
    if (v > 10000000.0) return v / 1000000.0;
    if (v > 10000.0)    return v / 1000.0;
    return v;
}

static CFStringRef CTCFStr(const char *s) {
    return s ? CFStringCreateWithCString(kCFAllocatorDefault, s, kCFStringEncodingUTF8) : NULL;
}

static BOOL CTFreqLoad(void) {
    if (g_ctIOReportTried) return g_ctIOReport != NULL;
    g_ctIOReportTried = YES;
    g_ctIOReport = dlopen("/System/Library/PrivateFrameworks/IOReport.framework/IOReport", RTLD_LAZY);
    if (!g_ctIOReport) g_ctIOReport = dlopen("/usr/lib/libIOReport.dylib", RTLD_LAZY);
    if (!g_ctIOReport) return NO;
    g_ctCopyChannels       = (CTIOR_CopyChannelsInGroup)dlsym(g_ctIOReport, "IOReportCopyChannelsInGroup");
    g_ctCreateSubscription = (CTIOR_CreateSubscription)dlsym(g_ctIOReport, "IOReportCreateSubscription");
    g_ctCreateSamples      = (CTIOR_CreateSamples)dlsym(g_ctIOReport, "IOReportCreateSamples");
    g_ctIterate            = (CTIOR_Iterate)dlsym(g_ctIOReport, "IOReportIterate");
    g_ctChannelName        = (CTIOR_ChannelGetChannelName)dlsym(g_ctIOReport, "IOReportChannelGetChannelName");
    g_ctChannelSubGroup    = (CTIOR_ChannelGetSubGroup)dlsym(g_ctIOReport, "IOReportChannelGetSubGroup");
    g_ctStateCount         = (CTIOR_StateGetCount)dlsym(g_ctIOReport, "IOReportStateGetCount");
    g_ctStateName          = (CTIOR_StateGetNameForIndex)dlsym(g_ctIOReport, "IOReportStateGetNameForIndex");
    g_ctStateResidency     = (CTIOR_StateGetResidency)dlsym(g_ctIOReport, "IOReportStateGetResidency");
    return (g_ctCopyChannels && g_ctCreateSubscription && g_ctCreateSamples && g_ctIterate &&
            g_ctStateCount && g_ctStateName && g_ctStateResidency);
}

static BOOL CTFreqSetup(void) {
    if (g_ctSub && g_ctSubbed) return YES;
    if (!CTFreqLoad()) { g_ctFreqErrCode = 1; return NO; }

    static const char *pairs[][2] = {
        { "CPU Stats", NULL },
        { "CPU Stats", "CPU Complex Performance States" },
        { "CPU Stats", "CPU Performance States" },
        { "PMP", NULL },
        { "SoC Stats", NULL },
        { NULL, NULL }
    };

    CFMutableDictionaryRef bestRel = NULL, bestRelSubbed = NULL;   // 含 CPU 频率通道的
    CFMutableDictionaryRef bestAny = NULL, bestAnySubbed = NULL;   // 兜底：其它
    int bestRelStates = 0, bestAnyStates = -1;
    for (int pi = 0; pairs[pi][0]; pi++) {
        CFStringRef g  = CTCFStr(pairs[pi][0]);
        CFStringRef sg = pairs[pi][1] ? CTCFStr(pairs[pi][1]) : NULL;
        CFMutableDictionaryRef chans = g_ctCopyChannels(g, sg, 0, 0, 0);
        if (g) CFRelease(g);
        if (sg) CFRelease(sg);
        if (!chans) continue;

        CFMutableDictionaryRef subbed = NULL;
        CFMutableDictionaryRef sub = g_ctCreateSubscription(NULL, chans, &subbed, 0, NULL);
        int totalStates = 0, chansWithStates = 0, anyOnly = 0;
        if (sub && subbed && g_ctCreateSamples && g_ctIterate && g_ctStateCount) {
            CFDictionaryRef samples = g_ctCreateSamples(sub, subbed, NULL);
            if (samples) {
                __block int tot = 0, cnt = 0, anyTot = 0;
                g_ctIterate(samples, ^int(CFDictionaryRef ch) {
                    int n = g_ctStateCount(ch);
                    if (n <= 0) return 0;
                    anyTot += n;
                    NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
                    BOOL rel = (sub && ([sub containsString:S("Complex Voltage States")] ||
                                        [sub containsString:S("Complex Performance States")]));
                    if (rel) { tot += n; cnt++; }
                    return 0;
                });
                totalStates = tot; chansWithStates = cnt;
                if (cnt == 0) anyOnly = anyTot;
                CFRelease(samples);
            }
        }
        CFRelease(chans);

        if (sub && subbed && totalStates > bestRelStates) {          // 优先：真有 CPU 频率通道的
            if (bestRel) CFRelease(bestRel);
            if (bestRelSubbed) CFRelease(bestRelSubbed);
            bestRel = sub; bestRelSubbed = subbed;
            bestRelStates = totalStates;
            g_ctFreqStateChans = chansWithStates;
        } else if (sub && subbed && anyOnly > bestAnyStates) {        // 兜底
            if (bestAny) CFRelease(bestAny);
            if (bestAnySubbed) CFRelease(bestAnySubbed);
            bestAny = sub; bestAnySubbed = subbed;
            bestAnyStates = anyOnly;
        } else {
            if (sub) CFRelease(sub);
            if (subbed) CFRelease(subbed);
        }
    }

    if (bestRel && bestRelSubbed) {
        if (bestAny) CFRelease(bestAny);
        if (bestAnySubbed) CFRelease(bestAnySubbed);
        g_ctSub = bestRel; g_ctSubbed = bestRelSubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    if (bestAny && bestAnySubbed) {
        g_ctSub = bestAny; g_ctSubbed = bestAnySubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    g_ctFreqErrCode = 2;
    return NO;
}
// 从 “P3: 2400MHz / 2.4GHz” 这类状态名里直接读频率
static double CTFreqParseStateNameMHz(CFStringRef name) {
    if (!name) return -1;
    NSString *s = [(__bridge NSString *)name lowercaseString];
    NSRange r = [s rangeOfString:@"ghz"];
    double mult = 1000.0;
    if (r.location == NSNotFound) { r = [s rangeOfString:@"mhz"]; mult = 1.0; }
    if (r.location == NSNotFound) return -1;
    // 往前取数字（含小数点）
    NSInteger end = (NSInteger)r.location;
    NSInteger start = end;
    while (start > 0) {
        unichar c = [s characterAtIndex:(NSUInteger)(start - 1)];
        if ((c >= '0' && c <= '9') || c == '.') start--; else break;
    }
    if (start >= end) return -1;
    double v = [[s substringWithRange:NSMakeRange((NSUInteger)start, (NSUInteger)(end - start))] doubleValue];
    if (v <= 0) return -1;
    return v * mult;
}

// 读某颗 CPU 的 DVFS 频率表（取状态数最接近的那张）
// 解析一段 uint32 数组：按 (频率,电压) 成对取频率，两种排列都试，用电压做合理性校验
static NSArray<NSNumber *> *CTFreqParsePairArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 6) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    for (int flip = 0; flip < 2; flip++) {
        NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
        BOOL ok = YES, asc = YES;
        double prev = 0;
        for (NSUInteger idx = 0; idx + 1 < n; idx += 2) {
            double a = w[idx], b = w[idx + 1];
            double f = flip ? b : a, volt = flip ? a : b;
            if (volt > 10000.0) volt /= 1000.0;              // µV → mV
            if (volt < 300.0 || volt > 1600.0) { ok = NO; break; }
            double mhz = CTFreqNormalizeMHz((long long)f);
            if (mhz < 200.0 || mhz > 4600.0) { ok = NO; break; }
            if (mhz < prev) asc = NO;
            prev = mhz;
            [freqs addObject:@(mhz)];
        }
        if (!ok || freqs.count < 3) continue;
        NSInteger delta = 0;
        if (want > 0) {
            delta = labs((long)((NSInteger)freqs.count - want));
            if (delta > 1) continue;                          // 长度要接近状态数（允许差 1 个 IDLE）
        }
        NSInteger sc = 100 - delta * 20 + (asc ? 10 : 0);
        if (sc > bestScore) { bestScore = sc; best = freqs; }
    }
    if (best && score) *score = bestScore;
    return best;
}

// 解析「纯频率列表」：整段都是 200~4600MHz 的升序值
static NSArray<NSNumber *> *CTFreqParsePlainArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 3) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
    double prev = 0;
    BOOL asc = YES;
    for (NSUInteger i = 0; i < n; i++) {
        double mhz = CTFreqNormalizeMHz((long long)w[i]);
        if (mhz < 200.0 || mhz > 4600.0) return nil;
        if (mhz < prev) asc = NO;
        prev = mhz;
        [freqs addObject:@(mhz)];
    }
    NSInteger delta = 0;
    if (want > 0) {
        delta = labs((long)((NSInteger)freqs.count - want));
        if (delta > 1) return nil;
    }
    if (score) *score = 90 - delta * 20 + (asc ? 10 : 0);
    return freqs;
}

// 递归扫设备树找频率表；先只找属性名含 voltage-states 的，找不到再全扫
static void CTFreqScanTree(io_registry_entry_t node, int depth, int want, BOOL onlyVoltageStates,
                           NSArray<NSNumber *> **best, NSInteger *bestScore, int *visited) {
    if (depth > 4 || (*visited) > 300) return;
    (*visited)++;
    char nodePath[512] = {0};
    IORegistryEntryGetPath(node, "IODeviceTree", nodePath);
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = CFBridgingRelease(props);
        for (NSString *k in d.allKeys) {
            if (onlyVoltageStates && ![k containsString:S("voltage-states")]) continue;
            NSInteger scPair = -1, scPlain = -1;
            NSArray<NSNumber *> *tPair = CTFreqParsePairArray(d[k], want, &scPair);
            NSArray<NSNumber *> *tPlain = CTFreqParsePlainArray(d[k], want, &scPlain);
            NSInteger sc = (scPlain > scPair) ? scPlain : scPair;
            NSArray<NSNumber *> *t = (scPlain > scPair) ? tPlain : tPair;
            if (t) {
                if (!g_ctFreqScanLog) g_ctFreqScanLog = [NSMutableString string];
                if (g_ctFreqScanLog.length < 4000) {
                    [g_ctFreqScanLog appendFormat:S("%s [%@] 档数=%lu 得分=%ld 值=%@\n"),
                     nodePath, k, (unsigned long)t.count, (long)sc,
                     [t componentsJoinedByString:S(",")]];
                }
            }
            if (t && sc > *bestScore) { *bestScore = sc; *best = t; }
        }
    }
    static const char *planes[] = { "IODeviceTree", "IOService" };
    for (int pi = 0; pi < 2; pi++) {
        if (*best) break;
        io_iterator_t it = 0;
        if (IORegistryEntryGetChildIterator(node, planes[pi], &it) != KERN_SUCCESS) continue;
        io_registry_entry_t child = 0;
        while ((child = IOIteratorNext(it))) {
            CTFreqScanTree(child, depth + 1, want, onlyVoltageStates, best, bestScore, visited);
            IOObjectRelease(child);
        }
        IOObjectRelease(it);
    }
}

// 实时扫描：每次都重新从系统（设备树）读，不做任何缓存
static NSArray<NSNumber *> *CTFreqTableScan(int stateCount) {
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    int visited = 0;
    io_registry_entry_t root = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/");
    if (root) {
        CTFreqScanTree(root, 0, stateCount, YES, &best, &bestScore, &visited);
        if (!best) { visited = 0; CTFreqScanTree(root, 0, stateCount, NO, &best, &bestScore, &visited); }
        IOObjectRelease(root);
    }
    if (best.count >= 2) best = [best sortedArrayUsingSelector:@selector(compare:)];
    if (!best) {   // 设备树里没搜到才用实测档位表兜底（A17 Pro）
        if (stateCount == 5) {
            best = @[ @744, @960, @1344, @1728, @2112 ];
        } else if (stateCount == 17) {
            best = @[ @576, @1092, @1344, @1584, @1824, @2064, @2304, @2544, @2724, @2904,
                      @3084, @3264, @3444, @3564, @3684, @3732, @3780 ];
        }
    }
    return best;
}

// 带缓存的版本（只有历史实时频率代码在用）
static NSArray<NSNumber *> *CTFreqTableMatching(int stateCount) {
    static NSMutableDictionary *cache = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSNumber *key = @(stateCount);
    if (cache[key]) return cache[key];
    NSArray<NSNumber *> *best = CTFreqTableScan(stateCount);
    if (best) cache[key] = best;
    return best;
}

// 从系统频率表里读「最高档」= 这个模式能跑到的 CPU 最大值
// 每次都重新读设备树（实时）；读不到返回 0，由调用方兜底
static int CTFreqSystemMaxMHz(int stateCount) {
    NSArray<NSNumber *> *tbl = CTFreqTableScan(stateCount);
    if (tbl.count == 0) return 0;
    return (int)[tbl.lastObject doubleValue];
}

// 取一次实时频率：返回当前“最高正在跑”的那个核心簇频率（MHz）
#include <notify.h>

// 系统热压力等级（thermalmonitord 广播）：0 正常 / 10 轻 / 20 中 / 30 重 / 40 / 50
// 读不到返回 -1（那就当作"没发热"，显示最高档）
static int CTThermalPressureLevel(void) {
    static int ctTpToken = -1;
    static BOOL ctTpTried = NO;
    if (!ctTpTried) {
        ctTpTried = YES;
        int t = 0;
        if (notify_register_check("com.apple.system.thermalpressurelevel", &t) == NOTIFY_STATUS_OK) {
            ctTpToken = (int)t;
        }
    }
    if (ctTpToken < 0) return -1;
    uint64_t st = 0;
    if (notify_get_state(ctTpToken, &st) != NOTIFY_STATUS_OK) return -1;
    return (int)st;
}

static BOOL CTFreqReadMHzInner(double *outMHz) {
    if (!CTFreqSetup()) return NO;
    CFDictionaryRef samples = g_ctCreateSamples(g_ctSub, g_ctSubbed, NULL);
    if (!samples) { g_ctFreqErrCode = 4; return NO; }

    __block double best = -1.0;
    __block BOOL sawActive = NO;
    __block NSInteger relChans = 0;
    __block int bestPrio = 0;
    __block int maxStates = 0;
    g_ctIterate(samples, ^int(CFDictionaryRef ch) {
        int n = g_ctStateCount(ch);
        if (n <= 0) return 0;
        if (n > maxStates) maxStates = n;

        // 只认两种通道：CPU Complex Voltage States（无 IDLE、下标对齐）
        //              CPU Complex Performance States（多一个 IDLE，下标要 -1）
        NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
        NSString *cname = g_ctChannelName ? (__bridge NSString *)g_ctChannelName(ch) : nil;
        BOOL isVoltStates = (sub && [sub containsString:S("Complex Voltage States")]);
        BOOL isPerfStates = (sub && [sub containsString:S("Complex Performance States")]);
        if (!isVoltStates && !isPerfStates) return 0;   // DVD 百分比、核心级通道都不要
        relChans++;
        // 优先级：大核 PCPU 的 Voltage States（3）> 其它 Voltage States（2）> Performance States（1）
        int prio = isVoltStates ? ([cname hasPrefix:S("PCPU")] ? 3 : 2) : 1;
        if (prio < bestPrio) return 0;

        if (!g_ctPrevRes) g_ctPrevRes = [NSMutableDictionary dictionary];
        // 取「这一秒内有活动过的最高档」= 实时最高频率
        // （状态计数是累计值 → 用本次与上次采样的差值判断"这一秒到底用没用过"）
        int hi = -1;
        int topIdx = -1;
        int64_t bestRes = 0;
        int base = isPerfStates ? 1 : 0;                 // Performance States 第 0 档是 IDLE
        int wantW = isPerfStates ? (n - 1) : n;
        NSArray<NSNumber *> *tblW = CTFreqTableMatching(wantW);
        double sumW = 0.0, sumWF = 0.0;                  // ★ 方案A：按占用时间加权
        for (int i = 0; i < n; i++) {
            int64_t r = g_ctStateResidency(ch, i);
            if (r > bestRes) { bestRes = r; hi = i; }
            NSString *rk = [NSString stringWithFormat:@"%@#%d", cname, i];
            NSNumber *prev = g_ctPrevRes[rk];
            int64_t d = prev ? (r - prev.longLongValue) : 0;
            g_ctPrevRes[rk] = @(r);
            if (d <= 0 || i < base) continue;
            int idx = i - base;
            if (idx > topIdx) topIdx = idx;
            double f = 0.0;
            if (tblW && idx < (int)tblW.count) f = tblW[idx].doubleValue;
            if (f <= 0.0) {
                int si0 = isPerfStates ? (idx + 1) : idx;
                if (si0 >= 0 && si0 < n) f = CTFreqParseStateNameMHz(g_ctStateName(ch, si0));
            }
            if (f > 0.0) { sumW += (double)d; sumWF += (double)d * f; }
        }
        if (hi < 0) return 0;
        sawActive = YES;

        int useIdx = (topIdx >= 0) ? topIdx : (isPerfStates ? (hi - 1) : hi);
        if (useIdx < 0) return 0;                        // 命中的是 IDLE 档，不算频率
        int si   = isPerfStates ? (useIdx + 1) : useIdx;  // 对应的状态名下标
        CFStringRef nmRef = (si >= 0 && si < n) ? g_ctStateName(ch, si) : NULL;
        NSString *nmStr = nmRef ? (__bridge NSString *)nmRef : nil;
        double topMHz = 0.0;
        if (topIdx >= 0 && tblW && topIdx < (int)tblW.count) topMHz = tblW[topIdx].doubleValue;
        double mhz = (sumW > 0.0) ? (sumWF / sumW) : 0.0;   // ★ 加权平均频率（方案 A）
        if (mhz <= 0) {
            NSArray<NSNumber *> *tbl = CTFreqTableMatching(wantW);
            if (tbl && useIdx < (int)tbl.count) mhz = tbl[useIdx].doubleValue;
        }
        if (mhz > 0) {
            if (prio > bestPrio) { bestPrio = prio; best = mhz; g_ctTopActiveMHz = topMHz; }
            else if (mhz > best) { best = mhz; g_ctTopActiveMHz = topMHz; }
            if (nmStr) g_ctFreqStateName = [nmStr copy];
        }
        return 0;
    });
    CFRelease(samples);
    g_ctFreqMaxStates = maxStates;
    g_ctFreqRelChans = relChans;   // cN：相关通道个数（诊断用）

    if (best >= 200.0 && best <= 6000.0) { if (outMHz) *outMHz = best; g_ctFreqErrCode = 0; return YES; }
    g_ctFreqErrCode = sawActive ? 6 : 5;
    return NO;
}

static double CTDirectFreqMHz(void) { double m = 0.0; return CTFreqReadMHzInner(&m) ? m : 0.0; }
static int CTDirectCurrentmA(void) {   // ★ 0930-0207：直读电池电流（正=进电 / 负=放电）
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    if (!svc) return 0;
    CFMutableDictionaryRef props = NULL;
    int ma = 0;
    if (IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = (__bridge_transfer NSDictionary *)props;
        id v = d[@"InstantAmperage"] ?: d[@"Amperage"];
        if ([v respondsToSelector:@selector(intValue)]) ma = [v intValue];
    }
    IOObjectRelease(svc);
    return ma;
}

static double CTDirectTempC(void) {   // ★ 0930-0207：直读电池温度（只读）
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    if (!svc) return -1.0;
    CFMutableDictionaryRef props = NULL;
    double t = -1.0;
    if (IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = (__bridge_transfer NSDictionary *)props;
        id v = d[@"Temperature"];
        if ([v respondsToSelector:@selector(doubleValue)]) {
            double x = [v doubleValue];
            if (x > 1000.0) x /= 100.0;
            if (x > 0.0 && x < 120.0) t = x;
        }
    }
    IOObjectRelease(svc);
    return t;
}


// ---------- 电池服务 ----------
static io_service_t BatteryService(BOOL preferSmart) {
    io_service_t service = IO_OBJECT_NULL;
    if (preferSmart)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    if (service == IO_OBJECT_NULL)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOPMPowerSource"));
    if (service == IO_OBJECT_NULL && !preferSmart)
        service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    return service;
}

static NSDictionary *BatteryProperties(void) {
    io_service_t service = BatteryService(YES);
    if (service == IO_OBJECT_NULL) return nil;
    CFMutableDictionaryRef raw = NULL;
    NSDictionary *out = nil;
    if (IORegistryEntryCreateCFProperties(service, &raw, kCFAllocatorDefault, 0) == KERN_SUCCESS && raw)
        out = CFBridgingRelease(raw);
    IOObjectRelease(service);
    return out;
}

static BOOL AdapterConnected(NSDictionary *properties) {
    NSDictionary *adapter = [properties[S("AdapterDetails")] isKindOfClass:[NSDictionary class]] ? properties[S("AdapterDetails")] : nil;
    NSString *description = [adapter[S("Description")] isKindOfClass:[NSString class]] ? adapter[S("Description")] : nil;
    if (adapter.count && ![description isEqualToString:S("batt")]) return YES;
    return [properties[S("ExternalConnected")] boolValue] || [properties[S("ExternalChargeCapable")] boolValue];
}

// ---------- 写入（双服务尝试；1=AppleSmartBattery 2=IOPMPowerSource 0=全败） ----------
static BOOL WriteToOneService(BOOL preferSmart, NSDictionary *props, int *outErr) {
    io_service_t service = BatteryService(preferSmart);
    if (service == IO_OBJECT_NULL) { *outErr = 1; return NO; }
    kern_return_t r = IORegistryEntrySetCFProperties(service, (__bridge CFTypeRef)props);
    IOObjectRelease(service);
    *outErr = (r == KERN_SUCCESS) ? 0 : (int)r;
    return r == KERN_SUCCESS;
}

// 返回：成功=YES 且 outSvc 记住赢家；失败 outSvc=0、outErr=最后错误
static BOOL WriteCascade(NSDictionary *props, int *outSvc, int *outErr) {
    int err = 0;
    if (WriteToOneService(YES, props, &err)) { *outSvc = 1; *outErr = 0; return YES; }
    int lastErr = err;
    if (WriteToOneService(NO, props, &err)) { *outSvc = 2; *outErr = 0; return YES; }
    lastErr = err;
    *outSvc = 0; *outErr = lastErr;
    return NO;
}

// ---------- 通道封装（与主插件语义对齐） ----------
// 停充主通道：IsCharging=YES + PredictiveChargingInhibit=YES（ChargeLimiter 实证组合）
static BOOL PressStopMain(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @YES;
    p[S("PredictiveChargingInhibit")] = @YES;
    return WriteCascade(p, svc, err);
}
// 禁流通道：ExternalConnected=NO
static BOOL PressStopInflow(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("ExternalConnected")] = @NO;
    return WriteCascade(p, svc, err);
}
// 备用形态：直写 IsCharging=NO
static BOOL PressStopDirect(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @NO;
    return WriteCascade(p, svc, err);
}
// 恢复
static BOOL PressAllowInflow(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("ExternalConnected")] = @YES;
    return WriteCascade(p, svc, err);
}
static BOOL PressAllowMain(int *svc, int *err) {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    p[S("IsCharging")] = @YES;
    p[S("PredictiveChargingInhibit")] = @NO;
    return WriteCascade(p, svc, err);
}

// ---------- 状态 ----------
static BOOL gOwnsStop = NO;         // 我们当前按着"停"
static BOOL gFeatureWasOn = NO;
static CFAbsoluteTime gStoppedAt = 0;
static CFAbsoluteTime gLastFailLog = 0;
static int gLastSig = -9999;
static int gLastAbsMA = -1;   // 上轮电流（用于"被放开"边沿检测）
static CFAbsoluteTime gLastAllowAt = 0;    // 清残留放行的节流
static CFAbsoluteTime gLastReleaseLog = 0; // 清残留日志 60 秒限频

// ---------- 自检探针（启动时各跑一次） ----------
static void RunWriteProbe(void) {
    // 探针1：把 ExternalConnected 的原值原样写回（真实键、无副作用）
    NSDictionary *props = BatteryProperties();
    BOOL extVal = props ? [props[S("ExternalConnected")] boolValue] : YES;
    NSMutableDictionary *p1 = [NSMutableDictionary dictionary];
    p1[S("ExternalConnected")] = @(extVal);
    int svc = 0, err = 0;
    BOOL ok1 = WriteCascade(p1, &svc, &err);
    // 探针2：自定义键（看是否"全禁"）
    NSMutableDictionary *p2 = [NSMutableDictionary dictionary];
    p2[S("CTHermesProbe")] = @(1);
    int svc2 = 0, err2 = 0;
    BOOL ok2 = WriteCascade(p2, &svc2, &err2);
    ctlog(@"写入探针：真实键回写=%@（服务%d 错误%d）自定义键=%@（服务%d 错误%d）",
          ok1 ? @"成功" : @"失败", svc, err, ok2 ? @"成功" : @"失败", svc2, err2);
}

// ---------- ★ 0929：网速采样（root 守护进程，无沙箱限制；写文件供浮窗读取） ----------
static uint64_t gToolNetLastBytes = 0;
static CFAbsoluteTime gToolNetLastAt = 0;
static double gToolNetAvg = 0.0;
static CFAbsoluteTime gToolNetLastLog = 0;
static int gToolNetFailLogged = 0;
static int gToolNetIfCount = 0;
static uint64_t CTToolNetBytes(void) {
    uint64_t total = 0;
    int matched = 0;
    struct ifaddrs *addrs = NULL;
    if (getifaddrs(&addrs) == 0) {
        for (struct ifaddrs *ifa = addrs; ifa; ifa = ifa->ifa_next) {
            if (!ifa->ifa_addr || ifa->ifa_addr->sa_family != AF_LINK || !ifa->ifa_data) continue;
            const char *nm = ifa->ifa_name;
            if (!nm) continue;
            if (strncmp(nm, "en", 2) != 0 && strncmp(nm, "pdp_ip", 6) != 0) continue;
            struct if_data *di = (struct if_data *)ifa->ifa_data;
            total += (uint64_t)di->ifi_ibytes + (uint64_t)di->ifi_obytes;
            matched++;
        }
        freeifaddrs(addrs);
    } else if (!gToolNetFailLogged) {
        gToolNetFailLogged = 1;
        ctlog(@"网速采样失败（getifaddrs 被拒）");
    }
    gToolNetIfCount = matched;
    return total;
}
static void CTToolNetTick(void) {
    uint64_t total = CTToolNetBytes();
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    int bps = 0;
    if (gToolNetLastAt > 0 && now > gToolNetLastAt + 0.25 && total >= gToolNetLastBytes) {
        bps = (int)((total - gToolNetLastBytes) / (now - gToolNetLastAt));
    }
    gToolNetLastBytes = total; gToolNetLastAt = now;
    gToolNetAvg = gToolNetAvg * 0.55 + (double)bps * 0.45;
    int outBps = (int)gToolNetAvg;
    NSString *__np = [CTDiagLogDir() stringByAppendingPathComponent:S("CTHermesNet.txt")];
    const char *netPath = __np.fileSystemRepresentation;
    char tmpPath[128];
    snprintf(tmpPath, sizeof(tmpPath), "%s.tmp", netPath);
    FILE *f = fopen(tmpPath, "w");
    if (f) { fprintf(f, "%d", outBps); fclose(f); rename(tmpPath, netPath); CTStateWrite(@"CTHermesNet.txt", [NSString stringWithFormat:@"%d", outBps]); }   // ★ 0930-0207：镜像一份到共享目录
    if (now - gToolNetLastLog > 300.0) {   // 首条立刻记，之后每 5 分钟
        gToolNetLastLog = now;
        ctlog(@"网速采样：%d B/s（平滑后；接口数=%d）", outBps, gToolNetIfCount);
    }
}

static BOOL sUnauthLogged = NO;   // 未授权提示只记一次（授权恢复后允许再记）
// ---------- 授权门控（★ 0930）：主插件写授权文件；未激活 → 本工具待命 ----------
static BOOL CTToolAuthorized(void) {
    static CFAbsoluteTime sLastRead = 0;
    static BOOL sAuth = NO;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - sLastRead > 3.0) {
        sLastRead = now;
        // ★ 1.4.11：授权文件内容 = 授权码本身 → 必须能独立验签才算数（不再认裸 "1"，杜绝旁路）
        sAuth = CTAuthFileAuthorized();
        if (!sAuth) {
            // ★ 0930-0191：独立验签兜底（修死代码：原先无论验签结果都被下一行覆盖成 NO）
            // 文件缺失 / 文件为 0 都兜底一次；验签不过才保守待命（绝不放行未激活）
            NSString *__c = [CTHermesReadPrefs() objectForKey:kCTKeyActivationCode];
            NSString *__dv = CTAuthDeviceCode();
            if ([__c isKindOfClass:[NSString class]] && __c.length > 0 && __dv.length > 0 &&
                CTAuthVerifyCode(__dv, __c)) {
                sAuth = YES;
                sUnauthLogged = NO;   // 授权恢复 → 允许下次状态变化再记录一次
            }
        }
    }
    // ★ 0930-0207：root 身份把授权码同步到"跨权限票据"路径
    //   （某些机器上温控进程读不到 /var/mobile/Library/…，全靠这份票据判定授权，否则核心会全程待命）
    if (sAuth) {
        static CFAbsoluteTime sTkSyncAt = 0;
        CFAbsoluteTime nowTk = CFAbsoluteTimeGetCurrent();
        if (nowTk - sTkSyncAt > 60.0) { sTkSyncAt = nowTk; CTAuthTicketWrite(CTAuthBestCodeText()); }
    }
    return sAuth;
}

// ---------- 核心评估 ----------
static void EvaluateBattery(void) {
    NSDictionary *prefs = CTHermesReadPrefs() ?: @{};
    BOOL enabled = [prefs[S("chargeLimitEnabled")] respondsToSelector:@selector(boolValue)] ? [prefs[S("chargeLimitEnabled")] boolValue] : NO;
    int limit = [prefs[S("chargeLimitValue")] respondsToSelector:@selector(intValue)] ? [prefs[S("chargeLimitValue")] intValue] : 80;
    if (limit < 50) limit = 50; if (limit > 100) limit = 100;
    int resumeLevel = limit - 5; if (resumeLevel < 40) resumeLevel = 40;
    // ★ 1.4.60：守护也认"温度保护"（此前只认上限 ⇒ 会把核心的温控停充顶回去 ✓）
    BOOL ctTempOn = NO;   // ★ 1.4.61：功能已取消 ✓
    int ctTempVal = [prefs[S("chargeTempThreshold")] respondsToSelector:@selector(intValue)] ? [prefs[S("chargeTempThreshold")] intValue] : 42;
    if (ctTempVal < 35) ctTempVal = 35; if (ctTempVal > 55) ctTempVal = 55;
    double ctT = CTDirectTempC();
    BOOL ctTempWantsStop = (ctTempOn && ctT > 0.0 && ctT >= (double)ctTempVal);

    // ★ 1.4.105：启动"松开一次"——不管激活与否，先把历史"停充"残留清掉（未激活/刚装好也绝不被残留卡住）
    {
        static BOOL sStartupCleared = NO;
        if (!sStartupCleared) {
            sStartupCleared = YES;
            int svc0 = 0, err0 = 0;
            PressAllowInflow(&svc0, &err0);
            PressAllowMain(&svc0, &err0);
            ctlog(@"启动：已清一次停充残留（服务%d 错误%d）", svc0, err0);
        }
    }

    // ★ 授权门控：未激活 → 待命（并松开一切停充）
    if (!CTToolAuthorized()) {
        if (!sUnauthLogged) { sUnauthLogged = YES; ctlog(@"未授权 → 充电管理待命（激活后自动上岗）"); }
        if (gFeatureWasOn || gOwnsStop) {
            int svc = 0, err = 0;
            PressAllowInflow(&svc, &err);
            PressAllowMain(&svc, &err);
            gOwnsStop = NO; gStoppedAt = 0;
            ctlog(@"未授权 → 已恢复充电（待命）");
        }
        gFeatureWasOn = NO;
        return;
    }

    // ★ 1.4.105：本段已移到授权门控之前（不管激活与否都要先松开）

    if (!enabled) {
        if (gFeatureWasOn || gOwnsStop) {
            int svc = 0, err = 0;
            PressAllowInflow(&svc, &err);
            PressAllowMain(&svc, &err);
            gOwnsStop = NO; gStoppedAt = 0;
            ctlog(@"功能关闭 → 已发出恢复充电");
        }
        gFeatureWasOn = NO;
        return;
    }
    if (!gFeatureWasOn) ctlog(@"功能开启（上限=%d%%）", limit);

    gFeatureWasOn = YES;

    NSDictionary *props = BatteryProperties();
    if (!props) return;
    NSInteger capacity = [props[S("CurrentCapacity")] integerValue];
    double amp = [props[S("InstantAmperage")] doubleValue];
    if (![props[S("InstantAmperage")] isKindOfClass:[NSNumber class]])
        amp = [props[S("Amperage")] doubleValue];
    int absMA = (int)(amp < 0 ? -amp : amp);
    BOOL connected = AdapterConnected(props);
    if (capacity < 0 || !connected) return;

    BOOL isChargingB = [props[S("IsCharging")] respondsToSelector:@selector(boolValue)] ? [props[S("IsCharging")] boolValue] : NO;
    BOOL atOrAbove = (capacity >= limit);
    BOOL normalRelease = (capacity <= resumeLevel);

    if (atOrAbove) {
        // 到点：停充（主通道 + 禁流），双双重申；都失败再换直写形态
        int svcM = 0, errM = 0, svcI = 0, errI = 0;
        BOOL okM = PressStopMain(&svcM, &errM);
        BOOL okI = PressStopInflow(&svcI, &errI);
        int svcD = 0, errD = 0; BOOL okD = NO;
        if (!okM && !okI) okD = PressStopDirect(&svcD, &errD);

        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        BOOL newlyStopped = !gOwnsStop;
        BOOL released = NO;
        if (gOwnsStop && gLastAbsMA >= 0 && gLastAbsMA <= 150 && absMA > 150) released = YES;   // 由"已切断"变"又有电流"= 被系统放开（边沿）
        gLastAbsMA = absMA;
        gOwnsStop = YES; if (gStoppedAt <= 0) gStoppedAt = now;

        // 日志：状态变化必记；稳态 60 秒一条；新按下/被放开立即记
        int sig = (okM ? 100 : 0) + (okI ? 10 : 0) + (absMA > 150 ? 1 : 0);
        if (newlyStopped || released || sig != gLastSig || (now - gLastFailLog) > 60.0) {
            gLastSig = sig; gLastFailLog = now;
            if (released)
                ctlog(@"⚠️ 被系统放开 → 已重新按（主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA）",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
            else if (newlyStopped && (okM || okI || okD))
                ctlog(@"已咬合：主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
            else
                ctlog(@"停充重申：主[服务%d 错误%d] 禁流[服务%d 错误%d] 直写[服务%d 错误%d] 电量=%d%% 电流=%dmA",
                      svcM, errM, svcI, errI, svcD, errD, (int)capacity, absMA);
        }
    } else {
        // ★ 1.4.6z6：掉过回差线放行；并清理"插着但没在充、又不是我们按的"残留停充状态
        CFAbsoluteTime nowR = CFAbsoluteTimeGetCurrent();
        BOOL releaseOwn = (gOwnsStop && normalRelease);
        // ★ 1.4.8 修复（重要）：原逻辑在"插着电但此刻没在充"时每 10 秒写一次"允许充电"——
        //   而快充期间 iOS 本就会频繁短暂停充（PD 协商/温控/脉冲），我们反复去写会把
        //   充电状态机打断 → 实测快充被压到 ~1.6A/6.6W（用户实锤）。改为：只有"是我们按下的"才恢复。
        // ★ 1.4.8b 修正：不再一有"没在充"就放行（会打断快充），也不能完全不管（会卡死不充电）。
        //   折中：插着电 + 持续 90 秒几乎无电流（absMA<=20）才放行一次；写入后 90 秒冷却。
        //   快充协商/脉冲停充都在 10 秒内完成 → 不会被打断；真卡死则 90 秒后自动恢复。
        BOOL staleStop = (!gOwnsStop && !isChargingB && absMA <= 20 && (nowR - gLastAllowAt > 90.0));
        // ★ 1.4.60：温度保护想要停 ⇒ 守护不得恢复/清残留（治"4 秒后又被充上"✓）
        if (ctTempWantsStop) { releaseOwn = NO; staleStop = NO; }
        if (releaseOwn || staleStop) {
            int svc = 0, err = 0;
            PressAllowInflow(&svc, &err);
            PressAllowMain(&svc, &err);
            gLastAllowAt = nowR;
            if (releaseOwn) {
                gOwnsStop = NO; gStoppedAt = 0; gLastSig = -9999;
                ctlog(@"恢复充电（电量=%d%%）", (int)capacity);
            } else if (nowR - gLastReleaseLog > 60.0) {
                gLastReleaseLog = nowR;
                ctlog(@"恢复充电·清残留停充（电量=%d%%）", (int)capacity);
            }
        }
    }
}

// ---------- 退出时恢复 ----------
static void RestoreBeforeExit(void) {
    if (gOwnsStop) {
        int svc = 0, err = 0;
        PressAllowInflow(&svc, &err);
        PressAllowMain(&svc, &err);
        gOwnsStop = NO;
        ctlog(@"退出：已恢复充电");
    }
}
static void SignalHandler(int sig) {
    (void)sig;
    RestoreBeforeExit();
    _exit(0);
}

// ============================================================================
// ★ 注销代做：主插件跑在 thermalmonitord 里，权限不保证；本进程是 LaunchDaemon（root），最稳。
//   主插件杀不动 SpringBoard 时会写请求文件 + 发通知，本进程接手真正重启 SpringBoard。
// ============================================================================
static void CTToolKillSpringBoard(NSString *why) {
    const char *paths[] = {"/var/jb/usr/bin/killall", "/usr/bin/killall", "/bin/killall", "/var/jb/bin/killall", NULL};
    for (int i = 0; paths[i]; i++) {
        if (access(paths[i], X_OK) != 0) continue;
        pid_t p = fork();
        if (p == 0) { execl(paths[i], "killall", "-9", "SpringBoard", (char *)NULL); _exit(127); }
        if (p > 0) { int st = 0; waitpid(p, &st, 0); ctlog(@"[注销] %@：killall(%s) 状态=%d", why, paths[i], st); return; }
    }
    pid_t p = fork();                       // PATH 里找（RootHide 的 jb 路径随机，写死不可靠）
    if (p == 0) { execlp("killall", "killall", "-9", "SpringBoard", (char *)NULL); _exit(127); }
    if (p > 0) { int st = 0; waitpid(p, &st, 0); if (st == 0) { ctlog(@"[注销] %@：killall(PATH) 状态=%d", why, st); return; } }
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};   // 最后兜底：枚举进程杀
    size_t len = 0;
    if (sysctl(mib, 4, NULL, &len, NULL, 0) != 0 || len == 0) { ctlog(@"[注销] %@：拿不到进程表", why); return; }
    len = len * 3 / 2 + 8192;
    struct kinfo_proc *buf = malloc(len);
    if (!buf) return;
    size_t got = len;
    if (sysctl(mib, 4, buf, &got, NULL, 0) == 0) {
        int n = (int)(got / sizeof(struct kinfo_proc));
        for (int i = 0; i < n; i++) {
            if (strcmp(buf[i].kp_proc.p_comm, "SpringBoard") == 0) {
                if (kill(buf[i].kp_proc.p_pid, SIGKILL) == 0) ctlog(@"[注销] %@：已 SIGKILL SpringBoard(%d)", why, (int)buf[i].kp_proc.p_pid);
                else ctlog(@"[注销] %@：kill 失败 errno=%d", why, errno);
            }
        }
    }
    free(buf);
}

static void CTToolRespringIfRequested(void) {
    NSString *__rq = [CTDiagLogDir() stringByAppendingPathComponent:S("CTHermesRespring.req")];
    const char *req = __rq.fileSystemRepresentation;
    if (access(req, F_OK) != 0) return;
    unlink(req);
    ctlog(@"[注销] 收到注销请求（宿主权限不足）→ 由 root 守护进程代做");
    CTToolKillSpringBoard(@"代做");
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc > 1 && strcmp(argv[1], "probe") == 0) { RunWriteProbe(); return 0; }
        if (argc > 1 && strcmp(argv[1], "reset") == 0) { RestoreBeforeExit(); return 0; }

        ctlog(@"启动 %s", kToolTag);
        signal(SIGTERM, SignalHandler); signal(SIGINT, SignalHandler); signal(SIGHUP, SignalHandler);
        CTNotifyStateStart();   // ★ 0930-0207：订阅核心的"桶通知"（守护当桥）
        // ★ 0930-0207：一次性清掉"旧版直读"残留在共享状态文件里的污染（标记文件保证只做一次）
        {
            NSString *mark = CTStateRead(@"CTHermesCleanup.done");
            if (!mark.length) {
                CTStateRemove(@"CTHermesStatus.txt");
                CTStateWrite(@"CTHermesCleanup.done", [NSString stringWithFormat:@"%.0f", CFAbsoluteTimeGetCurrent()]);
                ctlog(@"[清理] 已清一次旧版共享状态污染");
            }
        }
        RunWriteProbe();

        int token = 0;
        notify_register_dispatch(kCTHermesSettingsChangedNotifC, &token, dispatch_get_main_queue(), ^(int t) {
            (void)t; @autoreleasepool { EvaluateBattery(); CTToolRespringIfRequested(); }
        });
        [NSTimer scheduledTimerWithTimeInterval:5.0 repeats:YES block:^(__unused NSTimer *timer) {
            ctAppearanceRelay();
            ctCoreDataBridge();   // ★ 0930-0207：核心数据桥
            ctRelayBridge();   // ★ 0930-0207：核心↔界面 数据中转
            @autoreleasepool { EvaluateBattery(); CTToolRespringIfRequested(); }
        }];
        [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(__unused NSTimer *timer) {
            @autoreleasepool { CTToolNetTick(); }
        }];
        EvaluateBattery();
        [[NSRunLoop mainRunLoop] run];
    }
    return 0;
}
