#import <CTHermesPaths.h>
#include <stdio.h>
#include <sys/time.h>
// ★ 0930-0207：CC 诊断日志（写主日志，便于判断"控制中心有没有来取模块"）
static void CTCCLog(NSString *msg) {
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; localtime_r(&tv.tv_sec, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    FILE *f = CTDiagLogOpenForAppend();   // ★ 2.0.38：统一闸门
    // ★ 2.0.38：/var/jb 兜底已移除（隐根零旧路径）
    if (f) { fprintf(f, "[%s][CC] %s\n", ts, msg.UTF8String); fclose(f); }
}

#import "CTHermesCCModule.h"
#import "CTHermesCCModuleViewController.h"

@implementation CTHermesCCModule

@synthesize contentViewController = _contentViewController;

+ (void)load { CTCCLog(@"模块类已加载 (CTHermesCCModule)"); }

- (UIViewController<CCUIContentModuleContentViewController> *)contentViewController {
    if (!_contentViewController) {
        CTCCLog(@"控制中心来取 contentViewController");
        @try {
            _contentViewController = [[CTHermesCCModuleViewController alloc] init];
        } @catch (NSException *e) {
            CTCCLog([NSString stringWithFormat:@"contentViewController 创建异常: %@", e.reason]);
            _contentViewController = nil;
        }
        if (!_contentViewController) {
            CTCCLog(@"创建失败 → 退回空白控制器（先保证能显示）");
            _contentViewController = (UIViewController<CCUIContentModuleContentViewController> *)[[UIViewController alloc] init];
        }
    }
    return _contentViewController;
}

- (UIViewController *)backgroundViewController {
    return nil;
}

@end
