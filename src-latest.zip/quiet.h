#define CTLOG(...) ((void)0)
