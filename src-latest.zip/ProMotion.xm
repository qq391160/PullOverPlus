// ============================================================================
// CTHermesProMotion —— 「高刷解锁」（★ 2.0.68 新件；注入 UIApplication 类进程＝所有 App + SpringBoard）
//   目标：让高刷设备「持续保持 120 帧、丝滑流畅」——全链路把帧率顶到 120（App + SpringBoard + WebKit + backboardd）：
//     UIScreen / CADisplayLink / CAMetalLayer·Drawable / CAContext / CADisplayPreferences /
//     CADynamicFrameRateSource / CAFrameRateRangeGroup；SpringBoard 内再挂一条常驻值守维持系统界面。
//   （全链路钳位；按本插件自有风格实现）
//   硬门（缺一即完全直通、零动作）：①已授权 ②设置里「开启高刷」=开 ③本机支持 120Hz（13 Pro 及以上）
//   红线：零新线程（常驻源=一条 CADisplayLink）；开关关=完全还原系统行为；全 @try，异常一律放行；
//         不写任何文件（卸载 0 残留）；设置变更即时生效（通知驱动、零轮询）；仅上岗时每进程写 1 行日志。
//   ★ 2.0.92：智能锁帧——只认"滑动/拖动"才锁满 120（点按/打字不触发）；松手即放（省电）；
//     视频/直播纯看=让路（交系统）；深层在岗=每 10 分钟定期上报（不再只靠开机一次）。
// ============================================================================
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#import <notify.h>
#import <CTHermesPaths.h>
#import <CTHardening.h>
#include <stdio.h>
#include <sys/time.h>

#define CTPM_TARGET_FPS 120

#ifndef __IPHONE_15_0
typedef struct { float minimum; float maximum; float preferred; } CAFrameRateRange;
#endif

static BOOL gPMIsSB = NO;
static BOOL gPMIsDeep = NO;   // ★ 2.0.69：backboardd / WebKit 内容进程 = "全局注入"层（由开关控制）
static BOOL gPMUninstalled = NO;   // ★ 2.0.73：卸载自拆——收到"卸载中"通知后全线停手（0 残留）

// ---------- 日志（仅在"上岗"时写一次/进程；未开启=零日志） ----------
static void CTPMLog(const char *fmt, ...) {
    FILE *fp = CTDiagLogOpenForAppend();
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][高刷] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

// ---------- 本机是否支持 120Hz（CADisplay 模式表里找 ≥119；结果缓存） ----------
@interface CADisplayMode : NSObject
@property (nonatomic, readonly) double refreshRate;
@end

@interface CADisplay : NSObject
+ (CADisplay *)mainDisplay;
@property (nonatomic, readonly) NSArray *availableModes;
- (void)setPreferences:(id)preferences;
@end

static BOOL CTPMDeviceSupports120(void) {
    static BOOL checked = NO; static BOOL supported = NO;
    if (!checked) {
        @autoreleasepool {
            Class cls = NSClassFromString(@"CADisplay");
            if (cls) {
                CADisplay *d = [cls performSelector:@selector(mainDisplay)];
                if (d) {
                    NSArray *modes = [d valueForKey:@"availableModes"];
                    for (id m in modes) {
                        double rate = [[m valueForKey:@"refreshRate"] doubleValue];
                        if (rate >= 119.0) { supported = YES; break; }
                    }
                }
            }
        }
        checked = YES;
    }
    return supported;
}

// ---------- 硬门（5 秒缓存；关=全线直通） ----------
static BOOL CTPMActive(void) {
    static BOOL sOK = NO; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (now - sAt) < 5.0) return sOK;
    sAt = now; sOK = NO;
    @try {
        NSDictionary *p = CTHermesReadPrefs();
        if (!gPMUninstalled && [p[S("proMotion120Enabled")] boolValue] && CTAuthFileAuthorized()) sOK = YES;
    } @catch (__unused NSException *e) { sOK = NO; }
    return sOK;
}
// ★ 2.0.69："全局注入"开关（仅影响深层进程；5 秒缓存；关=常规层照常）
static BOOL CTPMGlobalOn(void) {
    static BOOL sOK = NO; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (now - sAt) < 5.0) return sOK;
    sAt = now; sOK = NO;
    @try {
        NSDictionary *p = CTHermesReadPrefs();
        if ([p[S("proMotionGlobalEnabled")] boolValue]) sOK = YES;
    } @catch (__unused NSException *e) { sOK = NO; }
    return sOK;
}
// ★ 2.0.88：「滑动锁满 120」开关（把帧率申报的最低档也顶到 120；5 秒缓存；关=维持原行为）
static BOOL CTPMLockOn(void) {
    static BOOL sOK = NO; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (now - sAt) < 5.0) return sOK;
    sAt = now; sOK = NO;
    @try {
        NSDictionary *p = CTHermesReadPrefs();
        if ([p[S("proMotionLockEnabled")] boolValue]) sOK = YES;
    } @catch (__unused NSException *e) { sOK = NO; }
    return sOK;
}
// ★ 2.0.92：智能锁帧场景状态——"只认滑动/拖动"（通知驱动、零轮询）
static CFAbsoluteTime gPMLastDrag = 0;   // 最近一次手指移动（滑动/拖动）时刻
static BOOL gPMVideoOn = NO;             // 视频/直播播放中（纯看=让路，不顶）
static BOOL CTPMSlideActive(void) {      // 滑动窗口：最后一次拖动后 1.5 秒内
    if (gPMLastDrag <= 0) return NO;
    return (CFAbsoluteTimeGetCurrent() - gPMLastDrag) < 1.5;
}
static BOOL CTPMVideoPass(void) {        // 视频让路：播放中且不是在滑动
    return gPMVideoOn && !CTPMSlideActive();
}
static BOOL CTPMAnyOK(void)     { return CTPMActive() && CTPMDeviceSupports120() && (!gPMIsDeep || CTPMGlobalOn()); }
static BOOL CTPMEffective(void) { return CTPMAnyOK() && !CTPMVideoPass(); }   // ★ 2.0.92：视频让路时=直通
static BOOL CTPMGeneralOK(void) { return CTPMEffective() && !gPMIsSB; }
static BOOL CTPMLockNow(void) { return CTPMLockOn() && CTPMSlideActive(); }   // ★ 2.0.92：锁帧门=开关开且滑动窗口内
static BOOL CTPMRangeForced(void) { return CTPMEffective() && (!CTPMLockOn() || CTPMSlideActive()); }   // 常驻结构门

static void CTPMApplyDisplayLink(CADisplayLink *link) {
    if (!link) return;
    @try {
        if ([link respondsToSelector:@selector(setPreferredFrameRateRange:)]) {
            CAFrameRateRange range;
            range.minimum = CTPMLockNow() ? CTPM_TARGET_FPS : 10;   // ★ 2.0.92：只在滑动窗口内锁满 120（松手即放）
            range.maximum = CTPM_TARGET_FPS;
            range.preferred = CTPM_TARGET_FPS;
            [link setPreferredFrameRateRange:range];
        } else if ([link respondsToSelector:@selector(setPreferredFramesPerSecond:)]) {
            [link setPreferredFramesPerSecond:0];
        }
    } @catch (__unused NSException *e) {}
}

// ---------- SpringBoard 常驻值守（开关可随时切换、通知驱动、零轮询） ----------
@interface CTHermesPMRefreshSource : NSObject
@property (nonatomic, strong) CADisplayLink *link;
@property (nonatomic, assign) BOOL slideLockNow;   // ★ 2.0.92：当前是否处于"滑动锁帧"档
+ (instancetype)shared;
- (void)sync;
@end
@implementation CTHermesPMRefreshSource
+ (instancetype)shared {
    static CTHermesPMRefreshSource *s = nil; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[self alloc] init]; });
    return s;
}
// ★ 2.0.92：按场景给常驻源定档——锁帧窗口=120 满档；松手/视频让路=放行（省电）
- (void)applyRange {
    @try {
        if (!self.link) return;
        BOOL lockNow = CTPMLockNow();
        BOOL released = CTPMVideoPass() || (CTPMLockOn() && !lockNow);
        CAFrameRateRange r;
        r.minimum = lockNow ? CTPM_TARGET_FPS : 10;
        r.maximum = CTPM_TARGET_FPS;
        r.preferred = released ? 10 : CTPM_TARGET_FPS;
        if ([self.link respondsToSelector:@selector(setPreferredFrameRateRange:)]) [self.link setPreferredFrameRateRange:r];
        self.slideLockNow = lockNow;
    } @catch (__unused NSException *e) {}
}
- (void)bumpSlide {   // ★ 2.0.94：滑动起步→锁帧（带日志；已在档则仅靠时间戳续期）
    @try {
        if (self.slideLockNow) return;
        [self sync];
        if (gPMIsSB && self.slideLockNow) CTPMLog("场景：滑动 → 锁帧 120");
    } @catch (__unused NSException *e) {}
}
- (void)sync {
    @try {
        BOOL want = CTPMActive() && CTPMDeviceSupports120();
        if (want && !self.link) {
            self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
            [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
            CTPMLog("常驻值守=已启动");
        } else if (!want && self.link) {
            [self.link invalidate]; self.link = nil;
            CTPMLog("常驻值守=已停止");
        }
        [self applyRange];
    } @catch (__unused NSException *e) {}
}
- (void)tick:(CADisplayLink *)link {
    (void)link;
    // ★ 2.0.92：滑动结束的自动松开——只在状态跳变时动手（只比对时间戳，不轮询业务）
    @try {
        if (CTPMLockOn() && self.slideLockNow != CTPMSlideActive()) {
            BOOL was = self.slideLockNow;
            [self applyRange];
            if (gPMIsSB) CTPMLog(was ? "场景：松开 → 回落省电" : "场景：滑动 → 锁帧 120");
        }
    } @catch (__unused NSException *e) {}
}
@end

// ============================================================
// UIScreen 帧率上限（App 内；SpringBoard 走常驻源，不在本钩子范围）
// ============================================================
%hook UIScreen
- (NSInteger)maximumFramesPerSecond {
    if (CTPMGeneralOK()) return CTPM_TARGET_FPS;
    return %orig;
}
%end

// ============================================================
// App 级 CADisplayLink（持续 120 的核心：新建即顶满 + 改回满档）
// ============================================================
%hook CADisplayLink

+ (CADisplayLink *)displayLinkWithTarget:(id)target selector:(SEL)sel {
    CADisplayLink *link = %orig;
    if (CTPMGeneralOK()) CTPMApplyDisplayLink(link);
    return link;
}

- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CTPMGeneralOK()) {
        CAFrameRateRange newRange;
        newRange.minimum = (range.minimum > 0 && range.minimum <= CTPM_TARGET_FPS) ? range.minimum : 10;
        newRange.preferred = CTPM_TARGET_FPS;
        newRange.maximum = CTPM_TARGET_FPS;
        if (newRange.minimum > CTPM_TARGET_FPS) newRange.minimum = 10;
        if (CTPMLockNow()) newRange.minimum = CTPM_TARGET_FPS;   // ★ 2.0.92：滑动窗口内才把最低档顶满
        %orig(newRange);
    } else {
        %orig(range);
    }
}

- (void)setPreferredFramesPerSecond:(NSInteger)fps {
    if (CTPMGeneralOK()) {
        %orig(0);
    } else {
        %orig(fps);
    }
}

- (void)setFrameInterval:(NSInteger)interval {
    if (CTPMGeneralOK()) {
        %orig(1);
    } else {
        %orig(interval);
    }
}
%end

// ============================================================
// CAAnimation 帧率申报（★ 2.0.88 新增；仅「滑动锁满 120」模式下把动画口径也顶到 120）
// ============================================================
%hook CAAnimation
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CTPMEffective() && CTPMLockNow()) {
        CAFrameRateRange newRange;
        newRange.minimum = CTPM_TARGET_FPS;
        newRange.maximum = CTPM_TARGET_FPS;
        newRange.preferred = CTPM_TARGET_FPS;
        %orig(newRange);
    } else {
        %orig(range);
    }
}
%end

// ============================================================
// Metal 渲染
// ============================================================
@interface CAMetalLayer (Private)
@property (assign) NSUInteger maximumDrawableCount;
@end

%hook CAMetalLayer
- (NSUInteger)maximumDrawableCount {
    NSUInteger orig = %orig;
    if (CTPMGeneralOK() && orig < 3) return 3;
    return orig;
}
%end

%hook CAMetalDrawable
- (void)presentAfterMinimumDuration:(CFTimeInterval)duration {
    if (CTPMGeneralOK()) {
        %orig(1.0 / CTPM_TARGET_FPS);
    } else {
        %orig(duration);
    }
}
%end

%hook MTLCommandBuffer
- (void)presentDrawable:(id)drawable afterMinimumDuration:(CFTimeInterval)minimumDuration {
    if (CTPMGeneralOK()) {
        %orig(drawable, 1.0 / CTPM_TARGET_FPS);
    } else {
        %orig(drawable, minimumDuration);
    }
}
%end

// ============================================================
// CoreAnimation 刷新率控制（SB 内同样生效）
// ============================================================
@interface CADisplayPreferences : NSObject
@property (nonatomic, assign) double preferredRefreshRate;
@end

@interface CAMutableDisplayPreferences : CADisplayPreferences
@end

%hook CAMutableDisplayPreferences
- (void)setPreferredRefreshRate:(double)rate {
    if (CTPMEffective()) {
        %orig(120.0);
    } else {
        %orig(rate);
    }
}
%end

%hook CADisplayPreferences
- (void)setPreferredRefreshRate:(double)rate {
    if (CTPMEffective()) {
        %orig(120.0);
    } else {
        %orig(rate);
    }
}
%end

%hook CADisplay
- (void)setPreferences:(id)preferences {
    if (CTPMEffective() && preferences) {
        @try {
            if ([preferences respondsToSelector:@selector(setPreferredRefreshRate:)]) {
                [preferences setValue:@(120.0) forKey:@"preferredRefreshRate"];
            }
        } @catch (__unused NSException *e) {}
    }
    %orig(preferences);
}
%end

// ============================================================
// CAContext / 帧率源 / 仲裁组（"持续保持"的关键：仲裁输出强制满档）
// ============================================================
@interface CAContext : NSObject
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range;
- (void)setPreferredFrameRate:(float)rate;
@end

%hook CAContext
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CTPMEffective()) {
        CAFrameRateRange newRange = range;
        newRange.maximum = CTPM_TARGET_FPS;
        if (newRange.preferred >= 60) newRange.preferred = CTPM_TARGET_FPS;
        if (CTPMLockNow()) { newRange.minimum = CTPM_TARGET_FPS; newRange.preferred = CTPM_TARGET_FPS; }   // ★ 2.0.92：滑动窗口内锁满
        %orig(newRange);
    } else {
        %orig(range);
    }
}
- (void)setPreferredFrameRate:(float)rate {
    if (CTPMEffective() && rate >= 60) {
        %orig(CTPM_TARGET_FPS);
    } else {
        %orig(rate);
    }
}
%end

@interface CADynamicFrameRateSource : NSObject
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range;
- (CAFrameRateRange)preferredFrameRateRange;
@end

@interface CAFrameRateRangeGroup : NSObject
- (CAFrameRateRange)arbitratedRange;
@end

%hook CADynamicFrameRateSource
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CTPMRangeForced()) {
        CAFrameRateRange newRange = range;
        newRange.minimum = CTPM_TARGET_FPS;
        newRange.maximum = CTPM_TARGET_FPS;
        newRange.preferred = CTPM_TARGET_FPS;
        %orig(newRange);
    } else {
        %orig(range);
    }
}
- (CAFrameRateRange)preferredFrameRateRange {
    CAFrameRateRange range = %orig;
    if (CTPMRangeForced()) {
        range.minimum = CTPM_TARGET_FPS;
        range.maximum = CTPM_TARGET_FPS;
        range.preferred = CTPM_TARGET_FPS;
    }
    return range;
}
%end

%hook CAFrameRateRangeGroup
- (CAFrameRateRange)arbitratedRange {
    CAFrameRateRange range = %orig;
    if (CTPMRangeForced()) {
        range.minimum = CTPM_TARGET_FPS;
        range.maximum = CTPM_TARGET_FPS;
        range.preferred = CTPM_TARGET_FPS;
    }
    return range;
}
%end

// ★ 2.0.92：深层定期在岗上报——每 10 分钟一行（刷新率读数 + 开关状态），不再只靠开机那一次
static void CTPMDeepPeriodicReport(NSString *pn) {
    @try {
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        if (!t) return;
        dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(600ull * NSEC_PER_SEC)), (uint64_t)(600ull * NSEC_PER_SEC), (uint64_t)(60ull * NSEC_PER_SEC));
        dispatch_source_set_event_handler(t, ^{
            @try {
                double hz = 0;
                Class dc = NSClassFromString(@"CADisplay");
                id d = dc ? [dc performSelector:@selector(mainDisplay)] : nil;
                if (d) { id cm = [d valueForKey:@"currentMode"]; if (cm) hz = [[cm valueForKey:@"refreshRate"] doubleValue]; }
                NSDictionary *p = CTHermesReadPrefs();
                CTPMLog("在岗（%s）：总开关=%d 全局=%d 刷新≈%.0fHz",
                        [pn isEqualToString:@"backboardd"] ? "深层1" : "深层2",
                        [p[S("proMotion120Enabled")] boolValue] ? 1 : 0,
                        [p[S("proMotionGlobalEnabled")] boolValue] ? 1 : 0, hz);
            } @catch (__unused NSException *e) {}
        });
        dispatch_resume(t);
    } @catch (__unused NSException *e) {}
}

// ★ 2.0.94：深层心跳——每 5 分钟发一条通知（tm 收账记日志；绕开"深层写不了日志"的死角）
static void CTPMDeepHeartbeatStart(NSString *pn) {
    @try {
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        if (!t) return;
        dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(300ull * NSEC_PER_SEC)), (uint64_t)(300ull * NSEC_PER_SEC), (uint64_t)(30ull * NSEC_PER_SEC));
        dispatch_source_set_event_handler(t, ^{
            @try { notify_post([pn isEqualToString:@"backboardd"] ? kCTHermesDeepAlive1NotifC : kCTHermesDeepAlive2NotifC); } @catch (__unused NSException *e) {}
        });
        dispatch_resume(t);
    } @catch (__unused NSException *e) {}
}

// ★ 2.0.94：桌面侧定期在岗（10 分钟一行，含当前刷新率读数）
static void CTPMSBPeriodicStart(void) {
    @try {
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        if (!t) return;
        dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(600ull * NSEC_PER_SEC)), (uint64_t)(600ull * NSEC_PER_SEC), (uint64_t)(60ull * NSEC_PER_SEC));
        dispatch_source_set_event_handler(t, ^{
            @try {
                double hz = 0;
                Class dc = NSClassFromString(@"CADisplay");
                id d = dc ? [dc performSelector:@selector(mainDisplay)] : nil;
                if (d) { id cm = [d valueForKey:@"currentMode"]; if (cm) hz = [[cm valueForKey:@"refreshRate"] doubleValue]; }
                NSDictionary *p = CTHermesReadPrefs();
                CTPMLog("在岗（桌面）：总开关=%d 全局=%d 锁满=%d 刷新≈%.0fHz",
                        [p[S("proMotion120Enabled")] boolValue] ? 1 : 0,
                        [p[S("proMotionGlobalEnabled")] boolValue] ? 1 : 0,
                        [p[S("proMotionLockEnabled")] boolValue] ? 1 : 0, hz);
            } @catch (__unused NSException *e) {}
        });
        dispatch_resume(t);
    } @catch (__unused NSException *e) {}
}

// ============================================================
// 构造函数
// ============================================================
%ctor {
    @autoreleasepool {
        @try {
            NSString *bid = [[NSBundle mainBundle] bundleIdentifier];
            NSString *pn  = [NSProcessInfo processInfo].processName;
            BOOL isSB = [bid isEqualToString:@"com.apple.springboard"];
            BOOL target = NO;
            if (isSB || [bid isEqualToString:@"com.apple.WebKit.WebContent"] || [pn isEqualToString:@"backboardd"]) {
                target = YES;   // ★ 2.0.69：再下探 backboardd（渲染服务器）与 WebKit 内容进程
            } else {
                NSString *bp = [[NSBundle mainBundle] bundlePath];
                if (bp.length && ([bp rangeOfString:@"/Bundle/Application" options:NSCaseInsensitiveSearch].location != NSNotFound ||
                                  [bp rangeOfString:@"/Applications" options:NSCaseInsensitiveSearch].location != NSNotFound)) target = YES;
            }
            if (!target) return;
            gPMIsSB = isSB;
            gPMIsDeep = ([pn isEqualToString:@"backboardd"] || [bid isEqualToString:@"com.apple.WebKit.WebContent"]);
            %init;
            if (gPMIsDeep) CTPMLog("深层组件已装入（%s）（5 秒后出状态诊断）", [pn isEqualToString:@"backboardd"] ? "backboardd" : "webcontent");   // ★ 2.0.94：装入即报——先证明"注进来了"
            {   // ★ 2.0.73：卸载自拆（0 残留）——收到"卸载中"通知 → 立即停值守、停动作
                static int sByeTok = 0;
                notify_register_dispatch("com.qq391160.cpucore/uninstalling", &sByeTok, dispatch_get_main_queue(), ^(int t2) {
                    (void)t2;
                    gPMUninstalled = YES;
                    @try { [[CTHermesPMRefreshSource shared] sync]; } @catch (__unused NSException *e) {}
                });
            }
            {   // ★ 2.0.92：场景信号——滑动/拖动（只认手指移动）与视频起停；通知驱动、零轮询
                static int sDragTok = 0;
                notify_register_dispatch(kCTHermesDragNotifC, &sDragTok, dispatch_get_main_queue(), ^(int t3) {
                    (void)t3;
                    gPMLastDrag = CFAbsoluteTimeGetCurrent();
                    if (gPMIsSB) @try { [[CTHermesPMRefreshSource shared] bumpSlide]; } @catch (__unused NSException *e) {}
                });
                static int sVOnTok = 0;
                notify_register_dispatch(kCTHermesVideoOnNotifC, &sVOnTok, dispatch_get_main_queue(), ^(int t4) {
                    (void)t4;
                    gPMVideoOn = YES;
                    if (gPMIsSB) { CTPMLog("场景：视频/直播开始 → 让路省电"); @try { [[CTHermesPMRefreshSource shared] sync]; } @catch (__unused NSException *e) {} }
                });
                static int sVOffTok = 0;
                notify_register_dispatch(kCTHermesVideoOffNotifC, &sVOffTok, dispatch_get_main_queue(), ^(int t5) {
                    (void)t5;
                    gPMVideoOn = NO;
                    if (gPMIsSB) @try { [[CTHermesPMRefreshSource shared] sync]; } @catch (__unused NSException *e) {}
                });
            }
            if (gPMIsDeep) {   // ★ 2.0.82：深层进程把“为什么上岗/为什么没上岗”全写出来（日志一眼可见）
                // ★ 2.0.82：诊断行“启动后延迟 5 秒再打”——不在构造期触碰任何系统服务
                //   （2.0.81 这里会在开机链路里直接问显示系统；现已彻底撤掉）
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                    @try {
                        NSDictionary *pdD = CTHermesReadPrefs();
                        BOOL swD = [pdD[S("proMotion120Enabled")] boolValue];
                        BOOL glD = [pdD[S("proMotionGlobalEnabled")] boolValue];
                        BOOL auD = CTAuthFileAuthorized();
                        CTPMLog("载入（%s）：总开关=%d 全局=%d 授权=%d → %s",
                                [pn isEqualToString:@"backboardd"] ? "深层1(backboardd)" : "深层2(网页)",
                                swD ? 1 : 0, glD ? 1 : 0, auD ? 1 : 0,
                                (swD && glD && auD) ? "已上岗" : "未上岗");
                        CTPMDeepPeriodicReport(pn);   // ★ 2.0.94：定期在岗上报（始终排程；行内含开关/刷新率）
                        notify_post([pn isEqualToString:@"backboardd"] ? kCTHermesDeepAlive1NotifC : kCTHermesDeepAlive2NotifC);   // ★ 2.0.94：第一拍心跳
                        CTPMDeepHeartbeatStart(pn);   // ★ 2.0.94：心跳（5 分钟一拍，tm 收账）
                    } @catch (__unused NSException *e) {}
                });
            } else if (CTPMActive()) {
                CTPMLog("已上岗（%s）", bid.UTF8String ?: "?");
            }
            if (isSB) {
                static int sTok = 0;
                notify_register_dispatch(kCTHermesSettingsChangedNotifC, &sTok, dispatch_get_main_queue(), ^(int t) {
                    (void)t;
                    @try { [[CTHermesPMRefreshSource shared] sync]; } @catch (__unused NSException *e) {}
                    @try {   // ★ 2.0.82：开关状态行（“全局注入到底是开是关”从此日志可见）
                        NSDictionary *pdS = CTHermesReadPrefs();
                        CTPMLog("[高刷] 状态：总开关=%d 全局注入=%d 锁满=%d",
                                [pdS[S("proMotion120Enabled")] boolValue] ? 1 : 0,
                                [pdS[S("proMotionGlobalEnabled")] boolValue] ? 1 : 0, [pdS[S("proMotionLockEnabled")] boolValue] ? 1 : 0);
                    } @catch (__unused NSException *e) {}
                });
                [[CTHermesPMRefreshSource shared] sync];
                CTPMSBPeriodicStart();   // ★ 2.0.94：桌面侧定期在岗（10 分钟一行，含刷新率读数）
                @try {   // ★ 2.0.82：启动即打一次状态行
                        NSDictionary *pdS2 = CTHermesReadPrefs();
                        CTPMLog("[高刷] 状态：总开关=%d 全局注入=%d 锁满=%d",
                                [pdS2[S("proMotion120Enabled")] boolValue] ? 1 : 0,
                                [pdS2[S("proMotionGlobalEnabled")] boolValue] ? 1 : 0, [pdS2[S("proMotionLockEnabled")] boolValue] ? 1 : 0);
                } @catch (__unused NSException *e) {}
            }
        } @catch (__unused NSException *e) {}
    }
}
