#import <CTObf.h>
#import <CTFingerprint.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <notify.h>
#include <time.h>
#include <stdio.h>
#import <stdint.h>
#import <string.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <substrate.h>
#include <signal.h>
#include <unistd.h>
#include <spawn.h>
#include <sys/wait.h>
#include <CPUthermalPaths.h>
#import <CPUthermalPressure.h>
#import <IOKit/IOKitLib.h>
#import <IOKit/IOMessage.h>
#import <os/lock.h>
#import <mach/host_info.h>
#import <mach/task_info.h>

// ============================================================================
// ObjC 类声明（thermalmonitord 内部类，class-dump 获取）
// ============================================================================
@interface HidSensors : NSObject
+ (id)sharedInstance;
- (void)handleTemperatureEvent:(int)arg1 service:(id)arg2;
@end

@interface CommonProduct : NSObject
- (id)initProduct:(id)arg1;
- (void)putDeviceInThermalSimulationMode:(id)arg1;
- (void)tryTakeAction;
- (void)simulateLightThermalPressure;
- (void)updatePowerzoneTelemetry;
- (void)setCPMSMitigationsEnabled:(BOOL)enabled;
- (void)setCPULevel:(int)level;
- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(id)source;
- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setThermalState:(id)state;
@end

// ============================================================================
@interface ThermalManager : NSObject
- (id)initWithComponentControllers:(id)components hotspotControllers:(id)hotspots decisionTreeTable:(id)table;
- (void)evaluateDecisionTree;
- (id)findComponent:(id)component;
- (void)actionComponentControl;
- (void)readReleaseRateForAllComponents;
- (float)getReleaseRateForComponent:(id)component;
- (int)getPotentialForcedThermalLevel:(id)component;
- (int)getPotentialForcedThermalPressureLevel;
- (void)updateThermalPressureLevelNotification:(id)notification shouldForceThermalPressure:(BOOL)force;
- (void)updateThermalNotification:(id)notification;
- (BOOL)shouldEnforceLightThermalPressure;
- (void)setCPMSMitigationState:(int)state;
@end

@interface ThermalControl : NSObject
- (float)calculateControlEffort:(id)trigger trigger:(id)arg2;
- (id)findCC:(id)component;
- (float)dieTempFilteredMaxAverage;
- (float)getHighestSkinTemp;
- (float)thermalSensorValuesMaxFromIndexSet:(id)indexSet;
- (void)copyDieTempSensorIndexSetForFourthChar:(char)c sensors:(id)sensors;
- (BOOL)powerSaveActive;
- (void)setPowerSaveActive:(BOOL)active;
- (void)setPowerSaveToken:(id)token;
- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams;
- (id)initWithParams:(id)params;
- (void)updatePowerParameters:(id)params;
@end

@interface ApplePPMCPU : NSObject
- (void)setCPULevel:(int)level;
- (void)updateCPU;
@end

@interface MitigationController : NSObject
- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams;
- (void)updateCPU;
- (void)updateGPU;
- (void)updatePackage;
- (void)setCPULowPowerTarget:(int)target;
- (void)setPackageLowPowerTarget;
- (void)setMaxCPUPowerTarget:(int)target useLegacyPath:(BOOL)legacy setProperty:(uintptr_t)property;
- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setCPUPowerCeiling:(int)ceiling forDVD1Contributor:(int)contributor;
- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setCPUPowerZoneTarget:(int)target;
- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setGPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setGPUPowerZoneTarget:(int)target;
- (void)setSGXLevel:(int)level;
- (void)setMaxGraphicsDrivePowerTarget:(int)target;
- (void)setPackagePowerBudgetDirect:(int)budget withDetails:(id)details;
- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setPackagePowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setPackagePowerZoneTarget;
- (void)setMaxPackagePower:(int)power;
- (int)CPULevel;
- (void)setCPULevel:(int)level;
- (void)setCPUMitigationLevel:(int)level;
- (void)setDVD1Level:(int)level;
- (BOOL)powerSaveActive;
- (void)setPowerSaveActive:(BOOL)active;
- (void)setPowerSaveToken:(int)token;
@end

@interface ThermalDecisionTable : NSObject
- (id)initDecisionTable:(id)table;
@end

@interface PIDController : NSObject
- (id)initPIDWith:(id)params;
@end

@interface HotspotController : NSObject
- (id)initWithParams:(id)params aggdController:(id)aggd;
@end

@interface CommonAggdController : NSObject
- (id)initWithParams:(id)params product:(id)product;
@end

// ============================================================================
// 配置
// ============================================================================
static BOOL g_enabled               = YES; // 总开关，可由设置动态关闭
static BOOL g_cpuProtection         = YES; // 仅用于低功耗模式控制

// 性能模式拦截网络射频热限流；低功耗与禁用状态下保持系统原生行为。
static BOOL g_blockNetworkThermalThrottle = YES;
static BOOL networkThrottleBlockingEnabled(void);

// Wi‑Fi Apple80211 射频限流关键字 iOS15~iOS16通用
static const char *networkThrottleKeys[] = {
"txPowerLimit",
"transmitPowerLimit",
"maxThroughput",
"rateLimiting",
"thermalThrottleEnabled",
"antennaThrottle",
"thermalPowerCap",
"radioPowerLimit",
"modemThermalLimit",
"basebandPowerLimit",
NULL
};

// 判断是否为网络射频限流属性key
static BOOL isNetworkThrottleProperty(CFStringRef keyRef) {
if (!keyRef || !networkThrottleBlockingEnabled()) return NO;
NSString *key = (__bridge NSString *)keyRef;
NSString *lowerKey = [key lowercaseString];

for (int i = 0; networkThrottleKeys[i]; i++) {
NSString *k = [NSString stringWithUTF8String:networkThrottleKeys[i]];
if ([lowerKey containsString:[k lowercaseString]]) {
return YES;
}
}
return NO;
}

typedef enum {
CPUthermalPowerModeFull = 0,
CPUthermalPowerModeLow  = 1,
CPUthermalPowerModeNative = 2   // ★ 智能模式专用：原生（不干预，交还系统）
} CPUthermalPowerMode;

static CPUthermalPowerMode g_powerMode = CPUthermalPowerModeFull;
static CPUthermalPowerMode g_userSelectedPowerMode = CPUthermalPowerModeFull;
static BOOL g_foregroundAppForcesLowPower = NO;
// ★ 智能模式（顶部分段第三格）：游戏→高性能 / 其他应用→低频率 / 桌面→原生
static BOOL g_smartEnabled = NO;                 // 常驻"智能"时为 YES（老的两档一律不受影响）
static NSMutableSet *g_tierFullHashes = nil;     // ★ T7w：App 档位——高性能
static NSMutableSet *g_tierLowHashes = nil;      // ★ T7w：App 档位——低频率
static NSMutableSet *g_tierNativeHashes = nil;   // ★ T7w：App 档位——原生
static CFAbsoluteTime g_scrollBoostUntil = 0;    // ★ T7w：滑动升频截止时刻
static BOOL g_scrollBoostEnabled = YES;
static BOOL g_lowPowerDesktopNative = NO;   // ★ T7x6：低功耗模式下「桌面原生频率」开关（设置里可开；默认关=桌面也压）
static BOOL g_scrollBoostActive = NO;            // ★ 269：滑动放行中（模式名义上保持低功耗，不产生模式跳变）          // ★ T7w：滑动提速开关（默认开）
static NSSet *g_smartGameHashes = nil;           // 识别到的游戏 App（前台哈希集合）
static NSSet *g_smartFullListHashes = nil;       // 「指定 App 高性能率」名单（智能下的例外）
static NSSet *g_smartKnownAppHashes = nil;       // 可识别的普通应用（带分类信息；识别不到的走原生）
static NSSet *g_smartLowListHashes = nil;        // 「指定 App 低频率」名单（智能下：钉住一律低频率）
static BOOL g_smartScanDone = NO;                // 是否已完成一次分类扫描
static BOOL g_gameForceFull = YES;               // ★ T7z26：游戏强制高性能（默认开）
static CPUthermalPowerMode g_smartLastTarget = CPUthermalPowerModeNative;   // 上次判定（读不到前台时沿用）
// ★ T7 取证助手前置声明
static void CTAuditMode(const char *who, CPUthermalPowerMode newMode);
static void CTAuditFlag(const char *who, BOOL v);
static uint64_t g_lastAppliedForegroundHash = 0;
static BOOL g_foregroundExitPending = NO;   // 退出指定应用去抖中（防转场瞬时误报）

// setCPULowPowerTarget:/setMaxCPUPowerTarget: 使用 mW；65000 是 thermalmonitord 的无限制哨兵值。
// setCPULevel:/setCPUPowerCeiling:/setCPUPowerFloor:/setCPUPowerZoneTarget: 使用 0~100 百分比。
static const int kUnrestrictedPowerLimitMW = 65000;
static const int kUnrestrictedPerformancePercent = 100;
static const int kLowPowerCPULevel = 2;
// 低功耗参数：固定 2500mW / 45%（原「省电强度」三级设置已移除）
static int g_lowPowerPowerLimitMW = 2500;
static int g_lowPowerPerformancePercent = 45;
#define kLowPowerPowerLimitMW g_lowPowerPowerLimitMW
#define kLowPowerPerformancePercent g_lowPowerPerformancePercent

// ★ T7z6：无操作深度降频 + 视频场景优化（两个开关均默认开，设置里可关）
static BOOL g_ctIdleSinkEnabled = YES;        // 无操作深度省电
static BOOL g_ctVideoOptEnabled = YES;        // 视频场景优化
static BOOL g_ctVideoDeepEnabled = NO;        // ★ T7z7：视频中也允许深度降频（默认关）
static BOOL g_ctDeepIdleActive = NO;          // 深度档激活中（参数更深）
static CFAbsoluteTime g_ctLastActivityAt = 0; // 最后一次"用户操作"时刻
static BOOL g_ctVideoActive = NO;             // 视频/直播播放中
static uint64_t g_ctVideoActiveHash = 0;      // 视频档绑定的 App 哈希
static const int kDeepLowPowerCPULevel = 3;   // 深度档：系统 CPU Level 3（≈1G 档）
static const int kDeepLowPowerBudgetMW = 1800;// 深度档：功率预算 ~1.8W
static int CTLowPowerLevel(void) { return g_ctDeepIdleActive ? kDeepLowPowerCPULevel : kLowPowerCPULevel; }
static int CTLowPowerBudgetMW(void) { return g_ctDeepIdleActive ? kDeepLowPowerBudgetMW : g_lowPowerPowerLimitMW; }

// 低功耗参数：原「省电强度」三级设置已移除——固定 2500 mW / 45%
static void CPUthermalReloadLowPowerPreset(NSDictionary *prefs) {
    (void)prefs;
    g_lowPowerPowerLimitMW = 2500;
    g_lowPowerPerformancePercent = 45;
}

static const int kFullPowerCPULevel = 0;
static const int kCPUDecisionSourceCount = 6;
static const int kCPUDVD1ContributorCount = 4;

static CommonProduct *g_commonProduct = nil;
static NSHashTable *g_mitigationControllers = nil;  // 弱引用，防止僵尸实例泄漏
static os_unfair_lock g_stateLock = OS_UNFAIR_LOCK_INIT;      // 配置与 CommonProduct
static os_unfair_lock g_controllerLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock g_runtimeLock = OS_UNFAIR_LOCK_INIT;    // 有限模式应用任务
static __thread BOOL g_restoringFullPower = NO;
static BOOL g_fullPowerRecoveryPulseScheduled = NO;
static BOOL g_lowPowerApplyPulseScheduled = NO;
static BOOL g_thermalReloadScheduled = NO;
static BOOL g_forceThermalConfigReload = NO;
static int g_lockStateToken = -1;
static int g_blankedScreenToken = -1;
static int g_thermalNotificationToken = -1;
static int g_thermalPressureToken = -1;
static dispatch_queue_t g_thermalResetQueue = NULL;
static os_unfair_lock g_thermalResetLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastThermalReset = 0;
static os_unfair_lock g_nominalLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastNominalCorrection = 0;
static os_unfair_lock g_modeLock = OS_UNFAIR_LOCK_INIT;  // 线程安全：保护g_powerMode
static NSHashTable *g_applePPMInstances = nil;           // 追踪 ApplePPMCPU 实例（弱引用，防止僵尸实例泄漏）
// 高温告警默认屏蔽；防暗屏仍由用户设置决定。
static BOOL g_thermalBlockNotifPopup = NO;
static BOOL g_thermalPreventDimmingEnabled = NO;
static BOOL g_hipLockedEnabled = NO;
static BOOL g_overheatAutoProtect = NO;   // ★ 1.4.6s：过热自动保护（温控保护面板开关）
static BOOL g_nominalAutoRecover = YES;   // ★ 1.4.6s：温度正常后自动恢复
static BOOL g_overheatActive = NO;        // 过热保护临时介入中（临时低功耗）
static CFAbsoluteTime g_overheatNormalSince = 0;
static BOOL g_hipApplied = NO;
static BOOL g_hipStateKnown = NO;
static BOOL isFullPowerMode(void);
static BOOL shouldApplyLowPowerLimit(void);
static int targetCPUPerformanceLevel(void);
static void loadPrefs(void);
static NSDictionary *readPrefsDictionary(void);
static BOOL foregroundAppShouldUseLowPower(NSDictionary *prefs);
static BOOL CPUthermalTierSystemActive(NSDictionary *prefs);   // ★ T7x：档位体系接管判定（前向声明）
static CPUthermalPowerMode CPUthermalResolveTargetMode(CPUthermalPowerMode selected, BOOL blanked, BOOL appLowPower);
static CPUthermalPowerMode CPUthermalSelectedModeFromPrefs(NSDictionary *prefs);
static BOOL foregroundAppForcesFullPower(NSDictionary *prefs);
static BOOL foregroundAppListHit(CPUthermalPowerMode selected, NSDictionary *prefs);
static void CPUthermalSyncModeFromPrefs(void);
static void applyCurrentPowerModeToRuntime(void);
static void applyPowerModeToRuntime(BOOL respectBootGuard);
static void scheduleFullPowerRecoveryPulse(void);
static void runFullPowerRecoveryPulse(int remainingPulses);
static void scheduleLowPowerApplyPulse(void);
static void runLowPowerApplyPulse(int remainingPulses);
static void startForegroundRecheckTimer(void);
static void applyForegroundDecision(const char *reason);
static void scheduleForegroundExitApply(void);
static void applyCurrentModeToApplePPMCPU(void);
static void forceCPUPerformanceLevelOnController(id controller);
static void applyFullPowerBudgetsOnController(id controller);
static void applyLowPowerToCommonProduct(void);
static void applyLowPowerPerformancePreferenceToController(id controller);
static void restoreNativeRuntimeAfterDisable(void);
static void correctNominalStateIfNeeded(void);
static BOOL shouldApplyAppFullProtection(void);       // ★ 1.4.4：前台 App 享受"高性能"时 = 同级防降频
static int CPUthermalTierForHash(uint64_t ctHv);      // 前置声明（定义在档位区）
static void scheduleThermalMonitorReload(void);
static void scheduleThermalConfigurationReload(void);
static void switchToLowPowerForSleep(const char *source);
static void restoreUserModeAfterWake(const char *source);
static BOOL runSoftModeSwing(const char *reason);
static BOOL CTFreqReadMHzInner(double *outMHz);   // ★ T7z11/T7z16h：IOReport 读取（内部实现）
static os_unfair_lock g_ctFreqLock = OS_UNFAIR_LOCK_INIT;
static BOOL CTFreqReadMHz(double *outMHz) {   // ★ 1.4.6h：加锁——主队列与每秒服务队列可并发读取
    os_unfair_lock_lock(&g_ctFreqLock);
    BOOL ctFR = CTFreqReadMHzInner(outMHz);
    os_unfair_lock_unlock(&g_ctFreqLock);
    return ctFR;
}
static void registerScreenWakeObservers(void);
static void CPUthermalCaptureBrightnessBeforeModeChange(void);
static void CPUthermalCaptureExistingBacklightMaximum(void);
static void CPUthermalScheduleBacklightRecovery(void);
static void CPUthermalApplyHIPForCurrentScreen(void);

static void runtimeConfigSnapshot(BOOL *enabled, BOOL *cpuProtection, BOOL *blockNetwork, BOOL *blockPopup, BOOL *preventDimming) {
os_unfair_lock_lock(&g_stateLock);
if (enabled) *enabled = g_enabled;
if (cpuProtection) *cpuProtection = g_cpuProtection;
if (blockNetwork) *blockNetwork = g_blockNetworkThermalThrottle;
if (blockPopup) *blockPopup = g_thermalBlockNotifPopup;
if (preventDimming) *preventDimming = g_thermalPreventDimmingEnabled;
os_unfair_lock_unlock(&g_stateLock);
}

// ============================================================================
static BOOL isLowPowerMode(void);
static BOOL isNativeMode(void);

// ★ 智能模式的"原生"态判定（不干预、交还系统时用）
static BOOL isNativeMode(void) {
    os_unfair_lock_lock(&g_modeLock);
    BOOL res = (g_powerMode == CPUthermalPowerModeNative);
    os_unfair_lock_unlock(&g_modeLock);
    return res;
}

// 三态模式名（日志用）
static const char *CTModeName(CPUthermalPowerMode m) {
    return (m == CPUthermalPowerModeLow) ? "低功耗" : ((m == CPUthermalPowerModeFull) ? "高性能" : "原生");
}
static CommonProduct *commonProductSnapshot(void);
static NSArray *trackedPowerControllersSnapshot(void);
static NSArray *trackedApplePPMInstancesSnapshot(void);

// ★ 诊断日志（临时）：/var/mobile/Library/Logs/CPUthermalDiag.log
//   只在关键事件 + 低功耗期间每秒 1 行，文件超过 256KB 自动重建
// ============================================================================
#include <sys/stat.h>
#include <sys/time.h>
static void CTD(const char *fmt, ...) {
    static FILE *fp = NULL;
    // ★ 2026-09-17 加固：句柄校验——日志文件被换掉/删掉时自动重开（每 60 次写校验一次，开销忽略）
    if (fp) {
        static int sCTDCheckTick = 0;
        if ((++sCTDCheckTick % 60) == 0) {
            struct stat fst, pst;
            if (fstat(fileno(fp), &fst) != 0 || stat("/var/mobile/Library/Logs/CPUthermalDiag.log", &pst) != 0 || fst.st_ino != pst.st_ino) {
                fclose(fp);
                fp = NULL;
            }
        }
    }
    if (!fp) {
        mkdir("/var/mobile/Library/Logs", 0755);
        struct stat st;
        if (stat("/var/mobile/Library/Logs/CPUthermalDiag.log", &st) == 0 && st.st_size > 256 * 1024) {
            truncate("/var/mobile/Library/Logs/CPUthermalDiag.log", 0);   // ★ 不许 unlink（会"坑瞎"其它写入方的句柄）——改为清空；所有追加句柄继续有效
        }
        fp = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
    }
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s.%03d] ", ts, (int)(tv.tv_usec / 1000));
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fflush(fp);
}

// 捕获对象健康度：CommonProduct 是否还在 / 控制器数量 / PPM 数量 / 重压计数
static unsigned long g_ctApplyCount = 0;
// ★ 构建标记：启动时写进日志，方便确认"装的到底是哪一版"
#define kCTBuildTag "build 0928-2340-1.4.6"
// ★ 1.4.6 安全加强：身份完整性开关（③④）——非完整性被破坏时，插件所有功能静默停用
static BOOL g_ctIdentityIntact = YES;
static CFAbsoluteTime g_ctMainBeat = 0;   // ★ 1.4.6g：主队列心跳时间戳（独立看门狗用）
static CFAbsoluteTime g_ctProcStart = 0;  // ★ 1.4.6g：本进程启动时刻（防误伤：设置包更新晚于启动则暂缓指纹核对）
static int g_ctMainPhase = 0;         // ★ 1.4.6h：主队列当前阶段（卡死时日志定位用 1-10）
static CFAbsoluteTime g_ctEngineBeat = 0;  // ★ 1.4.6h：充电引擎队列心跳
static CFAbsoluteTime g_ctSvcBeat = 0;     // ★ 1.4.6h：每秒服务队列心跳
static int g_ctSvcPhase = 0;          // ★ 1.4.6h：每秒服务步骤（1-3）
static const char *CTFpSuffix(void) {
    static char sBuf[40] = {0};
    static int sInit = 0;
    if (!sInit) {
        sInit = 1;
        if (CT_SOURCE_FP[0]) snprintf(sBuf, sizeof(sBuf), " [fp:%s]", CT_SOURCE_FP);
    }
    return sBuf;   // 未注入指纹 → 空串（不影响功能）
}

static void CTDObjects(const char *tag) {
    id poc = commonProductSnapshot();
    NSArray *ctrls = trackedPowerControllersSnapshot();
    NSArray *ppms = trackedApplePPMInstancesSnapshot();
    CTD("对象[%s] CommonProduct=%s 控制器=%lu PPM=%lu 重压次数=%lu 模式=%s 名单标记=%d 前台=%llu",
        tag, poc ? "在" : "空(被系统换掉了)", (unsigned long)ctrls.count, (unsigned long)ppms.count,
        g_ctApplyCount, isNativeMode() ? "原生" : (isLowPowerMode() ? "低功耗" : "高性能"),
        (int)g_foregroundAppForcesLowPower,
        (unsigned long long)CPUthermalReadForegroundBundleHash());
}


static BOOL runtimeEnabled(void) {
BOOL enabled = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, NULL, NULL);
return enabled && g_ctIdentityIntact;
}

static BOOL runtimeProtectionEnabled(void) {
BOOL enabled = NO;
BOOL cpuProtection = NO;
runtimeConfigSnapshot(&enabled, &cpuProtection, NULL, NULL, NULL);
return enabled && cpuProtection && g_ctIdentityIntact;
}

static BOOL networkThrottleBlockingEnabled(void) {
BOOL enabled = NO;
BOOL blockNetwork = NO;
runtimeConfigSnapshot(&enabled, NULL, &blockNetwork, NULL, NULL);
return enabled && blockNetwork && isFullPowerMode();
}

static BOOL thermalPopupBlockingEnabled(void) {
BOOL enabled = NO;
BOOL blockPopup = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, &blockPopup, NULL);
return enabled && blockPopup;
}

static BOOL thermalDimmingPreventionEnabled(void) {
BOOL enabled = NO;
BOOL preventDimming = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, NULL, &preventDimming);
return enabled && preventDimming;
}

static CommonProduct *commonProductSnapshot(void) {
os_unfair_lock_lock(&g_stateLock);
CommonProduct *product = g_commonProduct;
os_unfair_lock_unlock(&g_stateLock);
return product;
}

static void setCommonProduct(CommonProduct *product) {
CommonProduct *previousProduct = nil;
os_unfair_lock_lock(&g_stateLock);
previousProduct = g_commonProduct;
g_commonProduct = product;
os_unfair_lock_unlock(&g_stateLock);
(void)previousProduct;
}

static BOOL CPUthermalScreenIsBlanked(void) {
int token = 0;
uint64_t state = 0;
if (notify_register_check("com.apple.springboard.hasBlankedScreen", &token) != NOTIFY_STATUS_OK) return NO;
int result = notify_get_state(token, &state);
notify_cancel(token);
return result == NOTIFY_STATUS_OK && state != 0;
}

static BOOL isLowPowerMode(void) {
os_unfair_lock_lock(&g_modeLock);
BOOL res = (g_powerMode == CPUthermalPowerModeLow);
os_unfair_lock_unlock(&g_modeLock);
return res;
}

static BOOL isFullPowerMode(void) {
os_unfair_lock_lock(&g_modeLock);
BOOL res = (g_powerMode == CPUthermalPowerModeFull);
os_unfair_lock_unlock(&g_modeLock);
return res;
}

static BOOL shouldApplyFullCPUProtection(void) {
if (!runtimeProtectionEnabled()) return NO;
if (isFullPowerMode()) return YES;
// ★ 1.4.4：前台 App 正在享受"高性能"（游戏 / 档位高性能 / 高性能名单）时，同样启用高性能级保护
return shouldApplyAppFullProtection();
}

static BOOL shouldRestoreNativePerformance(void) {
return shouldApplyFullCPUProtection();
}

// ★ 充电状态（外接电源）缓存：每 5 秒读一次，避免频繁访问 IORegistry

static BOOL shouldApplyLowPowerLimit(void) {
// ★ T7x：滑动提速期间，低功耗压制"全线让路"——否则提速自己的解锁调用会被本判定的各钩子当场改回低档
//   （270 实测：低功耗下每次"升频开始"前都出现 "★系统抢值 → 强制=2500"，提速被自我压制抵消 → 滑动不跟手）
return runtimeProtectionEnabled() && isLowPowerMode() && !g_scrollBoostActive;
}

static void correctNominalStateIfNeeded(void) {
if (!shouldApplyFullCPUProtection()) return;
CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
os_unfair_lock_lock(&g_nominalLock);
BOOL shouldCorrect = (now - g_lastNominalCorrection) >= 1.0;
if (shouldCorrect) g_lastNominalCorrection = now;
os_unfair_lock_unlock(&g_nominalLock);
if (shouldCorrect) CPUthermalForceNominalCombined();
}

static void scheduleThermalMonitorReload(void) {
// ★ 不再自杀/重启控温进程（那会引发 watchdog 连崩 + 发热）—— 改为立即安全重压一次
os_unfair_lock_lock(&g_runtimeLock);
if (g_thermalReloadScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_thermalReloadScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_async(dispatch_get_main_queue(), ^{
g_thermalReloadScheduled = NO;
if (runtimeProtectionEnabled()) {
applyCurrentPowerModeToRuntime();
}
});
}

static void scheduleThermalConfigurationReload(void) {
os_unfair_lock_lock(&g_runtimeLock);
g_forceThermalConfigReload = YES;
os_unfair_lock_unlock(&g_runtimeLock);
scheduleThermalMonitorReload();
}

static void CPUthermalSetHIPLockedAsync(BOOL enabled) {
NSString *tool=CPUthermalToolPath(); if(!tool.length)return;
dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{
    pid_t pid=0; char value[2]={enabled?'1':'0','\0'};
    char *args[]={(char *)"CPUthermalTool",(char *)"hip-lock",value,NULL};
    if(posix_spawn(&pid,tool.fileSystemRepresentation,NULL,NULL,args,NULL)==0)waitpid(pid,NULL,0);
});
}

static void CPUthermalApplyHIPForCurrentScreen(void) {
// 固定仅锁屏/熄屏生效；亮屏一定恢复原生 HIP 判断。
BOOL target=g_hipLockedEnabled && CPUthermalScreenIsBlanked();
if(g_hipStateKnown && target==g_hipApplied)return;
g_hipStateKnown=YES;
g_hipApplied=target;
CPUthermalSetHIPLockedAsync(target);
}

static CPUthermalPowerMode g_modeBeforeSleep = CPUthermalPowerModeLow;   // 锁屏前正在生效的模式
static BOOL g_prefsLoaded = NO;   // ★ T5：设置是否已成功读取过
static BOOL g_softSwingActive = NO;   // ★ T7x3：声明前移（写睡前也要判断"是否正在摆动自愈"）
static void switchToLowPowerForSleep(const char *source) {
BOOL changed = NO;
os_unfair_lock_lock(&g_modeLock);
if (g_prefsLoaded) {                 // ★ T5 修复：设置没读出来之前绝不记录，
    if (!g_softSwingActive) {        // ★ T7x3：摆动自愈期间模式瞬时=高性能，绝不能记成"睡前模式"（否则醒来恢复成高性能、8 秒内不重算 → "全是高性能"）
        g_modeBeforeSleep = g_powerMode;     //   否则会把默认值"高性能"记进去 → 首次解锁恢复成高性能（实机抓到过）
        CTD("[写睡前] sleep: → %s (fg=%llu)", CTModeName(g_modeBeforeSleep), (unsigned long long)CPUthermalReadForegroundBundleHash());
    } else {
        CTD("[写睡前] sleep: 摆动自愈进行中 → 沿用上次记录=%s", CTModeName(g_modeBeforeSleep));
    }
}
if (g_powerMode != CPUthermalPowerModeLow) {
CTAuditMode("sleep", CPUthermalPowerModeLow);
changed = YES;
}
os_unfair_lock_unlock(&g_modeLock);
if (changed) applyPowerModeToRuntime(NO);
CTLOG(S("[CPUthermal] %s 状态临时进入低功耗，保留用户模式:%@"), source ?: "sleep",
      g_userSelectedPowerMode == CPUthermalPowerModeLow ? S("低功耗") : S("性能模式"));
}

static void restoreUserModeAfterWake(const char *source) {
// 每次唤醒都以面板持久化的 powerMode 为权威来源；长时间锁屏后
// PMGR/ApplePPM 可能重建，内存枚举未变不代表硬件模式仍然有效。
NSDictionary *prefs = readPrefsDictionary();
CPUthermalPowerMode selected;
BOOL prefsOK = (prefs && [prefs[S("powerMode")] isKindOfClass:[NSString class]]);
if (prefsOK) {
    NSString *savedMode = prefs[S("powerMode")];
    selected = [savedMode isEqualToString:S(kCPUthermalLowPowerModeC)] ? CPUthermalPowerModeLow : CPUthermalPowerModeFull;
} else {
    // ★ 读取失败时保留当前用户模式 —— 绝不回退到"性能模式"
    //   （原来读不到就默认高性能 ✗ → 秒锁屏/秒亮屏撞上读取失败 → 一亮屏就高性能 ✗）
    os_unfair_lock_lock(&g_modeLock);
    selected = g_userSelectedPowerMode;
    os_unfair_lock_unlock(&g_modeLock);
}
// 修复：唤醒/解锁必须以"用户模式 + 指定应用覆盖"共同决定运行模式。
// 旧逻辑直接恢复用户模式，导致锁屏/解锁时若当前前台仍是指定应用，
// 低功耗被静默撤销，且 SpringBoard 因哈希未变化不会再上报，永久失效。
// ★★ 唤醒/解锁：直接沿用"锁屏前正在生效的模式"（g_modeBeforeSleep）。
//    解锁瞬间系统报的前台不可信（锁屏界面 / 旧 App），按它重算会把名单方向判反 —— 这正是"亮屏后高性能"的根因。
//    之后 8 秒内也不接受前台变化（见 applyForegroundDecision），等数据稳定了再正常判定。
CPUthermalPowerMode target = g_modeBeforeSleep;
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
CTAuditMode("wake-restore", target);
os_unfair_lock_unlock(&g_modeLock);

// 无论 previous 与 target 是否相同都重新应用，覆盖唤醒后的 PMGR 回写。
applyPowerModeToRuntime(NO);
CTD("★事件[%s] 恢复模式=%s", source ?: "wake", isNativeMode() ? "原生" : (isLowPowerMode() ? "低功耗" : "高性能"));
CTDObjects("唤醒后");
// ★ 唤醒后连续三次重算前台（0.5 / 1 / 2 秒）—— 最快 ~0.5 秒就能恢复，又不怕 SpringBoard 数据还没稳定
for (int i = 0; i < 3; i++) {
    const double ctDelay = (i == 0) ? 0.5 : ((i == 1) ? 1.0 : 2.0);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        applyForegroundDecision("wake-settle");
    });
}
// ★ 唤醒后 10 秒内持续重申低功耗（40 次 x 0.25 秒）：
//   对抗系统在"亮屏瞬间/之后几秒"抬预算或回写 —— 覆盖你报的"锁屏 10 秒再亮屏变高性能"窗口。
if (isLowPowerMode()) {
    // ★ "周期重申"已改由 startPeriodicReassertTimer 统一负责（亮屏每 2 秒 / 熄屏每 5 秒，
    //   重发"模式变更"通知 = 完整重应用）—— 不再挂在"唤醒次数"上误触发。
    dispatch_async(dispatch_get_main_queue(), ^{
        runLowPowerApplyPulse(40);
    });
}
CTLOG(S("[CPUthermal] %s 状态恢复面板模式:%@"), source ?: "wake",
      target == CPUthermalPowerModeLow ? S("低功耗") : (target == CPUthermalPowerModeFull ? S("高性能") : S("原生")));
// ★ 2026-09-17 自愈：唤醒后自动"完整摆动"——修复"睡醒后低功耗限制没落到真身"（模式=低但实际能跑满）
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if (!runSoftModeSwing("wake+2s")) {   // 此刻不是低功耗（如从名单App里锁的屏）→ 10 秒后再试一次
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            runSoftModeSwing("wake+10s");
        });
    }
});
}

static CFAbsoluteTime g_lastWakeStamp = 0;

// ★★★ T7 全量取证：模式写入审计（要求调用方已持 g_modeLock）
static void CTAuditMode(const char *who, CPUthermalPowerMode newMode) {
    CPUthermalPowerMode old = g_powerMode;
    g_powerMode = newMode;
    if (old != newMode) {
        CTD("[写模式] %s: %s → %s (fg=%llu blanked=%d 唤醒窗口=%.1fs)",
            who,
            CTModeName(old),
            CTModeName(newMode),
            (unsigned long long)CPUthermalReadForegroundBundleHash(),
            (int)CPUthermalScreenIsBlanked(),
            g_lastWakeStamp > 0 ? (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) : -1.0);
    }
}
static int g_ctFlagLast = -1;
static void CTAuditFlag(const char *who, BOOL v) {
    if ((int)v != g_ctFlagLast) {
        g_ctFlagLast = (int)v;
        CTD("[名单flag] %s: → %d (fg=%llu)", who, (int)v, (unsigned long long)CPUthermalReadForegroundBundleHash());
    }
}
static uint64_t g_exceptionAppHash = 0;      // 触发"名单例外"时那个 App 的前台哈希   // 最近一次亮屏/解锁时刻（用于"刚刚唤醒"窗口判断）
static void handleLockStateToken(int token) {
uint64_t state = UINT64_MAX;
if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK) return;
CTD("[事件] lockstate state=%llu (blankedNow=%d)", (unsigned long long)state, (int)CPUthermalScreenIsBlanked());
if (state == 0) { g_lastWakeStamp = CFAbsoluteTimeGetCurrent(); restoreUserModeAfterWake("unlock"); }
CPUthermalApplyHIPForCurrentScreen();
}

static void handleBlankedScreenToken(int token) {
uint64_t state = UINT64_MAX;
if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK) return;
CTD("[事件] blanked state=%llu", (unsigned long long)state);
if (state == 0) { g_lastWakeStamp = CFAbsoluteTimeGetCurrent(); restoreUserModeAfterWake("screen-on"); }
else switchToLowPowerForSleep("screen-off");
CPUthermalApplyHIPForCurrentScreen();
}

static void handleThermalLevelNotification(int token) {
    uint64_t state = 0;
    if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK || state == 0) return;
    CFAbsoluteTime now=CFAbsoluteTimeGetCurrent();
    // ★ 1.4.4：高性能 / 游戏保护期间 → 即时拍回（不等 5 秒）；其它模式保留限流（防低功耗被误抬满）
    BOOL active = shouldApplyFullCPUProtection();
    os_unfair_lock_lock(&g_thermalResetLock);
    BOOL allowed = active ? YES : ((now-g_lastThermalReset)>=5.0);
    if(allowed)g_lastThermalReset=now;
    os_unfair_lock_unlock(&g_thermalResetLock);
    if (allowed) {
        if (active) {
            CPUthermalForceNominalCombined();
        } else {
            applyCurrentPowerModeToRuntime();
        }
    }
}

static void registerThermalLevelResetObservers(void) {
    if (!g_thermalResetQueue) g_thermalResetQueue=dispatch_queue_create("com.qq391160.thermal.thermal-reset",DISPATCH_QUEUE_SERIAL);
    if (g_thermalPressureToken < 0) {
        notify_register_dispatch(kOSThermalNotificationPressureLevelName, &g_thermalPressureToken,
                                 g_thermalResetQueue, ^(int token) { handleThermalLevelNotification(token); });
    }
    if (g_thermalNotificationToken < 0) {
        notify_register_dispatch("com.apple.system.thermalnotification", &g_thermalNotificationToken,
                                 g_thermalResetQueue, ^(int token) { handleThermalLevelNotification(token); });
    }
}

static void registerScreenWakeObservers(void) {
if (g_lockStateToken < 0) {
notify_register_dispatch("com.apple.springboard.lockstate", &g_lockStateToken, dispatch_get_main_queue(), ^(int token) {
handleLockStateToken(token);
});
}
if (g_blankedScreenToken < 0) {
notify_register_dispatch("com.apple.springboard.hasBlankedScreen", &g_blankedScreenToken, dispatch_get_main_queue(), ^(int token) {
handleBlankedScreenToken(token);
});
}
// daemon 可能在设备已经熄屏时启动，注册后立即同步一次当前屏幕状态。
handleBlankedScreenToken(g_blankedScreenToken);
}

static int targetCPUPerformanceLevel(void) {
return isLowPowerMode() ? CTLowPowerLevel() : kFullPowerCPULevel;
}

static CFStringRef cpuMaxPowerPropertyName(void) {
static CFStringRef propertyName = NULL;
static dispatch_once_t once;
dispatch_once(&once, ^{
propertyName = CFStringCreateWithCString(kCFAllocatorDefault, "CPUMaxPower", kCFStringEncodingUTF8);
});
return propertyName;
}

static BOOL methodEncodingContains(id object, SEL selector, const char *needle) {
if (!object || !selector || !needle) return NO;
Method method = class_getInstanceMethod(object_getClass(object), selector);
if (!method) return NO;
const char *types = method_getTypeEncoding(method);
return types && strstr(types, needle) != NULL;
}

static char methodArgumentTypeCode(id object, SEL selector, unsigned int index) {
if (!object || !selector) return '\0';
Method method = class_getInstanceMethod(object_getClass(object), selector);
if (!method || index >= method_getNumberOfArguments(method)) return '\0';
char type[32] = {0};
method_getArgumentType(method, index, type, sizeof(type));
const char *cursor = type;
while (*cursor && strchr("rnNoORV", *cursor)) cursor++;
return *cursor;
}

static BOOL argumentTypeIs32BitInteger(char type) {
return type == 'c' || type == 'C' || type == 's' || type == 'S' ||
type == 'i' || type == 'I' || type == 'B';
}

static BOOL argumentTypeIs64BitInteger(char type) {
return type == 'q' || type == 'Q' || type == 'l' || type == 'L' || type == '^';
}

static void sendTwoIntegerArguments(id object, SEL selector, intptr_t firstValue, uintptr_t secondValue) {
if (!object || !selector || ![object respondsToSelector:selector]) return;
char firstType = methodArgumentTypeCode(object, selector, 2);
char secondType = methodArgumentTypeCode(object, selector, 3);
if (argumentTypeIs32BitInteger(firstType) && argumentTypeIs32BitInteger(secondType)) {
((void (*)(id, SEL, int, int))objc_msgSend)(object, selector, (int)firstValue, (int)secondValue);
return;
}
if (argumentTypeIs32BitInteger(firstType) && argumentTypeIs64BitInteger(secondType)) {
((void (*)(id, SEL, int, uintptr_t))objc_msgSend)(object, selector, (int)firstValue, secondValue);
return;
}
if (argumentTypeIs64BitInteger(firstType) && argumentTypeIs32BitInteger(secondType)) {
((void (*)(id, SEL, intptr_t, int))objc_msgSend)(object, selector, firstValue, (int)secondValue);
return;
}
if (argumentTypeIs64BitInteger(firstType) && argumentTypeIs64BitInteger(secondType)) {
((void (*)(id, SEL, intptr_t, uintptr_t))objc_msgSend)(object, selector, firstValue, secondValue);
}
}

static void sendSetPowerSaveToken(id controller, int token) {
if (!controller || ![controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460")]) return;
char argumentType = methodArgumentTypeCode(controller, CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460"), 2);
if (argumentType == '@') {
id tokenObject = token ? [NSNumber numberWithInt:token] : nil;
((void (*)(id, SEL, id))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460"), tokenObject);
return;
}
if (argumentTypeIs64BitInteger(argumentType)) {
((void (*)(id, SEL, intptr_t))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460"), (intptr_t)token);
return;
}
if (argumentTypeIs32BitInteger(argumentType)) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460"), token);
}

}

static void trackPowerController(id controller) {
if (!controller) return;
os_unfair_lock_lock(&g_controllerLock);
if (!g_mitigationControllers) g_mitigationControllers = [NSHashTable weakObjectsHashTable];
[g_mitigationControllers addObject:controller];
os_unfair_lock_unlock(&g_controllerLock);
}

static NSArray *trackedPowerControllersSnapshot(void) {
os_unfair_lock_lock(&g_controllerLock);
NSArray *controllers = g_mitigationControllers ? [g_mitigationControllers allObjects] : [NSArray array];
os_unfair_lock_unlock(&g_controllerLock);
return controllers;
}

static void trackApplePPMInstance(id instance) {
if (!instance) return;
os_unfair_lock_lock(&g_controllerLock);
if (!g_applePPMInstances) g_applePPMInstances = [NSHashTable weakObjectsHashTable];
[g_applePPMInstances addObject:instance];
os_unfair_lock_unlock(&g_controllerLock);
}

static NSArray *trackedApplePPMInstancesSnapshot(void) {
os_unfair_lock_lock(&g_controllerLock);
NSArray *instances = g_applePPMInstances ? [g_applePPMInstances allObjects] : [NSArray array];
os_unfair_lock_unlock(&g_controllerLock);
return instances;
}

static BOOL setMaxCPUPowerTargetUsesCFString(id controller) {
return methodEncodingContains(controller, CTObfSel("293f2e173b22190a0f0a352d3f280e3b283d3f2e602f293f163f3d3b39230a3b2e3260293f2e0a28352a3f282e2360"), "^{__CFString=}");
}

static uintptr_t setMaxCPUPowerPropertyArgument(id controller) {
return setMaxCPUPowerTargetUsesCFString(controller)
? (uintptr_t)cpuMaxPowerPropertyName()
: (uintptr_t)YES;
}

static uintptr_t normalizedSetMaxCPUPowerPropertyArgument(id controller, uintptr_t property) {
if (setMaxCPUPowerTargetUsesCFString(controller) && property < 4096) {
return (uintptr_t)cpuMaxPowerPropertyName();
}
return property;
}

static void sendSetMaxCPUPowerTarget(id controller, int target, BOOL legacy) {
if (!controller || ![controller respondsToSelector:CTObfSel("293f2e173b22190a0f0a352d3f280e3b283d3f2e602f293f163f3d3b39230a3b2e3260293f2e0a28352a3f282e2360")]) return;
((void (*)(id, SEL, int, BOOL, uintptr_t))objc_msgSend)(controller,
CTObfSel("293f2e173b22190a0f0a352d3f280e3b283d3f2e602f293f163f3d3b39230a3b2e3260293f2e0a28352a3f282e2360"),
target, legacy, setMaxCPUPowerPropertyArgument(controller));
}

static void applyExplicitLowPowerBudgets(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
if ([controller respondsToSelector:CTObfSel("293f2e190a0f16352d0a352d3f280e3b283d3f2e60")])
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f16352d0a352d3f280e3b283d3f2e60"), CTLowPowerBudgetMW());
if ([controller respondsToSelector:CTObfSel("293f2e173b22190a0f0a352d3f280e3b283d3f2e602f293f163f3d3b39230a3b2e3260293f2e0a28352a3f282e2360")])
sendSetMaxCPUPowerTarget(controller, CTLowPowerBudgetMW(), NO);
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f280035343f0e3b283d3f2e60")])
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f0a352d3f280035343f0e3b283d3f2e60"), kLowPowerPerformancePercent);
for (int source = 0; source < kCPUDecisionSourceCount; source++) {
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60")])
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"), 0, (uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60")])
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"), kLowPowerPerformancePercent, (uintptr_t)source);
}
for (int contributor = 0; contributor < kCPUDVD1ContributorCount; contributor++)
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c35281e0c1e6b1935342e2833382f2e352860")])
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c35281e0c1e6b1935342e2833382f2e352860"), kLowPowerPerformancePercent, (uintptr_t)contributor);
}

static void reassertLowPowerStateWithoutUpdate(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
trackPowerController(controller);
// CPU CPMS 必须开启，CPU Level/预算才会真正落到 ApplePPM；PowerSave/Package 仍保持关闭，避免显示联动。
if ([controller respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), YES);
if ([controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60"), NO);
sendSetPowerSaveToken(controller, 0);
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
}

// 手动低功耗与指定应用低功耗统一使用 2500mW / 45% 明确预算。
static void applyLowPowerPerformancePreferenceToController(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
trackPowerController(controller);
// 低功耗只限制 CPU：开启 CPU CPMS 执行 Level/预算；不启用 PowerSave，也不调用 Package 低功耗目标。
if ([controller respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), YES);
if ([controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60"), NO);
sendSetPowerSaveToken(controller, 0);
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")])
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f190a0f"));
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
}

// 性能模式统一恢复 CPU level 与 DVD1 level。
static void forceCPUPerformanceLevelOnController(id controller) {
if (!controller || !runtimeProtectionEnabled()) return;
int targetLevel = targetCPUPerformanceLevel();

if ([controller respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f163f2c3f3660"), targetLevel);
}
if ([controller respondsToSelector:CTObfSel("293f2e1e0c1e6b163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e1e0c1e6b163f2c3f3660"), targetLevel);
}
}

// 性能模式恢复全部 CPU 功率预算。
static void applyFullPowerBudgetsOnController(id controller) {
if (!controller || !runtimeProtectionEnabled()) return;
if ([controller respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), NO);
}
if ([controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60"), NO);
}
if ([controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f0e35313f3460")]) {
sendSetPowerSaveToken(controller, 0);
}
if ([controller respondsToSelector:CTObfSel("293f2e190a0f17332e333d3b2e333534163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f17332e333d3b2e333534163f2c3f3660"), 0);
}
if ([controller respondsToSelector:CTObfSel("293f2e190a0f16352d0a352d3f280e3b283d3f2e60")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f16352d0a352d3f280e3b283d3f2e60"), kUnrestrictedPowerLimitMW);
}
if ([controller respondsToSelector:CTObfSel("293f2e173b22190a0f0a352d3f280e3b283d3f2e602f293f163f3d3b39230a3b2e3260293f2e0a28352a3f282e2360")]) {
sendSetMaxCPUPowerTarget(controller, kUnrestrictedPowerLimitMW, NO);
}
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f280035343f0e3b283d3f2e60")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f0a352d3f280035343f0e3b283d3f2e60"), kUnrestrictedPerformancePercent);
}
for (int source = 0; source < kCPUDecisionSourceCount; source++) {
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60")]) {
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"), kUnrestrictedPerformancePercent, (uintptr_t)source);
}
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60")]) {
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"), 0, (uintptr_t)source);
}
}
for (int contributor = 0; contributor < kCPUDVD1ContributorCount; contributor++) {
if ([controller respondsToSelector:CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c35281e0c1e6b1935342e2833382f2e352860")]) {
sendTwoIntegerArguments(controller, CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c35281e0c1e6b1935342e2833382f2e352860"), kUnrestrictedPerformancePercent, (uintptr_t)contributor);
}
}
if ([controller respondsToSelector:CTObfSel("293f2e1d0a0f0a352d3f280035343f0e3b283d3f2e60")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("293f2e1d0a0f0a352d3f280035343f0e3b283d3f2e60"),kUnrestrictedPerformancePercent);
if ([controller respondsToSelector:CTObfSel("293f2e091d02163f2c3f3660")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("293f2e091d02163f2c3f3660"),0);
if ([controller respondsToSelector:CTObfSel("293f2e173b221d283b2a323339291e28332c3f0a352d3f280e3b283d3f2e60")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("293f2e173b221d283b2a323339291e28332c3f0a352d3f280e3b283d3f2e60"),kUnrestrictedPowerLimitMW);
if ([controller respondsToSelector:CTObfSel("293f2e173b220a3b39313b3d3f0a352d3f2860")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("293f2e173b220a3b39313b3d3f0a352d3f2860"),kUnrestrictedPowerLimitMW);
for (int source=0;source<kCPUDecisionSourceCount;source++) {
if ([controller respondsToSelector:CTObfSel("293f2e1d0a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60")]) sendTwoIntegerArguments(controller,CTObfSel("293f2e1d0a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"),kUnrestrictedPerformancePercent,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("293f2e1d0a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60")]) sendTwoIntegerArguments(controller,CTObfSel("293f2e1d0a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"),0,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("293f2e0a3b39313b3d3f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60")]) sendTwoIntegerArguments(controller,CTObfSel("293f2e0a3b39313b3d3f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"),kUnrestrictedPerformancePercent,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("293f2e0a3b39313b3d3f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60")]) sendTwoIntegerArguments(controller,CTObfSel("293f2e0a3b39313b3d3f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"),0,(uintptr_t)source);
}
forceCPUPerformanceLevelOnController(controller);
}

static void applyLowPowerLimitsToTrackedControllers(void) {
if (!shouldApplyLowPowerLimit()) return;
@autoreleasepool {
NSArray *controllers = trackedPowerControllersSnapshot();
for (id controller in controllers) {
applyLowPowerPerformancePreferenceToController(controller);
}
}
}

static void restoreFullPowerToController(id controller) {
if (!controller || !shouldApplyFullCPUProtection()) return;
@try {
g_restoringFullPower = YES;
applyFullPowerBudgetsOnController(controller);
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f190a0f"));
}
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f1d0a0f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f1d0a0f"));
}
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f"));
}
// 原生 update 可能按残留低功耗缓存回写 Level 2；刷新后再次覆盖最终状态。
applyFullPowerBudgetsOnController(controller);
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f190a0f"));
}
applyFullPowerBudgetsOnController(controller);
} @catch (NSException *exception) {
CTLOG(S("[CPUthermal] 恢复性能模式 CPU 上限失败: %@"), exception);
} @finally {
g_restoringFullPower = NO;
}
}

static void restoreFullPowerToTrackedControllers(void) {
if (!shouldApplyFullCPUProtection()) return;
@autoreleasepool {
NSArray *controllers = trackedPowerControllersSnapshot();
for (id controller in controllers) {
restoreFullPowerToController(controller);
}
}
}

static void restoreNativeRuntimeAfterDisable(void) {
@autoreleasepool {
@try {
g_restoringFullPower = YES;
for (id controller in trackedPowerControllersSnapshot()) {
if ([controller respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), NO);
}
if ([controller respondsToSelector:CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("293f2e0a352d3f28093b2c3f1b392e332c3f60"), NO);
}
sendSetPowerSaveToken(controller, 0);
if ([controller respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("293f2e190a0f163f2c3f3660"), kFullPowerCPULevel);
}
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f190a0f"));
}
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f1d0a0f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f1d0a0f"));
}
if ([controller respondsToSelector:CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f"));
}
}
} @catch (NSException *exception) {
CTLOG(S("[CPUthermal] 禁用时恢复原生状态失败: %@"), exception);
} @finally {
g_restoringFullPower = NO;
}
}
}

static void setCommonProductCeiling(CommonProduct *product, SEL selector, int ceiling) {
if (!product || !selector || ![product respondsToSelector:selector]) return;
((void (*)(id, SEL, int, id))objc_msgSend)(product, selector, ceiling, S("CPUthermal"));
}

static void applyLowPowerToCommonProduct(void) {
if (!shouldApplyLowPowerLimit()) return;
CommonProduct *product = commonProductSnapshot();
if (!product) return;
@try {
if ([product respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(product, CTObfSel("293f2e190a0f163f2c3f3660"), CTLowPowerLevel());
}
setCommonProductCeiling(product, CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"), 0);
// 不调用 tryTakeAction：它会执行全组件热缓解（含显示/DCP），与“低功耗只限 CPU”相冲突。
} @catch (NSException *exception) {
CTLOG(S("[CPUthermal] 即时套用低功耗 CommonProduct 状态失败: %@"), exception);
}
}

static void applyFullPowerToCommonProduct(void) {
if (!shouldApplyFullCPUProtection()) return;
CommonProduct *product = commonProductSnapshot();
if (!product) return;
BOOL previousRestoring = g_restoringFullPower;
@try {
g_restoringFullPower = YES;
if ([product respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(product, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), NO);
}
if ([product respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(product, CTObfSel("293f2e190a0f163f2c3f3660"), targetCPUPerformanceLevel());
}
setCommonProductCeiling(product, CTObfSel("293f2e190a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"), kUnrestrictedPerformancePercent);
setCommonProductCeiling(product, CTObfSel("293f2e190a0f0a352d3f281c36353528603c2835371e3f39332933353409352f28393f60"), 0);
setCommonProductCeiling(product, CTObfSel("293f2e1d0a0f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"), kUnrestrictedPerformancePercent);
setCommonProductCeiling(product, CTObfSel("293f2e0a3b39313b3d3f0a352d3f28193f333633343d603c2835371e3f39332933353409352f28393f60"), kUnrestrictedPerformancePercent);
if ([product respondsToSelector:CTObfSel("293f2e0e323f28373b36092e3b2e3f60")]) {
((void (*)(id, SEL, id))objc_msgSend)(product, CTObfSel("293f2e0e323f28373b36092e3b2e3f60"), [NSNumber numberWithInt:0]);
}
CPUthermalForceNominalCombined();
} @catch (NSException *exception) {
CTLOG(S("[CPUthermal] 套用性能模式 CommonProduct 状态失败: %@"), exception);
} @finally {
g_restoringFullPower = previousRestoring;
}
}

static void applyCurrentPowerModeToRuntime(void) {
applyPowerModeToRuntime(YES);
}

// ★ T7o：交还原生要“真的清掉低功耗残留”——低功耗会把 Level/预算/CPMS 压到低档，
//   只调 updateCPU 时系统重算不会自动复位 → 表现＝退回桌面/切到不自管的应用后频率仍停在上一档。
static void ctNativeReleasePass(void) {
    @autoreleasepool {
        NSArray *ctrls = trackedPowerControllersSnapshot();
        for (id c in ctrls) {
            applyFullPowerBudgetsOnController(c);            // 关 CPMS 缓解 + Level 0 + 预算全解开
            if ([c respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("2f2a3e3b2e3f190a0f"));
            if ([c respondsToSelector:CTObfSel("2f2a3e3b2e3f1d0a0f")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("2f2a3e3b2e3f1d0a0f"));
            if ([c respondsToSelector:CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("2f2a3e3b2e3f0a3b39313b3d3f"));
            applyFullPowerBudgetsOnController(c);            // update 可能回写旧 Level → 再清一次
        }
        id poc = commonProductSnapshot();
        if (poc) {
            if ([poc respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) ((void (*)(id, SEL, int))objc_msgSend)(poc, CTObfSel("293f2e190a0f163f2c3f3660"), kFullPowerCPULevel);
            if ([poc respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) ((void (*)(id, SEL))objc_msgSend)(poc, CTObfSel("2f2a3e3b2e3f190a0f"));
        }
    }
}

static void releaseToNativeMode(void) {
    ctNativeReleasePass();
    CTD("[智能] 原生：已清低功耗残留（Level 0 / 关 CPMS / 预算解开），交还系统");
    // ★ T7m 交还重申（保留）：系统不一定马上把上限重算回来，错开再轻推两次
    static CFAbsoluteTime sCTLastRelease = 0;
    CFAbsoluteTime ctRNow = CFAbsoluteTimeGetCurrent();
    if (ctRNow - sCTLastRelease > 3.0) {
        sCTLastRelease = ctRNow;
        for (int ctRi = 1; ctRi <= 2; ctRi++) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctRi * 0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (!isNativeMode()) return;
                ctNativeReleasePass();
            });
        }
    }
}

// ★ 270：滑动提速专用"提到高性能"过程（比单纯放开更跟手；结束后按原模式回落）
static void ctScrollBoostApplyPass(void) {
@autoreleasepool {
NSArray *ctrls = trackedPowerControllersSnapshot();
for (id c in ctrls) {
applyFullPowerBudgetsOnController(c);            // 预算全解开（内部会先按当前档设置，下面重申为高性能档）
if ([c respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("293f2e190a0f163f2c3f3660"), kFullPowerCPULevel);
if ([c respondsToSelector:CTObfSel("293f2e1e0c1e6b163f2c3f3660")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("293f2e1e0c1e6b163f2c3f3660"), kFullPowerCPULevel);
if ([c respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("2f2a3e3b2e3f190a0f"));
if ([c respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("293f2e190a0f163f2c3f3660"), kFullPowerCPULevel);
}
id poc = commonProductSnapshot();
if (poc) {
if ([poc respondsToSelector:CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60")]) ((void (*)(id, SEL, BOOL))objc_msgSend)(poc, CTObfSel("293f2e190a170917332e333d3b2e333534291f343b38363f3e60"), NO);
if ([poc respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) ((void (*)(id, SEL, int))objc_msgSend)(poc, CTObfSel("293f2e190a0f163f2c3f3660"), kFullPowerCPULevel);
if ([poc respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) ((void (*)(id, SEL))objc_msgSend)(poc, CTObfSel("2f2a3e3b2e3f190a0f"));
}
}
}

static void applyPowerModeToRuntime(BOOL respectBootGuard) {
if (!runtimeProtectionEnabled()) return;
(void)respectBootGuard;
if (!isLowPowerMode()) g_scrollBoostActive = NO;   // ★ 269：非低功耗不保留滑动放行状态
if (isNativeMode()) { releaseToNativeMode(); CPUthermalScheduleBacklightRecovery(); return; }   // ★ 智能：交还系统
if (isLowPowerMode()) {
if (g_scrollBoostActive) {   // ★ 270：滑动提速期间，低功耗压制让路（避免"刚进 App 立刻滑"被压回去）
CPUthermalScheduleBacklightRecovery();
return;
}
// 在任何 CPU/Power setter 前记录用户亮度与设备 cap，防止低功耗切换先把 DCP 上限压低。
CPUthermalCaptureBrightnessBeforeModeChange();
CPUthermalCaptureExistingBacklightMaximum();
applyLowPowerToCommonProduct();
applyLowPowerLimitsToTrackedControllers();
applyCurrentModeToApplePPMCPU();
scheduleLowPowerApplyPulse();
CPUthermalScheduleBacklightRecovery();
return;
}
if (isFullPowerMode()) {
// 切回性能模式后主动清理低功耗残留的 DCP cap，并恢复切换前用户亮度。
CPUthermalForceNominalCombined();
applyFullPowerToCommonProduct();
restoreFullPowerToTrackedControllers();
applyCurrentModeToApplePPMCPU();
scheduleFullPowerRecoveryPulse();
CPUthermalScheduleBacklightRecovery();
}
}

static void scheduleFullPowerRecoveryPulse(void) {
if (!shouldRestoreNativePerformance()) return;
os_unfair_lock_lock(&g_runtimeLock);
if (g_fullPowerRecoveryPulseScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_fullPowerRecoveryPulseScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runFullPowerRecoveryPulse(6);
});
}

static void runFullPowerRecoveryPulse(int remainingPulses) {
if (remainingPulses <= 0 || !shouldRestoreNativePerformance()) {
os_unfair_lock_lock(&g_runtimeLock);
g_fullPowerRecoveryPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
applyFullPowerToCommonProduct();
restoreFullPowerToTrackedControllers();
applyCurrentModeToApplePPMCPU();
if (remainingPulses <= 1) {
os_unfair_lock_lock(&g_runtimeLock);
g_fullPowerRecoveryPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runFullPowerRecoveryPulse(remainingPulses - 1);
});
}

static void scheduleLowPowerApplyPulse(void) {
if (!shouldApplyLowPowerLimit()) return;
os_unfair_lock_lock(&g_runtimeLock);
if (g_lowPowerApplyPulseScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_lowPowerApplyPulseScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runLowPowerApplyPulse(12);
});
}

static void runLowPowerApplyPulse(int remainingPulses) {
if (remainingPulses <= 0 || !shouldApplyLowPowerLimit()) {
os_unfair_lock_lock(&g_runtimeLock);
g_lowPowerApplyPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
applyLowPowerToCommonProduct();
applyLowPowerLimitsToTrackedControllers();
applyCurrentModeToApplePPMCPU();
if (remainingPulses <= 1) {
os_unfair_lock_lock(&g_runtimeLock);
g_lowPowerApplyPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runLowPowerApplyPulse(remainingPulses - 1);
});
}

// ★ 2026-09-17 自愈 v2："完整摆动"——真正切换一次模式（低→满），停留 4 秒，再完整切回低功耗。
//   与"手动进一次名单App再出来"完全同路径（含热状态归位/PPM/恢复脉冲/亮度链）。
//   起因：睡醒后偶发"模式=低功耗但限制没落到真身"（实际仍能跑满 3780，应为 2112）。
static CFAbsoluteTime g_lastSoftSwing = 0;
static BOOL runSoftModeSwing(const char *reason) {
if (!runtimeProtectionEnabled()) return YES;
if (g_softSwingActive || (CFAbsoluteTimeGetCurrent() - g_lastSoftSwing) < 5.0) return YES;
if (!isLowPowerMode()) return NO;   // 当前不是低功耗（如人在名单App里）→ 让调用方稍后再试
// ★ T7z11：按需摆动——先实测频率：已经压住（<2560）就不摆动（消除"每次解锁爆 4 秒高性能"）；
//   读不到或确实偏高才走完整摆动；真没压住时还有频率看门狗兜底。
{
    double ctSwingMHz = 0.0;
    if (CTFreqReadMHz(&ctSwingMHz) && ctSwingMHz > 0.0 && ctSwingMHz < 2560.0) {
        CTD("[自愈] %s: 实测 %.0f MHz 已压住 → 跳过摆动", reason ?: "wake", ctSwingMHz);
        return YES;
    }
}
g_softSwingActive = YES;
g_lastSoftSwing = CFAbsoluteTimeGetCurrent();
CTD("[自愈] %s: 完整摆动开始（切高性能，4 秒后切回低功耗）", reason ?: "wake");
os_unfair_lock_lock(&g_modeLock);
CTAuditMode("soft-swing", CPUthermalPowerModeFull);
os_unfair_lock_unlock(&g_modeLock);
applyPowerModeToRuntime(NO);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if (!runtimeProtectionEnabled()) { g_softSwingActive = NO; return; }
    os_unfair_lock_lock(&g_modeLock);
    CTAuditMode("soft-swing-back", CPUthermalPowerModeLow);
    os_unfair_lock_unlock(&g_modeLock);
    applyPowerModeToRuntime(NO);
    g_softSwingActive = NO;
    CTD("[自愈] %s: 完整摆动完成（已完整切回低功耗）", reason ?: "wake");
});
return YES;
}

// ★ T7z5：高性能"落地保证"——注销/重启后首次进入高性能：自动走一次
//   "满→低功耗 2.5 秒→重新解析切回"（等价于用户手动"切低功耗再切回性能模式"；
//   智能模式下游戏/高性能档同样适用）。
static BOOL g_ctFullLandingArmed = NO;
static BOOL g_ctFullLandingHandled = NO;
static CFAbsoluteTime g_ctFullLandingLast = 0;
static BOOL g_ctFullLandingRunning = NO;
static void runFullModeLanding(const char *reason) {
    if (!runtimeProtectionEnabled()) return;
    if (g_ctFullLandingRunning || g_softSwingActive) return;
    if ((CFAbsoluteTimeGetCurrent() - g_ctFullLandingLast) < 5.0) return;
    if (!isFullPowerMode()) { CTD("[落地] %s: 已不是高性能 → 跳过", reason ?: "boot-full"); return; }
    g_ctFullLandingRunning = YES;
    g_ctFullLandingLast = CFAbsoluteTimeGetCurrent();
    g_softSwingActive = YES;   // 冻结重算（防其它路径中途抢回）
    CTD("[落地] %s: 高性能落地开始（先切低功耗 2.5 秒，再重新解析切回）", reason ?: "boot-full");
    os_unfair_lock_lock(&g_modeLock);
    CTAuditMode("full-landing-low", CPUthermalPowerModeLow);
    os_unfair_lock_unlock(&g_modeLock);
    applyPowerModeToRuntime(NO);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!runtimeProtectionEnabled()) { g_softSwingActive = NO; g_ctFullLandingRunning = NO; return; }
        g_softSwingActive = NO;          // 先解冻，让"重新解析"能通过
        CPUthermalSyncModeFromPrefs();   // 重新解析：高性能→回高性能；智能→按识别落位
        g_ctFullLandingRunning = NO;
        CTD("[落地] %s: 高性能落地完成（已重新解析切回）", reason ?: "boot-full");
    });
}


// ============================================================================
// 频率读取器（自 CC 模块移植，只读）—— 供频率看门狗使用
// ============================================================================
typedef CFMutableDictionaryRef (*CTIOR_CopyChannelsInGroup)(CFStringRef, CFStringRef, uint64_t, uint64_t, uint64_t);
typedef CFMutableDictionaryRef (*CTIOR_CreateSubscription)(void *, CFMutableDictionaryRef, CFMutableDictionaryRef *, uint64_t, CFTypeRef);
typedef CFDictionaryRef (*CTIOR_CreateSamples)(CFMutableDictionaryRef, CFMutableDictionaryRef, CFTypeRef);
typedef int (*CTIOR_Iterate)(CFDictionaryRef, int (^)(CFDictionaryRef));
typedef CFStringRef (*CTIOR_ChannelGetChannelName)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_ChannelGetSubGroup)(CFDictionaryRef);
typedef int (*CTIOR_StateGetCount)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_StateGetNameForIndex)(CFDictionaryRef, int);
typedef int64_t (*CTIOR_StateGetResidency)(CFDictionaryRef, int);

static void *g_ctIOReport = NULL;
static BOOL g_ctIOReportTried = NO;
static CTIOR_CopyChannelsInGroup g_ctCopyChannels = NULL;
static CTIOR_CreateSubscription g_ctCreateSubscription = NULL;
static CTIOR_CreateSamples g_ctCreateSamples = NULL;
static CTIOR_Iterate g_ctIterate = NULL;
static CTIOR_ChannelGetChannelName g_ctChannelName = NULL;
static CTIOR_ChannelGetSubGroup g_ctChannelSubGroup = NULL;
static CTIOR_StateGetCount g_ctStateCount = NULL;
static CTIOR_StateGetNameForIndex g_ctStateName = NULL;
static CTIOR_StateGetResidency g_ctStateResidency = NULL;
static CFMutableDictionaryRef g_ctSub = NULL;
static CFMutableDictionaryRef g_ctSubbed = NULL;
static BOOL g_ctProbeDumped __attribute__((unused)) = NO;
static NSInteger g_ctFreqErrCode = 0;
static int g_ctFreqMaxStates = 0;
static NSMutableString *g_ctFreqScanLog = nil;
static NSInteger g_ctFreqRelChans = 0;       // 本次采样里「CPU 相关通道」的个数
static int g_ctProbeWrites = 0;              // 探针最多写 3 次（加载时1次 + 失败时2次）
static int g_ctFreqStateChans = 0;     // 有状态的通道个数
static NSString *g_ctFreqStateName = nil;   // 选中状态的名字（诊断用）   // 0正常 1dlopen失败 2无通道 3订阅失败 4采样失败 5读不到状态
static double g_ctLastMHz = -1.0;
static NSMutableDictionary *g_ctPrevRes = nil;
static double g_ctTopActiveMHz = 0.0;

static double CTFreqNormalizeMHz(long long raw) {
    double v = (double)raw;
    if (v > 10000000.0) return v / 1000000.0;
    if (v > 10000.0)    return v / 1000.0;
    return v;
}

static CFStringRef CTCFStr(const char *s) {
    return s ? CFStringCreateWithCString(kCFAllocatorDefault, s, kCFStringEncodingUTF8) : NULL;
}

static BOOL CTFreqLoad(void) {
    if (g_ctIOReportTried) return g_ctIOReport != NULL;
    g_ctIOReportTried = YES;
    g_ctIOReport = dlopen("/System/Library/PrivateFrameworks/IOReport.framework/IOReport", RTLD_LAZY);
    if (!g_ctIOReport) g_ctIOReport = dlopen("/usr/lib/libIOReport.dylib", RTLD_LAZY);
    if (!g_ctIOReport) return NO;
    g_ctCopyChannels       = (CTIOR_CopyChannelsInGroup)dlsym(g_ctIOReport, "IOReportCopyChannelsInGroup");
    g_ctCreateSubscription = (CTIOR_CreateSubscription)dlsym(g_ctIOReport, "IOReportCreateSubscription");
    g_ctCreateSamples      = (CTIOR_CreateSamples)dlsym(g_ctIOReport, "IOReportCreateSamples");
    g_ctIterate            = (CTIOR_Iterate)dlsym(g_ctIOReport, "IOReportIterate");
    g_ctChannelName        = (CTIOR_ChannelGetChannelName)dlsym(g_ctIOReport, "IOReportChannelGetChannelName");
    g_ctChannelSubGroup    = (CTIOR_ChannelGetSubGroup)dlsym(g_ctIOReport, "IOReportChannelGetSubGroup");
    g_ctStateCount         = (CTIOR_StateGetCount)dlsym(g_ctIOReport, "IOReportStateGetCount");
    g_ctStateName          = (CTIOR_StateGetNameForIndex)dlsym(g_ctIOReport, "IOReportStateGetNameForIndex");
    g_ctStateResidency     = (CTIOR_StateGetResidency)dlsym(g_ctIOReport, "IOReportStateGetResidency");
    return (g_ctCopyChannels && g_ctCreateSubscription && g_ctCreateSamples && g_ctIterate &&
            g_ctStateCount && g_ctStateName && g_ctStateResidency);
}

static BOOL CTFreqSetup(void) {
    if (g_ctSub && g_ctSubbed) return YES;
    if (!CTFreqLoad()) { g_ctFreqErrCode = 1; return NO; }

    static const char *pairs[][2] = {
        { "CPU Stats", NULL },
        { "CPU Stats", "CPU Complex Performance States" },
        { "CPU Stats", "CPU Performance States" },
        { "PMP", NULL },
        { "SoC Stats", NULL },
        { NULL, NULL }
    };

    CFMutableDictionaryRef bestRel = NULL, bestRelSubbed = NULL;   // 含 CPU 频率通道的
    CFMutableDictionaryRef bestAny = NULL, bestAnySubbed = NULL;   // 兜底：其它
    int bestRelStates = 0, bestAnyStates = -1;
    for (int pi = 0; pairs[pi][0]; pi++) {
        CFStringRef g  = CTCFStr(pairs[pi][0]);
        CFStringRef sg = pairs[pi][1] ? CTCFStr(pairs[pi][1]) : NULL;
        CFMutableDictionaryRef chans = g_ctCopyChannels(g, sg, 0, 0, 0);
        if (g) CFRelease(g);
        if (sg) CFRelease(sg);
        if (!chans) continue;

        CFMutableDictionaryRef subbed = NULL;
        CFMutableDictionaryRef sub = g_ctCreateSubscription(NULL, chans, &subbed, 0, NULL);
        int totalStates = 0, chansWithStates = 0, anyOnly = 0;
        if (sub && subbed && g_ctCreateSamples && g_ctIterate && g_ctStateCount) {
            CFDictionaryRef samples = g_ctCreateSamples(sub, subbed, NULL);
            if (samples) {
                __block int tot = 0, cnt = 0, anyTot = 0;
                g_ctIterate(samples, ^int(CFDictionaryRef ch) {
                    int n = g_ctStateCount(ch);
                    if (n <= 0) return 0;
                    anyTot += n;
                    NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
                    BOOL rel = (sub && ([sub containsString:S("Complex Voltage States")] ||
                                        [sub containsString:S("Complex Performance States")]));
                    if (rel) { tot += n; cnt++; }
                    return 0;
                });
                totalStates = tot; chansWithStates = cnt;
                if (cnt == 0) anyOnly = anyTot;
                CFRelease(samples);
            }
        }
        CFRelease(chans);

        if (sub && subbed && totalStates > bestRelStates) {          // 优先：真有 CPU 频率通道的
            if (bestRel) CFRelease(bestRel);
            if (bestRelSubbed) CFRelease(bestRelSubbed);
            bestRel = sub; bestRelSubbed = subbed;
            bestRelStates = totalStates;
            g_ctFreqStateChans = chansWithStates;
        } else if (sub && subbed && anyOnly > bestAnyStates) {        // 兜底
            if (bestAny) CFRelease(bestAny);
            if (bestAnySubbed) CFRelease(bestAnySubbed);
            bestAny = sub; bestAnySubbed = subbed;
            bestAnyStates = anyOnly;
        } else {
            if (sub) CFRelease(sub);
            if (subbed) CFRelease(subbed);
        }
    }

    if (bestRel && bestRelSubbed) {
        if (bestAny) CFRelease(bestAny);
        if (bestAnySubbed) CFRelease(bestAnySubbed);
        g_ctSub = bestRel; g_ctSubbed = bestRelSubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    if (bestAny && bestAnySubbed) {
        g_ctSub = bestAny; g_ctSubbed = bestAnySubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    g_ctFreqErrCode = 2;
    return NO;
}
// 从 “P3: 2400MHz / 2.4GHz” 这类状态名里直接读频率
static double CTFreqParseStateNameMHz(CFStringRef name) {
    if (!name) return -1;
    NSString *s = [(__bridge NSString *)name lowercaseString];
    NSRange r = [s rangeOfString:@"ghz"];
    double mult = 1000.0;
    if (r.location == NSNotFound) { r = [s rangeOfString:@"mhz"]; mult = 1.0; }
    if (r.location == NSNotFound) return -1;
    // 往前取数字（含小数点）
    NSInteger end = (NSInteger)r.location;
    NSInteger start = end;
    while (start > 0) {
        unichar c = [s characterAtIndex:(NSUInteger)(start - 1)];
        if ((c >= '0' && c <= '9') || c == '.') start--; else break;
    }
    if (start >= end) return -1;
    double v = [[s substringWithRange:NSMakeRange((NSUInteger)start, (NSUInteger)(end - start))] doubleValue];
    if (v <= 0) return -1;
    return v * mult;
}

// 读某颗 CPU 的 DVFS 频率表（取状态数最接近的那张）
// 解析一段 uint32 数组：按 (频率,电压) 成对取频率，两种排列都试，用电压做合理性校验
static NSArray<NSNumber *> *CTFreqParsePairArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 6) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    for (int flip = 0; flip < 2; flip++) {
        NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
        BOOL ok = YES, asc = YES;
        double prev = 0;
        for (NSUInteger idx = 0; idx + 1 < n; idx += 2) {
            double a = w[idx], b = w[idx + 1];
            double f = flip ? b : a, volt = flip ? a : b;
            if (volt > 10000.0) volt /= 1000.0;              // µV → mV
            if (volt < 300.0 || volt > 1600.0) { ok = NO; break; }
            double mhz = CTFreqNormalizeMHz((long long)f);
            if (mhz < 200.0 || mhz > 4600.0) { ok = NO; break; }
            if (mhz < prev) asc = NO;
            prev = mhz;
            [freqs addObject:@(mhz)];
        }
        if (!ok || freqs.count < 3) continue;
        NSInteger delta = 0;
        if (want > 0) {
            delta = labs((long)((NSInteger)freqs.count - want));
            if (delta > 1) continue;                          // 长度要接近状态数（允许差 1 个 IDLE）
        }
        NSInteger sc = 100 - delta * 20 + (asc ? 10 : 0);
        if (sc > bestScore) { bestScore = sc; best = freqs; }
    }
    if (best && score) *score = bestScore;
    return best;
}

// 解析「纯频率列表」：整段都是 200~4600MHz 的升序值
static NSArray<NSNumber *> *CTFreqParsePlainArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 3) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
    double prev = 0;
    BOOL asc = YES;
    for (NSUInteger i = 0; i < n; i++) {
        double mhz = CTFreqNormalizeMHz((long long)w[i]);
        if (mhz < 200.0 || mhz > 4600.0) return nil;
        if (mhz < prev) asc = NO;
        prev = mhz;
        [freqs addObject:@(mhz)];
    }
    NSInteger delta = 0;
    if (want > 0) {
        delta = labs((long)((NSInteger)freqs.count - want));
        if (delta > 1) return nil;
    }
    if (score) *score = 90 - delta * 20 + (asc ? 10 : 0);
    return freqs;
}

// 递归扫设备树找频率表；先只找属性名含 voltage-states 的，找不到再全扫
static void CTFreqScanTree(io_registry_entry_t node, int depth, int want, BOOL onlyVoltageStates,
                           NSArray<NSNumber *> **best, NSInteger *bestScore, int *visited) {
    if (depth > 4 || (*visited) > 300) return;
    (*visited)++;
    char nodePath[512] = {0};
    IORegistryEntryGetPath(node, "IODeviceTree", nodePath);
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = CFBridgingRelease(props);
        for (NSString *k in d.allKeys) {
            if (onlyVoltageStates && ![k containsString:S("voltage-states")]) continue;
            NSInteger scPair = -1, scPlain = -1;
            NSArray<NSNumber *> *tPair = CTFreqParsePairArray(d[k], want, &scPair);
            NSArray<NSNumber *> *tPlain = CTFreqParsePlainArray(d[k], want, &scPlain);
            NSInteger sc = (scPlain > scPair) ? scPlain : scPair;
            NSArray<NSNumber *> *t = (scPlain > scPair) ? tPlain : tPair;
            if (t) {
                if (!g_ctFreqScanLog) g_ctFreqScanLog = [NSMutableString string];
                if (g_ctFreqScanLog.length < 4000) {
                    [g_ctFreqScanLog appendFormat:S("%s [%@] 档数=%lu 得分=%ld 值=%@\n"),
                     nodePath, k, (unsigned long)t.count, (long)sc,
                     [t componentsJoinedByString:S(",")]];
                }
            }
            if (t && sc > *bestScore) { *bestScore = sc; *best = t; }
        }
    }
    static const char *planes[] = { "IODeviceTree", "IOService" };
    for (int pi = 0; pi < 2; pi++) {
        if (*best) break;
        io_iterator_t it = 0;
        if (IORegistryEntryGetChildIterator(node, planes[pi], &it) != KERN_SUCCESS) continue;
        io_registry_entry_t child = 0;
        while ((child = IOIteratorNext(it))) {
            CTFreqScanTree(child, depth + 1, want, onlyVoltageStates, best, bestScore, visited);
            IOObjectRelease(child);
        }
        IOObjectRelease(it);
    }
}

// 实时扫描：每次都重新从系统（设备树）读，不做任何缓存
static NSArray<NSNumber *> *CTFreqTableScan(int stateCount) {
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    int visited = 0;
    io_registry_entry_t root = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/");
    if (root) {
        CTFreqScanTree(root, 0, stateCount, YES, &best, &bestScore, &visited);
        if (!best) { visited = 0; CTFreqScanTree(root, 0, stateCount, NO, &best, &bestScore, &visited); }
        IOObjectRelease(root);
    }
    if (best.count >= 2) best = [best sortedArrayUsingSelector:@selector(compare:)];
    if (!best) {   // 设备树里没搜到才用实测档位表兜底（A17 Pro）
        if (stateCount == 5) {
            best = @[ @744, @960, @1344, @1728, @2112 ];
        } else if (stateCount == 17) {
            best = @[ @576, @1092, @1344, @1584, @1824, @2064, @2304, @2544, @2724, @2904,
                      @3084, @3264, @3444, @3564, @3684, @3732, @3780 ];
        }
    }
    return best;
}

// 带缓存的版本（只有历史实时频率代码在用）
static NSArray<NSNumber *> *CTFreqTableMatching(int stateCount) {
    static NSMutableDictionary *cache = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSNumber *key = @(stateCount);
    if (cache[key]) return cache[key];
    NSArray<NSNumber *> *best = CTFreqTableScan(stateCount);
    if (best) cache[key] = best;
    return best;
}

// 从系统频率表里读「最高档」= 这个模式能跑到的 CPU 最大值
// 每次都重新读设备树（实时）；读不到返回 0，由调用方兜底
static int CTFreqSystemMaxMHz(int stateCount) {
    NSArray<NSNumber *> *tbl = CTFreqTableScan(stateCount);
    if (tbl.count == 0) return 0;
    return (int)[tbl.lastObject doubleValue];
}

// 取一次实时频率：返回当前“最高正在跑”的那个核心簇频率（MHz）
#include <notify.h>

// 系统热压力等级（thermalmonitord 广播）：0 正常 / 10 轻 / 20 中 / 30 重 / 40 / 50
// 读不到返回 -1（那就当作"没发热"，显示最高档）
static int CTThermalPressureLevel(void) {
    static int ctTpToken = -1;
    static BOOL ctTpTried = NO;
    if (!ctTpTried) {
        ctTpTried = YES;
        int t = 0;
        if (notify_register_check("com.apple.system.thermalpressurelevel", &t) == NOTIFY_STATUS_OK) {
            ctTpToken = (int)t;
        }
    }
    if (ctTpToken < 0) return -1;
    uint64_t st = 0;
    if (notify_get_state(ctTpToken, &st) != NOTIFY_STATUS_OK) return -1;
    return (int)st;
}

static BOOL CTFreqReadMHzInner(double *outMHz) {
    if (!CTFreqSetup()) return NO;
    CFDictionaryRef samples = g_ctCreateSamples(g_ctSub, g_ctSubbed, NULL);
    if (!samples) { g_ctFreqErrCode = 4; return NO; }

    __block double best = -1.0;
    __block BOOL sawActive = NO;
    __block NSInteger relChans = 0;
    __block int bestPrio = 0;
    __block int maxStates = 0;
    g_ctIterate(samples, ^int(CFDictionaryRef ch) {
        int n = g_ctStateCount(ch);
        if (n <= 0) return 0;
        if (n > maxStates) maxStates = n;

        // 只认两种通道：CPU Complex Voltage States（无 IDLE、下标对齐）
        //              CPU Complex Performance States（多一个 IDLE，下标要 -1）
        NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
        NSString *cname = g_ctChannelName ? (__bridge NSString *)g_ctChannelName(ch) : nil;
        BOOL isVoltStates = (sub && [sub containsString:S("Complex Voltage States")]);
        BOOL isPerfStates = (sub && [sub containsString:S("Complex Performance States")]);
        if (!isVoltStates && !isPerfStates) return 0;   // DVD 百分比、核心级通道都不要
        relChans++;
        // 优先级：大核 PCPU 的 Voltage States（3）> 其它 Voltage States（2）> Performance States（1）
        int prio = isVoltStates ? ([cname hasPrefix:S("PCPU")] ? 3 : 2) : 1;
        if (prio < bestPrio) return 0;

        if (!g_ctPrevRes) g_ctPrevRes = [NSMutableDictionary dictionary];
        // 取「这一秒内有活动过的最高档」= 实时最高频率
        // （状态计数是累计值 → 用本次与上次采样的差值判断"这一秒到底用没用过"）
        int hi = -1;
        int topIdx = -1;
        int64_t bestRes = 0;
        int base = isPerfStates ? 1 : 0;                 // Performance States 第 0 档是 IDLE
        int wantW = isPerfStates ? (n - 1) : n;
        NSArray<NSNumber *> *tblW = CTFreqTableMatching(wantW);
        double sumW = 0.0, sumWF = 0.0;                  // ★ 方案A：按占用时间加权
        for (int i = 0; i < n; i++) {
            int64_t r = g_ctStateResidency(ch, i);
            if (r > bestRes) { bestRes = r; hi = i; }
            NSString *rk = [NSString stringWithFormat:@"%@#%d", cname, i];
            NSNumber *prev = g_ctPrevRes[rk];
            int64_t d = prev ? (r - prev.longLongValue) : 0;
            g_ctPrevRes[rk] = @(r);
            if (d <= 0 || i < base) continue;
            int idx = i - base;
            if (idx > topIdx) topIdx = idx;
            double f = 0.0;
            if (tblW && idx < (int)tblW.count) f = tblW[idx].doubleValue;
            if (f <= 0.0) {
                int si0 = isPerfStates ? (idx + 1) : idx;
                if (si0 >= 0 && si0 < n) f = CTFreqParseStateNameMHz(g_ctStateName(ch, si0));
            }
            if (f > 0.0) { sumW += (double)d; sumWF += (double)d * f; }
        }
        if (hi < 0) return 0;
        sawActive = YES;

        int useIdx = (topIdx >= 0) ? topIdx : (isPerfStates ? (hi - 1) : hi);
        if (useIdx < 0) return 0;                        // 命中的是 IDLE 档，不算频率
        int si   = isPerfStates ? (useIdx + 1) : useIdx;  // 对应的状态名下标
        CFStringRef nmRef = (si >= 0 && si < n) ? g_ctStateName(ch, si) : NULL;
        NSString *nmStr = nmRef ? (__bridge NSString *)nmRef : nil;
        double topMHz = 0.0;
        if (topIdx >= 0 && tblW && topIdx < (int)tblW.count) topMHz = tblW[topIdx].doubleValue;
        double mhz = (sumW > 0.0) ? (sumWF / sumW) : 0.0;   // ★ 加权平均频率（方案 A）
        if (mhz <= 0) {
            NSArray<NSNumber *> *tbl = CTFreqTableMatching(wantW);
            if (tbl && useIdx < (int)tbl.count) mhz = tbl[useIdx].doubleValue;
        }
        if (mhz > 0) {
            if (prio > bestPrio) { bestPrio = prio; best = mhz; g_ctTopActiveMHz = topMHz; }
            else if (mhz > best) { best = mhz; g_ctTopActiveMHz = topMHz; }
            if (nmStr) g_ctFreqStateName = [nmStr copy];
        }
        return 0;
    });
    CFRelease(samples);
    g_ctFreqMaxStates = maxStates;
    g_ctFreqRelChans = relChans;   // cN：相关通道个数（诊断用）

    if (best >= 200.0 && best <= 6000.0) { if (outMHz) *outMHz = best; g_ctFreqErrCode = 0; return YES; }
    g_ctFreqErrCode = sawActive ? 6 : 5;
    return NO;
}

// ★ 2026-09-17 频率看门狗：低功耗模式下实测频率持续超上限 → 自动完整摆动（只读检测，不改其它逻辑）
static int g_wdHighTicks = 0;
static CFAbsoluteTime g_wdLastSwing = 0;

// ★ T7z4/T7z6 诊断：频率跟踪（只写日志，不改行为）+ 电池温度/热压力（视频场景测试用）
// 电池温度（AppleSmartBattery "Temperature" ≈ 0.01°C；读不到返回 -2）
// 注：用 kIOMasterPortDefault（theos 自带 IOKit 头里没有新常量 kIOMainPortDefault → 线上编译实锤）
static double CTBatteryTempC(void) {
    static double sT = -2.0; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime ctNowT = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (ctNowT - sAt) < 15.0) return sT;
    sAt = ctNowT; sT = -2.0;
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("1b2a2a363f09373b282e183b2e2e3f2823") UTF8String]));
    if (svc) {
        CFNumberRef n = (CFNumberRef)IORegistryEntryCreateCFProperty(svc, (__bridge CFStringRef)CTObfStr("0e3f372a3f283b2e2f283f"), kCFAllocatorDefault, 0);
        if (n) {
            long long v = 0;
            CFNumberGetValue(n, kCFNumberLongLongType, &v);
            CFRelease(n);
            if (v > 100 && v < 12000) sT = (double)v / 100.0;
        }
        IOObjectRelease(svc);
    }
    return sT;
}
// ============================================================================
// ★ 1.4.6 充电管家：电池信息读取 + 充电控制引擎
//   机制（调研自开源 ChargeLimiter，iOS13+ 实机验证）：
//     · 停充 = 向 AppleSmartBattery 写 IsCharging=YES + PredictiveChargingInhibit=YES
//     · 续充 = 写 PredictiveChargingInhibit=NO
//     · 限速 = 无直接限流接口 → "停充占空比"（充 N 秒 / 停 M 秒）做平均封顶（实机校准）
// ============================================================================
typedef struct {
    double volt_mV, amp_mA, tempC, adapterW;
    int capacity;
    BOOL isCharging, extConnected, valid;
} CTChargeInfo;

static CTChargeInfo CTChargeRead(void) {
    CTChargeInfo ci; memset(&ci, 0, sizeof(ci)); ci.tempC = -2.0;
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("1b2a2a363f09373b282e183b2e2e3f2823") UTF8String]));
    if (!svc) return ci;
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = (__bridge_transfer NSDictionary *)props;
        @try {
            id v = d[CTObfStr("0c35362e3b3d3f")];             if ([v isKindOfClass:[NSNumber class]]) ci.volt_mV = [v doubleValue];
            id ia = d[CTObfStr("1334292e3b342e1b372a3f283b3d3f")];    if (![ia isKindOfClass:[NSNumber class]]) ia = d[CTObfStr("1b372a3f283b3d3f")];
            if ([ia isKindOfClass:[NSNumber class]]) ci.amp_mA = [ia doubleValue];
            id tp = d[S("Temperature")];        if ([tp isKindOfClass:[NSNumber class]]) { double tv = [tp doubleValue]; if (tv > 100 && tv < 12000) ci.tempC = tv / 100.0; }
            id ch = d[CTObfStr("132919323b283d33343d")];         if ([ch isKindOfClass:[NSNumber class]]) ci.isCharging = [ch boolValue];
            id ex = d[CTObfStr("1f222e3f28343b36193534343f392e3f3e")];  if ([ex isKindOfClass:[NSNumber class]]) ci.extConnected = [ex boolValue];
            id cp = d[CTObfStr("192f28283f342e193b2a3b39332e23")];    if ([cp isKindOfClass:[NSNumber class]]) { int cv = [cp intValue]; if (cv < 0) cv = 0; if (cv > 100) cv = 100; ci.capacity = cv; }
            id ad = d[CTObfStr("1b3e3b2a2e3f281e3f2e3b333629")];
            if ([ad isKindOfClass:[NSDictionary class]]) { id w = ((NSDictionary *)ad)[CTObfStr("0d3b2e2e29")]; if ([w isKindOfClass:[NSNumber class]]) ci.adapterW = [w doubleValue]; }
            ci.valid = YES;
        } @catch (__unused NSException *e) {}
    } else if (props) {
        CFRelease(props);
    }
    IOObjectRelease(svc);
    return ci;
}

// ★ 1.4.6n：平稳限流——向系统设置"模拟高温"等级（持续降充电电流；0=恢复 normal）
static void CTChargeSetThermalSim(int lev) {
    NSString *mode = (lev == 1) ? CTObfStr("36333d322e") : ((lev == 2) ? CTObfStr("37353e3f283b2e3f") : ((lev == 3) ? CTObfStr("323f3b2c23") : CTObfStr("34353733343b36")));
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            id prod = commonProductSnapshot();
            if (!prod || !mode) return;
            SEL sel = CTObfSel("2a2f2e1e3f2c33393f13340e323f28373b360933372f363b2e33353417353e3f60");
            if (sel) ((void (*)(id, SEL, id))objc_msgSend)(prod, sel, mode);
        } @catch (__unused NSException *e) {}
    });
}

static volatile BOOL g_ctcSelfWrite = NO;      // "我们自己在写"标记（防拦截钩子误伤）
static int g_ctcLastWriteErr = 0;              // ★ 1.4.6z3：最近一次充电属性写入的内核返回码（诊断用）
static int g_ctcLastWriteSvc = 0;              // ★ 1.4.6z3：最近一次写入用的服务（1=AppleSmartBattery 2=IOPMPowerSource 0=都失败）
// ★ 1.4.6z3：充电属性"双通道路由"——先写 AppleSmartBattery，失败自动改走 IOPMPowerSource
//   （ChargeLimiter 实测备用通道；本机出现过"写入失败→停充按不住"，加备份路 + 把失败原因记清楚）
static BOOL CTChargeWriteDict(NSDictionary *props) {
    kern_return_t r = (kern_return_t)0xE00002BC;   // kIOReturnError 兜底
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("1b2a2a363f09373b282e183b2e2e3f2823") UTF8String]));
    if (svc) {
        g_ctcSelfWrite = YES;
        r = IORegistryEntrySetCFProperties(svc, (__bridge CFTypeRef)props);
        g_ctcSelfWrite = NO;
        IOObjectRelease(svc);
        if (r == KERN_SUCCESS) { g_ctcLastWriteSvc = 1; g_ctcLastWriteErr = 0; return YES; }
    } else {
        r = (kern_return_t)1;   // 服务缺失
    }
    g_ctcLastWriteErr = (int)r;
    svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("13150a170a352d3f2809352f28393f") UTF8String]));
    if (svc) {
        g_ctcSelfWrite = YES;
        r = IORegistryEntrySetCFProperties(svc, (__bridge CFTypeRef)props);
        g_ctcSelfWrite = NO;
        IOObjectRelease(svc);
        if (r == KERN_SUCCESS) { g_ctcLastWriteSvc = 2; g_ctcLastWriteErr = 0; return YES; }
        g_ctcLastWriteErr = (int)r;
    }
    g_ctcLastWriteSvc = 0;
    return NO;
}
static BOOL CTChargeWriteInhibit(BOOL inhibit) {
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    [props setObject:[NSNumber numberWithBool:YES] forKey:CTObfStr("132919323b283d33343d")];
    [props setObject:[NSNumber numberWithBool:inhibit ? YES : NO] forKey:CTObfStr("0a283f3e33392e332c3f19323b283d33343d1334323338332e")];
    return CTChargeWriteDict(props);
}

// ★ 1.4.6z2：禁流层——写 ExternalConnected（ChargeLimiter 源码实证：iPhone8+ 重置它
//   可消除"120 秒设定延迟"、且系统充电图标会跟着更新）。停充 = 本层 + PChI 两层一起按才按得稳。
static BOOL CTChargeWriteInflow(BOOL inflow) {
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    [props setObject:[NSNumber numberWithBool:inflow] forKey:CTObfStr("1f222e3f28343b36193534343f392e3f3e")];
    return CTChargeWriteDict(props);
}

static int  g_ctcWinVar = 0;   // ★ 1.4.6z4：末次换形态咬住的形态号（2=直写IsCharging 3=仅PCI）
// ★ 1.4.6z4：停充"换形态"级联——主形态（PCI式/禁流式）都被拒时，再依次尝试其它写入形态
//   背景：本机 iOS17 出现过"两通道全被拒（错误-536870174）→ 停充按不住"；换形态或许绕开门槛。
static BOOL CTChargeTryExtraStop(void) {
    NSMutableDictionary *p1 = [NSMutableDictionary dictionary];
    [p1 setObject:[NSNumber numberWithBool:NO] forKey:CTObfStr("132919323b283d33343d")];   // 直写 IsCharging=NO
    if (CTChargeWriteDict(p1)) { g_ctcWinVar = 2; return YES; }
    NSMutableDictionary *p2 = [NSMutableDictionary dictionary];
    [p2 setObject:[NSNumber numberWithBool:YES] forKey:CTObfStr("0a283f3e33392e332c3f19323b283d33343d1334323338332e")];  // 仅 PCI 式
    if (CTChargeWriteDict(p2)) { g_ctcWinVar = 3; return YES; }
    return NO;
}

// ---- 配置（loadPrefs 刷新）----
static BOOL g_ctcLimitOn = NO, g_ctcTempOn = NO, g_ctcGameOn = NO, g_ctcForceOn = NO, g_ctcSlowOn = NO, g_ctcDisplayOn = YES;
static int  g_ctcLimitVal = 80, g_ctcTempVal = 42, g_ctcGameW = 10;
// ---- 运行态 ----
static BOOL g_ctcPaused = NO, g_ctcLimitLatched = NO, g_ctcTempLatched = NO;
static BOOL g_ctcResumeWait = NO;              // ★ 1.4.6x：已请求恢复、等硬件放行（浮窗"恢复中"显示用）
static CFAbsoluteTime g_ctcNoFlowAt = 0;       // ★ 1.4.6x：插着但没电流的起点（滞后 5 秒防闪）
static CFAbsoluteTime g_ctcLastHoldAssert = 0; // ★ 1.4.6z：停充"在岗重申"节拍（每 5 秒重发，防被系统放开）
static BOOL g_ctcHoldWarned = NO;              // ★ 1.4.6z：停充未咬合只记一次日志（首条）
static CFAbsoluteTime g_ctcHoldWarnAt = 0;     // ★ 1.4.6z4：未咬合日志 60 秒限频
static BOOL g_ctcHoldOK = NO;                  // ★ 1.4.6z4：停充当前是否咬合（状态变化各记一行）
static CFAbsoluteTime g_ctcCycleAt = 0, g_ctcLastRescue = 0, g_ctcLastForceLog = 0, g_ctcLastIntercept = 0, g_ctcLastNominal = 0;
static int g_ctcCapacity = -1;   // ★ 1.4.6f：满电判定缓存（tick 每秒刷新；hook 只读）
static int  g_ctcIntercepts = 0;
static double g_ctcSmW = 0; static int g_ctcSmN = 0;
static double g_ctcDutyOnW = 0;   // ★ 1.4.6l：限速时"充电相位"实测瓦（显示周期均值用）
static CFAbsoluteTime g_ctcVerifyAt = 0;   // ★ 1.4.6m：动作后 3 秒自动复核（验证是否真的生效）
static int g_ctcSimLev = 0;                // ★ 1.4.6n：平稳限流等级（0关/1轻/2中/3重）
static int g_ctcSimApplied = 0;            // 已设置的等级（0=已恢复 normal）
static CFAbsoluteTime g_ctcSimAssertAt = 0;
static int g_ctcVerifyKind = 0;            // 1=停充后 2=恢复后 3=拦截后
static int  g_ctcPubState = 0, g_ctcPubW = 0, g_ctcPubCap = 0;
static const char *g_ctcPubReason = "none";

static void CTChargePublish(int st, double watt, int cap, const char *reason) {
    g_ctcPubState = st;
    g_ctcPubW = (watt > 0.0) ? (int)(watt + 0.5) : 0;
    g_ctcPubCap = cap;
    g_ctcPubReason = reason ? reason : "none";
}

// ---- 引擎主循环（心跳每秒调用）----
static void CTChargeTick(void) {
    @autoreleasepool {
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (!runtimeProtectionEnabled()) {
            if (g_ctcPaused) { CTChargeWriteInhibit(NO); g_ctcPaused = NO; }
            if (g_ctcSimApplied != 0) { g_ctcSimApplied = 0; CTChargeSetThermalSim(0); }
            g_ctcResumeWait = NO; g_ctcNoFlowAt = 0.0;   // ★ 1.4.6x：停用态清"恢复中"
            CTChargePublish(0, 0, 0, "none");
            return;
        }
        if (!g_ctcLimitOn && !g_ctcTempOn && !g_ctcGameOn && !g_ctcForceOn && !g_ctcSlowOn && !g_ctcDisplayOn && !g_ctcPaused) {
            return;   // 全关：不读电池（省开销）
        }
        CTChargeInfo ci = CTChargeRead();
        g_ctcCapacity = ci.capacity;   // ★ 1.4.6f：刷新满电判定
        if (!ci.valid) return;

        // 瓦数平滑（约 5 秒窗口，防跳数）
        double wRaw = 0.0;
        if (ci.isCharging && ci.volt_mV > 0.0 && ci.amp_mA != 0.0) {
            double pw = ci.volt_mV * ci.amp_mA / 1000000.0;
            wRaw = (pw < 0) ? -pw : pw;
        }
        if (g_ctcSmN < 5) { g_ctcSmW = (g_ctcSmW * g_ctcSmN + wRaw) / (g_ctcSmN + 1); g_ctcSmN++; }
        else g_ctcSmW = g_ctcSmW * 0.6 + wRaw * 0.4;

        BOOL haveCable = ci.extConnected || ci.isCharging || ci.adapterW > 0.0;   // ★ 1.4.6z2：禁流会改写 ExternalConnected，用适配器瓦数兜底判断"插着"
        if (!haveCable) {
            if (g_ctcPaused) { CTChargeWriteInhibit(NO); g_ctcPaused = NO; }
            g_ctcLimitLatched = NO; g_ctcTempLatched = NO; g_ctcCycleAt = 0; g_ctcVerifyAt = 0;
            g_ctcResumeWait = NO; g_ctcNoFlowAt = 0.0;   // ★ 1.4.6x：拔线清"恢复中"
            if (g_ctcSimApplied != 0) { g_ctcSimApplied = 0; CTChargeSetThermalSim(0); }   // ★ 1.4.6n：拔线恢复
            g_ctcIntercepts = 0; g_ctcLastIntercept = 0; g_ctcSmW = 0; g_ctcSmN = 0;
            CTChargePublish(0, 0, ci.capacity, "none");
            return;
        }

        // ① 充电上限（2% 回差）
        BOOL wantPause = NO; const char *reason = "none";
        if (g_ctcLimitOn && g_ctcLimitVal < 100) {
            if (ci.capacity >= g_ctcLimitVal) g_ctcLimitLatched = YES;
            else if (ci.capacity <= g_ctcLimitVal - 2) g_ctcLimitLatched = NO;
            if (g_ctcLimitLatched) { wantPause = YES; reason = "limit"; }
        } else g_ctcLimitLatched = NO;

        // ② 温度保护（2°C 回差）
        if (!wantPause && g_ctcTempOn && ci.tempC > 0.0) {
            if (ci.tempC >= (double)g_ctcTempVal) g_ctcTempLatched = YES;
            else if (ci.tempC <= (double)g_ctcTempVal - 2.0) g_ctcTempLatched = NO;
            if (g_ctcTempLatched) { wantPause = YES; reason = "temp"; }
        } else if (!g_ctcTempOn) g_ctcTempLatched = NO;

        // ③ 慢速充电（10W/15W 档）→ 占空比控制器（周期 60 秒；数值待实机校准）
        BOOL dutyActive = NO; int dutyOn = 0, dutyOff = 0;
        if (!wantPause) {
            if (g_ctcSlowOn && !g_ctcForceOn && g_ctcSimLev == 0) {   // 慢速充电（占空比）；极速优先；平稳限流开启时让位
                dutyActive = YES;
                if (g_ctcGameW >= 15) { dutyOn = 35; dutyOff = 25; }   // 15W 档：充 35s / 停 25s
                else                   { dutyOn = 25; dutyOff = 35; }   // 10W 档：充 25s / 停 35s
            }
        }
        if (dutyActive) {
            if (g_ctcCycleAt <= 0.0) g_ctcCycleAt = now;
            double period = (double)(dutyOn + dutyOff);
            double el = now - g_ctcCycleAt;
            while (el >= period) { g_ctcCycleAt += period; el -= period; }
            if (el < (double)dutyOn && wRaw > 1.0) {   // ★ 1.4.6l：记录"充电相位"实测瓦（显示周期均值用）
                g_ctcDutyOnW = (g_ctcDutyOnW <= 0.5) ? wRaw : (g_ctcDutyOnW * 0.8 + wRaw * 0.2);
            }
            if (el >= (double)dutyOn) { wantPause = YES; reason = "duty"; }
        } else {
            g_ctcCycleAt = 0.0;
            g_ctcDutyOnW = 0.0;
        }

        // ③b ★ 1.4.6n：平稳限流（模拟高温）——持续降电流；每 10 秒重申（防系统重置）
        if (g_ctcSimLev > 0 && haveCable && !g_ctcForceOn) {   // ★ 1.4.6s：防停充同开时永久优先（限流让位）
            if (g_ctcSimApplied != g_ctcSimLev || (now - g_ctcSimAssertAt) > 10.0) {
                BOOL chg = (g_ctcSimApplied != g_ctcSimLev);
                g_ctcSimApplied = g_ctcSimLev; g_ctcSimAssertAt = now;
                CTChargeSetThermalSim(g_ctcSimLev);
                if (chg) {
                    CTD("[充电] 平稳限流：模拟高温=%s（持续降电流模式）",
                        (g_ctcSimLev == 1) ? "轻" : ((g_ctcSimLev == 2) ? "中" : "重"));
                    g_ctcVerifyAt = now + 4.0; g_ctcVerifyKind = 4;
                }
            }
        } else if (g_ctcSimApplied != 0) {
            g_ctcSimApplied = 0;
            CTChargeSetThermalSim(0);
            CTD("[充电] 平稳限流：已恢复（模拟高温=normal）");
        }

        // ④ 执行（只在状态变化时写属性）
        if (wantPause) {
            if (!g_ctcPaused) {
                BOOL okW0 = CTChargeWriteInhibit(YES);
                int wSvc0 = g_ctcLastWriteSvc, wErr0 = g_ctcLastWriteErr;
                BOOL okI0 = CTChargeWriteInflow(NO);   // ★ 1.4.6z2：禁流层一起按
                int iSvc0 = g_ctcLastWriteSvc, iErr0 = g_ctcLastWriteErr;
                g_ctcPaused = YES;
                g_ctcResumeWait = NO;   // ★ 1.4.6x：重新暂停 → 取消"恢复中"
                g_ctcLastHoldAssert = now; g_ctcHoldWarned = NO; g_ctcHoldOK = NO; g_ctcHoldWarnAt = now;
                CTD("[充电] 暂停充电（%s）", reason);
                if (!okW0 && !okI0) {
                    // ★ 1.4.6z4：主形态全被拒 → 立刻换形态
                    BOOL okX0 = CTChargeTryExtraStop();
                    CTD("[充电] 停充首发被拒（主[服务%d 错误%d] 禁[服务%d 错误%d]）→ 换形态%s（服务%d 错误%d）",
                        wSvc0, wErr0, iSvc0, iErr0, okX0 ? "成功" : "仍失败", g_ctcLastWriteSvc, g_ctcLastWriteErr);
                }
                g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 1;   // ★ 1.4.6m：3 秒后复核"停充是否真的切断"
            } else if (now - g_ctcLastHoldAssert >= (g_ctcHoldOK ? 5.0 : 2.0)) {
                // ★ 1.4.6z：停充在岗重申——每 5 秒重发（防系统放开）★ 1.4.6z4：未咬合时加密到 2 秒
                g_ctcLastHoldAssert = now;
                BOOL okW = CTChargeWriteInhibit(YES);
                int wSvc = g_ctcLastWriteSvc, wErr = g_ctcLastWriteErr;
                BOOL okI = CTChargeWriteInflow(NO);   // ★ 1.4.6z2：禁流层一起重申
                int iSvc = g_ctcLastWriteSvc, iErr = g_ctcLastWriteErr;
                int holdMA = (int)(ci.amp_mA < 0 ? -ci.amp_mA : ci.amp_mA);
                if (!okW && !okI) {
                    // ★ 1.4.6z4：主形态全被拒 → 换形态再试（直写式/仅PCI式）
                    BOOL okX = CTChargeTryExtraStop();
                    int xSvc = g_ctcLastWriteSvc, xErr = g_ctcLastWriteErr;
                    if (okX) {
                        CTD("[充电] 停充换形态咬住（形态%d 服务%d 电流=%d mA）", g_ctcWinVar, xSvc, holdMA);
                    } else if (now - g_ctcHoldWarnAt >= 60.0) {
                        g_ctcHoldWarnAt = now;
                        CTD("[充电] 停充未咬合重试中（主[服务%d 错误%d] 禁[服务%d 错误%d] 换形态[服务%d 错误%d] 电流=%d mA）", wSvc, wErr, iSvc, iErr, xSvc, xErr, holdMA);
                    }
                }
                BOOL bitten = (holdMA <= 150) && (okW || okI);
                if (bitten && !g_ctcHoldOK) { g_ctcHoldOK = YES; CTD("[充电] 停充已咬合（电流=%d mA 停充写%d 禁流写%d）", holdMA, (int)okW, (int)okI); }
                if (!bitten && g_ctcHoldOK) { g_ctcHoldOK = NO; CTD("[充电] 停充又松开（电流=%d mA）→ 重新按", holdMA); }
                if (!bitten && !g_ctcHoldWarned) {
                    g_ctcHoldWarned = YES; g_ctcHoldWarnAt = now;
                    CTD("[充电] 停充在岗重申：未咬合（停充[服务%d 错误%d] 禁流[服务%d 错误%d] 电流=%d mA）→ 持续重发", wSvc, wErr, iSvc, iErr, holdMA);
                }
            }
        } else {
            if (g_ctcPaused) {
                CTChargeWriteInhibit(NO);
                CTChargeWriteInflow(YES);   // ★ 1.4.6z2：恢复禁流层
                g_ctcPaused = NO;
                g_ctcResumeWait = YES;   // ★ 1.4.6x：进入"等硬件放行"（电流回来才结束）
                CTD("[充电] 恢复充电");
                g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 2;   // ★ 1.4.6m：3 秒后复核"恢复是否真的充上"
            }
        }
        // ★ 1.4.6m：动作 3 秒后自动复核实测电流（结果写日志——生效与否，日志自己给答案）
        if (g_ctcVerifyAt > 0 && now >= g_ctcVerifyAt) {
            g_ctcVerifyAt = 0;
            int ctMA = (int)(ci.amp_mA < 0 ? -ci.amp_mA : ci.amp_mA);
            if (g_ctcVerifyKind == 1)      CTD("[充电] 停充复核：实测电流=%d mA 充=%d（应≈0 = 生效）", ctMA, (int)ci.isCharging);
            else if (g_ctcVerifyKind == 2) CTD("[充电] 恢复复核：实测电流=%d mA 充=%d（应见充电流）", ctMA, (int)ci.isCharging);
            else if (g_ctcVerifyKind == 4) CTD("[充电] 限流复核：实测电流=%d mA（对比满速约 4900mA，应看到下降）", ctMA);
            else                           CTD("[充电] 拦截复核：实测电流=%d mA 充=%d（仍在充 = 拦成功）", ctMA, (int)ci.isCharging);
            if (g_ctcVerifyKind == 1 && ctMA > 150) {   // ★ 1.4.6z3：复核没咬合 → 立即补一刀（不等 5 秒节拍）
                BOOL okW1 = CTChargeWriteInhibit(YES);
                BOOL okI1 = CTChargeWriteInflow(NO);
                g_ctcLastHoldAssert = now;
                if (!okW1 && !okI1) { CTChargeTryExtraStop(); }   // ★ 1.4.6z4：补刀也带上换形态
                CTD("[充电] 停充复核未咬合 → 已立即补发（服务%d 错误%d）", g_ctcLastWriteSvc, g_ctcLastWriteErr);
            }
        }

        // ⑤ 防停充：兜底救援（插着但没在充、又不是我们停的 → 限频 15 秒试恢复）
        if ((g_ctcForceOn || g_ctcResumeWait) && haveCable && !ci.isCharging && !g_ctcPaused && ci.capacity < 99) {   // ★ 1.4.6f：满电（≥99%）不救援
            if (now - g_ctcLastRescue >= 15.0) {   // ★ 1.4.6s：救援提速 30→15 秒
                g_ctcLastRescue = now;
                CTChargeWriteInhibit(NO);
                CTChargeWriteInflow(YES);   // ★ 1.4.6z2：顺手恢复禁流层
                CTD("[充电] %s：检测到停充 → 已尝试恢复", g_ctcForceOn ? "防停充" : "恢复中");
            }
        }
        // ⑤b ★ 1.4.6t：防停充强化——每 5 秒重申"名义热态"（骗过系统的热逻辑，不让它来停充/降流）
        if (g_ctcForceOn && haveCable && ci.capacity < 99 && !g_ctcPaused) {
            if (now - g_ctcLastNominal >= 5.0) {
                g_ctcLastNominal = now;
                dispatch_async(dispatch_get_main_queue(), ^{ CPUthermalForceNominalCombined(); });
                static int sCTFNLog = 0;
                if (sCTFNLog < 3) { sCTFNLog++; CTD("[充电] 防停充·名义重申：已告诉系统“不热”（持续骗过高温逻辑）"); }
            }
        }

        // ★ 1.4.6x：恢复中——指令已请求充上、硬件还没放行（插着电、没电流、且不是我们按的暂停）
        BOOL ctNoFlow = (haveCable && !g_ctcPaused && !ci.isCharging && ci.capacity < 99);
        if (ctNoFlow) { if (g_ctcNoFlowAt <= 0.0) g_ctcNoFlowAt = now; } else g_ctcNoFlowAt = 0.0;
        if (g_ctcResumeWait && ci.isCharging) g_ctcResumeWait = NO;   // 电流回来 → 等待结束
        BOOL ctResuming = (ctNoFlow && g_ctcNoFlowAt > 0.0 && (now - g_ctcNoFlowAt) >= 5.0 && (g_ctcResumeWait || g_ctcForceOn));

        // ⑥ 发布显示状态（1绿=正常 2黄=限速(已退役/保留编号) 3红=防停充在岗 4黑=暂停 5橙=恢复中）
        int st;
        if (wantPause && dutyActive) st = 2;
        else if (wantPause) st = 4;
        else if (ctResuming) st = 5;   // ★ 1.4.6x：恢复中（等硬件放行；热天更久）
        else if (g_ctcForceOn && ((g_ctcLastIntercept > 0 && now - g_ctcLastIntercept < 300.0) || ci.tempC >= 20.0)) st = 3;   // ★ 1.4.6v：红灯门槛 40→20°C（开着防停充≈常亮=在岗指示）
        else if (dutyActive) st = 2;
        else st = 1;
        // ★ 1.4.6x：恢复中 进/出各留一行日志（自查用）
        { static BOOL sCTResumeSt = NO;
          if (st == 5 && !sCTResumeSt) { sCTResumeSt = YES; CTD("[充电] 恢复中：指令已发，等硬件放行（热天更久；急可拔插充电线）"); }
          else if (st != 5 && sCTResumeSt) { sCTResumeSt = NO; CTD(ci.isCharging ? "[充电] 恢复中结束：电流已恢复" : "[充电] 恢复中结束"); } }
        // ★ 1.4.6l：限速（占空比）时显示"周期平均瓦数"（≈所选 10W/15W 档），不再显示相位瞬时值
        double wPub = g_ctcSmW;
        if (dutyActive && (dutyOn + dutyOff) > 0 && g_ctcDutyOnW > 0.5) {
            wPub = g_ctcDutyOnW * ((double)dutyOn / (double)(dutyOn + dutyOff));
        }
        CTChargePublish(st, (st == 4) ? 0.0 : wPub, ci.capacity, reason);
    }
}

// ★ 1.4.6 防停充：识别"系统想停充"的属性写入（只拦"停"方向，不拦"充"方向）
static BOOL keyIsChargeControlKey(NSString *key) {
    if (!key) return NO;
    NSString *lower = [key lowercaseString];
    return [lower isEqualToString:CTObfStr("332939323b283d33343d")] || [lower isEqualToString:CTObfStr("2a283f3e33392e332c3f39323b283d33343d3334323338332e")];
}
static BOOL valueMeansStopChargingCF(NSString *key, CFTypeRef value) {
    id v = (__bridge id)value;
    if (![v respondsToSelector:@selector(boolValue)]) return NO;
    BOOL b = [v boolValue];
    NSString *lower = [key lowercaseString];
    if ([lower isEqualToString:CTObfStr("332939323b283d33343d")]) return !b;   // IsCharging=0 → 停
    return b;                                                  // Inhibit=1 → 停
}
static void CTChargeNoteIntercept(NSString *key) {
    g_ctcIntercepts++;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    g_ctcLastIntercept = now;
    g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 3;   // ★ 1.4.6m：拦截后复核"是否仍在充"
    if (g_ctcIntercepts <= 3 || (now - g_ctcLastForceLog) > 60.0) {
        g_ctcLastForceLog = now;
        CTD("[充电] 防停充：拦截系统停充 key=%s", [key UTF8String]);
    }
}

static void CTDiagFreqLog(void) {
    double mhz = 0.0;
    double bt = CTBatteryTempC();
    char bts[24];
    if (bt > 0.0) snprintf(bts, sizeof(bts), "%.1f", bt); else snprintf(bts, sizeof(bts), "--");
    if (CTFreqReadMHz(&mhz)) {
        CTD("[频率跟踪] 实测大核=%.0f MHz 模式=%s 提速=%d 深度=%d 视频=%d 电池=%s°C 热压=%d 前台=%llu",
            mhz, CTModeName(g_powerMode), (int)g_scrollBoostActive, (int)g_ctDeepIdleActive, (int)g_ctVideoActive,
            bts, CTThermalPressureLevel(),
            (unsigned long long)CPUthermalReadForegroundBundleHash());
    } else {
        CTD("[频率跟踪] 读取失败 err=%ld 模式=%s 提速=%d 深度=%d 视频=%d 电池=%s°C 热压=%d",
            (long)g_ctFreqErrCode, CTModeName(g_powerMode), (int)g_scrollBoostActive, (int)g_ctDeepIdleActive, (int)g_ctVideoActive,
            bts, CTThermalPressureLevel());
    }
}

static void freqWatchdogTick(void) {
if (!runtimeProtectionEnabled() || !isLowPowerMode()) { g_wdHighTicks = 0; return; }
if (g_softSwingActive) return;
if (CPUthermalScreenIsBlanked()) { g_wdHighTicks = 0; return; }
if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 12.0) return;
double mhz = 0.0;
if (!CTFreqReadMHz(&mhz) || mhz <= 0.0) return;
if (mhz >= 2560.0) {
    g_wdHighTicks++;
    if (g_wdHighTicks >= 3) {
        CFAbsoluteTime nowW = CFAbsoluteTimeGetCurrent();
        if ((nowW - g_wdLastSwing) >= 40.0) {
            g_wdLastSwing = nowW;
            g_wdHighTicks = 0;
            CTD("[看门狗] 实测=%.0f MHz 连续超标 → 触发自愈摆动", mhz);
            runSoftModeSwing("watchdog");
        }
    }
} else {
    g_wdHighTicks = 0;
}
}

// 前台应用兜底轮询：SpringBoard 只在哈希变化时上报，通知一旦丢失（进程重启、
// 通知被覆盖、唤醒强制恢复用户模式等）指定应用低功耗就无法自愈。此处每 3 秒
// 重新核对一次前台应用，保证状态最终一致。
// ★ 模式保持循环（每秒一次）：
//   - 生效模式 = 低功耗 → 每秒重压低功耗限制（对抗系统/充电抬预算、覆盖）
//   - 生效模式 = 高性能   → 每 5 秒重申高性能（清掉可能残留的低功耗限制）
//   - 全部只做"重压"，绝不触发任何"重载/重建"（血的教训）
// ★ T7z5：前台"读空"轨迹（全文件共享）——旧实现把"上次看到真实 App"记在 resolve 内部、
//   只有 resolve 被调用时才刷新 → 长时间没调用后吸收失效，"切 App/多任务瞬间读空"
//   被误判成"回桌面"交还系统（实测短暂放开 0.2~5 秒，用户感觉"失效一下、切回去又生效"）。
//   现在由每秒心跳持续保鲜 + 吸收窗口 2→5 秒。
static uint64_t g_ctBlipHash = 0;
static CFAbsoluteTime g_ctBlipAt = 0;

// ★ 1.4.4：前台 App"正在享受高性能"时 = 与性能模式同级的防降频保护（极端发热也不降频）。
//   覆盖三种来源：① 智能模式下识别为游戏；② 任意模式下该 App 档位 = 高性能（含低功耗模式下的"指定 App"）；
//   ③ 智能下的"指定 App 高性能率"名单。其它情况一律不介入（低功耗等模式的原有行为不变）。
static BOOL shouldApplyAppFullProtection(void) {
    uint64_t fg = CPUthermalReadForegroundBundleHash();
    if (fg == 0) fg = g_ctBlipHash;                 // 抖动吸收：沿用上一个真实 App
    if (fg == 0) return NO;
    // ① 智能模式 + 游戏（由「游戏强制高性能」开关控制）
    if (g_gameForceFull && g_smartEnabled && g_smartGameHashes && [g_smartGameHashes containsObject:@(fg)]) return YES;
    // ② App 档位 = 高性能（对三种常驻模式都生效；低功耗下的"指定 App"即走这里）
    if (CPUthermalTierForHash(fg) == 1) return YES;
    // ③ 智能下的"指定 App 高性能率"名单
    if (g_smartFullListHashes && [g_smartFullListHashes containsObject:@(fg)]) return YES;
    return NO;
}
static void CTBlipTrackForeground(void) {
    uint64_t fg = CPUthermalReadForegroundBundleHash();
    if (fg != 0 && fg != CPUthermalBundleIDHash(S("com.apple.springboard"))) {
        g_ctBlipHash = fg;
        g_ctBlipAt = CFAbsoluteTimeGetCurrent();
    }
}

// ★ T7z5：注销/重启后"落地保证"——启动后首次进入低功耗：+2.5 秒实测一把，
//   已压住 → 不做任何事；读不到频率或没压住 → 自动完整摆动落地
//   （等价于"手动切到高性能再切回低功耗"，替用户自动完成）。
static BOOL g_ctBootLandingArmed = NO;
static BOOL g_ctBootLandingHandled = NO;
static CFAbsoluteTime g_ctBootStamp = 0;

// ============================================================================
// ★ T7z16 新服务 A：状态文件（供 SpringBoard 状态浮窗读取）+ 一键自检（30 秒采样）
// ============================================================================
static const char *kCTStatusFilePathC  = "/var/mobile/Library/Logs/CPUthermalStatus.txt";
static const char *kCTSelfTestReqPathC = "/var/mobile/Library/Logs/CPUthermalSelfTest.req";
static const char *kCTSelfTestResPathC = "/var/mobile/Library/Logs/CPUthermalSelfTest.txt";
static BOOL g_floatWindowEnabled = NO;   // 设置里的「悬浮窗」开关（loadPrefs 刷新）

// ---------- 状态文件：每秒写一行键值（freq/mode/deep/boost/video） ----------
static void CTStatusFileTick(void) {
    if (!g_floatWindowEnabled) return;
    double mhz = 0.0;
    BOOL ok = CTFreqReadMHz(&mhz);
    const char *mname = CTModeName(g_powerMode);
    char buf[288];
    snprintf(buf, sizeof(buf), "freq=%.0f mode=%s deep=%d boost=%d video=%d chg=%d pw=%d cap=%d cr=%s",
             (ok && mhz > 0.0) ? mhz : 0.0, mname,
             g_ctDeepIdleActive ? 1 : 0, g_scrollBoostActive ? 1 : 0, g_ctVideoActive ? 1 : 0,
             g_ctcPubState, g_ctcPubW, g_ctcPubCap, g_ctcPubReason);
    // ★ 1.0.5：原子写——先写临时文件，再 rename 覆盖（读取方永远只会看到完整内容，读不到"清空的瞬间"）
    char tmpPath[256];
    snprintf(tmpPath, sizeof(tmpPath), "%s.tmp", kCTStatusFilePathC);
    FILE *f = fopen(tmpPath, "w");
    if (f) {
        fputs(buf, f);
        fclose(f);
        rename(tmpPath, kCTStatusFilePathC);
    }
}

// ---------- 一键自检：请求文件触发 → 30 秒采样 → 出报告 ----------
static int  g_stState = 0;              // 0=空闲 1=采样中
static int  g_stTicks = 0;
static CPUthermalPowerMode g_stMode0 = CPUthermalPowerModeLow;
static double g_stFreqs[40]; static int g_stFreqN = 0;
static int  g_stFreqFail = 0;
static int  g_stHighCount = 0;
static int  g_stDeepEntries = 0; static BOOL g_stDeepWas = NO;
static int  g_stBoostTicks = 0, g_stVideoTicks = 0, g_stBlankTicks = 0;
static int  g_stModeChanges = 0; static int g_stLastMode = -1;
static double g_stTemp0 = -2.0, g_stTempEnd = -2.0, g_stTempMax = -2.0;
static int  g_stPressMax = 0;

static void CTSelfTestWriteReport(void) {
    double v[40]; int n = g_stFreqN;
    for (int i = 0; i < n; i++) v[i] = g_stFreqs[i];
    for (int i = 1; i < n; i++) { double x = v[i]; int j = i - 1; while (j >= 0 && v[j] > x) { v[j + 1] = v[j]; j--; } v[j + 1] = x; }
    double mn = (n > 0) ? v[0] : -1.0, med = (n > 0) ? v[n / 2] : -1.0, mx = (n > 0) ? v[n - 1] : -1.0;
    char verdict[160];
    if (g_stMode0 == CPUthermalPowerModeLow) {
        if (n == 0)
            snprintf(verdict, sizeof(verdict), "◐ 没读到有效频率（失败 %d 次）——建议重测一次", g_stFreqFail);
        else if (mx <= 2200.0 && g_stHighCount == 0)
            snprintf(verdict, sizeof(verdict), "✅ 压制正常：峰值 %.0fMHz ≤ 2200，未发现漏压", mx);
        else
            snprintf(verdict, sizeof(verdict), "⚠ 发现 %d 个 >2200MHz 样本（峰值 %.0f）——可能没压住，建议复测", g_stHighCount, mx);
    } else {
        snprintf(verdict, sizeof(verdict), "放开/原生模式：中位 %.0fMHz（属于正常放开，无需压制）", med);
    }
    time_t tt = time(NULL); struct tm tmv; localtime_r(&tt, &tmv);
    char ts[40]; strftime(ts, sizeof(ts), "%m-%d %H:%M:%S", &tmv);
    FILE *f = fopen(kCTSelfTestResPathC, "w");
    if (!f) return;
    fprintf(f, "CPUthermal 一键自检报告\n");
    fprintf(f, "时间: %s ｜ 构建: %s%s\n", ts, kCTBuildTag, CTFpSuffix());
    fprintf(f, "采样: 30 秒 ｜ 起始模式: %s\n", CTModeName(g_stMode0));
    fprintf(f, "--------------------------------\n");
    fprintf(f, "频率: 最小 %.0f ／ 中位 %.0f ／ 最大 %.0f MHz（有效样本 %d，失败 %d）\n", mn, med, mx, n, g_stFreqFail);
    fprintf(f, "高频样本(>2200MHz): %d 个\n", g_stHighCount);
    fprintf(f, "深度档: 进入 %d 次 ｜ 提速占用 %d 秒 ｜ 视频档 %d 秒\n", g_stDeepEntries, g_stBoostTicks, g_stVideoTicks);
    fprintf(f, "熄屏: %d 秒 ｜ 模式变化: %d 次\n", g_stBlankTicks, g_stModeChanges);
    if (g_stTemp0 > -1.5)
        fprintf(f, "温度: %.1f°C → %.1f°C（最高 %.1f）｜ 热压峰值: %d\n", g_stTemp0, g_stTempEnd, g_stTempMax, g_stPressMax);
    else
        fprintf(f, "温度: 读不到（不影响结论）｜ 热压峰值: %d\n", g_stPressMax);
    fprintf(f, "--------------------------------\n");
    fprintf(f, "结论: %s\n", verdict);
    fclose(f);
    CTD("[自检] 完成 → %s", verdict);
}

static void CTSelfTestTick(void) {
    if (g_stState == 0) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:S(kCTSelfTestReqPathC)]) {
            [[NSFileManager defaultManager] removeItemAtPath:S(kCTSelfTestReqPathC) error:NULL];
            g_stState = 1; g_stTicks = 0; g_stFreqN = 0; g_stFreqFail = 0; g_stHighCount = 0;
            g_stDeepEntries = 0; g_stDeepWas = NO; g_stBoostTicks = 0; g_stVideoTicks = 0;
            g_stBlankTicks = 0; g_stModeChanges = 0; g_stLastMode = -1;
            g_stTemp0 = CTBatteryTempC();
            g_stTempEnd = g_stTemp0; g_stTempMax = g_stTemp0;
            g_stPressMax = CTThermalPressureLevel();
            g_stMode0 = g_powerMode;
            CTD("[自检] 开始 30 秒采样（起始模式=%s）", CTModeName(g_stMode0));
        }
        return;
    }
    if (g_stLastMode >= 0 && g_stLastMode != (int)g_powerMode) g_stModeChanges++;
    g_stLastMode = (int)g_powerMode;
    double mhz = 0.0;
    if (CTFreqReadMHz(&mhz) && mhz > 0.0) {
        if (g_stFreqN < 40) g_stFreqs[g_stFreqN++] = mhz;
        if (mhz > 2200.0) g_stHighCount++;
    } else {
        g_stFreqFail++;
    }
    if (g_ctDeepIdleActive) { if (!g_stDeepWas) { g_stDeepEntries++; g_stDeepWas = YES; } } else { g_stDeepWas = NO; }
    if (g_scrollBoostActive) g_stBoostTicks++;
    if (g_ctVideoActive) g_stVideoTicks++;
    if (CPUthermalScreenIsBlanked()) g_stBlankTicks++;
    double bt = CTBatteryTempC();
    if (bt > -1.5) { g_stTempEnd = bt; if (bt > g_stTempMax) g_stTempMax = bt; }
    int pr = CTThermalPressureLevel();
    if (pr > g_stPressMax) g_stPressMax = pr;
    g_stTicks++;
    if (g_stTicks >= 30) {
        CTSelfTestWriteReport();
        g_stState = 0;
    }
}


// ============================================================================
// ★ T7z16 新服务 B：定时切档（按周几+时段，临时覆盖"用户选择的模式"，结束自动恢复）
//   · 配置键：scheduleEnabled / seg1..2On / seg1..2Day0..6 / seg1..2Start / seg1..2End / seg1..2Mode
//   · 时段跨午夜自动处理；两段同时命中时"段一"优先；进/出时段各写一行日志
// ============================================================================
static BOOL g_schedEnabled = NO;
static BOOL g_schedSegOn[2] = {NO, NO};
static int  g_schedSegDays[2] = {0, 0};    // bit0=周一 … bit6=周日
static int  g_schedSegStart[2] = {0, 0};   // 分钟数（0~1439）
static int  g_schedSegEnd[2] = {0, 0};
static int  g_schedSegMode[2] = {0, 0};    // 0=低功耗 1=性能模式 2=智能
static int  g_schedActiveMode = -1;        // -1=未生效；0/1/2=当前时段目标
static void CPUthermalSyncModeFromPrefs(void);   // 稍后定义（前置声明）

static NSString *CTScheduleModeName(int m) {
    if (m == 0) return S("lowPower");
    if (m == 2) return S("smart");
    return S("fullPower");
}

static void CTScheduleLoadFromPrefs(NSDictionary *d) {
    g_schedEnabled = [d[S("scheduleEnabled")] ?: @NO boolValue];
    for (int i = 0; i < 2; i++) {
        NSString *base = (i == 0) ? S("seg1") : S("seg2");
        g_schedSegOn[i] = [d[[base stringByAppendingString:S("On")]] ?: @NO boolValue];
        int days = 0;
        for (int b = 0; b < 7; b++) {
            NSString *k = [base stringByAppendingFormat:S("Day%d"), b];
            if ([d[k] ?: @NO boolValue]) days |= (1 << b);
        }
        g_schedSegDays[i] = days;
        g_schedSegStart[i] = [d[[base stringByAppendingString:S("Start")]] ?: @0 intValue];
        g_schedSegEnd[i] = [d[[base stringByAppendingString:S("End")]] ?: @0 intValue];
        NSString *mstr = d[[base stringByAppendingString:S("Mode")]];
        int mm = 0;
        if ([mstr isKindOfClass:[NSString class]]) {
            if ([mstr isEqualToString:S("smart")]) mm = 2;
            else if ([mstr isEqualToString:S("fullPower")]) mm = 1;
        }
        g_schedSegMode[i] = mm;
    }
    if (g_schedEnabled)
        CTD("[定时] 配置：段1(开=%d 天%02X %02d:%02d-%02d:%02d→%s) 段2(开=%d 天%02X %02d:%02d-%02d:%02d→%s)",
            (int)g_schedSegOn[0], g_schedSegDays[0], g_schedSegStart[0] / 60, g_schedSegStart[0] % 60, g_schedSegEnd[0] / 60, g_schedSegEnd[0] % 60, CTScheduleModeName(g_schedSegMode[0]).UTF8String,
            (int)g_schedSegOn[1], g_schedSegDays[1], g_schedSegStart[1] / 60, g_schedSegStart[1] % 60, g_schedSegEnd[1] / 60, g_schedSegEnd[1] % 60, CTScheduleModeName(g_schedSegMode[1]).UTF8String);
}

static void CTScheduleTick(void) {
    if (!g_schedEnabled) {
        if (g_schedActiveMode >= 0) {
            g_schedActiveMode = -1;
            CTD("[定时] 定时已关闭 → 恢复你选择的模式");
            CPUthermalSyncModeFromPrefs();
        }
        return;
    }
    time_t tt = time(NULL); struct tm tmv; localtime_r(&tt, &tmv);
    int mon0 = (tmv.tm_wday + 6) % 7;         // 0=周一 … 6=周日
    int mins = tmv.tm_hour * 60 + tmv.tm_min;
    int desired = -1;
    for (int i = 0; i < 2; i++) {
        if (!g_schedSegOn[i]) continue;
        int s = g_schedSegStart[i], e = g_schedSegEnd[i];
        if (s == e) continue;
        BOOL hit = NO;
        if (s < e) {
            if ((g_schedSegDays[i] >> mon0) & 1) hit = (mins >= s && mins < e);
        } else {
            if (mins >= s) hit = ((g_schedSegDays[i] >> mon0) & 1) != 0;              // 晚段按"今天"
            else if (mins < e) hit = ((g_schedSegDays[i] >> ((mon0 + 6) % 7)) & 1) != 0;   // 早段按"昨天"
        }
        if (hit) { desired = g_schedSegMode[i]; break; }
    }
    if (desired != g_schedActiveMode) {
        g_schedActiveMode = desired;
        if (desired >= 0) CTD("[定时] 进入时段 → 切到 %s（%02d:%02d）", CTScheduleModeName(desired).UTF8String, tmv.tm_hour, tmv.tm_min);
        else CTD("[定时] 时段结束 → 恢复你选择的模式（%02d:%02d）", tmv.tm_hour, tmv.tm_min);
        CPUthermalSyncModeFromPrefs();
    }
}

// ---------- ★ 1.4.6 身份完整性校验（③④：分散校验点之一；每 60 秒 + 启动各一次） ----------
//   · ① 设置包侧校验失败时会写入 __integrityTampered 旗标；这里读到即停用全部功能
//   · ② 跨组件指纹核对：自己的构建指纹 vs 设置包 Info.plist 里的 CTSourceFP（不一致 = 混装/被换）
//   · 读不到（未注入指纹 / 文件不存在）→ 跳过（不影响功能，防误伤）
static NSString *CTFindSettingsInfoPlist(void) {
    NSMutableArray *cands = [NSMutableArray array];
    [cands addObject:S("/var/jb/Library/PreferenceBundles/CPUthermalSettings.bundle/Info.plist")];
    const char *jb = jbroot("/Library/PreferenceBundles/CPUthermalSettings.bundle/Info.plist");
    if (jb) [cands addObject:[NSString stringWithUTF8String:jb]];
    [cands addObject:S("/Library/PreferenceBundles/CPUthermalSettings.bundle/Info.plist")];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *cand in cands) {
        if (cand.length && [fm fileExistsAtPath:cand]) return cand;
    }
    return nil;
}
static void CTIdentityCheck(void) {
    static int sCtIdTick = 0;
    if (g_ctProcStart <= 0) g_ctProcStart = CFAbsoluteTimeGetCurrent();
    if ((++sCtIdTick % 60) != 1) return;
    BOOL intact = YES;
    NSString *ctWhy = nil;
    @try {
        NSDictionary *d = readPrefsDictionary();
        id flag = [d isKindOfClass:[NSDictionary class]] ? d[S("__integrityTampered")] : nil;
        if ([flag isKindOfClass:[NSNumber class]] && [flag boolValue]) { intact = NO; ctWhy = S("篡改旗标"); }
        if (intact && CT_SOURCE_FP[0]) {
            NSString *path = CTFindSettingsInfoPlist();
            if (path) {
                // ★ 1.4.6g：设置包晚于本进程启动才更新（=刚装包、还没重启用户空间）→ 暂缓指纹核对，防误伤
                NSDate *mtime = [[[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil] objectForKey:NSFileModificationDate];
                if (mtime && [mtime timeIntervalSince1970] > g_ctProcStart + 3.0) {
                    static BOOL sSkippedOnce = NO;
                    if (!sSkippedOnce) { sSkippedOnce = YES; CTD("[管理] 设置包更新晚于本次启动（可能刚安装未重启）→ 指纹核对暂缓，重启用户空间后恢复"); }
                } else {
                    NSDictionary *pl = [NSDictionary dictionaryWithContentsOfFile:path];
                    id fp = [pl isKindOfClass:[NSDictionary class]] ? pl[S("CTSourceFP")] : nil;
                    if ([fp isKindOfClass:[NSString class]] && [fp length] > 0 && ![fp isEqualToString:S(CT_SOURCE_FP)]) { intact = NO; ctWhy = S("指纹不一致"); }
                }
            }
        }
    } @catch (__unused NSException *e) {}
    static int sLastIntact = -1;
    if ((int)intact != sLastIntact) {
        sLastIntact = (int)intact;
        if (!intact) CTD("[管理] 身份校验未通过（%s）→ 全部功能静默停用（文件回正/重装官方后自动恢复）", ctWhy ? ctWhy.UTF8String : "未知");
        else CTD("[管理] 身份校验通过 → 功能恢复正常");
    }
    g_ctIdentityIntact = intact;   // 允许恢复：文件回正/旗标清除后自动复活
}

// ★ 1.4.6s：过热自动保护（对齐作者引擎）——热压≥2 / 电池≥44°C → 临时切低功耗帮降温；恢复（约 5 秒）→ 切回你的模式
static void CTEngineApplyEffective(const char *why) {
    CPUthermalPowerMode target = g_overheatActive ? CPUthermalPowerModeLow : CPUthermalResolveTargetMode(g_userSelectedPowerMode, CPUthermalScreenIsBlanked(), g_foregroundAppForcesLowPower);
    os_unfair_lock_lock(&g_modeLock);
    BOOL chg = (g_powerMode != target);
    g_powerMode = target;
    os_unfair_lock_unlock(&g_modeLock);
    if (chg) {
        applyPowerModeToRuntime(NO);
        CTD("[过热保护] 模式 → %s（%s）", (target == CPUthermalPowerModeLow) ? "低功耗" : "你的模式", why ? why : "");
    }
}
static void CTEngineOverheatCheck(void) {
    if (!g_overheatAutoProtect) {
        if (g_overheatActive) { g_overheatActive = NO; g_overheatNormalSince = 0; CTEngineApplyEffective("engine-off"); }
        return;
    }
    int ctPress = CTThermalPressureLevel();
    double ctTemp = CTBatteryTempC();
    BOOL hot = (ctPress >= 2) || (ctTemp >= 44.0);
    CFAbsoluteTime nowO = CFAbsoluteTimeGetCurrent();
    if (hot) {
        g_overheatNormalSince = 0;
        if (!g_overheatActive) {
            g_overheatActive = YES;
            CTD("[过热保护] 热压=%d 电池=%.1f°C → 临时切低功耗帮降温", ctPress, ctTemp);
            CTEngineApplyEffective("overheat");
        }
    } else if (g_overheatActive) {
        if (g_overheatNormalSince <= 0) g_overheatNormalSince = nowO;
        double hold = g_nominalAutoRecover ? 5.0 : 0.0;
        if (nowO - g_overheatNormalSince >= hold) {
            g_overheatActive = NO;
            g_overheatNormalSince = 0;
            CTD("[过热保护] 温度恢复（电池=%.1f°C）→ 切回你的模式", ctTemp);
            CTEngineApplyEffective("recovered");
        }
    }
}

static void startModeAssertTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        CTIdentityCheck();                     // ★ 1.4.6：身份校验先跑（被停用后仍持续核对 → 修复后可自动复活）
        g_ctMainBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6g：主队列心跳
        if (!runtimeProtectionEnabled()) return;
        g_ctMainPhase = 1;
        static int ctAssertTicks = 0;
        ctAssertTicks++;
        // ★ 启动标记（只写一次）
        static BOOL ctTagged = NO;
        if (!ctTagged) { ctTagged = YES; CTD("======== CPUthermal %s%s ========", kCTBuildTag, CTFpSuffix()); }
        // ★ 每秒持续记录"当前生效模式"（只在屏幕亮着时）——
        //   唤醒时直接沿用它，不再依赖熄屏通知（实测该通知可能不触发）。
        if (!CPUthermalScreenIsBlanked()) {
            // ★ 只记录"已稳定 3 秒以上"的模式：防止被两次心跳之间的瞬时误判污染
            static CPUthermalPowerMode sSeenMode = CPUthermalPowerModeFull;
            static int sSeenStableTicks = 0;
            os_unfair_lock_lock(&g_modeLock);
            CPUthermalPowerMode ctCurMode = g_powerMode;
            os_unfair_lock_unlock(&g_modeLock);
            // ★ T6 诊断：模式变化追踪（任何来源改模式，≤1 秒内必被记录）
            static int sLastModeSeen = -1;
            if ((int)ctCurMode != sLastModeSeen) {
                CTD("[模式] 变化：%s → %s", (sLastModeSeen < 0) ? "?" : CTModeName((CPUthermalPowerMode)sLastModeSeen),
                    CTModeName(ctCurMode));
                sLastModeSeen = (int)ctCurMode;
            }
            if (ctCurMode != sSeenMode) { sSeenMode = ctCurMode; sSeenStableTicks = 0; }
            else if (sSeenStableTicks < 100) { sSeenStableTicks++; }
            if (!g_softSwingActive && sSeenStableTicks >= 3) {
                static int sCtRecLast = -1;
                if ((int)ctCurMode != sCtRecLast) {
                    sCtRecLast = (int)ctCurMode;
                    CTD("[写睡前] tracker(稳定3秒): → %s", CTModeName(ctCurMode));
                }
                os_unfair_lock_lock(&g_modeLock);
                g_modeBeforeSleep = ctCurMode;
                os_unfair_lock_unlock(&g_modeLock);
            }
        }
        if (isLowPowerMode()) {
            g_ctMainPhase = 2;
            if (!g_scrollBoostActive) {
                applyLowPowerToCommonProduct();
                applyLowPowerLimitsToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
                g_ctApplyCount++;
            } else if (CFAbsoluteTimeGetCurrent() > g_scrollBoostUntil + 2.0) {
                // ★ T7x2 保险丝：提速状态异常滞留（>2.6 秒无新信号却没正常收尾）→ 强制解除，低功耗压制立即恢复
                g_scrollBoostActive = NO;
                applyLowPowerToCommonProduct();
                applyLowPowerLimitsToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
                g_ctApplyCount++;
                CTD("[滑动] 提速状态滞留 → 已强制解除（保险丝）");
            }
            CTDObjects("每秒心跳");
        } else {
            g_ctMainPhase = 3;
            if ((ctAssertTicks % 5) == 0) {
                applyFullPowerToCommonProduct();
                restoreFullPowerToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
            }
            CTD("[心跳] 非低功耗分支运行中（模式=%s）", isNativeMode() ? "原生" : "高性能");
        }
        g_ctMainPhase = 4;
        if ((ctAssertTicks % 2) == 0) freqWatchdogTick();   // ★ 频率看门狗（每 2 秒，只读检测）
        // ★ 1.4.6g：充电引擎已迁到独立队列（startChargeEngineTimer）——主队列卡死不再连累充电
        CTIdentityCheck();                                  // ★ 1.4.6 身份完整性抽查（每 60 秒）
        g_ctMainPhase = 5;
        if ((ctAssertTicks % 2) == 1) CTDiagFreqLog();      // ★ T7z4 诊断：频率跟踪（每 2 秒，只写日志）
        g_ctMainPhase = 6;
        // ★ 1.4.4：防降频每秒兜底重申——不依赖系统任何回调；含"智能模式 + 游戏前台"
        if (shouldApplyFullCPUProtection()) {
            CPUthermalForceNominalCombined();
            static int sCTFreedomLogTick = 0;
            if ((++sCTFreedomLogTick % 5) == 0) {
                CTD("[防降频] 名义已重申（高性能=%d 保护=%d）", isFullPowerMode() ? 1 : 0,
                    (!isFullPowerMode() && shouldApplyAppFullProtection()) ? 1 : 0);
            }
        }
        // ★ 1.4.6s：性能模式强化（对齐"极限高性能"）——每 2 秒重申满功率预算与 PPM 等级
        if ((ctAssertTicks % 2) == 0 && isFullPowerMode() && !g_overheatActive) {
            applyCurrentModeToApplePPMCPU();
            restoreFullPowerToTrackedControllers();
        }
        // ★ 1.4.6s：过热自动保护检查（每 2 秒）
        if (ctAssertTicks % 2) CTEngineOverheatCheck();
        g_ctMainPhase = 7;
        CTBlipTrackForeground();                            // ★ T7z5：每秒保鲜"最近真实App"轨迹（读空防抖）
        g_ctMainPhase = 8;
        // ★ T7z5：落地保证（一次性）——注销/重启后首次进入低功耗时验证并自动落地
        if (g_ctBootStamp <= 0) g_ctBootStamp = CFAbsoluteTimeGetCurrent();
        if (!g_ctBootLandingHandled && !g_ctBootLandingArmed) {
            if (isLowPowerMode()) {
                g_ctBootLandingArmed = YES;
                CTD("[落地] 启动后首次进入低功耗 → 2.5 秒后验证是否压住");
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    g_ctBootLandingHandled = YES;
                    g_ctBootLandingArmed = NO;
                    if (!isLowPowerMode()) { CTD("[落地] 验证时已离开低功耗 → 跳过"); return; }
                    double m = 0.0;
                    BOOL ok = CTFreqReadMHz(&m);
                    if (ok && m > 0.0 && m < 2560.0) {
                        CTD("[落地] 实测 %.0f MHz 已压住 → 无需摆动", m);
                    } else {
                        CTD("[落地] 未压住（实测=%.0f 读取=%d）→ 完整摆动落地", m, (int)ok);
                        runSoftModeSwing("boot-landing");
                    }
                });
            } else if (g_ctBootStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctBootStamp) > 1800.0) {
                g_ctBootLandingHandled = YES;   // 30 分钟内没进过低功耗 → 不再跟踪
            }
        }
        // ★ T7z5：高性能落地保证（一次性）——启动后首次进入高性能
        if (!g_ctFullLandingHandled && !g_ctFullLandingArmed) {
            if (isFullPowerMode()) {
                g_ctFullLandingArmed = YES;
                CTD("[落地] 启动后首次进入高性能 → 2 秒后自动落地");
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    g_ctFullLandingHandled = YES;
                    g_ctFullLandingArmed = NO;
                    runFullModeLanding("boot-full");
                });
            } else if (g_ctBootStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctBootStamp) > 1800.0) {
                g_ctFullLandingHandled = YES;   // 30 分钟内没进过高性能 → 不再跟踪
            }
        }
        g_ctMainPhase = 9;
        // ★ T7z6/T7z8：无操作深度降频——低频率态 + 停手 ≥2 秒 → 换更深参数重压；有操作/换场景立即恢复
        if (g_ctLastActivityAt <= 0) g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();   // 启动初始化
        if (!g_ctIdleSinkEnabled) {
            if (g_ctDeepIdleActive) { g_ctDeepIdleActive = NO; applyPowerModeToRuntime(NO); CTD("[深度] 开关关闭 → 恢复常规低频率"); }
        } else if (g_ctDeepIdleActive && (!isLowPowerMode() || CPUthermalScreenIsBlanked() || g_scrollBoostActive || (g_ctVideoActive && !g_ctVideoDeepEnabled))) {
            g_ctDeepIdleActive = NO;   // 场景已变：下次压回按常规参数
            CTD("[深度] 退出（模式/提速/视频变化）");
        } else if (!g_ctDeepIdleActive && isLowPowerMode() && !CPUthermalScreenIsBlanked() && !g_scrollBoostActive && !g_softSwingActive && !g_ctFullLandingRunning && (!g_ctVideoActive || g_ctVideoDeepEnabled) && (CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt) >= 2.0) {
            g_ctDeepIdleActive = YES;
            applyPowerModeToRuntime(NO);
            CTD("[深度] 无操作 %.1f 秒 → 深度降频（Level %d / %d mW）",
                CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt, CTLowPowerLevel(), CTLowPowerBudgetMW());
        }
        g_ctMainPhase = 10;
        // ★ T7z6：视频档自查——绑定 App 不再在前台 → 结束；开关关闭 → 结束
        if (g_ctVideoActive && g_ctVideoActiveHash != 0) {
            uint64_t ctFgNow6 = CPUthermalReadForegroundBundleHash();
            if (ctFgNow6 != 0 && ctFgNow6 != CPUthermalBundleIDHash(S("com.apple.springboard")) && ctFgNow6 != g_ctVideoActiveHash) {
                g_ctVideoActive = NO;
                CTD("[视频档] App 已切换 → 结束");
            }
        }
        if (!g_ctVideoOptEnabled && !g_ctVideoDeepEnabled && g_ctVideoActive) { g_ctVideoActive = NO; CTD("[视频档] 开关关闭 → 结束"); }
        // ★ 1.4.6h：状态文件/自检/定时 已迁到独立队列（startPerSecondServicesTimer）
        g_ctMainPhase = 0;
    });
    dispatch_resume(t);
}


// ★ 周期重申（2026-09-16 晚）：亮屏每 2 秒 / 熄屏每 5 秒 重发"模式变更"通知
//   （完整重应用，等价于手动切一次 CC 开关）—— 用户需求："解锁后一直重申，别停"。
//   实现：1 秒检查 + 到点即发（真定时器，不再依赖唤醒事件次数）。
//   ⚠️ 熄屏期间系统会反复挂起本进程（日志心跳断档即证据）：熄屏 5 秒属"能跑就跑"——
//      系统每隔约 5~15 秒会给一次执行机会，到点就补一枪；深度睡眠时以"唤醒必恢复"兜底。
static CFAbsoluteTime g_lastPeriodicReassert = 0;
static void startPeriodicReassertTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        CTIdentityCheck();                     // ★ 1.4.6：身份校验先跑（被停用后仍持续核对 → 修复后可自动复活）
        if (!runtimeProtectionEnabled()) return;
        BOOL blanked = CPUthermalScreenIsBlanked();
        if (isNativeMode()) return; double period = blanked ? 5.0 : 2.0;   // ★ 原生：不重申
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (g_lastPeriodicReassert > 0 && (now - g_lastPeriodicReassert) < (period - 0.25)) return;
        g_lastPeriodicReassert = now;
        notify_post("com.qq391160.thermal/powerModeChanged");
        CTD("[周期] 重申模式变更（%s，每 %.0f 秒一次）", blanked ? "熄屏" : "亮屏", period);
    });
    dispatch_resume(t);
}


// ★ 1.4.6g：充电引擎独立定时器（独立队列）——即使主队列卡死，充电管家照常工作
static void startChargeEngineTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.thermal.chargeengine", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        g_ctEngineBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6h：引擎队列心跳
        if (!runtimeProtectionEnabled()) return;   // 与全局门一致：身份未过则保持停用
        CTChargeTick();
    });
    dispatch_resume(t);
}

// ============================================================================
// ★ 1.4.6i：卡死自动抓栈器 —— 心跳断档时，把「所有线程的调用栈」写进日志
//   （卡住的线程不会自己说话；由看门狗线程去采样它到底卡在哪一行）
// ============================================================================
#include <mach/mach.h>
#include <mach/arm/thread_status.h>
#include <mach/vm_region.h>
#include <dlfcn.h>
static uint64_t CTStripPAC(uint64_t a) { return a & 0x0000000FFFFFFFFFULL; }
static BOOL CTAddressReadable(uintptr_t addr) {
    vm_address_t region = (vm_address_t)addr; vm_size_t size = 0; mach_port_t obj = MACH_PORT_NULL;
    vm_region_basic_info_data_64_t info; mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    kern_return_t kr = vm_region_64(mach_task_self(), &region, &size, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj);
    if (obj != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), obj);
    if (kr != KERN_SUCCESS) return NO;
    return (addr >= region && addr + 16 <= region + size && (info.protection & VM_PROT_READ));
}
static void CTLogFrameLine(mach_msg_type_number_t ti, int idx, uintptr_t addr) {
    if (!addr) return;
    Dl_info info; const char *img = "?"; const char *sym = NULL;
    if (dladdr((void *)addr, &info)) {
        if (info.dli_fname) img = info.dli_fname;
        if (info.dli_sname) sym = info.dli_sname;
    }
    if (sym) CTD("[抓栈] T%u #%02d %s  (%s)", (unsigned)ti, idx, sym, img);
    else CTD("[抓栈] T%u #%02d 0x%llx  (%s)", (unsigned)ti, idx, (unsigned long long)addr, img);
}
static void CTDumpAllThreads(const char *why) {
    @try {
        CTD("[抓栈] %s —— 抓取线程栈开始…", why);
        thread_act_array_t list = NULL; mach_msg_type_number_t count = 0;
        if (task_threads(mach_task_self(), &list, &count) != KERN_SUCCESS || !list) {
            CTD("[抓栈] %s：task_threads 失败", why); return;
        }
        CTD("[抓栈] 共 %u 个线程，开始采样：", (unsigned)count);
        for (mach_msg_type_number_t ti = 0; ti < count && ti < 12; ti++) {
            arm_thread_state64_t st; mach_msg_type_number_t cnt = ARM_THREAD_STATE64_COUNT;
            if (thread_get_state(list[ti], ARM_THREAD_STATE64, (thread_state_t)&st, &cnt) != KERN_SUCCESS) continue;
            uintptr_t pc = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_pc(st));
            uintptr_t lr = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_lr(st));
            uintptr_t sp = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_sp(st));
            uintptr_t fp = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_fp(st));
            CTLogFrameLine(ti, 0, pc);
            if (lr && lr != pc) CTLogFrameLine(ti, 1, lr);
            int idx = 2; uintptr_t cur = fp; int walked = 0;
            while (idx < 26 && walked < 40 && cur && !(cur & 7)) {
                walked++;
                if (!CTAddressReadable(cur)) break;
                uintptr_t next = *(uintptr_t *)cur;
                uintptr_t ret  = *(uintptr_t *)(cur + 8);
                if (!ret) break;
                next = (uintptr_t)CTStripPAC((uint64_t)next);
                ret  = (uintptr_t)CTStripPAC((uint64_t)ret);
                if (next <= cur || next < sp) break;
                CTLogFrameLine(ti, idx, ret);
                cur = next; idx++;
            }
        }
        for (mach_msg_type_number_t ti = 0; ti < count; ti++) {
            if (list[ti] != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), list[ti]);
        }
        vm_deallocate(mach_task_self(), (vm_address_t)list, count * sizeof(thread_act_t));
    } @catch (__unused NSException *e) {}
}

// ★ 1.4.6g：主队列健康看门狗（独立队列）——主队列心跳断档超 90 秒 → 写日志（下次看一眼日志就能定位“卡死”）
static void startMainQueueWatchdog(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.thermal.watchdog", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 15ull * NSEC_PER_SEC),
                              15ull * NSEC_PER_SEC, 1ull * NSEC_PER_SEC);
    dispatch_source_set_event_handler(t, ^{
        static CFAbsoluteTime sPrevFire = 0;
        CFAbsoluteTime nowW = CFAbsoluteTimeGetCurrent();
        BOOL selfCont = (sPrevFire > 0 && (nowW - sPrevFire) < 45.0);   // 自身连续（排除熄屏挂起误判）
        sPrevFire = nowW;
        if (!selfCont) return;
        double mB = (g_ctMainBeat > 0) ? (nowW - g_ctMainBeat) : 0;
        double eB = (g_ctEngineBeat > 0) ? (nowW - g_ctEngineBeat) : 0;
        double sB = (g_ctSvcBeat > 0) ? (nowW - g_ctSvcBeat) : 0;
        // ★ 1.4.6q：自愈最优先——先写日志、立即 _exit（不跑清理流程，防退出阶段再卡）；任何旁路都挡不住它
        if (mB > 120.0 || eB > 120.0 || sB > 120.0) {
            CTD("[健康] %s卡死 %.0f 秒（阶段=%d/%d）→ 自动重启后台进程（自愈）",
                (mB > 120.0) ? "主队列" : ((eB > 120.0) ? "充电引擎" : "每秒服务"),
                (mB > 120.0) ? mB : ((eB > 120.0) ? eB : sB), g_ctMainPhase, g_ctSvcPhase);
            _exit(0);
        }
        // ★ 1.4.6q：抓栈改为旁路线程——抓栈自己卡住也不影响自愈（上次就是因为同步抓栈把自愈卡没了）
        static BOOL sStallDumped = NO;
        if (mB < 30.0 && eB < 30.0 && sB < 30.0) sStallDumped = NO;   // 心跳恢复 → 允许下轮再抓
        if (!sStallDumped && (mB > 60.0 || eB > 60.0 || sB > 60.0)) {
            sStallDumped = YES;
            double vm = mB, ve = eB, vs = sB;
            dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                @autoreleasepool {
                    const char *ctWhy = (vm > 60.0) ? "主队列冻结" : ((ve > 60.0) ? "充电引擎冻结" : "每秒服务冻结");
                    CTDumpAllThreads(ctWhy);   // ★ 旁路：写进日志；若它也卡住，不影响自愈
                }
            });
        }
    });
    dispatch_resume(t);
}

// ★ 1.4.6h：每秒服务独立队列（状态文件/一键自检/定时切档）——减轻主队列负担，且主队列卡死时浮窗数字照跑
static void startPerSecondServicesTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.thermal.persec", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        g_ctSvcBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6h：服务队列心跳
        if (!runtimeProtectionEnabled()) return;
        g_ctSvcPhase = 1; CTStatusFileTick();
        g_ctSvcPhase = 2; CTSelfTestTick();
        g_ctSvcPhase = 3; CTScheduleTick();
        g_ctSvcPhase = 0;
    });
    dispatch_resume(t);
}

static void startForegroundRecheckTimer(void) {
    static dispatch_source_t timer = NULL; // 必须强引用，避免离开作用域被释放
    if (timer) return;
    timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!timer) return;
    dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);   // ★加速：3秒→1秒
    dispatch_source_set_event_handler(timer, ^{
        if (!runtimeProtectionEnabled()) return;
        CPUthermalSyncModeFromPrefs();   // 面板写文件可能晚于通知，这里兜底同步
        applyForegroundDecision("recheck");
    });
    dispatch_resume(timer);
}
static void applyCurrentModeToApplePPMCPU(void) {
if (!runtimeProtectionEnabled()) return;
NSArray *instances = trackedApplePPMInstancesSnapshot();
BOOL restoring = isFullPowerMode();
BOOL previousRestoring = g_restoringFullPower;
@try {
if (restoring) g_restoringFullPower = YES;
for (id ppm in instances) {
if (!ppm) continue;
if ([ppm respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(ppm, CTObfSel("293f2e190a0f163f2c3f3660"), targetCPUPerformanceLevel());
}
if ([ppm respondsToSelector:CTObfSel("2f2a3e3b2e3f190a0f")]) {
((void (*)(id, SEL))objc_msgSend)(ppm, CTObfSel("2f2a3e3b2e3f190a0f"));
}
// updateCPU 可能重新应用旧 Level；确保最终状态仍为当前模式。
if ([ppm respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
((void (*)(id, SEL, int))objc_msgSend)(ppm, CTObfSel("293f2e190a0f163f2c3f3660"), targetCPUPerformanceLevel());
}
}
} @finally {
if (restoring) g_restoringFullPower = previousRestoring;
}
}

// 性能模式使用事件驱动 hook，不创建周期保活定时器。

static NSNumber *g_maxBacklightBrightnessValue = nil; // 设备自身亮度 cap（如13Pro=1060），动态发现，不硬编码
static NSNumber *g_userBrightnessBeforeModeChange = nil; // 切换前用户滑块/实际亮度（如850.1）
static BOOL g_backlightRecoveryScheduled = NO;
static os_unfair_lock g_brightnessRecommitLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastBrightnessRecommitSchedule = 0;

static id CPUthermalCopyUserBrightness(void) {
    const char *paths[]={
        "/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness",
        "/System/Library/PrivateFrameworks/corebrightness.framework/corebrightness",NULL};
    for(int i=0;paths[i];i++)if(dlopen(paths[i],RTLD_NOW|RTLD_LOCAL))break;
    Class cls=CTObfCls("1828333d322e343f29290923292e3f371936333f342e"); if(!cls)return nil;
    id client=[[cls alloc]init]; SEL cp=CTObfSel("39352a230a28352a3f282e231c3528113f2360");
    if(![client respondsToSelector:cp])return nil;
    id display=((id(*)(id,SEL,id))objc_msgSend)(client,cp,S("DisplayBrightness"));
    id b=[display isKindOfClass:[NSDictionary class]]?display[S("Brightness")]:nil;
    return [b respondsToSelector:@selector(doubleValue)]&&[b doubleValue]>0.0?b:nil;
}

static void CPUthermalCaptureBrightnessBeforeModeChange(void) {
    if(!thermalDimmingPreventionEnabled()||CPUthermalScreenIsBlanked())return;
    id b=CPUthermalCopyUserBrightness();
    if([b respondsToSelector:@selector(doubleValue)]&&[b doubleValue]>0.0)
        g_userBrightnessBeforeModeChange=[NSNumber numberWithDouble:[b doubleValue]];
}

static void CPUthermalRecommitUserBrightness(void) {
    if(CPUthermalScreenIsBlanked())return;
    Class cls=CTObfCls("1828333d322e343f29290923292e3f371936333f342e"); if(!cls)return;
    id client=[[cls alloc]init]; SEL set=CTObfSel("293f2e0a28352a3f282e23603c3528113f2360");
    if(![client respondsToSelector:set])return;
    id brightness=g_userBrightnessBeforeModeChange?:CPUthermalCopyUserBrightness();
    if(![brightness respondsToSelector:@selector(doubleValue)]||[brightness doubleValue]<=0.0)return;
    NSDictionary *request=@{S("Brightness"):brightness,S("Commit"):@YES};
    ((void(*)(id,SEL,id,id))objc_msgSend)(client,set,request,S("DisplayBrightness"));
}

static void CPUthermalRecommitUserBrightnessSoon(void) {
    if (CPUthermalScreenIsBlanked()) return;
    CFAbsoluteTime now=CFAbsoluteTimeGetCurrent();
    os_unfair_lock_lock(&g_brightnessRecommitLock);
    BOOL allowed=(now-g_lastBrightnessRecommitSchedule)>=0.20;
    if(allowed)g_lastBrightnessRecommitSchedule=now;
    os_unfair_lock_unlock(&g_brightnessRecommitLock);
    if(!allowed)return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,50ull*NSEC_PER_MSEC),dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{CPUthermalRecommitUserBrightness();});
}

static void CPUthermalRememberBacklightMaximum(id value) {
    if(![value respondsToSelector:@selector(doubleValue)])return;
    double v=[value doubleValue]; if(v<=0.0||v>10000.0)return;
    if(!g_maxBacklightBrightnessValue||v>[g_maxBacklightBrightnessValue doubleValue])
        g_maxBacklightBrightnessValue=[NSNumber numberWithDouble:v];
}

static void CPUthermalCaptureExistingBacklightMaximum(void) {
    if(!thermalDimmingPreventionEnabled()||CPUthermalScreenIsBlanked())return;
    io_iterator_t it=IO_OBJECT_NULL;
    if(IORegistryCreateIterator(kIOMasterPortDefault,kIOServicePlane,kIORegistryIterateRecursively,&it)!=KERN_SUCCESS||it==IO_OBJECT_NULL)return;
    const char*keys[]={"IOMFB_brightness_limit","max-brightness","brightness-limit","brightness_limit","maxbrightness","brightnesscap",NULL};
    io_registry_entry_t e;
    while((e=IOIteratorNext(it))!=IO_OBJECT_NULL){
        for(int i=0;keys[i];i++){
            CFStringRef k=CFStringCreateWithCString(NULL,keys[i],kCFStringEncodingUTF8); if(!k)continue;
            CFTypeRef v=IORegistryEntryCreateCFProperty(e,k,NULL,0);
            if(v){ if(CFGetTypeID(v)==CFNumberGetTypeID()||CFGetTypeID(v)==CFStringGetTypeID())CPUthermalRememberBacklightMaximum((__bridge id)v); CFRelease(v); }
            CFRelease(k);
        }
        IOObjectRelease(e);
    }
    IOObjectRelease(it);
}

static void CPUthermalRestoreExistingBacklightLimit(void) {
    if (!thermalDimmingPreventionEnabled() || CPUthermalScreenIsBlanked()) return;
    if(!g_maxBacklightBrightnessValue)CPUthermalCaptureExistingBacklightMaximum();
    if(!g_maxBacklightBrightnessValue){CPUthermalRecommitUserBrightness();return;}
    io_iterator_t iterator = IO_OBJECT_NULL;
    if (IORegistryCreateIterator(kIOMasterPortDefault, kIOServicePlane, kIORegistryIterateRecursively, &iterator) != KERN_SUCCESS || iterator == IO_OBJECT_NULL) { CPUthermalRecommitUserBrightness(); return; }
    const char *keys[] = {"IOMFB_brightness_limit","max-brightness","brightness-limit","brightness_limit","maxbrightness","brightnesscap",NULL};
    io_registry_entry_t entry;
    while ((entry = IOIteratorNext(iterator)) != IO_OBJECT_NULL) {
        for (int i=0; keys[i]; i++) {
            CFStringRef key = CFStringCreateWithCString(kCFAllocatorDefault, keys[i], kCFStringEncodingUTF8);
            if (!key) continue;
            CFTypeRef existing = IORegistryEntryCreateCFProperty(entry, key, kCFAllocatorDefault, 0);
            if (existing) {
                if (CFGetTypeID(existing)==CFNumberGetTypeID()) {
                    IORegistryEntrySetCFProperty(entry, key, (__bridge CFTypeRef)g_maxBacklightBrightnessValue);
                } else if (CFGetTypeID(existing)==CFStringGetTypeID()) {
                    NSString *text=[g_maxBacklightBrightnessValue stringValue];
                    IORegistryEntrySetCFProperty(entry, key, (__bridge CFTypeRef)text);
                }
                CFRelease(existing);
            }
            CFRelease(key);
        }
        IOObjectRelease(entry);
    }
    IOObjectRelease(iterator);
    CPUthermalRecommitUserBrightness();
}

static void CPUthermalScheduleBacklightRecovery(void) {
    if (!thermalDimmingPreventionEnabled() || g_backlightRecoveryScheduled) return;
    g_backlightRecoveryScheduled = YES;
    const double delays[] = {0.02,0.10,0.25,0.50,1.00};   // ★ 2026-09-17 提速：3 秒 → 1 秒（治通话/切换后亮度恢复慢）
    for (NSUInteger i=0;i<sizeof(delays)/sizeof(delays[0]);i++) {
        BOOL finalAttempt=(i+1==sizeof(delays)/sizeof(delays[0]));
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(delays[i]*NSEC_PER_SEC)),dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{CPUthermalRestoreExistingBacklightLimit();if(finalAttempt)dispatch_async(dispatch_get_main_queue(),^{g_backlightRecoveryScheduled=NO;g_userBrightnessBeforeModeChange=nil;});});
    }
}

static BOOL keyIsDisplayLifecycleProperty(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
return [lower containsString:S("idle")] || [lower containsString:S("autolock")] ||
       [lower containsString:S("lockstate")] || [lower containsString:S("sleep")] ||
       [lower containsString:S("blank")] || [lower containsString:S("screenoff")] ||
       [lower containsString:S("screen-off")] || [lower containsString:S("powerstate")] ||
       [lower containsString:S("power-state")] || [lower containsString:S("displaystate")] ||
       [lower containsString:S("screenstate")] || [lower containsString:S("wake")] ||
       [lower containsString:S("proximity")] || [lower containsString:S("backlightpower")];
}

static BOOL keyIsBacklightThermalLimit(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
if (keyIsDisplayLifecycleProperty(key)) return NO;
if ([lower isEqualToString:S("iomfb_brightness_limit")] ||
    [lower isEqualToString:S("max-brightness")] ||
    [lower isEqualToString:S("brightness-limit")] ||
    [lower isEqualToString:S("brightness_limit")] ||
    [lower isEqualToString:S("maxbrightness")] ||
    [lower isEqualToString:S("brightnesscap")]) return YES;
BOOL explicitThermal = [lower containsString:S("thermal")] ||
                       [lower containsString:S("mitigation")] ||
                       [lower containsString:S("temperature")];
BOOL explicitCap = [lower containsString:S("limit")] ||
                   [lower containsString:S("ceiling")] ||
                   [lower containsString:S("maximum")] ||
                   [lower containsString:S("max-")] ||
                   [lower containsString:S("cap")];
BOOL brightnessValue = [lower containsString:S("brightness")] ||
                       [lower containsString:S("luminance")] ||
                       [lower containsString:S("nits")];
BOOL displayOwner = [lower containsString:S("iomfb")] ||
                    [lower containsString:S("backlight")] ||
                    [lower containsString:S("display")];
return brightnessValue && explicitCap && (explicitThermal || displayOwner);
}

static id maximumBacklightReplacementForKey(NSString *key) {
return g_maxBacklightBrightnessValue;
}

static id backlightReplacementMatchingValue(NSString *key, id originalValue) {
CPUthermalRememberBacklightMaximum(originalValue);
id maximum = maximumBacklightReplacementForKey(key);
if (!maximum) return nil;
if ([originalValue isKindOfClass:[NSString class]]) {
if ([(NSString *)originalValue doubleValue] <= 0.0) return nil;
return [(NSNumber *)maximum stringValue];
}
if ([originalValue isKindOfClass:[NSNumber class]]) {
if ([(NSNumber *)originalValue doubleValue] <= 0.0) return nil;
return maximum;
}
return nil;
}

// 判断是否为 thermalmonitord 发出的约束属性。
// 这里只丢弃用户态温控上限写入，不向内核写固定频点，因此不会锁死原生 DVFS。
static BOOL keyIsThermalThrottleProperty(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
if (keyIsDisplayLifecycleProperty(key)) return NO;

// Floor/Minimum 属于性能下限而非热降频上限，不能拦截。
if ([lower containsString:S("floor")]) return NO;

// 明确的温控缓解关键词 — 无条件拦截
if ([lower containsString:S("throttle")]) return YES;
if ([lower containsString:S("mitigation")]) return YES;

BOOL mentionsCPU = [lower containsString:S("cpu")] ||
[lower containsString:S("core")] ||
[lower containsString:S("ppm")] ||
[lower containsString:S("processor")];
BOOL mentionsGPU = [lower containsString:S("gpu")];
BOOL mentionsPackage = [lower containsString:S("package")] ||
[lower containsString:S("component")];
BOOL mentionsThermal = [lower containsString:S("thermal")];
BOOL mentionsFreq = [lower containsString:S("freq")] ||
[lower containsString:S("frequency")];
BOOL mentionsLimit = [lower containsString:S("limit")] ||
[lower containsString:S("cap")] ||
[lower containsString:S("ceiling")] ||
[lower containsString:S("floor")] ||
[lower containsString:S("target")] ||
[lower containsString:S("maximum")] ||
[lower containsString:S("minimum")];
BOOL mentionsSpeed = [lower containsString:S("speed")];
BOOL mentionsPower = [lower containsString:S("power")];
BOOL mentionsState = [lower containsString:S("level")] ||
[lower containsString:S("state")];

BOOL protectedComponent = mentionsCPU || mentionsGPU || mentionsPackage || mentionsThermal;
if (protectedComponent) {
// 日常性能模式只保护 CPU；高性能模式额外保护 GPU 与 Package 功率墙。
if (mentionsLimit || mentionsFreq || mentionsSpeed || mentionsPower || mentionsState) {
return YES;
}
}
return NO;
}

static CFDictionaryRef copyPropertiesByRemovingThermalLimits(CFTypeRef properties) {
if (!properties || CFGetTypeID(properties) != CFDictionaryGetTypeID()) return NULL;
NSDictionary *source = (__bridge NSDictionary *)properties;
NSMutableDictionary *filtered = [source mutableCopy];
if (!filtered) return NULL;
BOOL changed = NO;

for (id rawKey in source) {
if (![rawKey isKindOfClass:[NSString class]]) continue;
NSString *key = (NSString *)rawKey;
if (thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(key)) {
    id original = [source objectForKey:key];
    id replacement = backlightReplacementMatchingValue(key, original);
    if (replacement) [filtered setObject:replacement forKey:key];
    changed = YES;
    continue;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(key) && g_ctcCapacity < 99) {
    id original = [source objectForKey:key];
    if (valueMeansStopChargingCF(key, (__bridge CFTypeRef)original)) {
        [filtered removeObjectForKey:key];
        changed = YES;
        CTChargeNoteIntercept(key);
        continue;
    }
}
BOOL shouldDrop = isNetworkThrottleProperty((__bridge CFStringRef)key);
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(key)) {
shouldDrop = YES;
}
if (!shouldDrop) continue;
[filtered removeObjectForKey:key];
changed = YES;
}

return changed ? CFBridgingRetain(filtered) : NULL;
}

// iOS 15~17 热管理私有类存在命名差异；以下别名 Hook 按方法签名动态安装。
static void (*origTDT_Evaluate)(id, SEL) = NULL;
static void (*origTDT_Action)(id, SEL) = NULL;
static void (*origTDT_ReadRelease)(id, SEL) = NULL;
static float (*origTDT_GetRelease)(id, SEL, id) = NULL;
static void (*origComponent_CPMS)(id, SEL, int) = NULL;
static void (*origNotification_Thermal)(id, SEL, id) = NULL;

static void aliasTDT_Evaluate(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) { correctNominalStateIfNeeded(); return; }
if (origTDT_Evaluate) origTDT_Evaluate(self, cmd);
}
static void aliasTDT_Action(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) return;
if (origTDT_Action) origTDT_Action(self, cmd);
}
static void aliasTDT_ReadRelease(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) return;
if (origTDT_ReadRelease) origTDT_ReadRelease(self, cmd);
}
static float aliasTDT_GetRelease(id self, SEL cmd, id component) {
if (shouldApplyFullCPUProtection()) return 0.0f;
return origTDT_GetRelease ? origTDT_GetRelease(self, cmd, component) : 0.0f;
}
static void aliasComponent_CPMS(id self, SEL cmd, int state) {
if (shouldApplyFullCPUProtection()) { if (origComponent_CPMS) origComponent_CPMS(self, cmd, 0); return; }
if (origComponent_CPMS) origComponent_CPMS(self, cmd, state);
}
static void aliasNotification_Thermal(id self, SEL cmd, id notification) {
if (thermalPopupBlockingEnabled()) return;
if (origNotification_Thermal) origNotification_Thermal(self, cmd, notification);
}

static BOOL CPUthermalMethodMatches(Class cls, SEL sel, unsigned int arguments, char returnType) {
Method method = class_getInstanceMethod(cls, sel);
if (!method || method_getNumberOfArguments(method) != arguments) return NO;
char type[16] = {0}; method_getReturnType(method, type, sizeof(type));
const char *cursor = type; while (*cursor && strchr("rnNoORV", *cursor)) cursor++;
return *cursor == returnType;
}

static BOOL CPUthermalMethodArgumentMatches(Class cls, SEL sel, unsigned int index, const char *allowed) {
Method method = class_getInstanceMethod(cls, sel); if (!method || index >= method_getNumberOfArguments(method)) return NO;
char type[16]={0}; method_getArgumentType(method,index,type,sizeof(type)); const char *cursor=type;
while(*cursor&&strchr("rnNoORV",*cursor))cursor++; return *cursor && strchr(allowed,*cursor)!=NULL;
}

static void installCrossVersionThermalAliases(void) {
Class tree = CTObfCls("0e3b38363f1e28332c3f341e3f3933293335340e283f3f");
if (tree) {
SEL eval = CTObfSel("3f2c3b362f3b2e3f1e3f3933293335340e283f3f");
SEL action = CTObfSel("3b392e3335341935372a35343f342e1935342e283536");
SEL read = CTObfSel("283f3b3e083f363f3b293f083b2e3f1c35281b36361935372a35343f342e29");
SEL release = CTObfSel("3d3f2e083f363f3b293f083b2e3f1c35281935372a35343f342e60");
if (!origTDT_Evaluate && CPUthermalMethodMatches(tree, eval, 2, 'v')) MSHookMessageEx(tree, eval, (IMP)aliasTDT_Evaluate, (IMP *)&origTDT_Evaluate);
if (!origTDT_Action && CPUthermalMethodMatches(tree, action, 2, 'v')) MSHookMessageEx(tree, action, (IMP)aliasTDT_Action, (IMP *)&origTDT_Action);
if (!origTDT_ReadRelease && CPUthermalMethodMatches(tree, read, 2, 'v')) MSHookMessageEx(tree, read, (IMP)aliasTDT_ReadRelease, (IMP *)&origTDT_ReadRelease);
if (!origTDT_GetRelease && CPUthermalMethodMatches(tree, release, 3, 'f') && CPUthermalMethodArgumentMatches(tree, release, 2, "@")) MSHookMessageEx(tree, release, (IMP)aliasTDT_GetRelease, (IMP *)&origTDT_GetRelease);
}
Class component = CTObfCls("1935372a35343f342e1935342e283536");
SEL cpms = CTObfSel("293f2e190a170917332e333d3b2e333534092e3b2e3f60");
if (component && !origComponent_CPMS && CPUthermalMethodMatches(component, cpms, 3, 'v') && CPUthermalMethodArgumentMatches(component, cpms, 2, "cCsSiIlLqQB")) MSHookMessageEx(component, cpms, (IMP)aliasComponent_CPMS, (IMP *)&origComponent_CPMS);
Class notification = CTObfCls("14352e333c33393b2e333534173b343b3d3f28");
SEL update = CTObfSel("2f2a3e3b2e3f0e323f28373b3614352e333c33393b2e33353460");
if (notification && !origNotification_Thermal && CPUthermalMethodMatches(notification, update, 3, 'v') && CPUthermalMethodArgumentMatches(notification, update, 2, "@")) MSHookMessageEx(notification, update, (IMP)aliasNotification_Thermal, (IMP *)&origNotification_Thermal);
}

static NSDictionary *readPrefsDictionary(void) {
return CPUthermalReadPrefs();
}

static BOOL foregroundAppShouldUseLowPower(NSDictionary *prefs) {
if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
if (CPUthermalTierSystemActive(prefs)) return NO;   // ★ T7x：旧名单退役（档位"低频率"由 resolve 的档位优先处理）
uint64_t foregroundHash = CPUthermalReadForegroundBundleHash();
NSArray *selected = [prefs[S("lowPowerApps")] isKindOfClass:[NSArray class]] ? prefs[S("lowPowerApps")] : nil;
if (foregroundHash == 0 || selected.count == 0) return NO;
if (foregroundHash == CPUthermalBundleIDHash(S("com.apple.springboard"))) return NO;   // ★ 桌面进程永不匹配名单
for (id rawBundleID in selected) {
if ([rawBundleID isKindOfClass:[NSString class]] && CPUthermalBundleIDHash(rawBundleID) == foregroundHash) return YES;
}
return NO;
}

// 例外名单（面板上的「指定应用低功耗」）：跟着常驻模式反着走 ——
//   常驻「低功耗」   → 名单内应用改为高性能运行（不卡；微信/相机/扫码这类）
//   常驻「性能模式」 → 名单内应用照旧执行低功耗（省电；抖音这类耗电大户）
// 熄屏低功耗与高温自动低功耗不受名单影响（安全优先）。
// 两份独立名单，各归各的模式：
//   常驻「低功耗」  + 高性能名单命中   → 高性能运行（不卡；微信/相机/扫码放这份名单）
//   常驻「性能模式」+ 低功耗名单命中 → 执行低功耗（省电；抖音这类放这份名单）
// ★★★ 智能模式（T7h）：应用分类 —— 靠 App Store 元数据认"游戏"
// 返回：2 = 游戏；1 = 可识别的普通应用；0 = 识别不到（无分类信息，如自签）→ 走"原生"
static NSInteger CTSmartAppClassAtPath(NSString *bundlePath) {
    if (![bundlePath isKindOfClass:[NSString class]] || bundlePath.length == 0) return 0;
    NSInteger cls = 0;
    @try {
        NSDictionary *meta = [NSDictionary dictionaryWithContentsOfFile:
            [bundlePath stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
        if (![meta isKindOfClass:[NSDictionary class]]) {
            // ★ T7l：有些环境元数据放在包"旁边"（同一父目录）而不是包内
            NSString *ctParentDir = [bundlePath stringByDeletingLastPathComponent];
            meta = [NSDictionary dictionaryWithContentsOfFile:
                [ctParentDir stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
        }
        if ([meta isKindOfClass:[NSDictionary class]]) {
            cls = 1;                                                        // 有 App Store 元数据 = 可识别
            id gid = meta[S("genreId")];
            NSInteger g = [gid respondsToSelector:@selector(integerValue)] ? [gid integerValue] : -1;
            if (g == 6014 || (g >= 7001 && g <= 7019)) cls = 2;             // 「游戏」主类 / 子类
            id genre = meta[S("genre")];
            if ([genre isKindOfClass:[NSString class]] &&
                ([genre containsString:S("游戏")] || [genre caseInsensitiveCompare:S("Games")] == NSOrderedSame)) cls = 2;
        }
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:
            [bundlePath stringByAppendingPathComponent:S("Info.plist")]];
        id cat = [info isKindOfClass:[NSDictionary class]] ? info[S("LSApplicationCategoryType")] : nil;
        if ([cat isKindOfClass:[NSString class]] && [cat length] > 0) {
            if (cls == 0) cls = 1;                                          // 有分类字段 = 可识别
            if ([cat rangeOfString:S("games")].location != NSNotFound) cls = 2;
        }
    } @catch (__unused NSException *e) { }
    return cls;
}

// ★ T7x：档位体系是否已接管（有档位表 appTiers 或已迁移标记）——
//   接管后旧"两份名单"（fullPowerApps / lowPowerApps）正式退役，钉档一律走「App 档位」。
static BOOL CPUthermalTierSystemActive(NSDictionary *prefs) {
    if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
    if ([prefs[S("appTiers")] isKindOfClass:[NSDictionary class]]) return YES;
    return prefs[S("appTiersMigrated")] != nil;
}

static void CPUthermalRebuildSmartAppClasses(NSDictionary *prefs) {
    NSMutableSet *games = [NSMutableSet set];
    NSMutableSet *knownApps = [NSMutableSet set];
    NSMutableSet *pinned = [NSMutableSet set];
    NSMutableSet *seenBundles = [NSMutableSet set];
    __block int metaInside = 0, metaBeside = 0;
    NSFileManager *ctFMProbe = [NSFileManager defaultManager];
    __block NSString *ctFirstAppPath = nil;
    __block NSString *ctLolmAppPath = nil;
    // ★ T7o：先读“跨进程扫描”产出的分类缓存（thermalmonitord 沙箱看不到应用目录 —— T7n 诊断：扫描根全 0）
    @try {
        NSDictionary *ctCache = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("smartClasses")] isKindOfClass:[NSDictionary class]])
            ? prefs[S("smartClasses")] : nil;
        if (ctCache) {
            NSInteger ctCG = 0, ctCK = 0;
            for (id ctV in ctCache[S("games")]) if ([ctV isKindOfClass:[NSNumber class]]) { [games addObject:ctV]; [knownApps addObject:ctV]; ctCG++; }
            for (id ctV in ctCache[S("known")]) if ([ctV isKindOfClass:[NSNumber class]]) { [knownApps addObject:ctV]; ctCK++; }
            NSString *ctCacheTsStr = [ctCache[S("ts")] description] ?: @"?";
            CTD("[智能] 缓存载入：游戏 %ld / 可识别 %ld（写入时间 %s）", (long)ctCG, (long)ctCK, ctCacheTsStr.UTF8String);
        } else {
            CTD("[智能] 缓存：无（等挂载工具/前台插件产出）");
        }
    } @catch (__unused NSException *e) { }
    void (^ctHandleApp)(NSString *, NSString *) = ^(NSString *bid, NSString *path) {
        if (![bid isKindOfClass:[NSString class]] || bid.length == 0) return;
        if ([seenBundles containsObject:bid]) return;
        [seenBundles addObject:bid];
        if ([path isKindOfClass:[NSString class]] && path.length > 0) {
            if (!ctFirstAppPath) ctFirstAppPath = path;
            if (!ctLolmAppPath && [[path lowercaseString] rangeOfString:S("lolm")].location != NSNotFound) ctLolmAppPath = path;
            NSString *metaIn = [path stringByAppendingPathComponent:S("iTunesMetadata.plist")];
            NSString *metaP  = [[path stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("iTunesMetadata.plist")];
            if ([ctFMProbe fileExistsAtPath:metaIn]) metaInside++;
            else if ([ctFMProbe fileExistsAtPath:metaP]) metaBeside++;
        }
        NSInteger cls = CTSmartAppClassAtPath(path);
        if (cls == 2) { [games addObject:@(CPUthermalBundleIDHash(bid))]; [knownApps addObject:@(CPUthermalBundleIDHash(bid))]; }
        else if (cls == 1) { [knownApps addObject:@(CPUthermalBundleIDHash(bid))]; }
    };
    @try {
        // ★ T7k：文件系统扫描（兜底 —— thermalmonitord 沙箱常挡住这里；主路径＝上面的缓存）
        NSFileManager *ctFM = [NSFileManager defaultManager];
        for (NSString *root in @[S("/var/containers/Bundle/Application"), S("/var/mobile/Containers/Bundle/Application"), S("/private/var/containers/Bundle/Application")]) {
            NSError *ctRootErr = nil;
            NSArray *children = [ctFM contentsOfDirectoryAtPath:root error:&ctRootErr];
            CTD("[智能] 扫描根 %s：%lu 项 (err=%ld)", root.UTF8String, (unsigned long)children.count, (long)ctRootErr.code);
            for (NSString *child in children) {
                NSString *full = [root stringByAppendingPathComponent:child];
                if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) {
                    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[full stringByAppendingPathComponent:S("Info.plist")]];
                    ctHandleApp([info isKindOfClass:[NSDictionary class]] ? info[S("CFBundleIdentifier")] : nil, full);
                    continue;
                }
                NSArray *inner = [ctFM contentsOfDirectoryAtPath:full error:nil];
                for (NSString *entry in inner) {
                    if ([[entry pathExtension] caseInsensitiveCompare:S("app")] != NSOrderedSame) continue;
                    NSString *appPath = [full stringByAppendingPathComponent:entry];
                    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:S("Info.plist")]];
                    ctHandleApp([info isKindOfClass:[NSDictionary class]] ? info[S("CFBundleIdentifier")] : nil, appPath);
                }
            }
        }
    } @catch (__unused NSException *e) { }
    if (ctFirstAppPath.length) {
        NSString *ctSib1 = [ctFirstAppPath stringByDeletingLastPathComponent];
        NSArray *ctSibL = [ctFMProbe contentsOfDirectoryAtPath:ctSib1 error:nil];
        NSString *ctSibS = ctSibL ? [ctSibL componentsJoinedByString:S(" | ")] : S("(读不到)");
        CTD("[智能] 目录样例：%s → %s", ctSib1.UTF8String, ctSibS.UTF8String);
    }
    if (ctLolmAppPath.length) {
        NSString *ctSib2 = [ctLolmAppPath stringByDeletingLastPathComponent];
        NSArray *ctSibL2 = [ctFMProbe contentsOfDirectoryAtPath:ctSib2 error:nil];
        NSString *ctSibS2 = ctSibL2 ? [ctSibL2 componentsJoinedByString:S(" | ")] : S("(读不到)");
        CTD("[智能] lolm 目录样例：%s → %s", ctSib2.UTF8String, ctSibS2.UTF8String);
    }
    @try {
        // LSApplicationWorkspace 补充扫描（能拿到什么算什么）
        Class wsClass = CTObfCls("16091b2a2a3633393b2e3335340d352831292a3b393f");
        id ws = (wsClass && [wsClass respondsToSelector:CTObfSel("3e3f3c3b2f362e0d352831292a3b393f")])
            ? ((id (*)(id, SEL))objc_msgSend)(wsClass, CTObfSel("3e3f3c3b2f362e0d352831292a3b393f")) : nil;
        NSArray *apps = (ws && [ws respondsToSelector:CTObfSel("3b36361b2a2a3633393b2e33353429")])
            ? ((id (*)(id, SEL))objc_msgSend)(ws, CTObfSel("3b36361b2a2a3633393b2e33353429")) : nil;
        if ([apps isKindOfClass:[NSArray class]]) {
            for (id proxy in apps) {
                NSString *bid = nil;
                for (NSString *selName in @[S("applicationIdentifier"), S("bundleIdentifier")]) {
                    SEL s = NSSelectorFromString(selName);
                    if (![proxy respondsToSelector:s]) continue;
                    id v = ((id (*)(id, SEL))objc_msgSend)(proxy, s);
                    if ([v isKindOfClass:[NSString class]] && [v length] > 0) { bid = v; break; }
                }
                if (bid.length == 0) continue;
                NSString *path = nil;
                SEL urlSel = CTObfSel("382f343e363f0f0816");
                if ([proxy respondsToSelector:urlSel]) {
                    id url = ((id (*)(id, SEL))objc_msgSend)(proxy, urlSel);
                    if ([url isKindOfClass:[NSURL class]]) path = ((NSURL *)url).path;
                }
                ctHandleApp(bid, path);
            }
        }
    } @catch (__unused NSException *e) { }
    // ★ T7x：档位体系接管后，旧"两份名单"退役——不再作为隐形钉档（钉档走「App 档位」的档位优先）。
    //   未接管（老设备首次升级、还没开过档位页）时仍读旧名单，保证不丢用户设置（打开档位页会自动迁移）。
    NSMutableSet *lowPinned = [NSMutableSet set];
    if (!CPUthermalTierSystemActive(prefs)) {
        NSArray *fullList = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("fullPowerApps")] isKindOfClass:[NSArray class]])
            ? prefs[S("fullPowerApps")] : nil;
        for (id raw in fullList) if ([raw isKindOfClass:[NSString class]]) [pinned addObject:@(CPUthermalBundleIDHash(raw))];
        NSArray *lowList = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("lowPowerApps")] isKindOfClass:[NSArray class]])
            ? prefs[S("lowPowerApps")] : nil;
        for (id raw in lowList) if ([raw isKindOfClass:[NSString class]]) [lowPinned addObject:@(CPUthermalBundleIDHash(raw))];
    }
    g_smartGameHashes = [games copy];
    g_smartKnownAppHashes = [knownApps copy];
    g_smartFullListHashes = [pinned copy];
    g_smartLowListHashes = [lowPinned copy];
    g_smartScanDone = YES;
    CTD("[智能] 分类扫描：bundle %lu 个 / iTunesMetadata 包内 %d + 包旁 %d / 游戏 %lu / 可识别 %lu / 高性能名单 %lu / 低频名单 %lu", (unsigned long)seenBundles.count, metaInside, metaBeside, (unsigned long)games.count, (unsigned long)knownApps.count, (unsigned long)pinned.count, (unsigned long)lowPinned.count);
}

static CPUthermalPowerMode CPUthermalSmartResolveTarget(BOOL blanked) {
    if (blanked) return CPUthermalPowerModeLow;                                     // 熄屏：一律低功耗（照旧）
    uint64_t fg = CPUthermalReadForegroundBundleHash();
    // ★ T7u：系统组件误报 → 保持上次结果（不参与判定）
    if (fg == CPUthermalBundleIDHash(S("com.apple.chrono.WidgetRenderer-Default"))) {
        return g_smartLastTarget;
    }
    uint64_t sb = CPUthermalBundleIDHash(S("com.apple.springboard"));
    if (fg == 0) { g_smartLastTarget = CPUthermalPowerModeNative; return CPUthermalPowerModeNative; }   // 识别不到：一律原生（不干预）
    if (fg == sb) { g_smartLastTarget = CPUthermalPowerModeNative; return CPUthermalPowerModeNative; }      // 桌面 / 系统界面：原生
    if (g_smartFullListHashes && [g_smartFullListHashes containsObject:@(fg)]) { g_smartLastTarget = CPUthermalPowerModeFull; return CPUthermalPowerModeFull; } // 手动：高性能名单 → 高性能
    if (g_smartLowListHashes && [g_smartLowListHashes containsObject:@(fg)]) { g_smartLastTarget = CPUthermalPowerModeLow; return CPUthermalPowerModeLow; }    // 手动：低频率名单 → 低频率
    if (g_smartGameHashes && [g_smartGameHashes containsObject:@(fg)]) { g_smartLastTarget = CPUthermalPowerModeFull; return CPUthermalPowerModeFull; }   // 自动：游戏 → 高性能
    if (g_smartKnownAppHashes && [g_smartKnownAppHashes containsObject:@(fg)]) { g_smartLastTarget = CPUthermalPowerModeLow; return CPUthermalPowerModeLow; }   // 自动：可识别普通应用 → 低频率
    // ★ T7o：认不出且不是桌面 → 请求重扫分类缓存（每个 App 一次；≥20 秒间隔）
    {
        static uint64_t sCtScanAsked[96];
        static int sCtScanAskedN = 0;
        static CFAbsoluteTime sCtScanAskT = 0;
        BOOL ctAsked = NO;
        for (int ctQi = 0; ctQi < sCtScanAskedN; ctQi++) if (sCtScanAsked[ctQi] == fg) { ctAsked = YES; break; }
        CFAbsoluteTime ctNowQ = CFAbsoluteTimeGetCurrent();
        if (!ctAsked && (ctNowQ - sCtScanAskT) > 20.0) {
            sCtScanAskT = ctNowQ;
            if (sCtScanAskedN < 96) sCtScanAsked[sCtScanAskedN++] = fg;
            notify_post("com.qq391160.thermal/scanRequest");
            CTD("[智能] 未识别应用（hash=%llu）→ 请求重扫分类缓存", (unsigned long long)fg);
        }
    }
    g_smartLastTarget = CPUthermalPowerModeNative;
    return CPUthermalPowerModeNative;                                               // 识别不到（无分类信息，如自签）：原生（可手动加两个名单）
}
// ★ T7w：App 档位查询（1=高性能 2=低频率 3=原生 0=无/自动）
static int CPUthermalTierForHash(uint64_t ctHv) {
    if (!ctHv) return 0;
    if (g_tierFullHashes && [g_tierFullHashes containsObject:@(ctHv)]) return 1;
    if (g_tierLowHashes && [g_tierLowHashes containsObject:@(ctHv)]) return 2;
    if (g_tierNativeHashes && [g_tierNativeHashes containsObject:@(ctHv)]) return 3;
    return 0;
}
static CPUthermalPowerMode CPUthermalResolveTargetModeRaw(CPUthermalPowerMode selected, BOOL blanked, BOOL appLowPower) {
    if (!blanked) {
        // ★ T7x5/T7z5："读数抖动吸收"——前台读数会瞬时空一下（切 App / 进多任务瞬间尤甚，
        //   日志实锤最长 ~5 秒）。T7z5 升级：轨迹由每秒心跳持续保鲜（CTBlipTrackForeground），
        //   吸收窗口 2→5 秒；5 秒内的读空一律沿用"上一个真实 App"继续判定，不再误判成
        //   "回桌面"而交还系统。（代价：真回桌面切原生最多晚 ~5 秒）
        uint64_t ctT7Fg = CPUthermalReadForegroundBundleHash();
        if (ctT7Fg != 0 && ctT7Fg != CPUthermalBundleIDHash(S("com.apple.springboard"))) {
            g_ctBlipHash = ctT7Fg;
            g_ctBlipAt = CFAbsoluteTimeGetCurrent();
        }
        if (ctT7Fg == 0) {
            if (g_ctBlipHash != 0 && (CFAbsoluteTimeGetCurrent() - g_ctBlipAt) < 5.0) {
                ctT7Fg = g_ctBlipHash;   // 抖动/间隙：按"上一个真实 App"继续判定（走下面的档位/智能逻辑）
            } else {
                // 桌面（无应用）——低功耗模式：桌面也压（开关打开则交还系统=原生）；智能 / 性能模式仍交还系统
                if (!g_smartEnabled && selected == CPUthermalPowerModeLow && !g_lowPowerDesktopNative) return CPUthermalPowerModeLow;
                return CPUthermalPowerModeNative;
            }
        }
        // ★ T7w：每 App 档位优先（三种模式通用）
        int ctTier = CPUthermalTierForHash(ctT7Fg);
        if (ctTier == 1) return CPUthermalPowerModeFull;
        if (ctTier == 2) return CPUthermalPowerModeLow;
        if (ctTier == 3) return CPUthermalPowerModeNative;
        // ★ T7z26：游戏强制高性能——识别为"游戏"的 App 一律按高性能执行（无视常驻模式；仅档位可覆盖）
        if (g_gameForceFull && g_smartGameHashes && [g_smartGameHashes containsObject:@(ctT7Fg)]) {
            return CPUthermalPowerModeFull;
        }
    }
    if (g_smartEnabled) return CPUthermalSmartResolveTarget(blanked);
    if (blanked) return CPUthermalPowerModeLow;
    if (appLowPower) return (selected == CPUthermalPowerModeLow) ? CPUthermalPowerModeFull : CPUthermalPowerModeLow;
    return selected;
}
static CPUthermalPowerMode CPUthermalResolveTargetMode(CPUthermalPowerMode selected, BOOL blanked, BOOL appLowPower) {
    // ★ 269：滑动放行改为"静默"实现（不再改变模式/不再产生模式跳变记录），这里纯透传
    CPUthermalPowerMode ctRM = CPUthermalResolveTargetModeRaw(selected, blanked, appLowPower);
    if (g_overheatActive && ctRM != CPUthermalPowerModeLow) ctRM = CPUthermalPowerModeLow;   // ★ 1.4.6s：过热保护优先（临时低功耗）
    return ctRM;
}

// 常驻模式（从偏好读，避免各调用点重复取值）
static CPUthermalPowerMode CPUthermalSelectedModeFromPrefs(NSDictionary *prefs) {
    NSString *mode = [prefs isKindOfClass:[NSDictionary class]] ? prefs[S("powerMode")] : nil;
    return ([mode isKindOfClass:[NSString class]] && [mode isEqualToString:S("lowPower")])
        ? CPUthermalPowerModeLow : CPUthermalPowerModeFull;
}

// 低功耗模式的「高性能名单」：命中后该 App 不套低功耗，高性能运行（不卡）
static BOOL foregroundAppForcesFullPower(NSDictionary *prefs) {
    if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
    if (CPUthermalTierSystemActive(prefs)) return NO;   // ★ T7x：旧名单退役（档位"高性能"由 resolve 的档位优先处理）
    NSArray *list = [prefs[S("fullPowerApps")] isKindOfClass:[NSArray class]] ? prefs[S("fullPowerApps")] : nil;
    if (list.count == 0) return NO;
    uint64_t foregroundHash = CPUthermalReadForegroundBundleHash();
    if (foregroundHash == 0) return NO;
    if (foregroundHash == CPUthermalBundleIDHash(S("com.apple.springboard"))) return NO;   // ★ 桌面进程永不匹配名单（旧版残留勾选也不生效）
    for (id rawBundleID in list) {
        if ([rawBundleID isKindOfClass:[NSString class]] && CPUthermalBundleIDHash(rawBundleID) == foregroundHash) return YES;
    }
    return NO;
}

// 两份名单互相独立：常驻「低功耗」用高性能名单；常驻「性能模式」用低功耗名单。
static BOOL foregroundAppListHit(CPUthermalPowerMode selected, NSDictionary *prefs) {
    if (g_smartEnabled) return NO;   // ★ 智能模式：两份名单不参与判定（高性能例外走内部缓存）
    return (selected == CPUthermalPowerModeLow) ? foregroundAppForcesFullPower(prefs)
                                               : foregroundAppShouldUseLowPower(prefs);
}

// ★★★ 统一规则（2026-09-15）：名单例外生效期间，只有"前台确实变成了另一个真实 App"才允许改变运行模式。
//      其余一切情况（读不到 / 锁屏界面 / 仍触发例外的那个 App）→ 一律保持，绝不撤销。
static BOOL CPUthermalForegroundAllowsModeChange(void) {
    if (!g_foregroundAppForcesLowPower) return YES;                 // 没有例外在生效 → 正常判定
    uint64_t fg = CPUthermalReadForegroundBundleHash();
    if (fg == 0) return NO;                                        // 读不到 → 保持
    if (fg == CPUthermalBundleIDHash(S("com.apple.springboard"))) return NO;  // 锁屏界面/桌面 → 保持
    if (fg == g_exceptionAppHash) return NO;                       // 还是触发例外的那个 App → 保持
    return YES;                                                    // 确实是另一个真实 App → 允许改
}

// 从配置文件直接同步“用户选择的模式”并立即应用（解决：面板写 plist 与发通知有先后延迟，导致要切换多次才生效）
static void CPUthermalSyncModeFromPrefs(void) {
    if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
    NSDictionary *prefs = readPrefsDictionary();
    if (!prefs) return;
    id raw = [prefs objectForKey:S("powerMode")];
    if (g_schedActiveMode >= 0) raw = CTScheduleModeName(g_schedActiveMode);   // ★ T7z16：定时时段覆盖档位
    if (![raw isKindOfClass:[NSString class]]) return;
    // ★ T7v：同步刷新"智能模式"标志（防"切换失效"）
    g_smartEnabled = [raw isEqualToString:S(kCPUthermalSmartModeC)];
    CPUthermalPowerMode selected = [raw isEqualToString:S("lowPower")] ? CPUthermalPowerModeLow : CPUthermalPowerModeFull;
    // ★★ 关键修复：唤醒/解锁后 8 秒内"只更新用户选择的模式"，不重算运行模式。
    //     否则锁屏界面上前台=SpringBoard → 名单不命中 → 按常驻模式重算 → 把刚恢复的低功耗顶成高性能。
    if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
        g_userSelectedPowerMode = selected;
        return;
    }
    // ★ 统一规则：例外生效期间，前台不是"另一个真实 App"→ 不重算运行模式
    if (!CPUthermalForegroundAllowsModeChange()) {
        g_userSelectedPowerMode = selected;
        return;
    }
    BOOL blanked = CPUthermalScreenIsBlanked();
    BOOL appLowPower = foregroundAppListHit(selected, prefs);
    CPUthermalPowerMode prev = g_powerMode;
    g_userSelectedPowerMode = selected;
    g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("sync-prefs", appLowPower);
    CTAuditMode("sync-prefs", CPUthermalResolveTargetMode(selected, blanked, appLowPower));
    if (prev != g_powerMode) applyPowerModeToRuntime(NO);
}

static void loadPrefs(void) {
@autoreleasepool {
NSDictionary *d = readPrefsDictionary();
// 关键修复：读取失败时立即返回，保留当前内存中正确的 g_powerMode，防止回退到性能模式
if (!d || d.count == 0) return;

BOOL enabled = YES;
BOOL blockPopup = [d[S("thermalBlockNotifPopup")] ?: @NO boolValue];
BOOL preventDimming = [d[S("thermalPreventDimmingEnabled")] ?: @NO boolValue];
BOOL hipLocked = [d[S("hipLockedEnabled")] ?: @NO boolValue];
g_hipLockedEnabled = hipLocked;
g_overheatAutoProtect = [d[S("thermalPressureAutoProtectionEnabled")] ?: @NO boolValue];
g_nominalAutoRecover  = [d[S("thermalNominalAutoRecoveryEnabled")] ?: @YES boolValue];
os_unfair_lock_lock(&g_stateLock);
g_enabled = enabled;
g_thermalBlockNotifPopup = blockPopup;
g_thermalPreventDimmingEnabled = preventDimming;
os_unfair_lock_unlock(&g_stateLock);

NSString *mode = [d[S("powerMode")] isKindOfClass:[NSString class]] ? d[S("powerMode")] : nil;
if (g_schedActiveMode >= 0) mode = CTScheduleModeName(g_schedActiveMode);   // ★ T7z16：定时时段覆盖档位
CPUthermalPowerMode selected;
if (mode) {
    selected = [mode isEqualToString:S("lowPower")] ? CPUthermalPowerModeLow : CPUthermalPowerModeFull;
} else {
    // ★ T7x3：键缺失（读取不完整）→ 保持当前用户模式，绝不默认"性能模式"（否则智能被关掉+高性能乱跳）
    os_unfair_lock_lock(&g_modeLock);
    selected = g_userSelectedPowerMode;
    os_unfair_lock_unlock(&g_modeLock);
}
// ★ 智能模式（T7h）：读取开关 + 重建分类缓存（关着时=原有两档逻辑，一行不受影响）
// ★ T7x3：只有确实读到模式字符串才刷新智能开关——读不到时保持原值
BOOL smartNow = (mode && [mode isEqualToString:S(kCPUthermalSmartModeC)]);
if (mode) g_smartEnabled = smartNow;
g_gameForceFull = [d[S("gameForceFullEnabled")] ?: @YES boolValue];   // ★ T7z26：游戏强制高性能（默认开）
if (smartNow || g_gameForceFull) {
    CPUthermalRebuildSmartAppClasses(d);
    if (smartNow) CTD("[智能] 已启用：游戏→高性能 / 其他应用→低频率 / 桌面→原生");
    CTD("[游戏高性能] 开关=%d（识别为游戏的 App 一律高性能）", g_gameForceFull ? 1 : 0);
}

    // ★ T7w：App 档位表（appTiers）→ 哈希集合；未迁移时用旧名单兜底（三种模式通用）
    {
        NSMutableSet *ctTf = [NSMutableSet set], *ctTl = [NSMutableSet set], *ctTn = [NSMutableSet set];
        NSDictionary *ctTiers = [d[S("appTiers")] isKindOfClass:[NSDictionary class]] ? d[S("appTiers")] : nil;
        // ★ T7x：档位体系接管后，旧名单不再"兜底"——否则"全部重置为自动"后旧钉档仍在偷偷生效（微信仍高性能的元凶）
        BOOL ctTierSystem = CPUthermalTierSystemActive(d);
        if (ctTierSystem) {
            for (id ctBid in ctTiers) {
                if (![ctBid isKindOfClass:[NSString class]] || ![ctBid length]) continue;
                NSString *ctT = ctTiers[ctBid];
                if (![ctT isKindOfClass:[NSString class]]) continue;
                uint64_t ctHv = CPUthermalBundleIDHash(ctBid);
                if ([ctT isEqualToString:S("full")]) [ctTf addObject:@(ctHv)];
                else if ([ctT isEqualToString:S("low")]) [ctTl addObject:@(ctHv)];
                else if ([ctT isEqualToString:S("native")]) [ctTn addObject:@(ctHv)];
            }
        } else {
            id ctF = d[S("fullPowerApps")], ctL = d[S("lowPowerApps")];
            if ([ctF isKindOfClass:[NSArray class]]) for (id ctBid in ctF) if ([ctBid isKindOfClass:[NSString class]]) [ctTf addObject:@(CPUthermalBundleIDHash(ctBid))];
            if ([ctL isKindOfClass:[NSArray class]]) for (id ctBid in ctL) if ([ctBid isKindOfClass:[NSString class]]) [ctTl addObject:@(CPUthermalBundleIDHash(ctBid))];
        }
        g_tierFullHashes = ctTf; g_tierLowHashes = ctTl; g_tierNativeHashes = ctTn;
        CTD("[档位] 已加载：高性能 %lu / 低频率 %lu / 原生 %lu（其余自动）", (unsigned long)ctTf.count, (unsigned long)ctTl.count, (unsigned long)ctTn.count);
    }

    // ★ T7w：滑动提速开关（默认开）
    g_scrollBoostEnabled = [d[S("scrollBoostEnabled")] ?: @NO boolValue];   // 默认关（设置页打开才生效）
    g_ctIdleSinkEnabled = [d[S("idleSinkEnabled")] ?: @YES boolValue];      // ★ T7z6：无操作深度省电（默认开）
    g_ctVideoOptEnabled = [d[S("videoProfileEnabled")] ?: @YES boolValue];  // ★ T7z6：视频场景优化（默认开）
    g_ctVideoDeepEnabled = [d[S("videoDeepEnabled")] ?: @NO boolValue];    // ★ T7z7：视频中也深度省电（默认关）
    g_lowPowerDesktopNative = [d[S("lowPowerDesktopNative")] ?: @NO boolValue];   // ★ T7x6：低功耗模式「桌面原生频率」（默认关=桌面也压）
    // ★ 1.4.6 充电管家（默认：数据显示开、其余全关）
    g_ctcLimitOn   = [d[S("chargeLimitEnabled")] ?: @NO boolValue];
    g_ctcLimitVal  = [d[S("chargeLimitValue")] ?: @80 intValue];
    if (g_ctcLimitVal < 50) g_ctcLimitVal = 50;
    if (g_ctcLimitVal > 100) g_ctcLimitVal = 100;
    g_ctcTempOn    = [d[S("chargeTempProtectEnabled")] ?: @NO boolValue];
    g_ctcTempVal   = [d[S("chargeTempThreshold")] ?: @42 intValue];
    if (g_ctcTempVal < 35) g_ctcTempVal = 35;
    if (g_ctcTempVal > 55) g_ctcTempVal = 55;
    g_ctcGameOn    = [d[S("chargeGameLimitEnabled")] ?: @NO boolValue];
    g_ctcGameW     = [d[S("chargeGameLimit")] ?: @10 intValue];      // 慢速充电档位：10 / 15（W）
    g_ctcForceOn   = [d[S("chargeForceEnabled")] ?: @NO boolValue];
    g_ctcSlowOn    = [d[S("chargeSlowEnabled")] ?: @NO boolValue];
    g_ctcDisplayOn = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];
    NSString *ctSimS = d[S("chargeSimLevel")];
    g_ctcSimLev = [ctSimS isEqualToString:S("light")] ? 1 : ([ctSimS isEqualToString:S("moderate")] ? 2 : ([ctSimS isEqualToString:S("heavy")] ? 3 : 0));
    g_floatWindowEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];          // ★ T7z16：悬浮窗开关
    CTScheduleLoadFromPrefs(d);                                                    // ★ T7z16：定时切档配置
BOOL blanked = CPUthermalScreenIsBlanked();
BOOL appLowPower=foregroundAppListHit(selected, d);
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
if (CPUthermalForegroundAllowsModeChange()) {          // ★ 统一规则守卫
    g_foregroundAppForcesLowPower=appLowPower;
    CTAuditMode("loadPrefs", CPUthermalResolveTargetMode(selected, blanked, appLowPower));
}
os_unfair_lock_unlock(&g_modeLock);
}

// ★ T5：设置读取成功后——①标记已读 ②若不在锁屏中，把"锁屏前模式"同步为当前模式（防止残留默认值被解锁恢复用上）
g_prefsLoaded = YES;
if (!CPUthermalScreenIsBlanked()) {
os_unfair_lock_lock(&g_modeLock);
g_modeBeforeSleep = g_powerMode;
os_unfair_lock_unlock(&g_modeLock);
CTD("[写睡前] loadPrefs同步: → %s", g_modeBeforeSleep == CPUthermalPowerModeLow ? "低功耗" : "高性能");
}
}

// ============================================================================
// 热管理 IOKit 服务名
// ============================================================================
static const char *g_hotServices[] = {
"AppleSPU", "AppleSPU.original",
"AppleARMPlatform",
"pmu", "ApplePMGR",
"AppleGPU", "AGXDriver",
"ANECompilerService", "AppleANE",
"AppleM2ScalerCSC", "IOSurface",
NULL
};

#define SELECTOR_IS_MITIGATION(s)  ((s) >= 0x20 && (s) <= 0x5F)  // 拦截 0x20-0x5F（扩展低频管理+温控）
#define SELECTOR_IS_CRITICAL(s)    ((s) >= 0x60)                  // 紧急保护 — 不拦截

// ============================================================================
// connection 追踪
// ============================================================================
#define MAX_CONN 64

typedef struct {
io_connect_t conn;
BOOL         isThermal;
} ConnEntry;

static ConnEntry g_conns[MAX_CONN];
static int g_connCount = 0;
static os_unfair_lock g_connLock = OS_UNFAIR_LOCK_INIT;  // 线程安全：保护 g_conns/g_connCount

static void trackConnection(io_connect_t conn, BOOL thermal) {
if (conn == MACH_PORT_NULL) return;
os_unfair_lock_lock(&g_connLock);
if (g_connCount < MAX_CONN) {
g_conns[g_connCount].conn     = conn;
g_conns[g_connCount].isThermal = thermal;
g_connCount++;
}
os_unfair_lock_unlock(&g_connLock);
}

static BOOL serviceIsThermal(io_service_t service) {
if (service == MACH_PORT_NULL) return NO;
io_name_t name = {0};
if (IORegistryEntryGetName(service, name) != KERN_SUCCESS) return NO;
for (int i = 0; g_hotServices[i]; i++) {
if (strcmp(name, g_hotServices[i]) == 0) return YES;
}
return NO;
}

// ============================================================================
// IOKit 层钩子
// ============================================================================

// --- IOServiceOpen — 追踪 thermal connection ---
%hookf(kern_return_t, IOServiceOpen, io_service_t service, task_t task, uint32_t type, io_connect_t *connect) {
kern_return_t ret = %orig;
if (ret == KERN_SUCCESS && connect && *connect != MACH_PORT_NULL) {
trackConnection(*connect, serviceIsThermal(service));
}
return ret;
}

// --- IOServiceClose — 清理已断开的 thermal connection（防止 g_conns 数组溢出后拦截失效）---
%hookf(kern_return_t, IOServiceClose, io_connect_t connect) {
if (connect == MACH_PORT_NULL) return %orig(connect);
os_unfair_lock_lock(&g_connLock);
for (int i = 0; i < g_connCount; i++) {
if (g_conns[i].conn == connect) {
for (int j = i; j < g_connCount - 1; j++) {
g_conns[j] = g_conns[j + 1];
}
g_connCount--;
break;
}
}
os_unfair_lock_unlock(&g_connLock);
return %orig(connect);
}

// --- IOConnectCallMethod — 保留连接追踪，不再按 selector 范围盲拦截 ---
%hookf(kern_return_t, IOConnectCallMethod, mach_port_t connection, uint32_t selector, const uint64_t *input, uint32_t inputCnt, const void *inputStruct, size_t inputStructCnt, uint64_t *output, uint32_t *outputCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

// 异步与结构体调用必须放行，否则 ObjC 层强制后的目标也无法真正写入 ApplePPM。
%hookf(kern_return_t, IOConnectCallAsyncMethod, mach_port_t connection, uint32_t selector, mach_port_t wakePort, mach_port_t *asyncRef, uint32_t asyncRefCnt, const void *inputStruct, size_t inputStructCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

%hookf(kern_return_t, IOConnectCallStructMethod, mach_port_t connection, uint32_t selector, const void *inputStruct, size_t inputStructCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

// --- IOServiceSetProperty — 丢弃 thermalmonitord 的频率/功耗约束属性 ---
static kern_return_t (*orig_IOServiceSetProperty)(io_service_t, CFStringRef, CFTypeRef) = NULL;

static kern_return_t hooked_IOServiceSetProperty(io_service_t service, CFStringRef key, CFTypeRef value) {
if (!orig_IOServiceSetProperty) return KERN_FAILURE;
if (service == MACH_PORT_NULL || !key || !value) return orig_IOServiceSetProperty(service, key, value);
if (!runtimeEnabled() || g_restoringFullPower) {
return orig_IOServiceSetProperty(service, key, value);
}

if (isNetworkThrottleProperty(key)) {
return KERN_SUCCESS;
}

NSString *keyString = (__bridge NSString *)key;
if (thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(keyString)) {
    id replacement = nil;
    if (CFGetTypeID(value) == CFNumberGetTypeID() || CFGetTypeID(value) == CFStringGetTypeID()) {
        replacement = backlightReplacementMatchingValue(keyString, (__bridge id)value);
    }
    kern_return_t result = replacement ? orig_IOServiceSetProperty(service, key, (__bridge CFTypeRef)replacement) : orig_IOServiceSetProperty(service, key, value);
    CPUthermalRecommitUserBrightnessSoon();
    return result;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(keyString) && valueMeansStopChargingCF(keyString, value) && g_ctcCapacity < 99) {
CTChargeNoteIntercept(keyString);
return KERN_SUCCESS;
}
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(keyString)) {
return KERN_SUCCESS;
}
return orig_IOServiceSetProperty(service, key, value);
}

%hookf(kern_return_t, IORegistryEntrySetCFProperty, io_registry_entry_t entry, CFStringRef key, CFTypeRef value) {
if (entry == MACH_PORT_NULL || !key || !value) return %orig(entry, key, value);
if (!runtimeEnabled() || g_restoringFullPower) return %orig(entry, key, value);
if (isNetworkThrottleProperty(key)) return KERN_SUCCESS;
NSString *keyString = (__bridge NSString *)key;
if (thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(keyString)) {
    id replacement = nil;
    if (CFGetTypeID(value) == CFNumberGetTypeID() || CFGetTypeID(value) == CFStringGetTypeID()) {
        replacement = backlightReplacementMatchingValue(keyString, (__bridge id)value);
    }
    kern_return_t result;
    if (replacement) {
        result = %orig(entry, key, (__bridge CFTypeRef)replacement);
    } else {
        result = %orig(entry, key, value);
    }
    CPUthermalRecommitUserBrightnessSoon();
    return result;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(keyString) && valueMeansStopChargingCF(keyString, value) && g_ctcCapacity < 99) {
CTChargeNoteIntercept(keyString);
return KERN_SUCCESS;
}
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(keyString)) {
return KERN_SUCCESS;
}
return %orig(entry, key, value);
}

%hookf(kern_return_t, IORegistryEntrySetCFProperties, io_registry_entry_t entry, CFTypeRef properties) {
if (entry == MACH_PORT_NULL || !properties) return %orig(entry, properties);
if (g_ctcSelfWrite) return %orig(entry, properties);   // ★ 1.4.6：我们自己写的充电属性直接放行
if (!runtimeEnabled() || g_restoringFullPower) return %orig(entry, properties);
CFDictionaryRef replacement = copyPropertiesByRemovingThermalLimits(properties);
if (!replacement) return %orig(entry, properties);
if (CFDictionaryGetCount(replacement) == 0) {
CFRelease(replacement);
return KERN_SUCCESS;
}
kern_return_t result = %orig(entry, replacement);
CFRelease(replacement);
return result;
}

// ============================================================================
// ObjC 类钩子（第1层: CommonProduct / HidSensors — 已有）
// ============================================================================

// --- CommonProduct: thermalmonitord 核心热管理对象 ---
%hook CommonProduct

- (id)initProduct:(id)arg1 {
id res = %orig;
if (res && runtimeEnabled()) {
installCrossVersionThermalAliases();
setCommonProduct((CommonProduct *)res);
if (shouldApplyFullCPUProtection()) {
{ SEL ctTSSel = CTObfSel("2a2f2e1e3f2c33393f13340e323f28373b360933372f363b2e33353417353e3f60"); if (ctTSSel) ((void (*)(id, SEL, id))objc_msgSend)((id)res, ctTSSel, CTObfStr("34353733343b36")); }
}
applyCurrentPowerModeToRuntime();
CTLOG(S("[CPUthermal] CommonProduct init, 功率模式:%@"), isLowPowerMode() ? S("低功耗") : S("性能模式"));
}
return res;
}

- (void)tryTakeAction {
if (shouldApplyFullCPUProtection()) {
// 强制热压力为 Nominal（最多每秒校正一次，避免快循环广播）
correctNominalStateIfNeeded();
// 阻止所有热缓解动作
return;
}
%orig;
}

- (void)simulateLightThermalPressure {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

- (void)updatePowerzoneTelemetry {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

// 低功耗开启 CPU CPMS 使 Level2/预算落硬件；性能模式关闭 CPMS。
- (void)setCPMSMitigationsEnabled:(BOOL)enabled {
if (g_restoringFullPower) {
%orig(enabled);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(YES);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(enabled);
}

// 性能模式: 直接阻断 CPU 节流等级写入，拒绝执行降频指令。
- (void)setCPULevel:(int)level {
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

%end

// --- HidSensors: HID 温度事件处理（与「屏蔽高温温度计警告」共用开关）---
%hook HidSensors

- (void)handleTemperatureEvent:(int)arg1 service:(id)arg2 {
if (thermalPopupBlockingEnabled()) {
if (shouldApplyFullCPUProtection()) CPUthermalForceNominalCombined();
return;
}
%orig(arg1, arg2);
}

%end

// ============================================================================
// ObjC 类钩子（第2层: ThermalManager 决策层）
//
// 冲突避免说明:
//   - 传感器读数 getHighestSkinTemp/dieTempFilteredMaxAverage/thermalSensorValuesMaxFromIndexSet
//     不在此处 hook (IOKit 层已拦截)
//   - putDeviceInThermalSimulationMode: 不 hook (CPUthermal 自已调用会递归)
//   - setCPMSMitigationState: 直接在决策层拦截，避免进入 CPMS 写路径
//   - setHiPFeatureEnabled: 不 hook
// ============================================================================

// --- ThermalManager: hook 决策树和热压力升级 ---
%hook ThermalManager

// 决策树评估 — 这是 thermalmonitord 判断"要不要降频"的核心
- (void)evaluateDecisionTree {
// 全功率模式: 阻止决策树运行，避免温控降频
if (shouldApplyFullCPUProtection()) {
correctNominalStateIfNeeded();
return;
}
%orig;
}

- (void)setCPMSMitigationState:(int)state {
if (shouldApplyFullCPUProtection()) {
%orig(0);
return;
}
%orig(state);
}

// 热压力升级通知 — 不再主动阻断
- (void)updateThermalPressureLevelNotification:(id)notification shouldForceThermalPressure:(BOOL)force {
if (thermalPopupBlockingEnabled()) {
if (shouldApplyFullCPUProtection()) CPUthermalForceNominalCombined();
return;
}
%orig(notification, force);
}

// 热通知 — 受 thermalBlockNotifPopup 开关控制
- (void)updateThermalNotification:(id)notification {
@autoreleasepool {
if (thermalPopupBlockingEnabled()) {
return;
}
}
%orig;
}

// 是否应执行轻度热压力 — 不拦截
- (BOOL)shouldEnforceLightThermalPressure {
return %orig;
}

// 获取组件释放速率 — 可以降低不放 0
- (float)getReleaseRateForComponent:(id)component {
if (shouldApplyFullCPUProtection()) {
return 0.0;  // 彻底归零
}
return %orig(component);
}

// 获取强制热级别 — 不篡改
- (int)getPotentialForcedThermalLevel:(id)component {
return %orig(component);
}

// 获取强制热压力级别 — 不篡改
- (int)getPotentialForcedThermalPressureLevel {
return %orig;
}

// 散热/电池服务建议 — 不拦截
- (id)getBatteryServiceSuggestion:(id)suggestion {
return %orig(suggestion);
}

%end

// --- ThermalControl: hook 控制力度计算 ---
%hook ThermalControl

- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams {
id res = %orig(fastLoop, noDisplay, saveParams, zoneParams);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (id)initWithParams:(id)params {
id res = %orig(params);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (BOOL)powerSaveActive {
if (g_restoringFullPower) return %orig;
// 手动低功耗仅限 CPU，不向系统/显示层暴露全局 PowerSave。
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return NO;
return %orig;
}

- (void)setPowerSaveActive:(BOOL)active {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(active);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(active);
}

- (void)setPowerSaveToken:(id)token {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(token);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(nil);
return;
}
%orig(token);
}

// 计算控制力度 — 这是 throttle 量的核心
// soften 模式下减半但不归零，保留基础调节能力
- (float)calculateControlEffort:(id)trigger trigger:(id)arg2 {
if (shouldApplyFullCPUProtection()) {
return 0.0;  // 彻底归零，不降频
}
return %orig(trigger, arg2);
}

// actionComponentControl — 组件控制动作
- (void)actionComponentControl {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

// readReleaseRateForAllComponents — 全组件释放速率
- (void)readReleaseRateForAllComponents {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

%end

// --- ApplePPMCPU: 兼容部分系统版本；当前主路径由 MitigationController 执行 ---
%hook ApplePPMCPU

// 修复：追踪实例，确保 keep-alive 能强制重应用（弱引用防止僵尸实例泄漏）
- (id)init {
id res = %orig;
if (res) {
trackApplePPMInstance(res);
}
return res;
}

- (void)setCPULevel:(int)level {
// 修复：每次调用都自注册实例，确保唤醒后重建的实例不被漏追踪
trackApplePPMInstance(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
// 性能模式: 直接阻断节流等级，ApplePPM 保持内核原生 DVFS 自由调频
return;
}
%orig;
}

- (void)updateCPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyLowPowerLimit()) {
if (self && [self respondsToSelector:CTObfSel("293f2e190a0f163f2c3f3660")]) {
[self setCPULevel:CTLowPowerLevel()];
}
%orig;
return;
}
// 性能模式只在模式切换时清除 Level 2；后续放行原生 DVFS 更新。
%orig;
}

%end

// --- MitigationController: 功率目标控制 ---
%hook MitigationController

- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams {
id res = %orig(fastLoop, noDisplay, saveParams, zoneParams);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (void)setCPMSMitigationsEnabled:(BOOL)enabled {
if (g_restoringFullPower) {
%orig(enabled);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(YES);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(enabled);
}

- (BOOL)powerSaveActive {
if (g_restoringFullPower) return %orig;
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return NO;
return %orig;
}

- (void)setPowerSaveActive:(BOOL)active {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(active);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(active);
}

- (void)setPowerSaveToken:(int)token {
if (g_restoringFullPower) {
%orig(token);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(0);
return;
}
%orig(token);
}

// 性能模式: 直接阻断 CPU 节流等级写入（MitigationController 使用 0~100 百分比）。
- (void)setCPULevel:(int)level {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

// 性能模式: 直接阻断 CPU 温控缓解等级写入。
- (void)setCPUMitigationLevel:(int)level {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(level);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)setDVD1Level:(int)level {
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(level);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)updateCPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyLowPowerLimit()) {
reassertLowPowerStateWithoutUpdate(self);
%orig;
reassertLowPowerStateWithoutUpdate(self);
return;
}
if (shouldApplyFullCPUProtection()) {
trackPowerController(self);
%orig;
return;
}
%orig;
}

- (void)updateGPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyFullCPUProtection()) {
%orig;
return;
}
%orig;
}

- (void)updatePackage {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyFullCPUProtection()) {
%orig;
return;
}
%orig;
}

- (void)setCPULowPowerTarget:(int)target {
if (shouldApplyLowPowerLimit() && target != CTLowPowerBudgetMW()) {
CTD("★系统抢值 setCPULowPowerTarget 系统=%d → 我们强制=%d", target, CTLowPowerBudgetMW());
}
if (g_restoringFullPower) {
%orig(target);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerBudgetMW());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPowerLimitMW);
return;
}
%orig(target);
}

- (void)setPackageLowPowerTarget {
if (g_restoringFullPower) {
%orig;
return;
}
// 两种用户模式都不允许 Package 低功耗联动；低功耗只由 CPU 专用 setter 实现。
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return;
%orig;
}

- (void)setMaxCPUPowerTarget:(int)target useLegacyPath:(BOOL)legacy setProperty:(uintptr_t)property {
uintptr_t propertyArg = normalizedSetMaxCPUPowerPropertyArgument(self, property);
if (g_restoringFullPower) {
%orig(target, legacy, propertyArg);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerBudgetMW(), NO, propertyArg);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPowerLimitMW, NO, propertyArg);
return;
}
%orig(target, legacy, propertyArg);
}

- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setCPUPowerCeiling:(int)ceiling forDVD1Contributor:(int)contributor {
if (g_restoringFullPower) {
%orig(ceiling, contributor);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent, contributor);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, contributor);
return;
}
%orig(ceiling, contributor);
}

- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source {
if (g_restoringFullPower) {
%orig(floor, source);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(0, source);
return;
}
if (shouldApplyFullCPUProtection()) {
// Ceiling 保持 100，但 Floor 固定为 0，让无负载核心进入原生空闲频点。
%orig(0, source);
return;
}
%orig(floor, source);
}

- (void)setCPUPowerZoneTarget:(int)target {
if (g_restoringFullPower) {
%orig(target);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent);
return;
}
%orig(target);
}

%end

// ============================================================================
// 防温控暗屏 — 修补热配置 plist 中的背光参数
// 由 thermalPreventDimmingEnabled 开关控制
// ============================================================================

// 按 Insulation 结构恢复 backlightComponentControl 的无热限制档位。
static NSMutableArray *CPUthermalFillBacklightArrayFromFirst(NSArray *source) {
    if (![source isKindOfClass:[NSArray class]] || source.count == 0) return nil;
    id first = source.firstObject;
    // 新机型常为 {level,down,up} 字典数组，旧实现只接受 NSNumber 导致整段补丁失效。
    if (![first isKindOfClass:[NSNumber class]] && ![first isKindOfClass:[NSDictionary class]]) return nil;
    NSMutableArray *result = [source mutableCopy];
    for (NSUInteger i = 1; i < result.count; i++) result[i] = [first copy];
    return result;
}

static BOOL CPUthermalIsDisplayMitigationKey(NSString *key);
static id CPUthermalZeroDisplayMitigationValue(id original);

static void CPUthermalPatchBacklightControl(NSMutableDictionary *backlight) {
    if (![backlight isKindOfClass:[NSMutableDictionary class]]) return;
    NSArray *brightness = [backlight[S("BacklightBrightness")] isKindOfClass:[NSArray class]]
        ? backlight[S("BacklightBrightness")] : nil;
    NSMutableArray *brightnessPatched = CPUthermalFillBacklightArrayFromFirst(brightness);
    if (brightnessPatched) {
        backlight[S("BacklightBrightness")] = brightnessPatched;
        id first = brightnessPatched.firstObject;
        if ([first isKindOfClass:[NSNumber class]]) g_maxBacklightBrightnessValue = first;
    }
    NSArray *power = [backlight[S("BacklightPower")] isKindOfClass:[NSArray class]]
        ? backlight[S("BacklightPower")] : nil;
    NSMutableArray *powerPatched = CPUthermalFillBacklightArrayFromFirst(power);
    if (powerPatched) backlight[S("BacklightPower")] = powerPatched;
    backlight[S("expectsCPMSSupport")] = [NSNumber numberWithBool:NO];
    backlight[S("maxThermalPower")] = [NSNumber numberWithInt:kUnrestrictedPowerLimitMW];
    backlight[S("minThermalPower")] = [NSNumber numberWithInt:kUnrestrictedPowerLimitMW];
    for(id rawKey in [backlight.allKeys copy]) if([rawKey isKindOfClass:[NSString class]] && CPUthermalIsDisplayMitigationKey(rawKey))
        backlight[rawKey]=CPUthermalZeroDisplayMitigationValue(backlight[rawKey]);
    CPUthermalScheduleBacklightRecovery();
}

static BOOL CPUthermalIsDisplayMitigationKey(NSString *key) {
    if (![key isKindOfClass:[NSString class]]) return NO;
    const char *keys[]={"needsPushingTSFDtoDisplayDriver","displayBrightnessMitigation","displayMitigation","eventDimmingEnabled","needsContextualClamp","shouldEnforceLightThermalPressure","shouldEnforceThermalPressure","thermalPressureMitigation","performanceMitigation",NULL};
    for(int i=0;keys[i];i++)if([key caseInsensitiveCompare:S(keys[i])]==NSOrderedSame)return YES;
    return NO;
}

static id CPUthermalZeroDisplayMitigationValue(id original) {
    if ([original isKindOfClass:[NSString class]]) return S("0");
    if ([original isKindOfClass:[NSNumber class]]) return [NSNumber numberWithInt:0];
    return original;
}

static id CPUthermalPatchBacklightNode(id node) {
    if ([node isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *result = [(NSDictionary *)node mutableCopy];
        for (id rawKey in [(NSDictionary *)node allKeys]) {
            id value = [(NSDictionary *)node objectForKey:rawKey];
            if ([rawKey isKindOfClass:[NSString class]] && CPUthermalIsDisplayMitigationKey(rawKey)) {
                result[rawKey]=CPUthermalZeroDisplayMitigationValue(value);
                continue;
            }
            if ([rawKey isKindOfClass:[NSString class]] &&
                [(NSString *)rawKey caseInsensitiveCompare:S("backlightComponentControl")] == NSOrderedSame &&
                [value isKindOfClass:[NSDictionary class]]) {
                NSMutableDictionary *backlight = [value mutableCopy];
                CPUthermalPatchBacklightControl(backlight);
                result[rawKey] = backlight;
            } else {
                result[rawKey] = CPUthermalPatchBacklightNode(value) ?: value;
            }
        }
        return result;
    }
    if ([node isKindOfClass:[NSArray class]]) {
        NSMutableArray *result = [NSMutableArray arrayWithCapacity:[node count]];
        for (id value in node) [result addObject:CPUthermalPatchBacklightNode(value) ?: value];
        return result;
    }
    return node;
}

static NSDictionary *patchThermalPlist(NSDictionary *dict) {
    if (![dict isKindOfClass:[NSDictionary class]] || !thermalDimmingPreventionEnabled()) return dict;
    // DeviceMonitor 的 _getConfigurationFor 可能直接返回 backlightComponentControl 子字典。
    if ([dict[S("BacklightBrightness")] isKindOfClass:[NSArray class]]) {
        NSMutableDictionary *direct = [dict mutableCopy];
        CPUthermalPatchBacklightControl(direct);
        return direct;
    }
    id patched = CPUthermalPatchBacklightNode(dict);
    return [patched isKindOfClass:[NSDictionary class]] ? patched : dict;
}

// ============================================================================
// %hook: NSDictionary — 拦截热配置 plist 加载，应用防暗屏补丁
// ============================================================================
%hook NSDictionary

+ (id)dictionaryWithContentsOfFile:(id)path {
id res = %orig(path);
if (thermalDimmingPreventionEnabled() &&
    [path isKindOfClass:[NSString class]] && [path containsString:S("/System/Library/ThermalMonitor")]) {
if ([res isKindOfClass:[NSDictionary class]]) {
NSDictionary *patched = patchThermalPlist(res);
return patched;
}
}
return res;
}

%end

// ============================================================================
// C 函数钩子: _getConfigurationFor → ___New_getConfigurationFor___
//
// 在 thermalmonitord 初始化时，会调用 _getConfigurationFor(NSString*)
// 来获取热配置字典。通过返回修改后的配置，可以影响所有热管理参数。
// ============================================================================

// 原函数类型: NSDictionary* _getConfigurationFor(NSString *key)
static NSDictionary* (*orig_getConfigurationFor)(NSString *key) = NULL;

// _getConfigurationFor 替换实现：调用原始函数后应用热配置补丁（防温控暗屏）
static NSDictionary *new_getConfigurationFor(NSString *key) {
    NSDictionary *config = orig_getConfigurationFor ? orig_getConfigurationFor(key) : nil;
    return patchThermalPlist(config);
}

static void onPowerModeChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CPUthermalSyncModeFromPrefs(); });   // ★加速
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CPUthermalSyncModeFromPrefs(); });   // ★加速
dispatch_block_t block = ^{
if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
// ★ 修复（2026-09-17）：模式判定一律以【设置文件】为准，不再读"通知状态缓存"——
//   该缓存在重启/长期未写时会回 0（=高性能），与设置文件互相对冲（低功耗 ↔ 高性能每 2 秒来回拨）。
NSDictionary *prefs = readPrefsDictionary();
id rawMode = [prefs isKindOfClass:[NSDictionary class]] ? prefs[S("powerMode")] : nil;
// ★ T7v：模式切换（CC/设置页只发 powerModeChanged）必须同步刷新"智能模式"标志——
//   否则从智能切到低功耗/性能模式后会继续跑智能逻辑（表现为"切换失效"）。
// ★ T7x3：只有确实读到模式字符串才刷新——一次读取失败不能把智能关掉（否则解析退回高性能 →"高性能乱跳"）
if ([rawMode isKindOfClass:[NSString class]]) {
    g_smartEnabled = [rawMode isEqualToString:S(kCPUthermalSmartModeC)];
}
CPUthermalPowerMode selected;
if ([rawMode isKindOfClass:[NSString class]]) {
selected = [rawMode isEqualToString:S("lowPower")] ? CPUthermalPowerModeLow : CPUthermalPowerModeFull;
} else {
os_unfair_lock_lock(&g_modeLock);
selected = g_userSelectedPowerMode;   // 读不到 → 保持当前，绝不默认高性能
os_unfair_lock_unlock(&g_modeLock);
}
// ★ 2026-09-17 加固：唤醒/解锁保护窗（8 秒）内：只记录用户模式，不重算运行模式（与 sync-prefs 行为一致）——
//   否则"兜底映射"会在窗口内每 2 秒把锁屏前的名单 App 顶回来，和正确的"降回低功耗"来回打架。
if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
os_unfair_lock_unlock(&g_modeLock);
CTD("[窗口] notify-sync: 唤醒窗口内只记用户模式（%s），不重算", selected == CPUthermalPowerModeLow ? "低功耗" : "高性能");
return;
}
BOOL blanked = CPUthermalScreenIsBlanked();
BOOL appLowPower = foregroundAppListHit(selected, prefs);
CPUthermalPowerMode previous;
os_unfair_lock_lock(&g_modeLock);
previous = g_powerMode;
g_userSelectedPowerMode = selected;
g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("notify-sync", appLowPower);
CTAuditMode("notify-sync", CPUthermalResolveTargetMode(selected, blanked, appLowPower));
CPUthermalPowerMode runtimeMode = g_powerMode;
os_unfair_lock_unlock(&g_modeLock);
if (previous != runtimeMode) {
applyPowerModeToRuntime(NO);
// 低→解除改为完整软恢复；重启会中断 3 秒 DCP/亮度恢复任务。
}
CTLOG(S("[CPUthermal] 用户模式已选择:%@，当前屏幕:%@，运行模式:%@"),
      selected == CPUthermalPowerModeLow ? S("低功耗") : S("性能模式"),
      blanked ? S("熄屏") : S("亮屏"),
      runtimeMode == CPUthermalPowerModeLow ? S("低功耗") : S("性能模式"));
};
if ([NSThread isMainThread]) block();
else dispatch_async(dispatch_get_main_queue(), block);
}

static void onSettingsChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    CPUthermalReloadLowPowerPreset(CPUthermalReadPrefs());
dispatch_block_t block = ^{
BOOL wasEnabled = runtimeEnabled();
BOOL previousPreventDimming = g_thermalPreventDimmingEnabled;
loadPrefs();
CPUthermalApplyHIPForCurrentScreen();
BOOL enabled = NO;
BOOL cpuProtection = NO;
BOOL blockPopup = NO;
BOOL preventDimming = NO;
runtimeConfigSnapshot(&enabled, &cpuProtection, NULL, &blockPopup, &preventDimming);
if (enabled) applyPowerModeToRuntime(NO);
else if (wasEnabled) restoreNativeRuntimeAfterDisable();
// 低→解除由软恢复完成；仅防暗屏设置本身变化时才重载配置。
if (previousPreventDimming != g_thermalPreventDimmingEnabled) scheduleThermalConfigurationReload();
CTLOG(S("[CPUthermal] 设置已重载 enabled:%d CPU:%d 弹窗:%d 防暗屏:%d DVFS:原生 level:%d"),
enabled, cpuProtection, blockPopup, preventDimming, targetCPUPerformanceLevel());
};
if ([NSThread isMainThread]) block();
else dispatch_async(dispatch_get_main_queue(), block);
}

// 退出指定应用去抖：SpringBoard 的 100ms 轮询在应用启动、转场、全屏视频切换
// 等瞬间可能返回 nil 或上一个应用，直接采信就会出现"刚生效马上失效"。退出统一
// 延迟 1.5 秒，并在触发时按最新状态二次确认；中途回到指定应用则自动作废。
static void scheduleForegroundExitApply(void) {
    if (g_foregroundExitPending) return;
    g_foregroundExitPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{   // ★加速：退出去抖 1.5s→0.6s
        g_foregroundExitPending = NO;
        @autoreleasepool {
            if (CPUthermalScreenIsBlanked()) return;   // ★ 熄屏/锁屏：不撤销，留到亮屏后再判断
            NSDictionary *prefs = readPrefsDictionary();
            if (foregroundAppListHit(CPUthermalSelectedModeFromPrefs(prefs), prefs)) return; // 已回到名单内应用，保持现状
            // ★★ 唤醒后 10 秒内：前台报成"锁屏界面/桌面(SpringBoard)"或读不到 → 一律不撤销。
            //    这两个值是解锁瞬间最常见的"假前台"，之前就是它把 QQ 的低功耗例外误撤销掉。
            // ★ 统一规则 + 连续确认 3 秒：只有"另一个真实 App 被持续激活"才允许撤销
            if (!CPUthermalForegroundAllowsModeChange()) return;
            {
                static CFAbsoluteTime sOtherAppFirstSeen = 0.0;
                CFAbsoluteTime ctNowT = CFAbsoluteTimeGetCurrent();
                if (sOtherAppFirstSeen == 0.0) { sOtherAppFirstSeen = ctNowT; scheduleForegroundExitApply(); return; }
                if ((ctNowT - sOtherAppFirstSeen) < 3.0) { scheduleForegroundExitApply(); return; }
                sOtherAppFirstSeen = 0.0;
            }
            BOOL blanked = CPUthermalScreenIsBlanked();
            CPUthermalPowerMode previous;
            CPUthermalPowerMode target;
            os_unfair_lock_lock(&g_modeLock);
            previous = g_powerMode;
            g_foregroundAppForcesLowPower = NO; CTAuditFlag("exit-debounce", NO);
            target = CPUthermalResolveTargetMode(g_userSelectedPowerMode, blanked, NO);
            CTAuditMode("exit-debounce", target);
            os_unfair_lock_unlock(&g_modeLock);
            CTLOG(S("[CPUthermal] 退出指定应用(去抖确认) 运行模式:%@"),
                  target == CPUthermalPowerModeLow ? S("低功耗") : (target == CPUthermalPowerModeFull ? S("高性能") : S("原生")));
            if (previous != target) applyPowerModeToRuntime(NO);
        }
    });
}

// 前台状态统一评估入口：进入指定应用立即生效；退出走 1.5s 去抖确认。
static void applyForegroundDecision(const char *reason) {
    if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
    // ★★ 唤醒/解锁后 8 秒内：解锁瞬间前后系统报的前台不可信（锁屏界面或旧 App），
    //     此时不接受任何前台变化，沿用"锁屏前的模式"，避免把名单方向判反。
    if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
        g_lastAppliedForegroundHash = CPUthermalReadForegroundBundleHash();
        return;
    }
    uint64_t foregroundHash = CPUthermalReadForegroundBundleHash();
    // ★ T7u：系统组件（小组件渲染器等）误报为前台 → 忽略，保持当前模式
    if (foregroundHash == CPUthermalBundleIDHash(S("com.apple.chrono.WidgetRenderer-Default"))) {
        static int ctCompIgnored = 0;
        if (ctCompIgnored < 3) { ctCompIgnored++; CTD("[前台] 系统组件（WidgetRenderer）误报 → 忽略（保持当前模式）"); }
        g_lastAppliedForegroundHash = foregroundHash;
        return;
    }
    // ★ T7v/269：fg=0 防抖（v2）——"切 App 瞬间"的假"无应用"必须自己撑满 0.75 秒才生效；
    //   无残留状态（修掉 v1 的 confirmed 泄漏：特殊时序下假 0 会"直通"→模式反复放行="应用全高性能"）。
    {
        static CFAbsoluteTime sCtT7vZeroSince = 0;
        static int sCtT7vZeroGen = 0;
        if (foregroundHash == 0 && !CPUthermalScreenIsBlanked()) {
            CFAbsoluteTime ctNowZ = CFAbsoluteTimeGetCurrent();
            if (sCtT7vZeroSince == 0) sCtT7vZeroSince = ctNowZ;
            if ((ctNowZ - sCtT7vZeroSince) >= 0.40) {     // ★ 270：去抖 0.75→0.40 秒（回桌面/多任务响应更快；读空小抖已在源头被顶住）
                // 已持续 ≥0.75 秒：确认无应用，落下面正常流程（0 → 原生）
            } else {
                int ctGen = ++sCtT7vZeroGen;
                double ctWait = (sCtT7vZeroSince + 0.40) - ctNowZ;
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctWait * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (ctGen != sCtT7vZeroGen) return;
                    if (CPUthermalReadForegroundBundleHash() != 0) return;
                    applyForegroundDecision("zero-confirm");
                });
                g_lastAppliedForegroundHash = foregroundHash;
                return;
            }
        } else {
            sCtT7vZeroSince = 0;
            sCtT7vZeroGen++;
        }
    }
    NSDictionary *prefs = readPrefsDictionary();
    BOOL appLowPower = foregroundAppListHit(CPUthermalSelectedModeFromPrefs(prefs), prefs);
    BOOL blanked = CPUthermalScreenIsBlanked();
    CPUthermalPowerMode previous;
    CPUthermalPowerMode target;
    BOOL wasAppDriven = NO;
    os_unfair_lock_lock(&g_modeLock);
    previous = g_powerMode;
    wasAppDriven = g_foregroundAppForcesLowPower;
    // ★ 熄屏/锁屏期间：一律不做"退出指定 App"的撤销（屏幕黑着不算退出），把状态留到亮屏后再重算
    if (blanked && wasAppDriven) {
        os_unfair_lock_unlock(&g_modeLock);
        g_lastAppliedForegroundHash = foregroundHash;
        return;
    }
    if (!appLowPower && !blanked && wasAppDriven && CPUthermalForegroundAllowsModeChange()) {
        // ★★ 终极规则：只有"前台真的变成了另一个真实 App"才允许撤销名单例外。
        //    0（读不到）和 SpringBoard（锁屏界面/桌面）都视为"不确定" → 保持不变。
        //    —— 用户的实测规律：切出 App 再切回来就正确，说明"切换"是可靠信号，"模糊的前台"不是。
        if (foregroundHash == 0 || foregroundHash == CPUthermalBundleIDHash(S("com.apple.springboard"))) {
            os_unfair_lock_unlock(&g_modeLock);
            g_lastAppliedForegroundHash = foregroundHash;
            return;
        }
        // 前台确实换成了别的真实 App → 交给去抖确认（去抖里还会再查一次名单）
        os_unfair_lock_unlock(&g_modeLock);
        g_lastAppliedForegroundHash = foregroundHash;
        scheduleForegroundExitApply();
        return;
    }
    g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("fg-decision", appLowPower);
    if (appLowPower && foregroundHash != 0) g_exceptionAppHash = foregroundHash;   // ★ 记住是谁触发的例外
    target = CPUthermalResolveTargetMode(g_userSelectedPowerMode, blanked, appLowPower);
    CTAuditMode("fg-decision", target);
    os_unfair_lock_unlock(&g_modeLock);
    g_lastAppliedForegroundHash = foregroundHash;
    // 诊断日志：前台哈希 / 指定应用命中 / 最终运行模式，便于确认检测链路是否正常。
    CTLOG(S("[CPUthermal] 前台状态(%s) hash=%llu 名单命中:%d 熄屏:%d 运行模式:%@"),
          reason ?: "event", (unsigned long long)foregroundHash, appLowPower, blanked,
          target == CPUthermalPowerModeLow ? S("低功耗") : (target == CPUthermalPowerModeFull ? S("高性能") : S("原生")));
    // 模式真正变化时才做完整切换；仅"心跳重申"（仍在指定应用但模式未变）时走轻量路径
    // 重申预算即可，避免每 2 秒重复整套切换（亮度捕获/脉冲/亮度恢复）。
    if (previous != target) {
        applyPowerModeToRuntime(NO);
    } else if (appLowPower) {
        applyLowPowerToCommonProduct();
        applyLowPowerLimitsToTrackedControllers();
        applyCurrentModeToApplePPMCPU();
    }
}

static void onForegroundAppChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    (void)center; (void)observer; (void)name; (void)object; (void)userInfo;
    @autoreleasepool {
        applyForegroundDecision("notify");
    }
}

// ============================================================================
// %ctor — 构造函数（配置仅在进程启动时加载一次）
// ============================================================================
%ctor {
@autoreleasepool {
loadPrefs();

// 确保 IOKit 已加载
void *iokit = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW | RTLD_GLOBAL);
if (iokit) {
kern_return_t (*ptr)(io_service_t, CFStringRef, CFTypeRef) = (kern_return_t (*)(io_service_t, CFStringRef, CFTypeRef))dlsym(iokit, "IOServiceSetProperty");
if (ptr) {
MSHookFunction((void *)ptr, (void *)hooked_IOServiceSetProperty, (void **)&orig_IOServiceSetProperty);
CTLOG(S("[CPUthermal] IOServiceSetProperty hook 已安装"));
} else {
CTLOG(S("[CPUthermal] 警告: 未找到 IOServiceSetProperty"));
}
}

// _getConfigurationFor — C 函数钩子
void *monitor = dlopen("/System/Library/PrivateFrameworks/DeviceMonitor.framework/DeviceMonitor", RTLD_NOW | RTLD_GLOBAL);
if (monitor) {
void *getConfig = dlsym(monitor, "_getConfigurationFor");
if (getConfig) {
MSHookFunction(getConfig, (void *)new_getConfigurationFor, (void **)&orig_getConfigurationFor);
CTLOG(S("[CPUthermal] _getConfigurationFor hook 已安装"));
} else {
CTLOG(S("[CPUthermal] 未找到 _getConfigurationFor (非致命)"));
}
} else {
CTLOG(S("[CPUthermal] 未找到 DeviceMonitor.framework (非致命)"));
}

// 仅性能模式伪造 Nominal；低功耗或禁用时保留系统真实状态。
if (shouldApplyFullCPUProtection()) CPUthermalForceNominalCombined();

BOOL cpuProtection = NO;
runtimeConfigSnapshot(NULL, &cpuProtection, NULL, NULL, NULL);
CTLOG(S("[CPUthermal] 温控防护已激活 — 安全阀:已禁用 CPU性能:%d"), cpuProtection);

// 功率模式与常规设置均通过 Darwin 通知实时重载，无需重启用户空间。

CFNotificationCenterRef c = CFNotificationCenterGetDarwinNotifyCenter();
if (c) {
CFNotificationCenterAddObserver(c, NULL, onSettingsChanged,
(__bridge CFStringRef)S(kCPUthermalSettingsChangedNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
CFNotificationCenterAddObserver(c, NULL, onPowerModeChanged,
(__bridge CFStringRef)S(kCPUthermalPowerModeChangedNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
CFNotificationCenterAddObserver(c, NULL, onForegroundAppChanged,
(__bridge CFStringRef)S(kCPUthermalForegroundAppNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    // ★ T7z6：无操作深度降频——"用户操作"探针（App 内触摸，限频上报）
    {
        static int ctUA = 0;
        notify_register_dispatch(kCPUthermalUserActivityNotifC, &ctUA, dispatch_get_main_queue(), ^(int ctUAt) {
            (void)ctUAt;
            g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();
            if (g_ctDeepIdleActive) {
                g_ctDeepIdleActive = NO;
                applyPowerModeToRuntime(NO);
                CTD("[深度] 用户操作 → 恢复常规低频率");
            }
        });
    }
    // ★ T7z6：视频场景优化——播放开始/结束（豁免深度降频、暂停滑动提速）
    {
        static int ctVOn = 0;
        notify_register_dispatch(kCPUthermalVideoOnNotifC, &ctVOn, dispatch_get_main_queue(), ^(int ctV1) {
            (void)ctV1;
            if (!g_ctVideoOptEnabled && !g_ctVideoDeepEnabled) return;
            g_ctVideoActiveHash = CPUthermalReadForegroundBundleHash();
            if (!g_ctVideoActive) {
                g_ctVideoActive = YES;
                CTD("[视频档] 检测到视频/直播播放（App=%llu）→ 豁免深度+暂停提速", (unsigned long long)g_ctVideoActiveHash);
            }
            if (g_ctDeepIdleActive && !g_ctVideoDeepEnabled) { g_ctDeepIdleActive = NO; applyPowerModeToRuntime(NO); }
        });
        static int ctVOff = 0;
        notify_register_dispatch(kCPUthermalVideoOffNotifC, &ctVOff, dispatch_get_main_queue(), ^(int ctV2) {
            (void)ctV2;
            if (g_ctVideoActive) { g_ctVideoActive = NO; CTD("[视频档] 播放结束 → 恢复正常档"); }
        });
    }
    // ★ T7w：滑动升频——App 内滚动时由前台插件发来信号（滑动中"低频率"临时放行为原生）
    {
        static int ctBoostToken = 0;
        notify_register_dispatch(kCPUthermalScrollBoostNotifC, &ctBoostToken, dispatch_get_main_queue(), ^(int ctBt) {
            (void)ctBt;
            if (!g_scrollBoostEnabled) return;
            g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();      // ★ T7z6：滑动也算"用户操作"
            if (g_ctVideoActive && g_ctVideoOptEnabled) return;   // ★ T7z6：视频档期间不提速（省电）
            CFAbsoluteTime ctNowB = CFAbsoluteTimeGetCurrent();
            g_scrollBoostUntil = ctNowB + 0.6;   // ★ T7x2：回落判决窗口 0.9→0.6 秒（停手后更快回落）
            static CFAbsoluteTime sCtBoostLastApply = 0;   // ★ T7x：上次"提到高性能"时刻（持续滑动时定期重申）
            static CFAbsoluteTime sCtBoostBegan = 0;       // ★ T7x2：本次提速开始时刻（结束日志里带"持续 x.xs"，方便看是微触发还是真滑动）
            if (!g_scrollBoostActive) {
                if (!isLowPowerMode() && !isNativeMode()) return;   // ★ 270：低功耗或原生都可立即放行（原生时释放=无害）；高性能模式不动
                g_scrollBoostActive = YES;
                g_ctDeepIdleActive = NO;    // ★ T7z6：提速开始 → 退出深度档
                ctScrollBoostApplyPass();   // ★ 270：临时"提到高性能"（比只放开更跟手）
                sCtBoostLastApply = ctNowB;
                sCtBoostBegan = ctNowB;
                CTD("[滑动] 升频开始（临时提高性能，模式名义不变）");
            } else if (isLowPowerMode() && (ctNowB - sCtBoostLastApply) >= 0.60) {
                // ★ T7x：持续滑动中每 0.6 秒重申一次（防任何回写，跟手保障）
                sCtBoostLastApply = ctNowB;
                ctScrollBoostApplyPass();
            }
            static int sCtBoostGen = 0;
            sCtBoostGen++;
            int ctGen = sCtBoostGen;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{   // ★ T7x2：检查间隔 1.0→0.75 秒
                if (ctGen != sCtBoostGen) return;
                if (CFAbsoluteTimeGetCurrent() < g_scrollBoostUntil) return;
                if (g_scrollBoostActive) {
                    g_scrollBoostActive = NO;
                    double ctBoostDur = CFAbsoluteTimeGetCurrent() - sCtBoostBegan;
                    if (isLowPowerMode()) {
                        applyPowerModeToRuntime(NO);
                        CTD("[滑动] 升频结束（静默压回低功耗，持续 %.1fs）", ctBoostDur);
                    } else {
                        ctNativeReleasePass();
                        CTD("[滑动] 升频结束（交还系统，持续 %.1fs）", ctBoostDur);
                    }
                }
            });
        });
    }
}

installCrossVersionThermalAliases();
// iOS 15/16/17 私有类可能晚于构造函数加载；只进行4次有界补装。
for (int retry=1;retry<=4;retry++) dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(retry*0.75*NSEC_PER_SEC)),dispatch_get_main_queue(),^{ installCrossVersionThermalAliases(); });

registerThermalLevelResetObservers();
registerScreenWakeObservers();
startForegroundRecheckTimer();
startModeAssertTimer();   // ★ 模式保持循环（每秒核对 + 重压）
startPeriodicReassertTimer();   // ★ 周期重申：亮屏每 2 秒 / 熄屏每 5 秒（重发模式变更通知）
startChargeEngineTimer();   // ★ 1.4.6g：充电引擎独立队列（防主队列卡死连累）
startMainQueueWatchdog();   // ★ 1.4.6g：主队列健康看门狗（卡死写日志）
startPerSecondServicesTimer();   // ★ 1.4.6h：每秒服务独立队列（状态文件/自检/定时）
// ★ T7s：启动时重置"前台通知状态"——防跳 respring 残留旧值被误读
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    CPUthermalPostForegroundBundleID(nil);
    CTD("[前台状态] 启动清理：前台通知状态已重置（防残留）");
});
applyCurrentPowerModeToRuntime();
CTLOG(S("[CPUthermal] 启动完成，当前功率模式:%@，低功耗将在下次亮屏/解锁后自动结束"), isLowPowerMode() ? S("低功耗") : S("性能模式"));
}
}
