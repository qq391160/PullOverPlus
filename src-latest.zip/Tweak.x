#import <CTObf.h>
#import <CTHardening.h>
#import <CTNotifyState.h>   // ★ 0930-0207：通知数据通道
#import <CTFingerprint.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <notify.h>
#include <time.h>
#include <stdio.h>
#import <stdint.h>
#import <string.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <substrate.h>
#include <signal.h>
#include <unistd.h>
#include <spawn.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <net/if_var.h>
#include <sys/wait.h>
#include <mach/mach.h>   // ★ 2.0.115：CPU 占用采样（host_statistics）
#include <CTHermesPaths.h>
#include <CTActivation.h>
#include <sys/sysctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <poll.h>
#include <fcntl.h>
#include <unistd.h>
#include <mach-o/dyld.h>
#import <CTHermesPressure.h>
#import <IOKit/IOKitLib.h>
#import <IOKit/IOMessage.h>
#import <os/lock.h>
#import <mach/host_info.h>
#import <mach/task_info.h>

// ============================================================================
// ObjC 类声明（thermalmonitord 内部类，class-dump 获取）
// ============================================================================
@interface HidSensors : NSObject
+ (id)sharedInstance;
- (void)handleTemperatureEvent:(int)arg1 service:(id)arg2;
@end

@interface CommonProduct : NSObject
- (id)initProduct:(id)arg1;
- (void)putDeviceInThermalSimulationMode:(id)arg1;
- (void)tryTakeAction;
- (void)simulateLightThermalPressure;
- (void)updatePowerzoneTelemetry;
- (void)setCPMSMitigationsEnabled:(BOOL)enabled;
- (void)setCPULevel:(int)level;
- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(id)source;
- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(id)source;
- (void)setThermalState:(id)state;
- (BOOL)setServiceProperty:(uintptr_t)service key:(id)key value:(uintptr_t)value scaleToFixedPoint:(BOOL)scale;
- (BOOL)shouldEnforceLightThermalPressure;
- (int)getPotentialForcedThermalLevel:(id)component;
- (int)getPotentialForcedThermalPressureLevel;
@end

// ============================================================================
@interface CTHermesThermalManager : NSObject
- (id)initWithComponentControllers:(id)components hotspotControllers:(id)hotspots decisionTreeTable:(id)table;
- (void)evaluateDecisionTree;
- (id)findComponent:(id)component;
- (void)actionComponentControl;
- (void)readReleaseRateForAllComponents;
- (float)getReleaseRateForComponent:(id)component;
- (int)getPotentialForcedThermalLevel:(id)component;
- (int)getPotentialForcedThermalPressureLevel;
- (void)updateThermalPressureLevelNotification:(id)notification shouldForceThermalPressure:(BOOL)force;
- (void)updateThermalNotification:(id)notification;
- (BOOL)shouldEnforceLightThermalPressure;
- (void)setCPMSMitigationState:(int)state;
- (id)getConfigurationFor:(id)key;
@end

@interface CTHermesThermalControl : NSObject
- (float)calculateControlEffort:(id)trigger trigger:(id)arg2;
- (id)findCC:(id)component;
- (float)dieTempFilteredMaxAverage;
- (float)getHighestSkinTemp;
- (float)thermalSensorValuesMaxFromIndexSet:(id)indexSet;
- (void)copyDieTempSensorIndexSetForFourthChar:(char)c sensors:(id)sensors;
- (BOOL)powerSaveActive;
- (void)setPowerSaveActive:(BOOL)active;
- (void)setPowerSaveToken:(id)token;
- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams;
- (id)initWithParams:(id)params;
- (void)updatePowerParameters:(id)params;
- (BOOL)setServiceProperty:(uintptr_t)service key:(id)key value:(uintptr_t)value scaleToFixedPoint:(BOOL)scale;
@end

@interface ApplePPMCPU : NSObject
- (void)setCPULevel:(int)level;
- (void)updateCPU;
@end

@interface MitigationController : NSObject
- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams;
- (void)updateCPU;
- (void)updateGPU;
- (void)updatePackage;
- (void)setCPULowPowerTarget:(int)target;
- (void)setPackageLowPowerTarget;
- (void)setMaxCPUPowerTarget:(int)target useLegacyPath:(BOOL)legacy setProperty:(uintptr_t)property;
- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setCPUPowerCeiling:(int)ceiling forDVD1Contributor:(int)contributor;
- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setCPUPowerZoneTarget:(int)target;
- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setGPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setGPUPowerZoneTarget:(int)target;
- (void)setSGXLevel:(int)level;
- (void)setMaxGraphicsDrivePowerTarget:(int)target;
- (void)setPackagePowerBudgetDirect:(int)budget withDetails:(id)details;
- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source;
- (void)setPackagePowerFloor:(int)floor fromDecisionSource:(uintptr_t)source;
- (void)setPackagePowerZoneTarget;
- (void)setMaxPackagePower:(int)power;
- (int)CPULevel;
- (void)setCPULevel:(int)level;
- (void)setCPUMitigationLevel:(int)level;
- (void)setDVD1Level:(int)level;
- (BOOL)powerSaveActive;
- (void)setPowerSaveActive:(BOOL)active;
- (void)setPowerSaveToken:(int)token;
@end

@interface CTHermesThermalDecisionTable : NSObject
- (id)initDecisionTable:(id)table;
@end

@interface PIDController : NSObject
- (id)initPIDWith:(id)params;
@end

@interface HotspotController : NSObject
- (id)initWithParams:(id)params aggdController:(id)aggd;
@end

@interface CommonAggdController : NSObject
- (id)initWithParams:(id)params product:(id)product;
@end

// ============================================================================
// 配置
// ============================================================================
static BOOL g_enabled               = YES; // 总开关，可由设置动态关闭
static BOOL g_cpuProtection         = YES; // 仅用于低功耗模式控制
static BOOL g_ctUninstalled = NO;   // ★ 1.4.100：收到「卸载中」通知 → 停止一切周期动作（松开压制/停充，绝不"按住"）

// 性能模式拦截网络射频热限流；低功耗与禁用状态下保持系统原生行为。
static BOOL g_blockNetworkThermalThrottle = YES;
static BOOL networkThrottleBlockingEnabled(void);

// Wi‑Fi Apple80211 射频限流关键字 iOS15~iOS16通用
static const char *networkThrottleKeys[] = {
"txPowerLimit",
"transmitPowerLimit",
"maxThroughput",
"rateLimiting",
"thermalThrottleEnabled",
"antennaThrottle",
"thermalPowerCap",
"radioPowerLimit",
"modemThermalLimit",
"basebandPowerLimit",
NULL
};

// 判断是否为网络射频限流属性key
static BOOL isNetworkThrottleProperty(CFStringRef keyRef) {
if (!keyRef || !networkThrottleBlockingEnabled()) return NO;
NSString *key = (__bridge NSString *)keyRef;
NSString *lowerKey = [key lowercaseString];

for (int i = 0; networkThrottleKeys[i]; i++) {
NSString *k = [NSString stringWithUTF8String:networkThrottleKeys[i]];
if ([lowerKey containsString:[k lowercaseString]]) {
return YES;
}
}
return NO;
}

typedef enum {
CTHermesPowerModeFull = 0,
CTHermesPowerModeLow  = 1,
CTHermesPowerModeNative = 2   // ★ 智能模式专用：原生（不干预，交还系统）
} CTHermesPowerMode;

static CTHermesPowerMode g_powerMode = CTHermesPowerModeFull;
static CTHermesPowerMode g_userSelectedPowerMode = CTHermesPowerModeFull;
static BOOL g_foregroundAppForcesLowPower = NO;
// ★ 智能模式（顶部分段第三格）：游戏→高性能 / 其他应用→低频率 / 桌面→原生
static BOOL g_smartEnabled = NO;                 // 常驻"智能"时为 YES（老的两档一律不受影响）
static NSMutableSet *g_tierFullHashes = nil;     // ★ T7w：App 档位——高性能
static NSMutableSet *g_tierLowHashes = nil;      // ★ T7w：App 档位——低频率
static NSMutableSet *g_tierNativeHashes = nil;   // ★ T7w：App 档位——原生
static CFAbsoluteTime g_scrollBoostUntil = 0;    // ★ T7w：滑动升频截止时刻
static BOOL g_scrollBoostEnabled = NO;
static BOOL g_ctAppBoostEnabled = NO;   // ★ 2.0.1：开合提速通道（随"开合 App 提速"开关；默认关）
static BOOL g_lowPowerDesktopNative = NO;   // ★ T7x6：低功耗模式下「桌面原生频率」开关（设置里可开；默认关=桌面也压）
static BOOL g_scrollBoostActive = NO;
static CFAbsoluteTime g_ctLastBoostAt = 0;   // ★ 1.4.90：最近一次提速时刻（看门狗用它避让 ✓）            // ★ 269：滑动放行中（模式名义上保持低功耗，不产生模式跳变）          // ★ T7w：滑动提速开关（默认开）
static NSSet *g_smartGameHashes = nil;           // 识别到的游戏 App（前台哈希集合）
static NSSet *g_smartFullListHashes = nil;       // 「指定 App 高性能率」名单（智能下的例外）
static NSSet *g_smartKnownAppHashes = nil;       // 可识别的普通应用（带分类信息；识别不到的走原生）
static NSSet *g_smartLowListHashes = nil;        // 「指定 App 低频率」名单（智能下：钉住一律低频率）
static BOOL g_smartScanDone = NO;                // 是否已完成一次分类扫描
static BOOL g_gameForceFull = NO;               // ★ T7z26：游戏强制高性能（默认开）
static CTHermesPowerMode g_smartLastTarget = CTHermesPowerModeNative;   // 上次判定（读不到前台时沿用）
// ★ T7 取证助手前置声明
static void CTAuditMode(const char *who, CTHermesPowerMode newMode);
static void CTAuditFlag(const char *who, BOOL v);
static uint64_t g_lastAppliedForegroundHash = 0;
static BOOL g_foregroundExitPending = NO;   // 退出指定应用去抖中（防转场瞬时误报）

// setCPULowPowerTarget:/setMaxCPUPowerTarget: 使用 mW；65000 是 thermalmonitord 的无限制哨兵值。
// setCPULevel:/setCPUPowerCeiling:/setCPUPowerFloor:/setCPUPowerZoneTarget: 使用 0~100 百分比。
static const int kUnrestrictedPowerLimitMW = 65000;
static const int kUnrestrictedPerformancePercent = 100;
static const int kLowPowerCPULevel = 2;
// 低功耗参数：固定 2500mW / 45%（原「省电强度」三级设置已移除）
static int g_lowPowerPowerLimitMW = 2500;
static int g_lowPowerPerformancePercent = 45;
#define kLowPowerPowerLimitMW g_lowPowerPowerLimitMW
#define kLowPowerPerformancePercent g_lowPowerPerformancePercent

// ★ T7z6：无操作深度降频 + 视频场景优化（两个开关均默认开，设置里可关）
static BOOL g_ctIdleSinkEnabled = NO;        // 无操作深度省电
static BOOL g_ctVideoOptEnabled = NO;        // 视频场景优化
static BOOL g_ctVideoDeepEnabled = NO;        // ★ T7z7：视频中也允许深度降频（默认关）
static BOOL g_ctDeepIdleActive = NO;          // 深度档激活中（参数更深）
static CFAbsoluteTime g_ctLastActivityAt = 0; // 最后一次"用户操作"时刻
static BOOL g_ctVideoActive = NO;             // 视频/直播播放中
static uint64_t g_ctVideoActiveHash = 0;      // 视频档绑定的 App 哈希
static const int kDeepLowPowerCPULevel = 3;   // 深度档：系统 CPU Level 3（≈1G 档）
static const int kDeepLowPowerBudgetMW = 1800;// 深度档：功率预算 ~1.8W
static int CTLowPowerLevel(void) { return g_ctDeepIdleActive ? kDeepLowPowerCPULevel : kLowPowerCPULevel; }
static int CTLowPowerBudgetMW(void) { return g_ctDeepIdleActive ? kDeepLowPowerBudgetMW : g_lowPowerPowerLimitMW; }

// 低功耗参数：原「省电强度」三级设置已移除——固定 2500 mW / 45%
static void CTHermesReloadLowPowerPreset(NSDictionary *prefs) {
    (void)prefs;
    g_lowPowerPowerLimitMW = 2500;
    g_lowPowerPerformancePercent = 45;
}

static const int kFullPowerCPULevel = 0;
static const int kCPUDecisionSourceCount = 6;
static const int kCPUDVD1ContributorCount = 4;

static CommonProduct *g_commonProduct = nil;
static NSHashTable *g_mitigationControllers = nil;  // 弱引用，防止僵尸实例泄漏
static os_unfair_lock g_stateLock = OS_UNFAIR_LOCK_INIT;      // 配置与 CommonProduct
static os_unfair_lock g_controllerLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock g_runtimeLock = OS_UNFAIR_LOCK_INIT;    // 有限模式应用任务
static __thread BOOL g_restoringFullPower = NO;
static BOOL g_fullPowerRecoveryPulseScheduled = NO;
static BOOL g_lowPowerApplyPulseScheduled = NO;
static BOOL g_thermalReloadScheduled = NO;
static BOOL g_forceThermalConfigReload = NO;
static int g_lockStateToken = -1;
static int g_blankedScreenToken = -1;
static int g_thermalNotificationToken = -1;
static int g_thermalPressureToken = -1;
static dispatch_queue_t g_thermalResetQueue = NULL;
static os_unfair_lock g_thermalResetLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastThermalReset = 0;
static os_unfair_lock g_nominalLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastNominalCorrection = 0;
static os_unfair_lock g_modeLock = OS_UNFAIR_LOCK_INIT;  // 线程安全：保护g_powerMode
static NSHashTable *g_applePPMInstances = nil;           // 追踪 ApplePPMCPU 实例（弱引用，防止僵尸实例泄漏）
// 高温告警默认屏蔽；防暗屏仍由用户设置决定。
static BOOL g_thermalBlockNotifPopup = NO;
static BOOL g_thermalPreventDimmingEnabled = NO;
static BOOL g_overheatAutoProtect = NO;   // ★ 1.4.6s：过热自动保护（温控保护面板开关）
static BOOL g_nominalAutoRecover = NO;   // ★ 1.4.6s：温度正常后自动恢复
static BOOL g_overheatActive = NO;        // 过热保护临时介入中（临时低功耗）
static CFAbsoluteTime g_overheatNormalSince = 0;
static BOOL isFullPowerMode(void);
static BOOL shouldApplyLowPowerLimit(void);
static int targetCPUPerformanceLevel(void);
static void loadPrefs(void);
// ★ 授权总闸（CTActivation.h）：未激活 → 不接管温控 / 充电 / 弹窗 / 亮度 / 网络
static BOOL g_ctAuthOK = NO;
static NSString *sCTLastGoodCode = nil;   // ★ 1.4.10 本进程已验证通过的授权码（配置读不到时兜底，绝不放行未激活的机器）

// ★ ④ 自校验（0930-0185）前向声明：检出被改包/hook → 静默降级
static BOOL g_ctHardTampered;
static NSString *g_ctAuthDevCode = nil;
static void CTAuthRefresh(void);
static void CTAnalysisAuditTick(void);
static void CTRespringForActivation(void);
static NSDictionary *readPrefsDictionary(void);
static BOOL foregroundAppShouldUseLowPower(NSDictionary *prefs);
static BOOL CTHermesTierSystemActive(NSDictionary *prefs);   // ★ T7x：档位体系接管判定（前向声明）
static CTHermesPowerMode CTHermesResolveTargetMode(CTHermesPowerMode selected, BOOL blanked, BOOL appLowPower);
static CTHermesPowerMode CTHermesSelectedModeFromPrefs(NSDictionary *prefs);
static BOOL foregroundAppForcesFullPower(NSDictionary *prefs);
static BOOL foregroundAppListHit(CTHermesPowerMode selected, NSDictionary *prefs);
static void CTHermesSyncModeFromPrefs(void);
static void applyCurrentPowerModeToRuntime(void);
static void applyPowerModeToRuntime(BOOL respectBootGuard);
static void scheduleFullPowerRecoveryPulse(void);
static void runFullPowerRecoveryPulse(int remainingPulses);
static void scheduleLowPowerApplyPulse(void);
static void runLowPowerApplyPulse(int remainingPulses);
static void startForegroundRecheckTimer(void);
static void applyForegroundDecision(const char *reason);
static void scheduleForegroundExitApply(void);
static void applyCurrentModeToApplePPMCPU(void);
static void forceCPUPerformanceLevelOnController(id controller);
static void applyFullPowerBudgetsOnController(id controller);
static void applyLowPowerToCommonProduct(void);
static void applyLowPowerPerformancePreferenceToController(id controller);
static void restoreNativeRuntimeAfterDisable(void);
static void correctNominalStateIfNeeded(void);
static BOOL shouldApplyAppFullProtection(void);       // ★ 1.4.4：前台 App 享受"高性能"时 = 同级防降频
static int CTHermesTierForHash(uint64_t ctHv);      // 前置声明（定义在档位区）
static void scheduleThermalMonitorReload(void);
static void scheduleThermalConfigurationReload(void);
static void switchToLowPowerForSleep(const char *source);
static void restoreUserModeAfterWake(const char *source);
static BOOL runSoftModeSwing(const char *reason);
static BOOL CTFreqReadMHzInner(double *outMHz);   // ★ T7z11/T7z16h：IOReport 读取（内部实现）
static os_unfair_lock g_ctFreqLock = OS_UNFAIR_LOCK_INIT;
static BOOL CTFreqReadMHz(double *outMHz) {   // ★ 1.4.6h：加锁——主队列与每秒服务队列可并发读取
    os_unfair_lock_lock(&g_ctFreqLock);
    BOOL ctFR = CTFreqReadMHzInner(outMHz);
    os_unfair_lock_unlock(&g_ctFreqLock);
    return ctFR;
}
static void registerScreenWakeObservers(void);
static void CTHermesCaptureBrightnessBeforeModeChange(void);
static void CTHermesCaptureExistingBacklightMaximum(void);
static void CTHermesScheduleBacklightRecovery(void);

static void runtimeConfigSnapshot(BOOL *enabled, BOOL *cpuProtection, BOOL *blockNetwork, BOOL *blockPopup, BOOL *preventDimming) {
os_unfair_lock_lock(&g_stateLock);
if (enabled) *enabled = g_enabled;
if (cpuProtection) *cpuProtection = g_cpuProtection;
if (blockNetwork) *blockNetwork = g_blockNetworkThermalThrottle;
if (blockPopup) *blockPopup = g_thermalBlockNotifPopup;
if (preventDimming) *preventDimming = g_thermalPreventDimmingEnabled;
os_unfair_lock_unlock(&g_stateLock);
}

// ============================================================================
static BOOL isLowPowerMode(void);
static BOOL isNativeMode(void);

// ★ 智能模式的"原生"态判定（不干预、交还系统时用）
static BOOL isNativeMode(void) {
    os_unfair_lock_lock(&g_modeLock);
    BOOL res = (g_powerMode == CTHermesPowerModeNative);
    os_unfair_lock_unlock(&g_modeLock);
    return res;
}

// 三态模式名（日志用）
static const char *CTModeName(CTHermesPowerMode m) {
    return (m == CTHermesPowerModeLow) ? "低功耗" : ((m == CTHermesPowerModeFull) ? "高性能" : "原生");
}
static CommonProduct *commonProductSnapshot(void);
static NSArray *trackedPowerControllersSnapshot(void);
static NSArray *trackedApplePPMInstancesSnapshot(void);

// ★ 诊断日志（临时）：容器内 CTHermesDiag.log（2.0.38 收口）
//   只在关键事件 + 低功耗期间每秒 1 行，文件超过 256KB 自动重建
// ============================================================================
#include <sys/stat.h>
#include <sys/time.h>
static void CTD(const char *fmt, ...) {
    static FILE *fp = NULL;
    // ★ 2026-09-17 加固：句柄校验——日志文件被换掉/删掉时自动重开（每 60 次写校验一次，开销忽略）
    if (fp) {
        static int sCTDCheckTick = 0;
        if ((++sCTDCheckTick % 60) == 0) {
            struct stat fst, pst;
            if (fstat(fileno(fp), &fst) != 0 || stat(CTDiagLogPathC(), &pst) != 0 || fst.st_ino != pst.st_ino) {
                fclose(fp);
                fp = NULL;
            }
        }
    }
    if (!fp) {
        // ★ 2.0.38：统一闸门——超限保留尾部（96KB 保留 / 128KB 封顶；不 unlink，追加句柄依旧有效）
        fp = CTDiagLogOpenForAppend();
        chmod(CTDiagLogPathC(), 0666);   // ★ 1.4.124：保持"谁都能写"（根治重装后普通进程日志失声）
    }
    if (!fp) {   // ★ 0930-0207：主日志写不进去（沙盒差异）→ 落"兜底日志"，由前台组件搬回主日志
        for (NSString *d in CTStateWriteDirs()) {
            NSString *lp = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
            mkdir([d UTF8String], 0755);
            fp = fopen([lp UTF8String], "a");
            if (fp) break;
        }
    }
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s.%03d] ", ts, (int)(tv.tv_usec / 1000));
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fflush(fp);
}

// 捕获对象健康度：CommonProduct 是否还在 / 控制器数量 / PPM 数量 / 重压计数
static unsigned long g_ctApplyCount = 0;
// ★ 构建标记：启动时写进日志，方便确认"装的到底是哪一版"
#define kCTBuildTag "build 2.0.128"
// ★ 1.4.6 安全加强：身份完整性开关（③④）——非完整性被破坏时，插件所有功能静默停用
static BOOL g_ctIdentityIntact = YES;
static CFAbsoluteTime g_ctMainBeat = 0;   // ★ 1.4.6g：主队列心跳时间戳（独立看门狗用）
static CFAbsoluteTime g_ctProcStart = 0;  // ★ 1.4.6g：本进程启动时刻（防误伤：设置包更新晚于启动则暂缓指纹核对）
static int g_ctMainPhase = 0;         // ★ 1.4.6h：主队列当前阶段（卡死时日志定位用 1-10）
static CFAbsoluteTime g_ctEngineBeat = 0;  // ★ 1.4.6h：充电引擎队列心跳
static CFAbsoluteTime g_ctSvcBeat = 0;     // ★ 1.4.6h：每秒服务队列心跳
static int g_ctSvcPhase = 0;          // ★ 1.4.6h：每秒服务步骤（1-3）
static const char *CTFpSuffix(void) {
    static char sBuf[40] = {0};
    static int sInit = 0;
    if (!sInit) {
        sInit = 1;
        if (CT_SOURCE_FP[0]) snprintf(sBuf, sizeof(sBuf), " [fp:%s]", CT_SOURCE_FP);
    }
    return sBuf;   // 未注入指纹 → 空串（不影响功能）
}

// ★ 1.4.124：兜底日志搬运（核心侧）——手机层进程写不进主日志时会把日志攒到"兜底文件"，
//   由 root 的核心每 60 秒把它们搬回主日志（否则那些进程的日志永远看不见）
static void ctCarryFallbackLog(void) {
    static CFAbsoluteTime sLastCarry = 0;
    CFAbsoluteTime n = CFAbsoluteTimeGetCurrent();
    if (n - sLastCarry < 60.0) return;
    sLastCarry = n;
    NSString *fb = nil;
    for (NSString *d in CTStateWriteDirs()) {
        NSString *p2 = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
        NSString *s2 = [NSString stringWithContentsOfFile:p2 encoding:NSUTF8StringEncoding error:NULL];
        if (s2.length > 0) { fb = s2; break; }
    }
    if (!fb.length) return;
    FILE *mf = fopen(CTDiagLogPathC(), "a");
    if (!mf) return;
    fprintf(mf, "\n---- [兜底日志搬运·核心版] ----\n%s\n---- [搬运结束] ----\n", fb.UTF8String);
    fclose(mf);
    for (NSString *d in CTStateWriteDirs()) {
        NSString *p2 = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
        truncate(p2.fileSystemRepresentation, 0);
    }
}

static void CTDObjects(const char *tag) {
    id poc = commonProductSnapshot();
    NSArray *ctrls = trackedPowerControllersSnapshot();
    NSArray *ppms = trackedApplePPMInstancesSnapshot();
    CTD("对象[%s] CommonProduct=%s 控制器=%lu PPM=%lu 重压次数=%lu 模式=%s 名单标记=%d 前台=%llu",
        tag, poc ? "在" : "空(被系统换掉了)", (unsigned long)ctrls.count, (unsigned long)ppms.count,
        g_ctApplyCount, isNativeMode() ? "原生" : (isLowPowerMode() ? "低功耗" : "高性能"),
        (int)g_foregroundAppForcesLowPower,
        (unsigned long long)CTHermesReadForegroundBundleHash());
}


static BOOL runtimeEnabled(void) {
BOOL enabled = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, NULL, NULL);
return enabled && g_ctIdentityIntact;
}

// ★ 0203（全新插件）：让位检测——机上若还有"老版温控插件"（huayuarc / 老 CPUthermal 同名文件），
//   本插件**自动待命**、不抢温控（避免两个温控同时改一套系统 ⇒ 异常/看门狗重启）。
//   老版退场后（卸载+重启）自动上岗。
// ★ 0203b：正确判据——看**本进程（温控进程）内存里**有没有加载"老版同名 dylib"。
//   磁盘上还留着旧文件（备份/残留）不代表它在跑 ⇒ 不能用扫盘做判据（会误判退场 ✗）。
static BOOL CTLegacyThermalLoadedInProcess(void) {
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *nm = _dyld_get_image_name(i);
        if (!nm) continue;
        const char *base = strrchr(nm, '/');
        base = base ? base + 1 : nm;
        // 我们的文件叫 CTHermes.dylib；出现 CPUthermal.dylib = 老版温控插件（huayuarc 或我们旧版）
        if (strcmp(base, "CPUthermal.dylib") == 0) return YES;
    }
    return NO;
}

static BOOL CTLegacyThermalPresent(void) {
    // 每 ~30 秒复查一次（热加载的插件可能在运行中出现）；平时走缓存
    static CFAbsoluteTime sLast = 0; static BOOL sHit = NO;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sLast > 0 && now - sLast < 30.0) return sHit;
    sLast = now; sHit = CTLegacyThermalLoadedInProcess();
    return sHit;
}


static BOOL runtimeProtectionEnabled(void) {
BOOL enabled = NO;
BOOL cpuProtection = NO;
runtimeConfigSnapshot(&enabled, &cpuProtection, NULL, NULL, NULL);
if (CTLegacyThermalPresent()) {   // ★ 2.0.38：待命必须出声（永不再静默）
    static CFAbsoluteTime sLegacyLogged = 0;
    CFAbsoluteTime lnow = CFAbsoluteTimeGetCurrent();
    if (sLegacyLogged == 0 || lnow - sLegacyLogged > 60.0) {
        sLegacyLogged = lnow;
        CTD("[让位] 本进程(%s)检测到老版 CPUthermal.dylib 正在加载 → 本进程待命、不抢温控（老版退场+重启后自动上岗）", getprogname());
    }
    return NO;
}
BOOL ok = enabled && cpuProtection && g_ctIdentityIntact && g_ctAuthOK;   // ★ 授权总闸
if (!ok) {   // ★ 2.0.38：总闸未开也必须出声（逐项写明原因）
    static CFAbsoluteTime sGateLogged = 0;
    CFAbsoluteTime gnow = CFAbsoluteTimeGetCurrent();
    if (sGateLogged == 0 || gnow - sGateLogged > 120.0) {
        sGateLogged = gnow;
        CTD("[总闸] 本进程(%s)保护未开：总开关=%d CPU保护=%d 身份=%d 授权=%d", getprogname(), enabled, cpuProtection, g_ctIdentityIntact, g_ctAuthOK);
    }
}
return ok;
}

static BOOL thermalDimmingPreventionEnabled(void);   // 自测增强前向声明
// ★ 2.0.38：宿主"心跳自证"（不依赖任何文件权限）——tm/powerd 每 30 秒发一次带"状态位"的 Darwin 通知；
//   SpringBoard 侧监听落日志 ⇒ "有没有在跑我们的代码"从此不用猜；状态位随行防暗屏挂载/到达进度。
static volatile uint64_t g_ctAliveFlags = 1;   // bit0=ctor 已到达；bit1=配置层挂载已执行；bit2-5=已挂类数；bit8=getConfigurationFor 已到达
static volatile uint64_t g_ctDiagWord = 0;     // ★ 2.0.38：细节通道数据字（参数数/返回码/参2/参3 + 名字前6字节）
static volatile uint64_t g_ctDiag2 = 0, g_ctDiag3 = 0;   // ★ 2.0.38：细节扩展（精确类型字符 + 名字 7-18 字节）
static volatile uint64_t g_ctDiag5 = 0;   // ★ 2.0.38：返回类型串前 8 字节（真名留证）
static volatile uint32_t g_ctBlkSeen = 0, g_ctBlkClamp = 0;
static volatile uint32_t g_ctPatchN = 0;   // 自测增强：补丁执行计数
static volatile uint32_t g_ctRWN = 0;      // 自测增强：回写次数
static volatile uint32_t g_ctRWV10 = 0;    // 自测增强：最后回写值x10
static volatile uint32_t g_ctHHN = 0;      // 自测增强：hook命中次数
static volatile uint32_t g_ctMntBits = 0;  // 自测增强：弹窗链「上岗位」位
static volatile uint64_t g_ctPopupN = 0;   // 自测增强：弹窗拦截计数（diag5）
static void ctMntBitsRefresh(void);        // 自测增强：上岗位刷新（定义在后部）
static CFAbsoluteTime g_ctProcStartAt = 0;   // 自测增强：本进程启动时刻
static inline BOOL ctBootSilence(void) { return (g_ctProcStartAt > 0.0 && (CFAbsoluteTimeGetCurrent() - g_ctProcStartAt) < 90.0); }   // ★2.0.38：开机头 90 秒静默   // ★ 2.0.38：背光变暗写入拦截计数（见到/挡下）
static id CTHermesCopyUserBrightness(void);   // 自测增强：前向声明
static void CTHostAlivePost(void) {
    @try {
    if (thermalDimmingPreventionEnabled()) g_ctAliveFlags |= (1ULL << 16); else g_ctAliveFlags &= ~(1ULL << 16);   // 自测增强：开关(tm读数)
    g_ctAliveFlags = (g_ctAliveFlags & ~(0xFFULL << 20)) | ((uint64_t)(g_ctPatchN > 255 ? 255 : g_ctPatchN) << 20);   // 自测增强：补丁计数
    g_ctDiag2 = ((uint64_t)(g_ctRWN > 65535 ? 65535 : g_ctRWN) << 32) | (uint64_t)g_ctRWV10;   // 自测增强：回写数字表
    ctMntBitsRefresh();
    g_ctDiag3 = ((uint64_t)(g_ctMntBits & 0xFFFFFFFF) << 32) | (uint64_t)(g_ctHHN & 0xFFFFFFFF);   // 自测增强：命中+上岗位
    g_ctDiag5 = g_ctPopupN;   // 自测增强：弹窗拦截计数
        char nm[96];
        snprintf(nm, sizeof(nm), "com.qq391160.cpucore/alive.%s", getprogname());
        int tk = 0;
        if (notify_register_check(nm, &tk) != NOTIFY_STATUS_OK) return;
        uint64_t st = ((uint64_t)(uint32_t)getpid() << 32) | (g_ctAliveFlags & 0xFFFFFFFFULL);
        notify_set_state(tk, st);
        notify_post(nm);
        notify_cancel(tk);
    } @catch (__unused NSException *e) {}
    @try {   // ★ 2.0.38：细节通道（签名+名字前6字节；0=无内容）
        char dn[96];
        snprintf(dn, sizeof(dn), "com.qq391160.cpucore/diag.%s", getprogname());
        int dtk = 0;
        if (notify_register_check(dn, &dtk) == NOTIFY_STATUS_OK) {
            notify_set_state(dtk, g_ctDiagWord);
            notify_post(dn);
            notify_cancel(dtk);
        }
    } @catch (__unused NSException *e) {}
    @try {   // ★ 2.0.38：细节扩展（diag2=类型字符+名字7-10；diag3=名字11-18；diag4=拦截计数）
        char dn2[96]; int dtk2 = 0;
        snprintf(dn2, sizeof(dn2), "com.qq391160.cpucore/diag2.%s", getprogname());
        if (notify_register_check(dn2, &dtk2) == NOTIFY_STATUS_OK) { notify_set_state(dtk2, g_ctDiag2); notify_post(dn2); notify_cancel(dtk2); }
        char dn3[96]; int dtk3 = 0;
        snprintf(dn3, sizeof(dn3), "com.qq391160.cpucore/diag3.%s", getprogname());
        if (notify_register_check(dn3, &dtk3) == NOTIFY_STATUS_OK) { notify_set_state(dtk3, g_ctDiag3); notify_post(dn3); notify_cancel(dtk3); }
        char dn4[96]; int dtk4 = 0;
        snprintf(dn4, sizeof(dn4), "com.qq391160.cpucore/diag4.%s", getprogname());
        if (notify_register_check(dn4, &dtk4) == NOTIFY_STATUS_OK) { notify_set_state(dtk4, (((uint64_t)g_ctBlkClamp) << 32) | (uint64_t)g_ctBlkSeen); notify_post(dn4); notify_cancel(dtk4); }
        char dn5[96]; int dtk5 = 0;
        snprintf(dn5, sizeof(dn5), "com.qq391160.cpucore/diag5.%s", getprogname());
        if (notify_register_check(dn5, &dtk5) == NOTIFY_STATUS_OK) { notify_set_state(dtk5, g_ctDiag5); notify_post(dn5); notify_cancel(dtk5); }
    } @catch (__unused NSException *e) {}
}
static void CTHostAliveStart(void) {
    CTHostAlivePost();
    @try {
        static dispatch_source_t sAliveTimer = NULL;
        if (!sAliveTimer) {
            sAliveTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
            if (sAliveTimer) {
                uint64_t iv = 30ull * NSEC_PER_SEC;
                dispatch_source_set_timer(sAliveTimer, dispatch_time(DISPATCH_TIME_NOW, (int64_t)iv), iv, 5ull * NSEC_PER_SEC);
                dispatch_source_set_event_handler(sAliveTimer, ^{ CTHostAlivePost(); });
                dispatch_resume(sAliveTimer);
            }
        }
    } @catch (__unused NSException *e) {}
}

#ifdef CT_SCHEME_ROOTHIDE
// ★ 2.0.38：自家状态目录权限放开给普通进程（浮窗在 SpringBoard=mobile，需能"新建"位置文件；
//   只碰自家目录/自家文件、有界 + @try；root 进程执行最稳。无根版不涉及）
static void CTNormalizeOwnedDirsForMobile(void) {
    @try {
        NSString *rh = CTHermesResolvedRootOnce();   // ★ 2.0.110：单根（缓存一次）
        if (!rh.length) return;
        NSString *stDir = [rh stringByAppendingPathComponent:S("Library/CTHermesState")];
        NSString *lgDir = [rh stringByAppendingPathComponent:S("Library/CTHermesState/logs")];
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:stDir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        [fm createDirectoryAtPath:lgDir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        chmod(stDir.fileSystemRepresentation, 01777);   // ★ 2.0.110：工作目录 01777（配置在目录内，需跨进程可写）
        chmod(lgDir.fileSystemRepresentation, 01777);
        for (NSString *n in @[S("CTHermesFloat.pos"), S("CTHermesFloat.land")]) {
            NSString *p = [lgDir stringByAppendingPathComponent:n];
            if (![fm fileExistsAtPath:p]) { FILE *f = fopen(p.fileSystemRepresentation, "a"); if (f) fclose(f); }   // 缺才建，绝不覆盖
            chmod(p.fileSystemRepresentation, 0666);
            [fm setAttributes:@{NSFileOwnerAccountID:@(501), NSFileGroupOwnerAccountID:@(501)} ofItemAtPath:p error:NULL];   // ★ 2.0.47：属主自愈为 mobile（窗口组件的身份），否则"写"永远被拒=位置存不住
        }
        // ★ 2.0.48：run 目录与兜底日志也放开给 mobile（部分 16 机主路径写不进 → 至少兜底可用）
        NSString *runDir = [rh stringByAppendingPathComponent:S("Library/CTHermesState/run")];
        [fm createDirectoryAtPath:runDir withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@(01777)} error:NULL];
        chmod(runDir.fileSystemRepresentation, 01777);
        for (NSString *n2 in @[S("CTHermesFloat.pos"), S("CTHermesFloat.land"), S("CTHermesFallback.log")]) {
            NSString *p2 = [runDir stringByAppendingPathComponent:n2];
            if (![fm fileExistsAtPath:p2]) { FILE *f2 = fopen(p2.fileSystemRepresentation, "a"); if (f2) fclose(f2); }   // 缺才建，绝不覆盖
            chmod(p2.fileSystemRepresentation, 0666);
            [fm setAttributes:@{NSFileOwnerAccountID:@(501), NSFileGroupOwnerAccountID:@(501)} ofItemAtPath:p2 error:NULL];
        }
        // ★ 2.0.40：注入件权限自愈（plist 644 / dylib 755）——防"打包链丢权限 → mobile 注入被跳过"
        NSString *dlDir = [rh stringByAppendingPathComponent:S("Library/MobileSubstrate/DynamicLibraries")];
        for (NSString *n in @[@"CTHermes.plist", @"CTHermesFaceDownLock.plist", @"CTHermesForeground.plist", @"CTHermesCCRegistration.plist"]) {
            chmod([[dlDir stringByAppendingPathComponent:n] fileSystemRepresentation], 0644);
        }
        for (NSString *n in @[@"CTHermes.dylib", @"CTHermesFaceDownLock.dylib", @"CTHermesForeground.dylib", @"CTHermesCCRegistration.dylib"]) {
            chmod([[dlDir stringByAppendingPathComponent:n] fileSystemRepresentation], 0755);
        }
        {   // ★ 2.0.40：配置文件对 mobile 开放（设置/控制中心要能写入；已知良好态 = root:mobile 0664）
            NSString *pcfg = [[rh stringByAppendingPathComponent:S("var/mobile/Library/Preferences")] stringByAppendingPathComponent:S("com.qq391160.cpucore.plist")];
            if ([[NSFileManager defaultManager] fileExistsAtPath:pcfg]) {
                chown(pcfg.fileSystemRepresentation, 0, 501);
                chmod(pcfg.fileSystemRepresentation, 0664);
            }
        }
        {   // ★ 2.0.40：授权文件照同标准（root:mobile 0664）
            NSString *paf = [rh stringByAppendingPathComponent:S("var/mobile/Library/Logs/CTHermesAuth.txt")];
            if ([[NSFileManager defaultManager] fileExistsAtPath:paf]) {
                chown(paf.fileSystemRepresentation, 0, 501);
                chmod(paf.fileSystemRepresentation, 0664);
            }
        }
        {   // ★ 2.0.40：工具 755 / 守护 644 / 日志 666（权限红线·自愈）
            NSArray *ctTools = @[@"usr/bin/CTHermesTool", @"usr/bin/CTHermesMountTool", @"usr/bin/CTHermesMountClient",
                                 @"usr/bin/CTHermesChargeTool",
                                 @"Library/PreferenceBundles/CTHermesSettings.bundle/CTHermesSettings",
                                 @"Library/ControlCenter/Bundles/CTHermesCC.bundle/CTHermesCC"];
            for (NSString *ctT in ctTools) chmod([[rh stringByAppendingPathComponent:ctT] fileSystemRepresentation], 0755);
            NSArray *ctLds = @[@"Library/LaunchDaemons/com.qq391160.cpucore.charge.plist",
                               @"Library/LaunchDaemons/com.qq391160.cpucore.mount.plist"];
            for (NSString *ctT in ctLds) chmod([[rh stringByAppendingPathComponent:ctT] fileSystemRepresentation], 0644);
            NSArray *ctLogs = @[@"Library/CTHermesState/logs/CTHermesDiag.log", @"Library/CTHermesState/logs/CTHermesFallback.log",
                                @"var/mobile/Library/Logs/CTHermesDiag.log", @"var/mobile/Library/Logs/CTHermesInstall.log"];
            for (NSString *ctT in ctLogs) chmod([[rh stringByAppendingPathComponent:ctT] fileSystemRepresentation], 0666);
        }
    } @catch (__unused NSException *e) {}
}
#endif

static BOOL networkThrottleBlockingEnabled(void) {
BOOL enabled = NO;
BOOL blockNetwork = NO;
runtimeConfigSnapshot(&enabled, NULL, &blockNetwork, NULL, NULL);
return enabled && blockNetwork && isFullPowerMode() && g_ctAuthOK;
}

static BOOL thermalPopupBlockingEnabled(void) {
BOOL enabled = NO;
BOOL blockPopup = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, &blockPopup, NULL);
return enabled && blockPopup && g_ctAuthOK;
}

static BOOL thermalDimmingPreventionEnabled(void) {
BOOL enabled = NO;
BOOL preventDimming = NO;
runtimeConfigSnapshot(&enabled, NULL, NULL, NULL, &preventDimming);
return enabled && preventDimming && g_ctAuthOK;
}

static CommonProduct *commonProductSnapshot(void) {
os_unfair_lock_lock(&g_stateLock);
CommonProduct *product = g_commonProduct;
os_unfair_lock_unlock(&g_stateLock);
return product;
}

static void setCommonProduct(CommonProduct *product) {
CommonProduct *previousProduct = nil;
os_unfair_lock_lock(&g_stateLock);
previousProduct = g_commonProduct;
g_commonProduct = product;
os_unfair_lock_unlock(&g_stateLock);
(void)previousProduct;
}

static BOOL CTHermesScreenIsBlanked(void) {
int token = 0;
uint64_t state = 0;
if (notify_register_check("com.apple.springboard.hasBlankedScreen", &token) != NOTIFY_STATUS_OK) return NO;
int result = notify_get_state(token, &state);
notify_cancel(token);
return result == NOTIFY_STATUS_OK && state != 0;
}

static BOOL isLowPowerMode(void) {
os_unfair_lock_lock(&g_modeLock);
BOOL res = (g_powerMode == CTHermesPowerModeLow);
os_unfair_lock_unlock(&g_modeLock);
return res;
}

static BOOL isFullPowerMode(void) {
os_unfair_lock_lock(&g_modeLock);
BOOL res = (g_powerMode == CTHermesPowerModeFull);
os_unfair_lock_unlock(&g_modeLock);
return res;
}

static BOOL shouldApplyFullCPUProtection(void) {
if (!runtimeProtectionEnabled()) return NO;
if (isFullPowerMode()) return YES;
// ★ 1.4.4：前台 App 正在享受"高性能"（游戏 / 档位高性能 / 高性能名单）时，同样启用高性能级保护
return shouldApplyAppFullProtection();
}

static BOOL shouldRestoreNativePerformance(void) {
return shouldApplyFullCPUProtection();
}

// ★ 充电状态（外接电源）缓存：每 5 秒读一次，避免频繁访问 IORegistry

static BOOL shouldApplyLowPowerLimit(void) {
// ★ T7x：滑动提速期间，低功耗压制"全线让路"——否则提速自己的解锁调用会被本判定的各钩子当场改回低档
//   （270 实测：低功耗下每次"升频开始"前都出现 "★系统抢值 → 强制=2500"，提速被自我压制抵消 → 滑动不跟手）
return runtimeProtectionEnabled() && isLowPowerMode() && !g_scrollBoostActive;
}

static void correctNominalStateIfNeeded(void) {
if (!shouldApplyFullCPUProtection()) return;
CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
os_unfair_lock_lock(&g_nominalLock);
BOOL shouldCorrect = (now - g_lastNominalCorrection) >= 1.0;
if (shouldCorrect) g_lastNominalCorrection = now;
os_unfair_lock_unlock(&g_nominalLock);
if (shouldCorrect) CTHermesForceNominalCombined();
}

static void scheduleThermalMonitorReload(void) {
// ★ 不再自杀/重启控温进程（那会引发 watchdog 连崩 + 发热）—— 改为立即安全重压一次
os_unfair_lock_lock(&g_runtimeLock);
if (g_thermalReloadScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_thermalReloadScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_async(dispatch_get_main_queue(), ^{
g_thermalReloadScheduled = NO;
if (runtimeProtectionEnabled()) {
applyCurrentPowerModeToRuntime();
}
});
}

static void scheduleThermalConfigurationReload(void) {
os_unfair_lock_lock(&g_runtimeLock);
g_forceThermalConfigReload = YES;
os_unfair_lock_unlock(&g_runtimeLock);
scheduleThermalMonitorReload();
}

static CTHermesPowerMode g_modeBeforeSleep = CTHermesPowerModeLow;   // 锁屏前正在生效的模式
static BOOL g_prefsLoaded = NO;   // ★ T5：设置是否已成功读取过
static BOOL g_softSwingActive = NO;   // ★ T7x3：声明前移（写睡前也要判断"是否正在摆动自愈"）
static void switchToLowPowerForSleep(const char *source) {
BOOL changed = NO;
os_unfair_lock_lock(&g_modeLock);
if (g_prefsLoaded) {                 // ★ T5 修复：设置没读出来之前绝不记录，
    if (!g_softSwingActive) {        // ★ T7x3：摆动自愈期间模式瞬时=高性能，绝不能记成"睡前模式"（否则醒来恢复成高性能、8 秒内不重算 → "全是高性能"）
        g_modeBeforeSleep = g_powerMode;     //   否则会把默认值"高性能"记进去 → 首次解锁恢复成高性能（实机抓到过）
        CTD("[写睡前] sleep: → %s (fg=%llu)", CTModeName(g_modeBeforeSleep), (unsigned long long)CTHermesReadForegroundBundleHash());
    } else {
        CTD("[写睡前] sleep: 摆动自愈进行中 → 沿用上次记录=%s", CTModeName(g_modeBeforeSleep));
    }
}
if (g_powerMode != CTHermesPowerModeLow) {
CTAuditMode("sleep", CTHermesPowerModeLow);
changed = YES;
}
os_unfair_lock_unlock(&g_modeLock);
if (changed) applyPowerModeToRuntime(NO);
CTLOG(S("[CTHermes] %s 状态临时进入低功耗，保留用户模式:%@"), source ?: "sleep",
      g_userSelectedPowerMode == CTHermesPowerModeLow ? S("低功耗") : S("性能模式"));
}

static void restoreUserModeAfterWake(const char *source) {
// 每次唤醒都以面板持久化的 powerMode 为权威来源；长时间锁屏后
// PMGR/ApplePPM 可能重建，内存枚举未变不代表硬件模式仍然有效。
NSDictionary *prefs = readPrefsDictionary();
CTHermesPowerMode selected;
BOOL prefsOK = (prefs && [prefs[S("powerMode")] isKindOfClass:[NSString class]]);
if (prefsOK) {
    NSString *savedMode = prefs[S("powerMode")];
    selected = [savedMode isEqualToString:S(kCTHermesLowPowerModeC)] ? CTHermesPowerModeLow : CTHermesPowerModeFull;
} else {
    // ★ 读取失败时保留当前用户模式 —— 绝不回退到"性能模式"
    //   （原来读不到就默认高性能 ✗ → 秒锁屏/秒亮屏撞上读取失败 → 一亮屏就高性能 ✗）
    os_unfair_lock_lock(&g_modeLock);
    selected = g_userSelectedPowerMode;
    os_unfair_lock_unlock(&g_modeLock);
}
// 修复：唤醒/解锁必须以"用户模式 + 指定应用覆盖"共同决定运行模式。
// 旧逻辑直接恢复用户模式，导致锁屏/解锁时若当前前台仍是指定应用，
// 低功耗被静默撤销，且 SpringBoard 因哈希未变化不会再上报，永久失效。
// ★★ 唤醒/解锁：直接沿用"锁屏前正在生效的模式"（g_modeBeforeSleep）。
//    解锁瞬间系统报的前台不可信（锁屏界面 / 旧 App），按它重算会把名单方向判反 —— 这正是"亮屏后高性能"的根因。
//    之后 8 秒内也不接受前台变化（见 applyForegroundDecision），等数据稳定了再正常判定。
CTHermesPowerMode target = g_modeBeforeSleep;
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
CTAuditMode("wake-restore", target);
os_unfair_lock_unlock(&g_modeLock);

// 无论 previous 与 target 是否相同都重新应用，覆盖唤醒后的 PMGR 回写。
applyPowerModeToRuntime(NO);
CTD("★事件[%s] 恢复模式=%s", source ?: "wake", isNativeMode() ? "原生" : (isLowPowerMode() ? "低功耗" : "高性能"));
CTDObjects("唤醒后");
// ★ 唤醒后连续三次重算前台（0.5 / 1 / 2 秒）—— 最快 ~0.5 秒就能恢复，又不怕 SpringBoard 数据还没稳定
for (int i = 0; i < 3; i++) {
    const double ctDelay = (i == 0) ? 0.5 : ((i == 1) ? 1.0 : 2.0);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        applyForegroundDecision("wake-settle");
    });
}
// ★ 唤醒后 10 秒内持续重申低功耗（40 次 x 0.25 秒）：
//   对抗系统在"亮屏瞬间/之后几秒"抬预算或回写 —— 覆盖你报的"锁屏 10 秒再亮屏变高性能"窗口。
if (isLowPowerMode()) {
    // ★ "周期重申"已改由 startPeriodicReassertTimer 统一负责（亮屏每 2 秒 / 熄屏每 5 秒，
    //   重发"模式变更"通知 = 完整重应用）—— 不再挂在"唤醒次数"上误触发。
    dispatch_async(dispatch_get_main_queue(), ^{
        runLowPowerApplyPulse(40);
    });
}
CTLOG(S("[CTHermes] %s 状态恢复面板模式:%@"), source ?: "wake",
      target == CTHermesPowerModeLow ? S("低功耗") : (target == CTHermesPowerModeFull ? S("高性能") : S("原生")));
// ★ 2026-09-17 自愈：唤醒后自动"完整摆动"——修复"睡醒后低功耗限制没落到真身"（模式=低但实际能跑满）
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if (!runSoftModeSwing("wake+2s")) {   // 此刻不是低功耗（如从名单App里锁的屏）→ 10 秒后再试一次
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            runSoftModeSwing("wake+10s");
        });
    }
});
}

static CFAbsoluteTime g_lastWakeStamp = 0;

// ★★★ T7 全量取证：模式写入审计（要求调用方已持 g_modeLock）
static void CTAuditMode(const char *who, CTHermesPowerMode newMode) {
    CTHermesPowerMode old = g_powerMode;
    g_powerMode = newMode;
    if (old != newMode) {
        CTD("[写模式] %s: %s → %s (fg=%llu blanked=%d 唤醒窗口=%.1fs)",
            who,
            CTModeName(old),
            CTModeName(newMode),
            (unsigned long long)CTHermesReadForegroundBundleHash(),
            (int)CTHermesScreenIsBlanked(),
            g_lastWakeStamp > 0 ? (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) : -1.0);
    }
}
static int g_ctFlagLast = -1;
static void CTAuditFlag(const char *who, BOOL v) {
    if ((int)v != g_ctFlagLast) {
        g_ctFlagLast = (int)v;
        CTD("[名单flag] %s: → %d (fg=%llu)", who, (int)v, (unsigned long long)CTHermesReadForegroundBundleHash());
    }
}
static uint64_t g_exceptionAppHash = 0;      // 触发"名单例外"时那个 App 的前台哈希   // 最近一次亮屏/解锁时刻（用于"刚刚唤醒"窗口判断）
static void handleLockStateToken(int token) {
uint64_t state = UINT64_MAX;
if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK) return;
CTD("[事件] lockstate state=%llu (blankedNow=%d)", (unsigned long long)state, (int)CTHermesScreenIsBlanked());
if (state == 0) { g_lastWakeStamp = CFAbsoluteTimeGetCurrent(); restoreUserModeAfterWake("unlock"); }
}

static void handleBlankedScreenToken(int token) {
uint64_t state = UINT64_MAX;
if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK) return;
CTD("[事件] blanked state=%llu", (unsigned long long)state);
g_lastWakeStamp = (state ? 0 : CFAbsoluteTimeGetCurrent());   // ★ 1.4.65：记录最近亮屏时刻（亮屏 3 秒内不写回亮度 ✓）
if (state == 0) { g_lastWakeStamp = CFAbsoluteTimeGetCurrent(); restoreUserModeAfterWake("screen-on"); }   // ★ 2.0.54：亮屏→立即预钉
else switchToLowPowerForSleep("screen-off");
}

static void handleThermalLevelNotification(int token) {
    uint64_t state = 0;
    if (token <= 0 || notify_get_state(token, &state) != NOTIFY_STATUS_OK || state == 0) return;
    CFAbsoluteTime now=CFAbsoluteTimeGetCurrent();
    // ★ 1.4.4：高性能 / 游戏保护期间 → 即时拍回（不等 5 秒）；其它模式保留限流（防低功耗被误抬满）
    BOOL active = shouldApplyFullCPUProtection();
    os_unfair_lock_lock(&g_thermalResetLock);
    BOOL allowed = active ? YES : ((now-g_lastThermalReset)>=5.0);
    if(allowed)g_lastThermalReset=now;
    os_unfair_lock_unlock(&g_thermalResetLock);
    if (allowed) {
        if (active) {
            CTHermesForceNominalCombined();
        } else {
            applyCurrentPowerModeToRuntime();
        }
    }
}

static void registerThermalLevelResetObservers(void) {
    if (!g_thermalResetQueue) g_thermalResetQueue=dispatch_queue_create("com.qq391160.cpucore.thermal-reset",DISPATCH_QUEUE_SERIAL);
    if (g_thermalPressureToken < 0) {
        notify_register_dispatch(kOSThermalNotificationPressureLevelName, &g_thermalPressureToken,
                                 g_thermalResetQueue, ^(int token) { handleThermalLevelNotification(token); });
    }
    if (g_thermalNotificationToken < 0) {
        notify_register_dispatch("com.apple.system.thermalnotification", &g_thermalNotificationToken,
                                 g_thermalResetQueue, ^(int token) { handleThermalLevelNotification(token); });
    }
}

static void registerScreenWakeObservers(void) {
if (g_lockStateToken < 0) {
notify_register_dispatch("com.apple.springboard.lockstate", &g_lockStateToken, dispatch_get_main_queue(), ^(int token) {
handleLockStateToken(token);
});
}
if (g_blankedScreenToken < 0) {
notify_register_dispatch("com.apple.springboard.hasBlankedScreen", &g_blankedScreenToken, dispatch_get_main_queue(), ^(int token) {
handleBlankedScreenToken(token);
});
}
// daemon 可能在设备已经熄屏时启动，注册后立即同步一次当前屏幕状态。
handleBlankedScreenToken(g_blankedScreenToken);
}

// ★ 2.0.94：深层心跳接收——深层进程发通知、tm 收账记日志（绕开"深层写不了日志"的死角）
static void handleDeepAliveCore(int which) {
    static int sN1 = 0, sN2 = 0; static CFAbsoluteTime sT1 = 0, sT2 = 0;
    int *n = (which == 1) ? &sN1 : &sN2; CFAbsoluteTime *lt = (which == 1) ? &sT1 : &sT2;
    CFAbsoluteTime nowD = CFAbsoluteTimeGetCurrent();
    int interval = (*lt > 0) ? (int)(nowD - *lt) : -1; *lt = nowD; (*n)++;
    if (*n <= 5) CTD("[高刷] 收到深层%d(%s)心跳（第 %d 次）→ 深层已注入实锤 ✓", which, (which == 1) ? "backboardd" : "网页", *n);
    else if ((*n % 6) == 0) CTD("[高刷] 深层%d心跳（第 %d 次，间隔≈%ds）", which, *n, interval);
}
static void registerDeepAliveObservers(void) {
    static int sDA1 = -1, sDA2 = -1;
    if (sDA1 < 0) notify_register_dispatch(kCTHermesDeepAlive1NotifC, &sDA1, dispatch_get_main_queue(), ^(int tk) { (void)tk; handleDeepAliveCore(1); });
    if (sDA2 < 0) notify_register_dispatch(kCTHermesDeepAlive2NotifC, &sDA2, dispatch_get_main_queue(), ^(int tk) { (void)tk; handleDeepAliveCore(2); });
}

// ★ 2.0.95：残留自检（一次性；仅 thermalmonitord）——把"老版体系文件/已装老包"直接列进日志
static void CTLegacyResidueOne(void) {
    @try {
        NSFileManager *fm = [NSFileManager defaultManager];
        NSMutableArray *dirs = [NSMutableArray arrayWithArray:@[ @"/Library/MobileSubstrate/DynamicLibraries", @"/var/jb/Library/MobileSubstrate/DynamicLibraries", @"/usr/lib/TweakInject", @"/var/jb/usr/lib/TweakInject",
                           @"/Library/LaunchDaemons", @"/var/jb/Library/LaunchDaemons",
                           @"/Library/PreferenceBundles", @"/var/jb/Library/PreferenceBundles",
                           @"/Library/ControlCenter/Bundles", @"/var/jb/Library/ControlCenter/Bundles",
                           @"/var/mobile/Library/Logs", @"/var/jb/var/mobile/Library/Logs", @"/var/jb/Library/Logs", @"/rootfs/var/mobile/Library/Logs", @"/rootfs/Library/Logs",
                           @"/var/mobile/Library/Preferences", @"/var/jb/var/mobile/Library/Preferences",
                           @"/var/mobile/Library/Caches", @"/var/jb/Library/Caches" ]];
        for (NSString *base in @[ @"/var/mobile/Containers/Shared/AppGroup", @"/var/containers/Shared/SystemGroup", @"/var/containers/Bundle/Application", @"/var/mobile/Library", @"/var/mobile/Containers/Data/Application" ]) {
            for (NSString *d in [fm contentsOfDirectoryAtPath:base error:nil]) {
                if (![d hasPrefix:@".jbroot-"]) continue;
                NSString *root = [base stringByAppendingPathComponent:d];
                [dirs addObject:[root stringByAppendingPathComponent:@"Library/Logs"]];
                [dirs addObject:[root stringByAppendingPathComponent:@"var/mobile/Library/Logs"]];
                [dirs addObject:[root stringByAppendingPathComponent:@"Library/MobileSubstrate/DynamicLibraries"]];
                [dirs addObject:[root stringByAppendingPathComponent:@"Library/LaunchDaemons"]];
                [dirs addObject:[root stringByAppendingPathComponent:@"Library/Preferences"]];
            }
        }
        int hits = 0;
        int selfN = 0;
        NSMutableString *ms = [NSMutableString string];
        NSDateFormatter *df = [[NSDateFormatter alloc] init]; df.dateFormat = @"MM-dd HH:mm";
        for (NSString *dir in dirs) {
            NSArray *items = [fm contentsOfDirectoryAtPath:dir error:nil];
            if (!items.count) continue;
            for (NSString *name in items) {
                NSString *low = [name lowercaseString];
                BOOL isLegacy = ([low containsString:@"cputhermal"] || [low containsString:@"huayuarc"]);
                BOOL isSelf = (!isLegacy && [low containsString:@"cthermes"]);
                if (!isLegacy && !isSelf) continue;
                NSString *full = [dir stringByAppendingPathComponent:name];
                NSDictionary *a = [fm attributesOfItemAtPath:full error:nil];
                unsigned long long sz = a ? [a[NSFileSize] unsignedLongLongValue] : 0;
                NSDate *mt = a ? a[NSFileModificationDate] : nil;
                if (isLegacy) {
                    if (hits < 30) [ms appendFormat:@"\n[残留自检] 命中: %@（%lluB %@）", full, sz, mt ? [df stringFromDate:mt] : @"?"];
                    hits++;
                } else {
                    if (selfN < 40) [ms appendFormat:@"\n[残留自检] 自名: %@（%lluB %@）", full, sz, mt ? [df stringFromDate:mt] : @"?"];
                    selfN++;
                }
            }
        }
        NSMutableString *pks = [NSMutableString string];
        int pkN = 0;
        for (NSString *sp in @[ @"/var/lib/dpkg/status", @"/rootfs/var/lib/dpkg/status", @"/var/jb/var/lib/dpkg/status" ]) {
            NSString *st = [NSString stringWithContentsOfFile:sp encoding:NSUTF8StringEncoding error:nil];
            if (!st.length) continue;
            for (NSString *line in [st componentsSeparatedByString:@"\n"]) {
                if (![line hasPrefix:@"Package: "]) continue;
                NSString *low = [line lowercaseString];
                if ([low containsString:@"cputhermal"] || [low containsString:@"huayuarc"] || [low containsString:@"cpusentry"] || [low containsString:@"qq391160.thermal"]) {
                    if (pkN < 20) [pks appendFormat:@"\n[残留自检] 老包: %@", [line substringFromIndex:9]];
                    pkN++;
                }
            }
        }
        CTD("[残留自检] 完成：文件命中=%d 自名=%d 老包命中=%d%@%@", hits, selfN, pkN, ms, pks);
    } @catch (__unused NSException *e) { CTD("[残留自检] 异常（已跳过）"); }
}

static int targetCPUPerformanceLevel(void) {
return isLowPowerMode() ? CTLowPowerLevel() : kFullPowerCPULevel;
}

static CFStringRef cpuMaxPowerPropertyName(void) {
static CFStringRef propertyName = NULL;
static dispatch_once_t once;
dispatch_once(&once, ^{
propertyName = CFStringCreateWithCString(kCFAllocatorDefault, "CPUMaxPower", kCFStringEncodingUTF8);
});
return propertyName;
}

static BOOL methodEncodingContains(id object, SEL selector, const char *needle) {
if (!object || !selector || !needle) return NO;
Method method = class_getInstanceMethod(object_getClass(object), selector);
if (!method) return NO;
const char *types = method_getTypeEncoding(method);
return types && strstr(types, needle) != NULL;
}

static char methodArgumentTypeCode(id object, SEL selector, unsigned int index) {
if (!object || !selector) return '\0';
Method method = class_getInstanceMethod(object_getClass(object), selector);
if (!method || index >= method_getNumberOfArguments(method)) return '\0';
char type[32] = {0};
method_getArgumentType(method, index, type, sizeof(type));
const char *cursor = type;
while (*cursor && strchr("rnNoORV", *cursor)) cursor++;
return *cursor;
}

static BOOL argumentTypeIs32BitInteger(char type) {
return type == 'c' || type == 'C' || type == 's' || type == 'S' ||
type == 'i' || type == 'I' || type == 'B';
}

static BOOL argumentTypeIs64BitInteger(char type) {
return type == 'q' || type == 'Q' || type == 'l' || type == 'L' || type == '^';
}

static void sendTwoIntegerArguments(id object, SEL selector, intptr_t firstValue, uintptr_t secondValue) {
if (!object || !selector || ![object respondsToSelector:selector]) return;
char firstType = methodArgumentTypeCode(object, selector, 2);
char secondType = methodArgumentTypeCode(object, selector, 3);
if (argumentTypeIs32BitInteger(firstType) && argumentTypeIs32BitInteger(secondType)) {
((void (*)(id, SEL, int, int))objc_msgSend)(object, selector, (int)firstValue, (int)secondValue);
return;
}
if (argumentTypeIs32BitInteger(firstType) && argumentTypeIs64BitInteger(secondType)) {
((void (*)(id, SEL, int, uintptr_t))objc_msgSend)(object, selector, (int)firstValue, secondValue);
return;
}
if (argumentTypeIs64BitInteger(firstType) && argumentTypeIs32BitInteger(secondType)) {
((void (*)(id, SEL, intptr_t, int))objc_msgSend)(object, selector, firstValue, (int)secondValue);
return;
}
if (argumentTypeIs64BitInteger(firstType) && argumentTypeIs64BitInteger(secondType)) {
((void (*)(id, SEL, intptr_t, uintptr_t))objc_msgSend)(object, selector, firstValue, secondValue);
}
}

static void sendSetPowerSaveToken(id controller, int token) {
if (!controller || ![controller respondsToSelector:CTObfSel("1db9ef0ff5c83a5c72ab2a4f844c6f913caafe1c4819")]) return;
char argumentType = methodArgumentTypeCode(controller, CTObfSel("9855e3655f65ea72dc16d12bb203aaea223b8706852b"), 2);
if (argumentType == '@') {
id tokenObject = token ? [NSNumber numberWithInt:token] : nil;
((void (*)(id, SEL, id))objc_msgSend)(controller, CTObfSel("e1c8c514a436b14cae0fa2829a89dee04ac591cb3c38"), tokenObject);
return;
}
if (argumentTypeIs64BitInteger(argumentType)) {
((void (*)(id, SEL, intptr_t))objc_msgSend)(controller, CTObfSel("27a9387714cd2e7692a066e2c124ce007974b334928d"), (intptr_t)token);
return;
}
if (argumentTypeIs32BitInteger(argumentType)) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("69fa9254ea2d6f9611d3c0d37dffbf46743be8936c3f"), token);
}

}

static void trackPowerController(id controller) {
if (!controller) return;
os_unfair_lock_lock(&g_controllerLock);
if (!g_mitigationControllers) g_mitigationControllers = [NSHashTable weakObjectsHashTable];
[g_mitigationControllers addObject:controller];
os_unfair_lock_unlock(&g_controllerLock);
}

static NSArray *trackedPowerControllersSnapshot(void) {
os_unfair_lock_lock(&g_controllerLock);
NSArray *controllers = g_mitigationControllers ? [g_mitigationControllers allObjects] : [NSArray array];
os_unfair_lock_unlock(&g_controllerLock);
return controllers;
}

static void trackApplePPMInstance(id instance) {
if (!instance) return;
os_unfair_lock_lock(&g_controllerLock);
if (!g_applePPMInstances) g_applePPMInstances = [NSHashTable weakObjectsHashTable];
[g_applePPMInstances addObject:instance];
os_unfair_lock_unlock(&g_controllerLock);
}

static NSArray *trackedApplePPMInstancesSnapshot(void) {
os_unfair_lock_lock(&g_controllerLock);
NSArray *instances = g_applePPMInstances ? [g_applePPMInstances allObjects] : [NSArray array];
os_unfair_lock_unlock(&g_controllerLock);
return instances;
}

static BOOL setMaxCPUPowerTargetUsesCFString(id controller) {
return methodEncodingContains(controller, CTObfSel("ea571ccc56fd65b54100d65afd59fe7e403b01ec1976e0736a7e078438c8b214074a5175cf565682cefa3337cff2ec1d6f1044"), "^{__CFString=}");
}

static uintptr_t setMaxCPUPowerPropertyArgument(id controller) {
return setMaxCPUPowerTargetUsesCFString(controller)
? (uintptr_t)cpuMaxPowerPropertyName()
: (uintptr_t)YES;
}

static uintptr_t normalizedSetMaxCPUPowerPropertyArgument(id controller, uintptr_t property) {
if (setMaxCPUPowerTargetUsesCFString(controller) && property < 4096) {
return (uintptr_t)cpuMaxPowerPropertyName();
}
return property;
}

static void sendSetMaxCPUPowerTarget(id controller, int target, BOOL legacy) {
if (!controller || ![controller respondsToSelector:CTObfSel("7456bae4de966ad4bca669a7aa5407856fe8d5d38278dec49877f26d3b1af1d9f905f40a2878ca69003822b1053c172853a0b1")]) return;
((void (*)(id, SEL, int, BOOL, uintptr_t))objc_msgSend)(controller,
CTObfSel("07a331b6e1625b1726fe6e200eaa25dfc9863c71d7e86535b7160595843b25a944e87ecaec326066ac5e6f82c034ba63eff069"),
target, legacy, setMaxCPUPowerPropertyArgument(controller));
}

// ★ 0186 充电让路（方案A）：插上充电器时，只把"功率预算压制"这一步让开（预算交还系统），
//   降频/等级/深度降频/温控一律保持原样；拔掉充电器立即恢复原节奏。
//   根因：低功耗档每秒重压预算 + 专门"对抗充电抬预算" → iOS 以为整机几乎不需要电 → 只向充电器要几瓦。
static BOOL g_ctChargeYield = NO;
static BOOL g_ctcPlugged = NO;   // ★ 0188：最近一次探测到的"插着充电器"状态（由每秒 tick 维护）
static CFAbsoluteTime g_ctcPluggedAt = 0;   // ★ 0188：该状态的时间戳（过期即视为未知，避免卡在"以为插着"）
static void ctChargeYieldTick(BOOL plugged) {
    g_ctcPlugged = plugged; g_ctcPluggedAt = CFAbsoluteTimeGetCurrent();   // ★ 0188：记住充电器状态+时间
    if (!runtimeProtectionEnabled() || !shouldApplyLowPowerLimit()) {
        if (g_ctChargeYield) { g_ctChargeYield = NO; notify_post("com.qq391160.cpucore/powerModeChanged"); CTD("[自测·充电] 让路=关（门控不满足）"); }   // 自测增强
        return;
    }
    if (plugged) {
        if (!g_ctChargeYield) {
            g_ctChargeYield = YES;
            for (id controller in trackedPowerControllersSnapshot()) {
                if (controller) applyFullPowerBudgetsOnController(controller);   // 只交还"预算"这一项
            }
            { static CFAbsoluteTime sYieldLogAt = 0; CFAbsoluteTime yn = CFAbsoluteTimeGetCurrent(); if (sYieldLogAt == 0 || yn - sYieldLogAt >= 120.0) { sYieldLogAt = yn; CTD("[充电让路] 让路上岗：预算交还系统（滚动提速往返会重复走这里，属正常）"); } }
        }
        return;
    }
    if (g_ctChargeYield) {
        g_ctChargeYield = NO;
        notify_post("com.qq391160.cpucore/powerModeChanged");   // 拔掉 → 恢复低功耗压制
        CTD("[充电让路] 充电器已拔：恢复低功耗预算压制");
    }
}

static void applyExplicitLowPowerBudgets(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
if (g_ctChargeYield || (g_ctcPlugged && CFAbsoluteTimeGetCurrent() - g_ctcPluggedAt < 10.0)) return;   // ★ 0188 充电让路：充电期间不压预算（含 App 刚切档的 1 秒空窗；状态 10 秒过期防卡死）
if ([controller respondsToSelector:CTObfSel("c0512001002086568eeed8c0322c641fd3c6413f5fd861eb7c")])
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("baea5811abb9821ef90e5dd4f94130de721086bd789541ae27"), CTLowPowerBudgetMW());
if ([controller respondsToSelector:CTObfSel("1dbb80425cdeee72a683a9da282c6d18a8db84928d46212299224f17e9b552dc19340eb9940fa82c0b22dcbd8bbba2cf7ec06e")])
sendSetMaxCPUPowerTarget(controller, CTLowPowerBudgetMW(), NO);
if ([controller respondsToSelector:CTObfSel("5ac05d00c7a22f92558870689f18b5ecc4e406460c5fea7e1748")])
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("8d6da8b600f7349aeee3f2a9a4b446c419d9b4d4d73012151ae6"), kLowPowerPerformancePercent);
for (int source = 0; source < kCPUDecisionSourceCount; source++) {
if ([controller respondsToSelector:CTObfSel("3c8233d7e113699125250b57f8bc6461d2cf31978cf077f6c591b3ec96c6a8a93c9d1ed7ae342ddf")])
sendTwoIntegerArguments(controller, CTObfSel("df586e0f5e85f0689745c227d8934ec5ef77a14a1cf37bb1f441aaa813fb30676f4bf32f71312856"), 0, (uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("090bc1bbca51f1ace74716aff882abc500fb6d0018eab3747573f9a7fff5d80c5b0c7f5399c4f35181fc")])
sendTwoIntegerArguments(controller, CTObfSel("ef9b6ad4abab9e2667f1ae6f6d8aa97d472f845efae8f71642b170e7793a2a417cbcd1be4b1910df965d"), kLowPowerPerformancePercent, (uintptr_t)source);
}
for (int contributor = 0; contributor < kCPUDVD1ContributorCount; contributor++)
if ([controller respondsToSelector:CTObfSel("519953db74ce3bd7cc89f61bbf3673951b87794203c70517372e9b12ebad7865bb52b257b4a12a6b9489")])
sendTwoIntegerArguments(controller, CTObfSel("9951ff7366cfe7664be4eae832b754251d23be9c967059e16393ebd5691c3ce28c834753444314dd31cb"), kLowPowerPerformancePercent, (uintptr_t)contributor);
}

static void reassertLowPowerStateWithoutUpdate(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
trackPowerController(controller);
// CPU CPMS 必须开启，CPU Level/预算才会真正落到 ApplePPM；PowerSave/Package 仍保持关闭，避免显示联动。
if ([controller respondsToSelector:CTObfSel("107eac6382cbcf4a9b3a463782792eede56fd6a49f7f5db1fa3a00978d75")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("3de00f8fa8ceb35004892bc947bc52289016e4bd1f4d58ebcd7400320c94"), YES);
if ([controller respondsToSelector:CTObfSel("b692d659ca5fbae6ba04e4e4d71a4b8ddf2f5438e90425")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("f14b0eeaa6975ba35b02a039aeb358d14d557aec4c1f13"), NO);
sendSetPowerSaveToken(controller, 0);
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
}

// 手动低功耗与指定应用低功耗统一使用 2500mW / 45% 明确预算。
static void applyLowPowerPerformancePreferenceToController(id controller) {
if (!controller || !shouldApplyLowPowerLimit()) return;
trackPowerController(controller);
// 低功耗只限制 CPU：开启 CPU CPMS 执行 Level/预算；不启用 PowerSave，也不调用 Package 低功耗目标。
if ([controller respondsToSelector:CTObfSel("739350d3766730b6677d536a3000d399e66635e9b73902e46a47f4093f1c")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("738af378c2e1440c973bb3de6d3cf491e3ae18d7490a3487e059b11788d0"), YES);
if ([controller respondsToSelector:CTObfSel("51846153f12a200a985739220495d7e66dd019f39a0f39")])
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("c6f8349d7b3a00ea0b67c33e394d181bc2b90af68d380d"), NO);
sendSetPowerSaveToken(controller, 0);
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
if ([controller respondsToSelector:CTObfSel("8a5e43864d32b1b19ae749e38c")])
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("0f106b8fa866d5d590250cee60"));
applyExplicitLowPowerBudgets(controller);
forceCPUPerformanceLevelOnController(controller);
}

// 性能模式统一恢复 CPU level 与 DVD1 level。
static void forceCPUPerformanceLevelOnController(id controller) {
if (!controller || !runtimeProtectionEnabled()) return;
int targetLevel = targetCPUPerformanceLevel();

if ([controller respondsToSelector:CTObfSel("4b3d550482a790dd8ac771a5dcee948f")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("7be284c0efa52dc71df2a8831322dde2"), targetLevel);
}
if ([controller respondsToSelector:CTObfSel("98a33dae9857027047dc797d3f6026eb1b")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("035ca117c94c8b34f6eded87ae30c449e4"), targetLevel);
}
}

// 性能模式恢复全部 CPU 功率预算。
static void applyFullPowerBudgetsOnController(id controller) {
if (!controller || !runtimeProtectionEnabled()) return;
if ([controller respondsToSelector:CTObfSel("67134d7bed2ff9a970cd8a197380bd6792512becb92040876dd0df6ff3ad")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("b1435ca19e240d379d567b30b60b690edabcbdd0ef268d1f948d7fd1fc39"), NO);
}
if ([controller respondsToSelector:CTObfSel("4b75168542346993051dbd96b31b4331811cc011ca86d7")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("5f95f26626a14848dd8c041284946bd32dbebcb95304ff"), NO);
}
if ([controller respondsToSelector:CTObfSel("30907c7cbb5bd5da9c29c2c4a864d71d759f38eacf0b")]) {
sendSetPowerSaveToken(controller, 0);
}
if ([controller respondsToSelector:CTObfSel("3b271807a6bd131f47b3911be5dd22140efd32dfd5e767524fcb")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("59e03c2a4b1e4407b7975cc5d884a3bff4baacadddff08697e28"), 0);
}
if ([controller respondsToSelector:CTObfSel("6f95c924573c057b01d53e264046ca58ad7d78eb6fc2ea08a5")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("60b65723b363dfbb74eb65b9c8aab75d0f51e66c97dda979a0"), kUnrestrictedPowerLimitMW);
}
if ([controller respondsToSelector:CTObfSel("9ba986efc755d0c4bd72062705c602244617d6ff780bb28fb907f6c54ad731e6d54b1e9c6344c56b09442c9fc7ddeb1ffd9cfc")]) {
sendSetMaxCPUPowerTarget(controller, kUnrestrictedPowerLimitMW, NO);
}
if ([controller respondsToSelector:CTObfSel("f1a115e57ffcd9a71c76eef47fbe50ed36d2d368f2efecf6e7bc")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("430877f27d0f3175c3ff930969c4be2560f05a54c04bf3e7b52c"), kUnrestrictedPerformancePercent);
}
for (int source = 0; source < kCPUDecisionSourceCount; source++) {
if ([controller respondsToSelector:CTObfSel("eb85807e8fa1cbe3e31982eaa2dca5345681e0f2f1b282ef669236866b11b8bc6582debf109cae72a365")]) {
sendTwoIntegerArguments(controller, CTObfSel("ee74b14537e93b5cf98d21f6450d3543ee6e4bd4089a498f16facd238207f6d8fe11d0283289e0fcaa26"), kUnrestrictedPerformancePercent, (uintptr_t)source);
}
if ([controller respondsToSelector:CTObfSel("69335b1726d13e6c07cc5de1bc8b6c9f1163e38090b7ac0ba5dbaeba106e78ff5cd8e1bca6b50185")]) {
sendTwoIntegerArguments(controller, CTObfSel("68a4cb1ecf289b5372df14e644b0b8ea55a8a5cc1c2ef3d9254893f6c49548c1728b8a2c0ce4d822"), 0, (uintptr_t)source);
}
}
for (int contributor = 0; contributor < kCPUDVD1ContributorCount; contributor++) {
if ([controller respondsToSelector:CTObfSel("51c2ca04629394367f8956dfaaa38fdcf7fbdb8b678817b2339861e545071e82e6eae51642c6ee9c2034")]) {
sendTwoIntegerArguments(controller, CTObfSel("722c6e6ce4812768bdb1f62639a4538a6e86256c0e5e80dd092a9f4321f837e801a623df2cad3fdcc577"), kUnrestrictedPerformancePercent, (uintptr_t)contributor);
}
}
if ([controller respondsToSelector:CTObfSel("3743b9f24cd66ee0444697fa0e229cb843288206aef7fea865d1")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("e7cf785962a85315bc5c38ac7e31cdfb1cc1cad07e430c5d2382"),kUnrestrictedPerformancePercent);
if ([controller respondsToSelector:CTObfSel("4950c2bd895a2590343f374161d90f6b")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("5ce861ffe31a49fe11fda82b2a96678d"),0);
if ([controller respondsToSelector:CTObfSel("395990e9dc29357fe49c134e1e4bff4dc9143172f9a9c84302761dd2d25b0d2ba4473b")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("fec1488ecf40b7f9a45b0be2e92009979cd61f318abd4ebb7de59b66ca7643586a7c72"),kUnrestrictedPowerLimitMW);
if ([controller respondsToSelector:CTObfSel("c88422910e5aa8507f2b582fd07887241eca38f9650f3e")]) ((void (*)(id,SEL,int))objc_msgSend)(controller,CTObfSel("b04e1bf1fa4292154adbae35ea997445079d3bda7d8c86"),kUnrestrictedPowerLimitMW);
for (int source=0;source<kCPUDecisionSourceCount;source++) {
if ([controller respondsToSelector:CTObfSel("1f8baf51c672a5dc02aea331f1add39d90b459f58a21563f4835bb0584ff6531bc127e310149b1f9bb1c")]) sendTwoIntegerArguments(controller,CTObfSel("29ddf80f0aae1326eb6022177b42c55654b1474beb701b40cdbaa404d721ac8ca1508390ff512947a8d4"),kUnrestrictedPerformancePercent,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("ed91168933127244f6fbe6bc501ff34008c521839c99c1e1b4a6e2a6f311a5012060f68cdb296a41")]) sendTwoIntegerArguments(controller,CTObfSel("244d06ee61737fad2394649014a6316812e819b7d023e9ae0e5fb348a78eff2eec473ab060bcb3d8"),0,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("338cb5539515a140852c40a1d8bcf4721d63c66225dbdb22ebf5251e3e70d67c61e214c0ac6cf638a6af6b47ca02")]) sendTwoIntegerArguments(controller,CTObfSel("fc1cfda11a7b8c009bb48dfac97e3ecd6fd48dbcefa268300448003a42e6e48fdc0a1296e19ba2369b5a307064fb"),kUnrestrictedPerformancePercent,(uintptr_t)source);
if ([controller respondsToSelector:CTObfSel("831278c2fc433214a98b65af6fab139883439fc9f17c0072d3680acff191223fc2beee9a4c184360d7dabbd4")]) sendTwoIntegerArguments(controller,CTObfSel("5902f1d2960be38050e903397c8402e07d32d727dc7712e596724a9b4c891776f668dc969ba522a3dfb64082"),0,(uintptr_t)source);
}
forceCPUPerformanceLevelOnController(controller);
}

static void applyLowPowerLimitsToTrackedControllers(void) {
if (!shouldApplyLowPowerLimit()) return;
@autoreleasepool {
NSArray *controllers = trackedPowerControllersSnapshot();
for (id controller in controllers) {
applyLowPowerPerformancePreferenceToController(controller);
}
}
}

static void restoreFullPowerToController(id controller) {
if (!controller || !shouldApplyFullCPUProtection()) return;
@try {
g_restoringFullPower = YES;
applyFullPowerBudgetsOnController(controller);
if ([controller respondsToSelector:CTObfSel("9c802b661eac9c84ad7ad67f0e")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("162f353b584e99e033b175f917"));
}
if ([controller respondsToSelector:CTObfSel("7b9d7abd7633400cf4588c553f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("721e3471dd4778068aff2bd2d3"));
}
if ([controller respondsToSelector:CTObfSel("3a9abc3e1d6b87ba64d1340a12dda40f8b")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("65856658eaeb5d8872ea2e658c45619566"));
}
// 原生 update 可能按残留低功耗缓存回写 Level 2；刷新后再次覆盖最终状态。
applyFullPowerBudgetsOnController(controller);
if ([controller respondsToSelector:CTObfSel("4a97dd4173367d343a57eed805")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("4559dc2eba50dd21d22f281b8b"));
}
applyFullPowerBudgetsOnController(controller);
} @catch (NSException *exception) {
CTLOG(S("[CTHermes] 恢复性能模式 CPU 上限失败: %@"), exception);
} @finally {
g_restoringFullPower = NO;
}
}

static void restoreFullPowerToTrackedControllers(void) {
if (!shouldApplyFullCPUProtection()) return;
@autoreleasepool {
NSArray *controllers = trackedPowerControllersSnapshot();
for (id controller in controllers) {
restoreFullPowerToController(controller);
}
}
}

static void restoreNativeRuntimeAfterDisable(void) {
@autoreleasepool {
@try {
g_restoringFullPower = YES;
for (id controller in trackedPowerControllersSnapshot()) {
if ([controller respondsToSelector:CTObfSel("b1f5fee563ae4725f8a1c500119f1dd5cd14ed62b9d9e98261a555c3c6fb")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("3db4fd8d03a9451216921e2815666e7cc0903839cef26e799219a8f467cf"), NO);
}
if ([controller respondsToSelector:CTObfSel("1ba9e4851d925f5ad203628dda98a4f97b1312f4b14b40")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(controller, CTObfSel("b5de63ed90a434f864e30406217d98c35507459f820448"), NO);
}
sendSetPowerSaveToken(controller, 0);
if ([controller respondsToSelector:CTObfSel("8232a749158a8c0f5338d20c66b437a9")]) {
((void (*)(id, SEL, int))objc_msgSend)(controller, CTObfSel("8909d9f66abf8a227e1d30fdf85c20e8"), kFullPowerCPULevel);
}
if ([controller respondsToSelector:CTObfSel("2700dc0ec51df9b2f59ac2725f")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("b6b55d0bcf135d8a8bf701396c"));
}
if ([controller respondsToSelector:CTObfSel("62aca2cce07a04c23b329228af")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("69ad1fb01fe80c23e296d8601e"));
}
if ([controller respondsToSelector:CTObfSel("ae0b469020509393a4d78b21c99b09a342")]) {
((void (*)(id, SEL))objc_msgSend)(controller, CTObfSel("0197ad6cca27fc589bfbc152bd440fbeca"));
}
}
} @catch (NSException *exception) {
CTLOG(S("[CTHermes] 禁用时恢复原生状态失败: %@"), exception);
} @finally {
g_restoringFullPower = NO;
}
}
}

static void setCommonProductCeiling(CommonProduct *product, SEL selector, int ceiling) {
if (!product || !selector || ![product respondsToSelector:selector]) return;
((void (*)(id, SEL, int, id))objc_msgSend)(product, selector, ceiling, S("CTHermes"));
}

static void applyLowPowerToCommonProduct(void) {
if (!shouldApplyLowPowerLimit()) return;
CommonProduct *product = commonProductSnapshot();
if (!product) return;
@try {
if ([product respondsToSelector:CTObfSel("b8b4ac12080282097a851608a5c29947")]) {
((void (*)(id, SEL, int))objc_msgSend)(product, CTObfSel("1c97e7724562d501c685f76617647903"), CTLowPowerLevel());
}
setCommonProductCeiling(product, CTObfSel("55abe0d908e5132c7e977b6c6a9cb8e49c27413cbfa7fa4f47b94d69946444b11efd517157991e87"), 0);
// 不调用 tryTakeAction：它会执行全组件热缓解（含显示/DCP），与“低功耗只限 CPU”相冲突。
} @catch (NSException *exception) {
CTLOG(S("[CTHermes] 即时套用低功耗 CommonProduct 状态失败: %@"), exception);
}
}

static void applyFullPowerToCommonProduct(void) {
if (!shouldApplyFullCPUProtection()) return;
CommonProduct *product = commonProductSnapshot();
if (!product) return;
BOOL previousRestoring = g_restoringFullPower;
@try {
g_restoringFullPower = YES;
if ([product respondsToSelector:CTObfSel("dca83c132008173707550a5b23a6670eb1f08c3188010e39d7f078fa7ff7")]) {
((void (*)(id, SEL, BOOL))objc_msgSend)(product, CTObfSel("766c241688f453f3502b01fd8a707cf6786744852db126eb673cd0f3f0fe"), NO);
}
if ([product respondsToSelector:CTObfSel("384c6a655c91f552e9e0ddc95b214f4d")]) {
((void (*)(id, SEL, int))objc_msgSend)(product, CTObfSel("9c480a4988dacddedf18a78c35fc0991"), targetCPUPerformanceLevel());
}
setCommonProductCeiling(product, CTObfSel("010572c3b8d85f42d911d6567fcf27e04514561c9fadc60cb42b57fe1381ae127e2793330323234d182d"), kUnrestrictedPerformancePercent);
setCommonProductCeiling(product, CTObfSel("82812453b0c6e5e7d4a7a92ae75e47284abbb4232405874f2284cbea9f9e0eeda1538f9aeb978f93"), 0);
setCommonProductCeiling(product, CTObfSel("499b31e3fcda55421d6876dd225f2ee70b7165ea311a3b6721944c9646634b1becb6c3c9d98885c6d60c"), kUnrestrictedPerformancePercent);
setCommonProductCeiling(product, CTObfSel("b10acc5bd4b1439be34c7a20acc0f2dc19bff324e558706d7c01e3a8913d09cfb9965fe41a4673681783daa3fd03"), kUnrestrictedPerformancePercent);
if ([product respondsToSelector:CTObfSel("a5984105fa4d5d204d716f68aa451908f5577b15")]) {
((void (*)(id, SEL, id))objc_msgSend)(product, CTObfSel("60cdf9828c4d4c8e7b3c39595ca2d440f3d4aaa1"), [NSNumber numberWithInt:0]);
}
CTHermesForceNominalCombined();
} @catch (NSException *exception) {
CTLOG(S("[CTHermes] 套用性能模式 CommonProduct 状态失败: %@"), exception);
} @finally {
g_restoringFullPower = previousRestoring;
}
}

static void applyCurrentPowerModeToRuntime(void) {
applyPowerModeToRuntime(YES);
}

// ★ T7o：交还原生要“真的清掉低功耗残留”——低功耗会把 Level/预算/CPMS 压到低档，
//   只调 updateCPU 时系统重算不会自动复位 → 表现＝退回桌面/切到不自管的应用后频率仍停在上一档。
static void ctNativeReleasePass(void) {
    @autoreleasepool {
        // ★ 1.4.20：无条件"已注入"信标 —— 发布版也能一眼看出主插件是否装载（支持排查）
        CTD("[核心] 主插件已注入 pid=%d（随后按 总开关/CPU保护/身份/授权 决定是否接管）", (int)getpid());
        NSArray *ctrls = trackedPowerControllersSnapshot();
        for (id c in ctrls) {
            applyFullPowerBudgetsOnController(c);            // 关 CPMS 缓解 + Level 0 + 预算全解开
            if ([c respondsToSelector:CTObfSel("e8e65e644828db2f07bd4a3eab")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("cba555a45ea02f175e828a4d90"));
            if ([c respondsToSelector:CTObfSel("7068ca92b76798721b61604c5c")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("714f0d9f6052f884a9e659feb3"));
            if ([c respondsToSelector:CTObfSel("f77042c19251b0b57cedba1072c0474e48")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("54409b3bbd169d65e25763cee022d0369d"));
            applyFullPowerBudgetsOnController(c);            // update 可能回写旧 Level → 再清一次
        }
        id poc = commonProductSnapshot();
        if (poc) {
            if ([poc respondsToSelector:CTObfSel("6ebbbbaba6302b74361afcc5df0ee1f2")]) ((void (*)(id, SEL, int))objc_msgSend)(poc, CTObfSel("5cb60e1abb09ab6b5564130d03fcfb75"), kFullPowerCPULevel);
            if ([poc respondsToSelector:CTObfSel("2d53f108c39aec29e2c44f09fd")]) ((void (*)(id, SEL))objc_msgSend)(poc, CTObfSel("65b3a0915ec57b7f415bddc5ed"));
        }
    }
}

static void releaseToNativeMode(void) {
    ctNativeReleasePass();
    CTD("[智能] 原生：已清低功耗残留（Level 0 / 关 CPMS / 预算解开），交还系统");
    // ★ T7m 交还重申（保留）：系统不一定马上把上限重算回来，错开再轻推两次
    static CFAbsoluteTime sCTLastRelease = 0;
    CFAbsoluteTime ctRNow = CFAbsoluteTimeGetCurrent();
    if (ctRNow - sCTLastRelease > 3.0) {
        sCTLastRelease = ctRNow;
        for (int ctRi = 1; ctRi <= 2; ctRi++) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctRi * 0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (!isNativeMode()) return;
                ctNativeReleasePass();
            });
        }
    }
}

// ★ 270：滑动提速专用"提到高性能"过程（比单纯放开更跟手；结束后按原模式回落）
static void ctScrollBoostApplyPass(void) {
    g_ctLastBoostAt = CFAbsoluteTimeGetCurrent();   // ★ 1.4.90
@autoreleasepool {
NSArray *ctrls = trackedPowerControllersSnapshot();
for (id c in ctrls) {
applyFullPowerBudgetsOnController(c);            // 预算全解开（内部会先按当前档设置，下面重申为高性能档）
if ([c respondsToSelector:CTObfSel("b5c1f336a5ec84bb20b3c7728b071d76")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("02681ea998cc8d95dfb02b1eb7e9cc43"), kFullPowerCPULevel);
if ([c respondsToSelector:CTObfSel("a75c2329e155f30e73be3c1d3f79aa3c8a")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("125c137188993570680c8c02f4031fd3d0"), kFullPowerCPULevel);
if ([c respondsToSelector:CTObfSel("6dc0f78b4518db7ec8c096bca7")]) ((void (*)(id, SEL))objc_msgSend)(c, CTObfSel("35872e027af0d8d08dacda87de"));
if ([c respondsToSelector:CTObfSel("690c8d333e3e570bd476466e1e088b94")]) ((void (*)(id, SEL, int))objc_msgSend)(c, CTObfSel("81af8eaabaf4f57d2fbb6de35243373c"), kFullPowerCPULevel);
}
id poc = commonProductSnapshot();
if (poc) {
if ([poc respondsToSelector:CTObfSel("20a4bb042f1e45d6215ae62125c8f308bd2309255559308611b78fb178ee")]) ((void (*)(id, SEL, BOOL))objc_msgSend)(poc, CTObfSel("abc273678848143e6b3a5c5d2bc3448f2cb238d5d1509d674bf7aac6259b"), NO);
if ([poc respondsToSelector:CTObfSel("3f489f6903a79099563b6ca1487c79ae")]) ((void (*)(id, SEL, int))objc_msgSend)(poc, CTObfSel("27b4eccb910ce9687ab661e763296c08"), kFullPowerCPULevel);
if ([poc respondsToSelector:CTObfSel("ef3fe999d21682d6b4436f4367")]) ((void (*)(id, SEL))objc_msgSend)(poc, CTObfSel("8f56a8e6295edbb0ed31bfd5f4"));
}
}
}

static void applyPowerModeToRuntime(BOOL respectBootGuard) {
if (!runtimeProtectionEnabled()) return;
(void)respectBootGuard;
if (!isLowPowerMode()) g_scrollBoostActive = NO;   // ★ 269：非低功耗不保留滑动放行状态
if (isNativeMode()) { releaseToNativeMode(); CTHermesScheduleBacklightRecovery(); return; }   // ★ 智能：交还系统
if (isLowPowerMode()) {
if (g_scrollBoostActive) {   // ★ 270：滑动提速期间，低功耗压制让路（避免"刚进 App 立刻滑"被压回去）
CTHermesScheduleBacklightRecovery();
return;
}
// 在任何 CPU/Power setter 前记录用户亮度与设备 cap，防止低功耗切换先把 DCP 上限压低。
CTHermesCaptureBrightnessBeforeModeChange();
CTHermesCaptureExistingBacklightMaximum();
applyLowPowerToCommonProduct();
applyLowPowerLimitsToTrackedControllers();
applyCurrentModeToApplePPMCPU();
scheduleLowPowerApplyPulse();
CTHermesScheduleBacklightRecovery();
return;
}
if (isFullPowerMode()) {
// 切回性能模式后主动清理低功耗残留的 DCP cap，并恢复切换前用户亮度。
CTHermesForceNominalCombined();
applyFullPowerToCommonProduct();
restoreFullPowerToTrackedControllers();
applyCurrentModeToApplePPMCPU();
scheduleFullPowerRecoveryPulse();
CTHermesScheduleBacklightRecovery();
}
}

static void scheduleFullPowerRecoveryPulse(void) {
if (!shouldRestoreNativePerformance()) return;
os_unfair_lock_lock(&g_runtimeLock);
if (g_fullPowerRecoveryPulseScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_fullPowerRecoveryPulseScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runFullPowerRecoveryPulse(6);
});
}

static void runFullPowerRecoveryPulse(int remainingPulses) {
if (remainingPulses <= 0 || !shouldRestoreNativePerformance()) {
os_unfair_lock_lock(&g_runtimeLock);
g_fullPowerRecoveryPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
applyFullPowerToCommonProduct();
restoreFullPowerToTrackedControllers();
applyCurrentModeToApplePPMCPU();
if (remainingPulses <= 1) {
os_unfair_lock_lock(&g_runtimeLock);
g_fullPowerRecoveryPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runFullPowerRecoveryPulse(remainingPulses - 1);
});
}

static void scheduleLowPowerApplyPulse(void) {
if (!shouldApplyLowPowerLimit()) return;
os_unfair_lock_lock(&g_runtimeLock);
if (g_lowPowerApplyPulseScheduled) {
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
g_lowPowerApplyPulseScheduled = YES;
os_unfair_lock_unlock(&g_runtimeLock);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runLowPowerApplyPulse(12);
});
}

static void runLowPowerApplyPulse(int remainingPulses) {
if (remainingPulses <= 0 || !shouldApplyLowPowerLimit()) {
os_unfair_lock_lock(&g_runtimeLock);
g_lowPowerApplyPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
applyLowPowerToCommonProduct();
applyLowPowerLimitsToTrackedControllers();
applyCurrentModeToApplePPMCPU();
if (remainingPulses <= 1) {
os_unfair_lock_lock(&g_runtimeLock);
g_lowPowerApplyPulseScheduled = NO;
os_unfair_lock_unlock(&g_runtimeLock);
return;
}
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
runLowPowerApplyPulse(remainingPulses - 1);
});
}

// ★ 2026-09-17 自愈 v2："完整摆动"——真正切换一次模式（低→满），停留 4 秒，再完整切回低功耗。
//   与"手动进一次名单App再出来"完全同路径（含热状态归位/PPM/恢复脉冲/亮度链）。
//   起因：睡醒后偶发"模式=低功耗但限制没落到真身"（实际仍能跑满 3780，应为 2112）。
static CFAbsoluteTime g_lastSoftSwing = 0;
static BOOL runSoftModeSwing(const char *reason) {
if (!runtimeProtectionEnabled()) return YES;
if (g_softSwingActive || (CFAbsoluteTimeGetCurrent() - g_lastSoftSwing) < 5.0) return YES;
if (!isLowPowerMode()) return NO;   // 当前不是低功耗（如人在名单App里）→ 让调用方稍后再试
// ★ T7z11：按需摆动——先实测频率：已经压住（<2560）就不摆动（消除"每次解锁爆 4 秒高性能"）；
//   读不到或确实偏高才走完整摆动；真没压住时还有频率看门狗兜底。
{
    double ctSwingMHz = 0.0;
    if (CTFreqReadMHz(&ctSwingMHz) && ctSwingMHz > 0.0 && ctSwingMHz < 2560.0) {
        CTD("[自愈] %s: 实测 %.0f MHz 已压住 → 跳过摆动", reason ?: "wake", ctSwingMHz);
        return YES;
    }
}
g_softSwingActive = YES;
g_lastSoftSwing = CFAbsoluteTimeGetCurrent();
CTD("[自愈] %s: 完整摆动开始（切高性能，4 秒后切回低功耗）", reason ?: "wake");
os_unfair_lock_lock(&g_modeLock);
CTAuditMode("soft-swing", CTHermesPowerModeFull);
os_unfair_lock_unlock(&g_modeLock);
applyPowerModeToRuntime(NO);
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if (!runtimeProtectionEnabled()) { g_softSwingActive = NO; return; }
    os_unfair_lock_lock(&g_modeLock);
    CTAuditMode("soft-swing-back", CTHermesPowerModeLow);
    os_unfair_lock_unlock(&g_modeLock);
    applyPowerModeToRuntime(NO);
    g_softSwingActive = NO;
    CTD("[自愈] %s: 完整摆动完成（已完整切回低功耗）", reason ?: "wake");
});
return YES;
}

// ★ T7z5：高性能"落地保证"——注销/重启后首次进入高性能：自动走一次
//   "满→低功耗 2.5 秒→重新解析切回"（等价于用户手动"切低功耗再切回性能模式"；
//   智能模式下游戏/高性能档同样适用）。
static BOOL g_ctFullLandingArmed = NO;
static BOOL g_ctFullLandingHandled = NO;
static CFAbsoluteTime g_ctFullLandingLast = 0;
static BOOL g_ctFullLandingRunning = NO;
static void runFullModeLanding(const char *reason) {
    if (!runtimeProtectionEnabled()) return;
    if (g_ctFullLandingRunning || g_softSwingActive) return;
    if ((CFAbsoluteTimeGetCurrent() - g_ctFullLandingLast) < 5.0) return;
    if (!isFullPowerMode()) { CTD("[落地] %s: 已不是高性能 → 跳过", reason ?: "boot-full"); return; }
    g_ctFullLandingRunning = YES;
    g_ctFullLandingLast = CFAbsoluteTimeGetCurrent();
    g_softSwingActive = YES;   // 冻结重算（防其它路径中途抢回）
    CTD("[落地] %s: 高性能落地开始（先切低功耗 2.5 秒，再重新解析切回）", reason ?: "boot-full");
    os_unfair_lock_lock(&g_modeLock);
    CTAuditMode("full-landing-low", CTHermesPowerModeLow);
    os_unfair_lock_unlock(&g_modeLock);
    applyPowerModeToRuntime(NO);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!runtimeProtectionEnabled()) { g_softSwingActive = NO; g_ctFullLandingRunning = NO; return; }
        g_softSwingActive = NO;          // 先解冻，让"重新解析"能通过
        CTHermesSyncModeFromPrefs();   // 重新解析：高性能→回高性能；智能→按识别落位
        g_ctFullLandingRunning = NO;
        CTD("[落地] %s: 高性能落地完成（已重新解析切回）", reason ?: "boot-full");
    });
}


// ============================================================================
// 频率读取器（自 CC 模块移植，只读）—— 供频率看门狗使用
// ============================================================================
typedef CFMutableDictionaryRef (*CTIOR_CopyChannelsInGroup)(CFStringRef, CFStringRef, uint64_t, uint64_t, uint64_t);
typedef CFMutableDictionaryRef (*CTIOR_CreateSubscription)(void *, CFMutableDictionaryRef, CFMutableDictionaryRef *, uint64_t, CFTypeRef);
typedef CFDictionaryRef (*CTIOR_CreateSamples)(CFMutableDictionaryRef, CFMutableDictionaryRef, CFTypeRef);
typedef int (*CTIOR_Iterate)(CFDictionaryRef, int (^)(CFDictionaryRef));
typedef CFStringRef (*CTIOR_ChannelGetChannelName)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_ChannelGetSubGroup)(CFDictionaryRef);
typedef int (*CTIOR_StateGetCount)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_StateGetNameForIndex)(CFDictionaryRef, int);
typedef int64_t (*CTIOR_StateGetResidency)(CFDictionaryRef, int);

static void *g_ctIOReport = NULL;
static BOOL g_ctIOReportTried = NO;
static CTIOR_CopyChannelsInGroup g_ctCopyChannels = NULL;
static CTIOR_CreateSubscription g_ctCreateSubscription = NULL;
static CTIOR_CreateSamples g_ctCreateSamples = NULL;
static CTIOR_Iterate g_ctIterate = NULL;
static CTIOR_ChannelGetChannelName g_ctChannelName = NULL;
static CTIOR_ChannelGetSubGroup g_ctChannelSubGroup = NULL;
static CTIOR_StateGetCount g_ctStateCount = NULL;
static CTIOR_StateGetNameForIndex g_ctStateName = NULL;
static CTIOR_StateGetResidency g_ctStateResidency = NULL;
static CFMutableDictionaryRef g_ctSub = NULL;
static CFMutableDictionaryRef g_ctSubbed = NULL;
static BOOL g_ctProbeDumped __attribute__((unused)) = NO;
static NSInteger g_ctFreqErrCode = 0;
static int g_ctFreqMaxStates = 0;
static NSMutableString *g_ctFreqScanLog = nil;
static NSInteger g_ctFreqRelChans = 0;       // 本次采样里「CPU 相关通道」的个数
static int g_ctProbeWrites = 0;              // 探针最多写 3 次（加载时1次 + 失败时2次）
static int g_ctFreqStateChans = 0;     // 有状态的通道个数
static NSString *g_ctFreqStateName = nil;   // 选中状态的名字（诊断用）   // 0正常 1dlopen失败 2无通道 3订阅失败 4采样失败 5读不到状态
static double g_ctLastMHz = -1.0;
static NSMutableDictionary *g_ctPrevRes = nil;
static double g_ctTopActiveMHz = 0.0;

static double CTFreqNormalizeMHz(long long raw) {
    double v = (double)raw;
    if (v > 10000000.0) return v / 1000000.0;
    if (v > 10000.0)    return v / 1000.0;
    return v;
}

static CFStringRef CTCFStr(const char *s) {
    return s ? CFStringCreateWithCString(kCFAllocatorDefault, s, kCFStringEncodingUTF8) : NULL;
}

static BOOL CTFreqLoad(void) {
    if (g_ctIOReportTried) return g_ctIOReport != NULL;
    g_ctIOReportTried = YES;
    g_ctIOReport = dlopen("/System/Library/PrivateFrameworks/IOReport.framework/IOReport", RTLD_LAZY);
    if (!g_ctIOReport) g_ctIOReport = dlopen("/usr/lib/libIOReport.dylib", RTLD_LAZY);
    if (!g_ctIOReport) return NO;
    g_ctCopyChannels       = (CTIOR_CopyChannelsInGroup)dlsym(g_ctIOReport, "IOReportCopyChannelsInGroup");
    g_ctCreateSubscription = (CTIOR_CreateSubscription)dlsym(g_ctIOReport, "IOReportCreateSubscription");
    g_ctCreateSamples      = (CTIOR_CreateSamples)dlsym(g_ctIOReport, "IOReportCreateSamples");
    g_ctIterate            = (CTIOR_Iterate)dlsym(g_ctIOReport, "IOReportIterate");
    g_ctChannelName        = (CTIOR_ChannelGetChannelName)dlsym(g_ctIOReport, "IOReportChannelGetChannelName");
    g_ctChannelSubGroup    = (CTIOR_ChannelGetSubGroup)dlsym(g_ctIOReport, "IOReportChannelGetSubGroup");
    g_ctStateCount         = (CTIOR_StateGetCount)dlsym(g_ctIOReport, "IOReportStateGetCount");
    g_ctStateName          = (CTIOR_StateGetNameForIndex)dlsym(g_ctIOReport, "IOReportStateGetNameForIndex");
    g_ctStateResidency     = (CTIOR_StateGetResidency)dlsym(g_ctIOReport, "IOReportStateGetResidency");
    return (g_ctCopyChannels && g_ctCreateSubscription && g_ctCreateSamples && g_ctIterate &&
            g_ctStateCount && g_ctStateName && g_ctStateResidency);
}

static BOOL CTFreqSetup(void) {
    if (g_ctSub && g_ctSubbed) return YES;
    if (!CTFreqLoad()) { g_ctFreqErrCode = 1; return NO; }

    static const char *pairs[][2] = {
        { "CPU Stats", NULL },
        { "CPU Stats", "CPU Complex Performance States" },
        { "CPU Stats", "CPU Performance States" },
        { "PMP", NULL },
        { "SoC Stats", NULL },
        { NULL, NULL }
    };

    CFMutableDictionaryRef bestRel = NULL, bestRelSubbed = NULL;   // 含 CPU 频率通道的
    CFMutableDictionaryRef bestAny = NULL, bestAnySubbed = NULL;   // 兜底：其它
    int bestRelStates = 0, bestAnyStates = -1;
    for (int pi = 0; pairs[pi][0]; pi++) {
        CFStringRef g  = CTCFStr(pairs[pi][0]);
        CFStringRef sg = pairs[pi][1] ? CTCFStr(pairs[pi][1]) : NULL;
        CFMutableDictionaryRef chans = g_ctCopyChannels(g, sg, 0, 0, 0);
        if (g) CFRelease(g);
        if (sg) CFRelease(sg);
        if (!chans) continue;

        CFMutableDictionaryRef subbed = NULL;
        CFMutableDictionaryRef sub = g_ctCreateSubscription(NULL, chans, &subbed, 0, NULL);
        int totalStates = 0, chansWithStates = 0, anyOnly = 0;
        if (sub && subbed && g_ctCreateSamples && g_ctIterate && g_ctStateCount) {
            CFDictionaryRef samples = g_ctCreateSamples(sub, subbed, NULL);
            if (samples) {
                __block int tot = 0, cnt = 0, anyTot = 0;
                g_ctIterate(samples, ^int(CFDictionaryRef ch) {
                    int n = g_ctStateCount(ch);
                    if (n <= 0) return 0;
                    anyTot += n;
                    NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
                    BOOL rel = (sub && ([sub containsString:S("Complex Voltage States")] ||
                                        [sub containsString:S("Complex Performance States")]));
                    if (rel) { tot += n; cnt++; }
                    return 0;
                });
                totalStates = tot; chansWithStates = cnt;
                if (cnt == 0) anyOnly = anyTot;
                CFRelease(samples);
            }
        }
        CFRelease(chans);

        if (sub && subbed && totalStates > bestRelStates) {          // 优先：真有 CPU 频率通道的
            if (bestRel) CFRelease(bestRel);
            if (bestRelSubbed) CFRelease(bestRelSubbed);
            bestRel = sub; bestRelSubbed = subbed;
            bestRelStates = totalStates;
            g_ctFreqStateChans = chansWithStates;
        } else if (sub && subbed && anyOnly > bestAnyStates) {        // 兜底
            if (bestAny) CFRelease(bestAny);
            if (bestAnySubbed) CFRelease(bestAnySubbed);
            bestAny = sub; bestAnySubbed = subbed;
            bestAnyStates = anyOnly;
        } else {
            if (sub) CFRelease(sub);
            if (subbed) CFRelease(subbed);
        }
    }

    if (bestRel && bestRelSubbed) {
        if (bestAny) CFRelease(bestAny);
        if (bestAnySubbed) CFRelease(bestAnySubbed);
        g_ctSub = bestRel; g_ctSubbed = bestRelSubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    if (bestAny && bestAnySubbed) {
        g_ctSub = bestAny; g_ctSubbed = bestAnySubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    g_ctFreqErrCode = 2;
    return NO;
}
// 从 “P3: 2400MHz / 2.4GHz” 这类状态名里直接读频率
static double CTFreqParseStateNameMHz(CFStringRef name) {
    if (!name) return -1;
    NSString *s = [(__bridge NSString *)name lowercaseString];
    NSRange r = [s rangeOfString:@"ghz"];
    double mult = 1000.0;
    if (r.location == NSNotFound) { r = [s rangeOfString:@"mhz"]; mult = 1.0; }
    if (r.location == NSNotFound) return -1;
    // 往前取数字（含小数点）
    NSInteger end = (NSInteger)r.location;
    NSInteger start = end;
    while (start > 0) {
        unichar c = [s characterAtIndex:(NSUInteger)(start - 1)];
        if ((c >= '0' && c <= '9') || c == '.') start--; else break;
    }
    if (start >= end) return -1;
    double v = [[s substringWithRange:NSMakeRange((NSUInteger)start, (NSUInteger)(end - start))] doubleValue];
    if (v <= 0) return -1;
    return v * mult;
}

// 读某颗 CPU 的 DVFS 频率表（取状态数最接近的那张）
// 解析一段 uint32 数组：按 (频率,电压) 成对取频率，两种排列都试，用电压做合理性校验
static NSArray<NSNumber *> *CTFreqParsePairArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 6) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    for (int flip = 0; flip < 2; flip++) {
        NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
        BOOL ok = YES, asc = YES;
        double prev = 0;
        for (NSUInteger idx = 0; idx + 1 < n; idx += 2) {
            double a = w[idx], b = w[idx + 1];
            double f = flip ? b : a, volt = flip ? a : b;
            if (volt > 10000.0) volt /= 1000.0;              // µV → mV
            if (volt < 300.0 || volt > 1600.0) { ok = NO; break; }
            double mhz = CTFreqNormalizeMHz((long long)f);
            if (mhz < 200.0 || mhz > 4600.0) { ok = NO; break; }
            if (mhz < prev) asc = NO;
            prev = mhz;
            [freqs addObject:@(mhz)];
        }
        if (!ok || freqs.count < 3) continue;
        NSInteger delta = 0;
        if (want > 0) {
            delta = labs((long)((NSInteger)freqs.count - want));
            if (delta > 1) continue;                          // 长度要接近状态数（允许差 1 个 IDLE）
        }
        NSInteger sc = 100 - delta * 20 + (asc ? 10 : 0);
        if (sc > bestScore) { bestScore = sc; best = freqs; }
    }
    if (best && score) *score = bestScore;
    return best;
}

// 解析「纯频率列表」：整段都是 200~4600MHz 的升序值
static NSArray<NSNumber *> *CTFreqParsePlainArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 3) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
    double prev = 0;
    BOOL asc = YES;
    for (NSUInteger i = 0; i < n; i++) {
        double mhz = CTFreqNormalizeMHz((long long)w[i]);
        if (mhz < 200.0 || mhz > 4600.0) return nil;
        if (mhz < prev) asc = NO;
        prev = mhz;
        [freqs addObject:@(mhz)];
    }
    NSInteger delta = 0;
    if (want > 0) {
        delta = labs((long)((NSInteger)freqs.count - want));
        if (delta > 1) return nil;
    }
    if (score) *score = 90 - delta * 20 + (asc ? 10 : 0);
    return freqs;
}

// 递归扫设备树找频率表；先只找属性名含 voltage-states 的，找不到再全扫
static void CTFreqScanTree(io_registry_entry_t node, int depth, int want, BOOL onlyVoltageStates,
                           NSArray<NSNumber *> **best, NSInteger *bestScore, int *visited) {
    if (depth > 4 || (*visited) > 300) return;
    (*visited)++;
    char nodePath[512] = {0};
    IORegistryEntryGetPath(node, "IODeviceTree", nodePath);
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = CFBridgingRelease(props);
        for (NSString *k in d.allKeys) {
            if (onlyVoltageStates && ![k containsString:S("voltage-states")]) continue;
            NSInteger scPair = -1, scPlain = -1;
            NSArray<NSNumber *> *tPair = CTFreqParsePairArray(d[k], want, &scPair);
            NSArray<NSNumber *> *tPlain = CTFreqParsePlainArray(d[k], want, &scPlain);
            NSInteger sc = (scPlain > scPair) ? scPlain : scPair;
            NSArray<NSNumber *> *t = (scPlain > scPair) ? tPlain : tPair;
            if (t) {
                if (!g_ctFreqScanLog) g_ctFreqScanLog = [NSMutableString string];
                if (g_ctFreqScanLog.length < 4000) {
                    [g_ctFreqScanLog appendFormat:S("%s [%@] 档数=%lu 得分=%ld 值=%@\n"),
                     nodePath, k, (unsigned long)t.count, (long)sc,
                     [t componentsJoinedByString:S(",")]];
                }
            }
            if (t && sc > *bestScore) { *bestScore = sc; *best = t; }
        }
    }
    static const char *planes[] = { "IODeviceTree", "IOService" };
    for (int pi = 0; pi < 2; pi++) {
        if (*best) break;
        io_iterator_t it = 0;
        if (IORegistryEntryGetChildIterator(node, planes[pi], &it) != KERN_SUCCESS) continue;
        io_registry_entry_t child = 0;
        while ((child = IOIteratorNext(it))) {
            CTFreqScanTree(child, depth + 1, want, onlyVoltageStates, best, bestScore, visited);
            IOObjectRelease(child);
        }
        IOObjectRelease(it);
    }
}

// 实时扫描：每次都重新从系统（设备树）读，不做任何缓存
static NSArray<NSNumber *> *CTFreqTableScan(int stateCount) {
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    int visited = 0;
    io_registry_entry_t root = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/");
    if (root) {
        CTFreqScanTree(root, 0, stateCount, YES, &best, &bestScore, &visited);
        if (!best) { visited = 0; CTFreqScanTree(root, 0, stateCount, NO, &best, &bestScore, &visited); }
        IOObjectRelease(root);
    }
    if (best.count >= 2) best = [best sortedArrayUsingSelector:@selector(compare:)];
    if (!best) {   // 设备树里没搜到才用实测档位表兜底（A17 Pro）
        if (stateCount == 5) {
            best = @[ @744, @960, @1344, @1728, @2112 ];
        } else if (stateCount == 17) {
            best = @[ @576, @1092, @1344, @1584, @1824, @2064, @2304, @2544, @2724, @2904,
                      @3084, @3264, @3444, @3564, @3684, @3732, @3780 ];
        }
    }
    return best;
}

// 带缓存的版本（只有历史实时频率代码在用）
static NSArray<NSNumber *> *CTFreqTableMatching(int stateCount) {
    static NSMutableDictionary *cache = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSNumber *key = @(stateCount);
    if (cache[key]) return cache[key];
    NSArray<NSNumber *> *best = CTFreqTableScan(stateCount);
    if (best) cache[key] = best;
    return best;
}

// 从系统频率表里读「最高档」= 这个模式能跑到的 CPU 最大值
// 每次都重新读设备树（实时）；读不到返回 0，由调用方兜底
static int CTFreqSystemMaxMHz(int stateCount) {
    NSArray<NSNumber *> *tbl = CTFreqTableScan(stateCount);
    if (tbl.count == 0) return 0;
    return (int)[tbl.lastObject doubleValue];
}

// 取一次实时频率：返回当前“最高正在跑”的那个核心簇频率（MHz）
#include <notify.h>

// 系统热压力等级（thermalmonitord 广播）：0 正常 / 10 轻 / 20 中 / 30 重 / 40 / 50
// 读不到返回 -1（那就当作"没发热"，显示最高档）
static int CTThermalPressureLevel(void) {
    static int ctTpToken = -1;
    static BOOL ctTpTried = NO;
    if (!ctTpTried) {
        ctTpTried = YES;
        int t = 0;
        if (notify_register_check("com.apple.system.thermalpressurelevel", &t) == NOTIFY_STATUS_OK) {
            ctTpToken = (int)t;
        }
    }
    if (ctTpToken < 0) return -1;
    uint64_t st = 0;
    if (notify_get_state(ctTpToken, &st) != NOTIFY_STATUS_OK) return -1;
    return (int)st;
}

static BOOL CTFreqReadMHzInner(double *outMHz) {
    if (!CTFreqSetup()) return NO;
    CFDictionaryRef samples = g_ctCreateSamples(g_ctSub, g_ctSubbed, NULL);
    if (!samples) { g_ctFreqErrCode = 4; return NO; }

    __block double best = -1.0;
    __block BOOL sawActive = NO;
    __block NSInteger relChans = 0;
    __block int bestPrio = 0;
    __block int maxStates = 0;
    g_ctIterate(samples, ^int(CFDictionaryRef ch) {
        int n = g_ctStateCount(ch);
        if (n <= 0) return 0;
        if (n > maxStates) maxStates = n;

        // 只认两种通道：CPU Complex Voltage States（无 IDLE、下标对齐）
        //              CPU Complex Performance States（多一个 IDLE，下标要 -1）
        NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
        NSString *cname = g_ctChannelName ? (__bridge NSString *)g_ctChannelName(ch) : nil;
        BOOL isVoltStates = (sub && [sub containsString:S("Complex Voltage States")]);
        BOOL isPerfStates = (sub && [sub containsString:S("Complex Performance States")]);
        if (!isVoltStates && !isPerfStates) return 0;   // DVD 百分比、核心级通道都不要
        relChans++;
        // 优先级：大核 PCPU 的 Voltage States（3）> 其它 Voltage States（2）> Performance States（1）
        int prio = isVoltStates ? ([cname hasPrefix:S("PCPU")] ? 3 : 2) : 1;
        if (prio < bestPrio) return 0;

        if (!g_ctPrevRes) g_ctPrevRes = [NSMutableDictionary dictionary];
        // 取「这一秒内有活动过的最高档」= 实时最高频率
        // （状态计数是累计值 → 用本次与上次采样的差值判断"这一秒到底用没用过"）
        int hi = -1;
        int topIdx = -1;
        int64_t bestRes = 0;
        int base = isPerfStates ? 1 : 0;                 // Performance States 第 0 档是 IDLE
        int wantW = isPerfStates ? (n - 1) : n;
        NSArray<NSNumber *> *tblW = CTFreqTableMatching(wantW);
        double sumW = 0.0, sumWF = 0.0;                  // ★ 方案A：按占用时间加权
        for (int i = 0; i < n; i++) {
            int64_t r = g_ctStateResidency(ch, i);
            if (r > bestRes) { bestRes = r; hi = i; }
            NSString *rk = [NSString stringWithFormat:@"%@#%d", cname, i];
            NSNumber *prev = g_ctPrevRes[rk];
            int64_t d = prev ? (r - prev.longLongValue) : 0;
            g_ctPrevRes[rk] = @(r);
            if (d <= 0 || i < base) continue;
            int idx = i - base;
            if (idx > topIdx) topIdx = idx;
            double f = 0.0;
            if (tblW && idx < (int)tblW.count) f = tblW[idx].doubleValue;
            if (f <= 0.0) {
                int si0 = isPerfStates ? (idx + 1) : idx;
                if (si0 >= 0 && si0 < n) f = CTFreqParseStateNameMHz(g_ctStateName(ch, si0));
            }
            if (f > 0.0) { sumW += (double)d; sumWF += (double)d * f; }
        }
        if (hi < 0) return 0;
        sawActive = YES;

        int useIdx = (topIdx >= 0) ? topIdx : (isPerfStates ? (hi - 1) : hi);
        if (useIdx < 0) return 0;                        // 命中的是 IDLE 档，不算频率
        int si   = isPerfStates ? (useIdx + 1) : useIdx;  // 对应的状态名下标
        CFStringRef nmRef = (si >= 0 && si < n) ? g_ctStateName(ch, si) : NULL;
        NSString *nmStr = nmRef ? (__bridge NSString *)nmRef : nil;
        double topMHz = 0.0;
        if (topIdx >= 0 && tblW && topIdx < (int)tblW.count) topMHz = tblW[topIdx].doubleValue;
        double mhz = (sumW > 0.0) ? (sumWF / sumW) : 0.0;   // ★ 加权平均频率（方案 A）
        if (mhz <= 0) {
            NSArray<NSNumber *> *tbl = CTFreqTableMatching(wantW);
            if (tbl && useIdx < (int)tbl.count) mhz = tbl[useIdx].doubleValue;
        }
        if (mhz > 0) {
            if (prio > bestPrio) { bestPrio = prio; best = mhz; g_ctTopActiveMHz = topMHz; }
            else if (mhz > best) { best = mhz; g_ctTopActiveMHz = topMHz; }
            if (nmStr) g_ctFreqStateName = [nmStr copy];
        }
        return 0;
    });
    CFRelease(samples);
    g_ctFreqMaxStates = maxStates;
    g_ctFreqRelChans = relChans;   // cN：相关通道个数（诊断用）

    if (best >= 200.0 && best <= 6000.0) { if (outMHz) *outMHz = best; g_ctFreqErrCode = 0; return YES; }
    g_ctFreqErrCode = sawActive ? 6 : 5;
    return NO;
}

// ★ 2026-09-17 频率看门狗：低功耗模式下实测频率持续超上限 → 自动完整摆动（只读检测，不改其它逻辑）
static int g_wdHighTicks = 0;
static CFAbsoluteTime g_wdLastSwing = 0;

// ★ T7z4/T7z6 诊断：频率跟踪（只写日志，不改行为）+ 电池温度/热压力（视频场景测试用）
// 电池温度（AppleSmartBattery "Temperature" ≈ 0.01°C；读不到返回 -2）
// 注：用 kIOMasterPortDefault（theos 自带 IOKit 头里没有新常量 kIOMainPortDefault → 线上编译实锤）
static double CTBatteryTempC(void) {
    static double sT = -2.0; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime ctNowT = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (ctNowT - sAt) < 15.0) return sT;
    if (!CTObfReady()) { sT = -2.0; sAt = ctNowT; return sT; }   // ★ 2.0.43：锁定态（未授权）不查询系统——防"空串喂 IOKit"闪崩
    sAt = ctNowT; sT = -2.0;
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("5f07c59b0acf23f23c705719745ebfb25e2807c505") UTF8String]));
    if (svc) {
        CFNumberRef n = (CFNumberRef)IORegistryEntryCreateCFProperty(svc, (__bridge CFStringRef)CTObfStr("1340e86cb3a8d8a2e15ca3294081a4"), kCFAllocatorDefault, 0);
        if (n) {
            long long v = 0;
            CFNumberGetValue(n, kCFNumberLongLongType, &v);
            CFRelease(n);
            if (v > 100 && v < 12000) sT = (double)v / 100.0;
        }
        IOObjectRelease(svc);
    }
    return sT;
}
// ============================================================================
// ★ 1.4.6 充电管家：电池信息读取 + 充电控制引擎
//   机制（调研自开源 ChargeLimiter，iOS13+ 实机验证）：
//     · 停充 = 向 AppleSmartBattery 写 IsCharging=YES + PredictiveChargingInhibit=YES
//     · 续充 = 写 PredictiveChargingInhibit=NO
//     · 限速 = 无直接限流接口 → "停充占空比"（充 N 秒 / 停 M 秒）做平均封顶（实机校准）
// ============================================================================
typedef struct {
    double volt_mV, amp_mA, tempC, adapterW;
    int capacity;
    BOOL isCharging, extConnected, valid;
} CTChargeInfo;

static CTChargeInfo CTChargeRead(void) {
    CTChargeInfo ci; memset(&ci, 0, sizeof(ci)); ci.tempC = -2.0;
    if (!CTObfReady()) return ci;   // ★ 2.0.43：锁定态不查询（防闪崩；数值留空不影响任何功能）
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("c7708a6a5e224eb865922835df2caeb3434ab2a4ae") UTF8String]));
    if (!svc) return ci;
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(svc, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = (__bridge_transfer NSDictionary *)props;
        @try {
            id v = d[CTObfStr("ab9c8251c55d1142b43667")];             if ([v isKindOfClass:[NSNumber class]]) ci.volt_mV = [v doubleValue];
            id ia = d[CTObfStr("ac8323b890e32f753e3392185a1f2dee8c06ef")];    if (![ia isKindOfClass:[NSNumber class]]) ia = d[CTObfStr("1cf515528e05009c1d036eeb")];
            if ([ia isKindOfClass:[NSNumber class]]) ci.amp_mA = [ia doubleValue];
            id tp = d[S("Temperature")];        if ([tp isKindOfClass:[NSNumber class]]) { double tv = [tp doubleValue]; if (tv > 100 && tv < 12000) ci.tempC = tv / 100.0; }
            id ch = d[CTObfStr("93cec93839566ec6733cbd50625b")];         if ([ch isKindOfClass:[NSNumber class]]) ci.isCharging = [ch boolValue];
            id ex = d[CTObfStr("17972a86e4be166bf974e9304e196773d3f48543a8")];  if ([ex isKindOfClass:[NSNumber class]]) ci.extConnected = [ex boolValue];
            id cp = d[CTObfStr("a13ed206accc8808b0239f1ec5bcb5dd2218bd")];    if ([cp isKindOfClass:[NSNumber class]]) { int cv = [cp intValue]; if (cv < 0) cv = 0; if (cv > 100) cv = 100; ci.capacity = cv; }
            id ad = d[CTObfStr("dceae37bffd63714929d06ce0428284e3904")];
            if ([ad isKindOfClass:[NSDictionary class]]) { id w = ((NSDictionary *)ad)[CTObfStr("ef1911451d4e90d7ab")]; if ([w isKindOfClass:[NSNumber class]]) ci.adapterW = [w doubleValue]; }
            ci.valid = YES;
        } @catch (__unused NSException *e) {}
    } else if (props) {
        CFRelease(props);
    }
    IOObjectRelease(svc);
    return ci;
}

static volatile BOOL g_ctcSelfWrite = NO;      // "我们自己在写"标记（防拦截钩子误伤）
static int g_ctcLastWriteErr = 0;              // ★ 1.4.6z3：最近一次充电属性写入的内核返回码（诊断用）
static int g_ctcLastWriteSvc = 0;              // ★ 1.4.6z3：最近一次写入用的服务（1=AppleSmartBattery 2=IOPMPowerSource 0=都失败）
// ★ 1.4.6z3：充电属性"双通道路由"——先写 AppleSmartBattery，失败自动改走 IOPMPowerSource
//   （ChargeLimiter 实测备用通道；本机出现过"写入失败→停充按不住"，加备份路 + 把失败原因记清楚）
static BOOL CTChargeWriteDict(NSDictionary *props) {
    if (!CTObfReady()) return NO;   // ★ 2.0.43：锁定态不写（防空键闪崩；未授权本就不该写）
    kern_return_t r = (kern_return_t)0xE00002BC;   // kIOReturnError 兜底
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("4eaba984bb8e4befdf3bf89989c576075f494a731a") UTF8String]));
    if (svc) {
        g_ctcSelfWrite = YES;
        r = IORegistryEntrySetCFProperties(svc, (__bridge CFTypeRef)props);
        g_ctcSelfWrite = NO;
        IOObjectRelease(svc);
        if (r == KERN_SUCCESS) { g_ctcLastWriteSvc = 1; g_ctcLastWriteErr = 0; return YES; }
    } else {
        r = (kern_return_t)1;   // 服务缺失
    }
    g_ctcLastWriteErr = (int)r;
    svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching([CTObfStr("b192ba5592fde161412711faa121911ae116c2") UTF8String]));
    if (svc) {
        g_ctcSelfWrite = YES;
        r = IORegistryEntrySetCFProperties(svc, (__bridge CFTypeRef)props);
        g_ctcSelfWrite = NO;
        IOObjectRelease(svc);
        if (r == KERN_SUCCESS) { g_ctcLastWriteSvc = 2; g_ctcLastWriteErr = 0; return YES; }
        g_ctcLastWriteErr = (int)r;
    }
    g_ctcLastWriteSvc = 0;
    return NO;
}
static BOOL CTChargeWriteInhibit(BOOL inhibit) {
    if (!CTObfReady()) return NO;   // ★ 2.0.43：锁定态不写（防空键闪崩）
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    [props setObject:[NSNumber numberWithBool:YES] forKey:CTObfStr("5b09a807f4d72b7003d8a473984a")];
    [props setObject:[NSNumber numberWithBool:inhibit ? YES : NO] forKey:CTObfStr("261c101b68279078dda2641c2735dba7e167287f8e950d3e14d1b43bca")];
    return CTChargeWriteDict(props);
}

// ★ 1.4.6z2：禁流层——写 ExternalConnected（ChargeLimiter 源码实证：iPhone8+ 重置它
//   可消除"120 秒设定延迟"、且系统充电图标会跟着更新）。停充 = 本层 + PChI 两层一起按才按得稳。
static BOOL CTChargeWriteInflow(BOOL inflow) {
    if (!CTObfReady()) return NO;   // ★ 2.0.43：锁定态不写（防空键闪崩）
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    [props setObject:[NSNumber numberWithBool:inflow] forKey:CTObfStr("bc6a7db448370df3263ec0bce6c799d4f7e999db79")];
    return CTChargeWriteDict(props);
}

static int  g_ctcWinVar = 0;   // ★ 1.4.6z4：末次换形态咬住的形态号（2=直写IsCharging 3=仅PCI）
// ★ 1.4.6z4：停充"换形态"级联——主形态（PCI式/禁流式）都被拒时，再依次尝试其它写入形态
//   背景：本机 iOS17 出现过"两通道全被拒（错误-536870174）→ 停充按不住"；换形态或许绕开门槛。
static BOOL CTChargeTryExtraStop(void) {
    if (!CTObfReady()) return NO;   // ★ 2.0.43：锁定态不写（防空键闪崩）
    NSMutableDictionary *p1 = [NSMutableDictionary dictionary];
    [p1 setObject:[NSNumber numberWithBool:NO] forKey:CTObfStr("c28b4fecc511fc15672f80215031")];   // 直写 IsCharging=NO
    if (CTChargeWriteDict(p1)) { g_ctcWinVar = 2; return YES; }
    NSMutableDictionary *p2 = [NSMutableDictionary dictionary];
    [p2 setObject:[NSNumber numberWithBool:YES] forKey:CTObfStr("d8341d8183c3e4d303e84657db77b5a53578114a56369227403fe53a41")];  // 仅 PCI 式
    if (CTChargeWriteDict(p2)) { g_ctcWinVar = 3; return YES; }
    return NO;
}

// ---- 配置（loadPrefs 刷新）----
// ★ 1.4.59：温度兜底——核心读不到时，直读电池（和守护同一路 ✓）
static double CTCFTempFallbackC(void) {
    double t = -1.0;
    io_service_t svc = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("AppleSmartBattery"));
    if (svc) {
        CFTypeRef v = IORegistryEntryCreateCFProperty(svc, CFSTR("Temperature"), kCFAllocatorDefault, 0);
        if (v) { if (CFGetTypeID(v) == CFNumberGetTypeID()) { int d = 0; CFNumberGetValue(v, kCFNumberIntType, &d); if (d != 0) t = d / 100.0; } CFRelease(v); }
        IOObjectRelease(svc);
    }
    return t;
}
static BOOL g_ctcLimitOn = NO, g_ctcTempOn = NO, g_ctcForceOn = NO, g_ctcDisplayOn = NO;   // ★ 2.0.103：显示默认关
static int  g_ctcLimitVal = 80, g_ctcTempVal = 42;
// ---- 运行态 ----
static BOOL g_ctcPaused = NO, g_ctcLimitLatched = NO, g_ctcTempLatched = NO;
static BOOL g_ctcResumeWait = NO;
static CFAbsoluteTime g_ctcResumeAt = 0;   // ★ 1.4.92：进入"恢复中"的时刻（超时自动落 ✓）              // ★ 1.4.6x：已请求恢复、等硬件放行（浮窗"恢复中"显示用）
static CFAbsoluteTime g_ctcNoFlowAt = 0;       // ★ 1.4.6x：插着但没电流的起点（滞后 5 秒防闪）
static CFAbsoluteTime g_ctcLastHoldAssert = 0; // ★ 1.4.6z：停充"在岗重申"节拍（每 5 秒重发，防被系统放开）
static CFAbsoluteTime g_ctcPausedAt = 0.0;      // ★ 2.0.113：停充全程起点（健康检查：长咬不合降频用）
static BOOL g_ctcHoldWarned = NO;              // ★ 1.4.6z：停充未咬合只记一次日志（首条）
static CFAbsoluteTime g_ctcHoldWarnAt = 0;     // ★ 1.4.6z4：未咬合日志 60 秒限频
static BOOL g_ctcHoldOK = NO;                  // ★ 1.4.6z4：停充当前是否咬合（状态变化各记一行）
static CFAbsoluteTime g_ctcLastRescue = 0, g_ctcLastForceLog = 0, g_ctcLastIntercept = 0, g_ctcLastNominal = 0;   // ★ 2.0.114：防停充记账（救援/拦截/名义重申）
static CFAbsoluteTime g_ctcRescueVerifyAt = 0;   // ★ 2.0.38：救援后核实点（仅留证）
static BOOL g_ctcRescueFailedLast = NO;          // ★ 2.0.38：上一轮救援是否"核实未恢复"
static CFAbsoluteTime g_ctcThrottleAt = 0, g_ctcLastThrottleFix = 0;   // ★ 2.0.38：热天"降流救援"节拍
static int g_ctcCapacity = -1;   // ★ 1.4.6f：满电判定缓存（tick 每秒刷新；hook 只读）
static int  g_ctcIntercepts = 0;   // ★ 2.0.114：拦截计数（2.0.96 版回归）
static double g_ctcSmW = 0; static int g_ctcSmN = 0;
static CFAbsoluteTime g_ctcVerifyAt = 0;   // ★ 1.4.6m：动作后 3 秒自动复核（验证是否真的生效）
static int g_ctcVerifyKind = 0;            // 1=停充后 2=恢复后 3=拦截后
static int  g_ctcPubState = 0, g_ctcPubW = 0, g_ctcPubCap = 0;
static const char *g_ctcPubReason = "none";

// ★ 2.0.51：防停充"真热门"——只有电池真热(≥38°C)才允许我们对充电做任何拦截/干预；不热=一律放行（绝不碰充电）。
//   缓存由引擎每秒刷新（hook 只读，零开销）；缓存失效时现场补读一次，读不到=视为不热（放行，不误拦）。
#define kCTChargeHotTempC 40.0   // ★ 2.0.116：按用户要求 38→40（防停充 ≥40°C 才出手）
static double g_ctcHotTempCache = -1.0;
static CFAbsoluteTime g_ctcHotTempAt = 0.0;
static BOOL CTChargeHotGate(void) {
    CFAbsoluteTime nowH = CFAbsoluteTimeGetCurrent();
    if (g_ctcHotTempCache < 0.0 || (nowH - g_ctcHotTempAt) > 5.0) {
        double bt = CTBatteryTempC();
        if (bt > 0.0) { g_ctcHotTempCache = bt; g_ctcHotTempAt = nowH; }
        else if (g_ctcHotTempCache < 0.0) { g_ctcHotTempCache = 0.0; g_ctcHotTempAt = nowH; }
    }
    return (g_ctcHotTempCache >= kCTChargeHotTempC);
}

static void CTChargePublish(int st, double watt, int cap, const char *reason) {
    g_ctcPubState = st;
    g_ctcPubW = (watt > 0.0) ? (int)(watt + 0.5) : 0;
    g_ctcPubCap = cap;
    g_ctcPubReason = reason ? reason : "none";
}

// ---- 引擎主循环（心跳每秒调用）----
static void CTChargeTick(void) {
    @autoreleasepool {
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (g_ctUninstalled) {   // ★ 1.4.100：卸载后停止充电引擎（若正按着停充则松开一次，然后静默）
            if (g_ctcPaused) { CTChargeWriteInhibit(NO); CTChargeWriteInflow(YES); g_ctcPaused = NO; }
            return;
        }
        if (!runtimeProtectionEnabled()) {
            if (g_ctcPaused) { CTChargeWriteInhibit(NO); g_ctcPaused = NO; }
            g_ctcResumeWait = NO; g_ctcNoFlowAt = 0.0;   // ★ 1.4.6x：停用态清"恢复中"
            CTChargePublish(0, 0, 0, "none");
            return;
        }
        if (!g_ctcLimitOn && !g_ctcTempOn && !g_ctcForceOn && !g_ctcDisplayOn && !g_ctcPaused) {
            return;   // 全关：不读电池（省开销）
        }
        CTChargeInfo ci = CTChargeRead();
        g_ctcCapacity = ci.capacity;   // ★ 1.4.6f：刷新满电判定
        g_ctcHotTempCache = ci.tempC; g_ctcHotTempAt = now;   // ★ 2.0.114：真热门缓存（每秒刷新，hook 只读）
        if (!ci.valid) return;

        // 瓦数平滑（约 5 秒窗口，防跳数）
        double wRaw = 0.0;
        if (ci.isCharging && ci.volt_mV > 0.0 && ci.amp_mA != 0.0) {
            double pw = ci.volt_mV * ci.amp_mA / 1000000.0;
            wRaw = (pw < 0) ? -pw : pw;
        }
        if (g_ctcSmN < 5) { g_ctcSmW = (g_ctcSmW * g_ctcSmN + wRaw) / (g_ctcSmN + 1); g_ctcSmN++; }
        else g_ctcSmW = g_ctcSmW * 0.6 + wRaw * 0.4;

        BOOL haveCable = ci.extConnected || ci.isCharging || ci.adapterW > 0.0;   // ★ 1.4.6z2：禁流会改写 ExternalConnected，用适配器瓦数兜底判断"插着"
        { static int sSTLastCable = -1; static CFAbsoluteTime sSTLastAt = 0;   // 自测增强：连接跳变留证
          int ctHC = haveCable ? 1 : 0;
          if (sSTLastCable >= 0 && ctHC != sSTLastCable && (CFAbsoluteTimeGetCurrent() - sSTLastAt) > 1.0) {
              sSTLastAt = CFAbsoluteTimeGetCurrent();
              CTD("[自测·充电] 连接跳变 %d→%d（ext=%d chg=%d adW=%.1f amp=%.0f mv=%.0f cap=%d）", sSTLastCable, ctHC,
                  (int)ci.extConnected, (int)ci.isCharging, (double)ci.adapterW, (double)ci.amp_mA, (double)ci.volt_mV, (int)ci.capacity);
          }
          if (ctHC != sSTLastCable) sSTLastCable = ctHC;
        }
        ctChargeYieldTick(haveCable);   // ★ 0186 充电让路：低功耗档在充电时只让开预算压制
        if (!haveCable) {
            if (g_ctcPaused) { CTChargeWriteInhibit(NO); g_ctcPaused = NO; }
            g_ctcPausedAt = 0.0;
            g_ctcLimitLatched = NO; g_ctcTempLatched = NO; g_ctcVerifyAt = 0;
            g_ctcResumeWait = NO; g_ctcNoFlowAt = 0.0;   // ★ 1.4.6x：拔线清"恢复中"
            g_ctcIntercepts = 0; g_ctcLastIntercept = 0; g_ctcSmW = 0; g_ctcSmN = 0;
            CTChargePublish(0, 0, ci.capacity, "none");
            return;
        }

        // ① 充电上限（5% 回差——与界面文案"掉 5% 再续"一致：95% 停，掉到 90% 才续）
        BOOL wantPause = NO; const char *reason = "none";
        if (g_ctcLimitOn && g_ctcLimitVal < 100) {
            if (ci.capacity >= g_ctcLimitVal) g_ctcLimitLatched = YES;
            else if (ci.capacity <= g_ctcLimitVal - 5) g_ctcLimitLatched = NO;
            if (g_ctcLimitLatched) { wantPause = YES; reason = "limit"; }
        } else g_ctcLimitLatched = NO;

        // ② 温度保护（2°C 回差）
        double ctTempUse = ci.tempC;
        if (ctTempUse <= 0.0 && g_ctcTempOn) { ctTempUse = CTCFTempFallbackC(); }   // ★ 1.4.59：核心读不到 ⇒ 直读电池兜底 ✓
        if (!wantPause && g_ctcTempOn && ctTempUse > 0.0) {
            if (ctTempUse >= (double)g_ctcTempVal) g_ctcTempLatched = YES;
            else if (ctTempUse <= (double)g_ctcTempVal - 2.0) g_ctcTempLatched = NO;
            if (g_ctcTempLatched) { wantPause = YES; reason = "temp"; }
        } else if (!g_ctcTempOn) g_ctcTempLatched = NO;

        // ③ 慢速充电（10W/15W 占空比）与平稳限流（模拟高温）已按用户要求彻底移除（2026-09-29）
        //    ——原整段代码删除，防止误复活

        // ④ 执行（只在状态变化时写属性）
        if (wantPause) {
            if (!g_ctcPaused) {
                BOOL okW0 = CTChargeWriteInhibit(YES);
                int wSvc0 = g_ctcLastWriteSvc, wErr0 = g_ctcLastWriteErr;
                BOOL okI0 = CTChargeWriteInflow(NO);   // ★ 1.4.6z2：禁流层一起按
                int iSvc0 = g_ctcLastWriteSvc, iErr0 = g_ctcLastWriteErr;
                g_ctcPaused = YES;
                g_ctcPausedAt = now;
                g_ctcResumeWait = NO;   // ★ 1.4.6x：重新暂停 → 取消"恢复中"
                g_ctcLastHoldAssert = now; g_ctcHoldWarned = NO; g_ctcHoldOK = NO; g_ctcHoldWarnAt = now;
                CTD("[充电] 暂停充电（%s）", reason);
                if (!okW0 && !okI0) {
                    // ★ 1.4.6z4：主形态全被拒 → 立刻换形态
                    BOOL okX0 = CTChargeTryExtraStop();
                    CTD("[充电] 停充首发被拒（主[服务%d 错误%d] 禁[服务%d 错误%d]）→ 换形态%s（服务%d 错误%d）",
                        wSvc0, wErr0, iSvc0, iErr0, okX0 ? "成功" : "仍失败", g_ctcLastWriteSvc, g_ctcLastWriteErr);
                }
                g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 1;   // ★ 1.4.6m：3 秒后复核"停充是否真的切断"
            } else if (now - g_ctcLastHoldAssert >= (g_ctcHoldOK ? 5.0 : ((g_ctcPausedAt > 0.0 && (now - g_ctcPausedAt) > 180.0) ? 15.0 : 2.0))) {   // ★ 2.0.113：咬不合超 180 秒 → 降频到 15 秒（防无限对刚）
                // ★ 1.4.6z：停充在岗重申——每 5 秒重发（防系统放开）★ 1.4.6z4：未咬合时加密到 2 秒
                g_ctcLastHoldAssert = now;
                BOOL okW = CTChargeWriteInhibit(YES);
                int wSvc = g_ctcLastWriteSvc, wErr = g_ctcLastWriteErr;
                BOOL okI = CTChargeWriteInflow(NO);   // ★ 1.4.6z2：禁流层一起重申
                int iSvc = g_ctcLastWriteSvc, iErr = g_ctcLastWriteErr;
                int holdMA = (int)(ci.amp_mA < 0 ? -ci.amp_mA : ci.amp_mA);
                if (!okW && !okI) {
                    // ★ 1.4.6z4：主形态全被拒 → 换形态再试（直写式/仅PCI式）
                    BOOL okX = CTChargeTryExtraStop();
                    int xSvc = g_ctcLastWriteSvc, xErr = g_ctcLastWriteErr;
                    if (okX) {
                        CTD("[充电] 停充换形态咬住（形态%d 服务%d 电流=%d mA）", g_ctcWinVar, xSvc, holdMA);
                    } else if (now - g_ctcHoldWarnAt >= 60.0) {
                        g_ctcHoldWarnAt = now;
                        CTD("[充电] 停充未咬合重试中（主[服务%d 错误%d] 禁[服务%d 错误%d] 换形态[服务%d 错误%d] 电流=%d mA）", wSvc, wErr, iSvc, iErr, xSvc, xErr, holdMA);
                    }
                }
                BOOL bitten = (holdMA <= 150) && (okW || okI);
                if (bitten && !g_ctcHoldOK) { g_ctcHoldOK = YES; CTD("[充电] 停充已咬合（电流=%d mA 停充写%d 禁流写%d）", holdMA, (int)okW, (int)okI); }
                if (!bitten && g_ctcHoldOK) { g_ctcHoldOK = NO; CTD("[充电] 停充又松开（电流=%d mA）→ 重新按", holdMA); }
                if (!bitten && !g_ctcHoldWarned) {
                    g_ctcHoldWarned = YES; g_ctcHoldWarnAt = now;
                    CTD("[充电] 停充在岗重申：未咬合（停充[服务%d 错误%d] 禁流[服务%d 错误%d] 电流=%d mA）→ 持续重发", wSvc, wErr, iSvc, iErr, holdMA);
                }
            }
        } else {
            if (g_ctcPaused) {
                CTChargeWriteInhibit(NO);
                CTChargeWriteInflow(YES);   // ★ 1.4.6z2：恢复禁流层
                g_ctcPaused = NO;
                g_ctcPausedAt = 0.0;
                g_ctcResumeWait = YES; g_ctcResumeAt = CFAbsoluteTimeGetCurrent();   // ★ 1.4.92   // ★ 1.4.6x：进入"等硬件放行"（电流回来才结束）
                CTD("[充电] 恢复充电");
                g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 2;   // ★ 1.4.6m：3 秒后复核"恢复是否真的充上"
            }
        }
        // ★ 1.4.6m：动作 3 秒后自动复核实测电流（结果写日志——生效与否，日志自己给答案）
        if (g_ctcVerifyAt > 0 && now >= g_ctcVerifyAt) {
            g_ctcVerifyAt = 0;
            int ctMA = (int)(ci.amp_mA < 0 ? -ci.amp_mA : ci.amp_mA);
            if (g_ctcVerifyKind == 1)      CTD("[充电] 停充复核：实测电流=%d mA 充=%d（应≈0 = 生效）", ctMA, (int)ci.isCharging);
            else if (g_ctcVerifyKind == 2) CTD("[充电] 恢复复核：实测电流=%d mA 充=%d（应见充电流）", ctMA, (int)ci.isCharging);
            else                           CTD("[充电] 拦截复核：实测电流=%d mA 充=%d（仍在充 = 拦成功）", ctMA, (int)ci.isCharging);
            if (g_ctcVerifyKind == 1 && ctMA > 150) {   // ★ 1.4.6z3：复核没咬合 → 立即补一刀（不等 5 秒节拍）
                BOOL ok通1 = CTChargeWriteInhibit(YES);
                BOOL okI1 = CTChargeWriteInflow(NO);
                g_ctcLastHoldAssert = now;
                if (!ok通1 && !okI1) { CTChargeTryExtraStop(); }   // ★ 1.4.6z4：补刀也带上换形态
                CTD("[充电] 停充复核未咬合 → 已立即补发（服务%d 错误%d）", g_ctcLastWriteSvc, g_ctcLastWriteErr);
            }
        }

        if (g_ctcRescueVerifyAt > 0 && now >= g_ctcRescueVerifyAt) {
            g_ctcRescueVerifyAt = 0;
            if (ci.isCharging) {
                if (g_ctcRescueFailedLast) CTD("[充电] 救援核实：电流已恢复 ✓");
                g_ctcRescueFailedLast = NO;
            } else {
                g_ctcRescueFailedLast = YES;
            }
        }

        // ⑤ 防停充：兜底救援（2.0.96 版挪回——插着但没在充、又不是我们停的 → 限频 90 秒试恢复）
        // ★ 1.4.8 修复（重要）：原来"恢复中(g_ctcResumeWait)"也会触发救援 → 与守护进程同款打断快充。
        //   现在只有用户打开「防停充」才做救援；充电上限本身不再往系统里写。
        // ★ 1.4.8b：只在"持续 90 秒没电流"时才救援（快充协商/脉冲停充不会被打断）；
        //   「恢复中」也重新纳入触发（否则上限留下的停充没人清）。
        if ((g_ctcForceOn || g_ctcResumeWait) && haveCable && !ci.isCharging && !g_ctcPaused && ci.capacity < 99 &&
            g_ctcNoFlowAt > 0.0 && (now - g_ctcNoFlowAt) >= 90.0) {   // ★ 1.4.6f：满电（≥99%）不救援
            if (now - g_ctcLastRescue >= 90.0) {   // ★ 1.4.8b：救援节拍 15→90 秒（避免频繁写系统）
                g_ctcLastRescue = now;
                BOOL okA = CTChargeWriteInhibit(NO);
                BOOL okB = CTChargeWriteInflow(YES);   // ★ 1.4.6z2：顺手恢复禁流层
                // ★ 2.0.38：恢复写入"出声"（写成功与否 / 走哪个服务，日志见真章）
                CTD("[充电] %s：检测到停充 → 已尝试恢复（写1=%d 写2=%d 服务%d 错误%d 电池 %.1f°C）",
                    g_ctcForceOn ? "防停充" : "恢复中", (int)okA, (int)okB, g_ctcLastWriteSvc, g_ctcLastWriteErr, ci.tempC);
                // ★ 2.0.38（按用户要求）：绝不模拟断连/拔插——上一轮没救回时只留证（5 分钟限频），不做任何动作
                if (g_ctcRescueFailedLast) {
                    g_ctcRescueFailedLast = NO;
                    static CFAbsoluteTime sCtcFailLogAt = 0;
                    if (now - sCtcFailLogAt >= 300.0) {
                        sCtcFailLogAt = now;
                        CTD("[充电] 救援暂未见效（写1=%d 写2=%d 服务%d 错误%d）——保持温和救援，不做任何断连动作",
                            (int)okA, (int)okB, g_ctcLastWriteSvc, g_ctcLastWriteErr);
                    }
                }
                g_ctcRescueVerifyAt = now + 3.0;   // ★ 2.0.38：3 秒后核实是否真的恢复
            }
        }

        // ⑤b ★ 1.4.6t：防停充强化——每 5 秒重申"名义热态"（骗过系统的热逻辑，不让它来停充/降流）
        //   ★ 0187：按用户要求保留（用户明确"就是要骗系统"）。仅在此路径生效，其它热态逻辑不受影响。
        if (g_ctcForceOn && haveCable && ci.capacity < 99 && !g_ctcPaused && ci.tempC >= kCTChargeHotTempC) {   // ★ 2.0.51：真热门——不热=整天不写
            if (now - g_ctcLastNominal >= 5.0) {
                g_ctcLastNominal = now;
                dispatch_async(dispatch_get_main_queue(), ^{ CTHermesForceNominalCombined(); });
                static int sCTFNLog = 0;
                if (sCTFNLog < 3) { sCTFNLog++; CTD("[充电] 防停充·名义重申：已告诉系统“不热”（持续骗过高温逻辑）"); }
            }
        }

        // ★ 2.0.51：热天"降流护航"——不再写充电键（1.4.8 教训：反复写会打断充电状态机 → 6.6W 用户实锤），
        //   只做温和"名义重申"；且只在真热(≥38°C)时工作（不热=完全不碰）。60 秒限频。
        if (g_ctcForceOn && haveCable && ci.isCharging && !g_ctcPaused && ci.capacity < 80 && ci.tempC >= kCTChargeHotTempC) {
            int ctCurMA = (int)(ci.amp_mA < 0 ? -ci.amp_mA : ci.amp_mA);
            if (ctCurMA > 0 && ctCurMA < 900) {
                if (g_ctcThrottleAt <= 0.0) g_ctcThrottleAt = now;
                else if ((now - g_ctcThrottleAt) >= 60.0 && (now - g_ctcLastThrottleFix) >= 60.0) {
                    g_ctcLastThrottleFix = now;
                    dispatch_async(dispatch_get_main_queue(), ^{ CTHermesForceNominalCombined(); });
                    CTD("[充电] 热天降流护航：电流=%d mA 电池=%.1f°C → 已温和重申（不写充电键）", ctCurMA, ci.tempC);
                }
            } else {
                g_ctcThrottleAt = 0.0;
            }
        }

        // ★ 1.4.6x：恢复中——指令已请求充上、硬件还没放行（插着电、没电流、且不是我们按的暂停）
        BOOL ctNoFlow = (haveCable && !g_ctcPaused && !ci.isCharging && ci.capacity < 99);
        if (ctNoFlow) { if (g_ctcNoFlowAt <= 0.0) g_ctcNoFlowAt = now; } else g_ctcNoFlowAt = 0.0;
        if (g_ctcResumeWait && ci.isCharging) g_ctcResumeWait = NO;   // 电流回来 → 等待结束
        BOOL ctResuming = (ctNoFlow && g_ctcNoFlowAt > 0.0 && (now - g_ctcNoFlowAt) >= 5.0 && (g_ctcResumeWait || g_ctcForceOn));   // ★ 2.0.114：恢复 2.0.96 口径（防停充在岗时也计入等待）

        // ⑥ 发布显示状态（1绿=正常 3红=防停充在岗 4黑=暂停 5橙=恢复中）
        int st;
        if (wantPause) st = 4;
        else if (ctResuming) st = 5;   // ★ 2.0.113：等待统一“恢复中”（原“等降温”已按用户令取消）
        else if (g_ctcForceOn && ((g_ctcLastIntercept > 0 && now - g_ctcLastIntercept < 300.0) || ci.tempC >= kCTChargeHotTempC)) st = 3;   // ★ 2.0.51：红灯=真在拦（热或刚拦过）——不热不亮
        else st = 1;
        // ★ 1.4.6x：恢复中 进/出各留一行日志（自查用）
        { static int sCTResumeSt = 0;
          int ctRS = (st == 5) ? st : 0;
          if (ctRS != 0 && ctRS != sCTResumeSt) {
              sCTResumeSt = ctRS;
              CTD("[充电] 恢复中：指令已发，等硬件放行（电池 %.1f°C；急可拔插充电线）", ci.tempC);
          } else if (ctRS == 0 && sCTResumeSt != 0) {
              sCTResumeSt = 0;
              CTD(ci.isCharging ? "[充电] 恢复中结束：电流已恢复" : "[充电] 恢复中结束");
          } }
        double wPub = g_ctcSmW;
        CTChargePublish(st, (st == 4) ? 0.0 : wPub, ci.capacity, reason);
    }
}

// ★ 1.4.6 防停充：识别"系统想停充"的属性写入（只拦"停"方向，不拦"充"方向）
static BOOL keyIsChargeControlKey(NSString *key) {
    if (!key) return NO;
    NSString *lower = [key lowercaseString];
    return [lower isEqualToString:CTObfStr("6c37178c3a3b7723215c4dc372c2")] || [lower isEqualToString:CTObfStr("88932f4964374ea17b82de7899607069bc9e7e95e3a5f95bae10634554")];
}
static BOOL valueMeansStopChargingCF(NSString *key, CFTypeRef value) {
    id v = (__bridge id)value;
    if (![v respondsToSelector:@selector(boolValue)]) return NO;
    BOOL b = [v boolValue];
    NSString *lower = [key lowercaseString];
    if ([lower isEqualToString:CTObfStr("743828cc12c239eb2a9dd90048c4")]) return !b;   // IsCharging=0 → 停
    return b;                                                  // Inhibit=1 → 停
}
static void CTChargeNoteIntercept(NSString *key) {
    g_ctcIntercepts++;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    g_ctcLastIntercept = now;
    g_ctcVerifyAt = now + 3.0; g_ctcVerifyKind = 3;   // ★ 1.4.6m：拦截后复核"是否仍在充"
    if (g_ctcIntercepts <= 3 || (now - g_ctcLastForceLog) > 60.0) {
        g_ctcLastForceLog = now;
        CTD("[充电] 防停充：拦截系统停充 key=%s", [key UTF8String]);
    }
}

static void CTDiagFreqLog(void) {
    double mhz = 0.0;
    double bt = CTBatteryTempC();
    char bts[24];
    if (bt > 0.0) snprintf(bts, sizeof(bts), "%.1f", bt); else snprintf(bts, sizeof(bts), "--");
    if (CTFreqReadMHz(&mhz)) {
        CTD("[频率跟踪] 实测大核=%.0f MHz 模式=%s 提速=%d 深度=%d 视频=%d 电池=%s°C 热压=%d 前台=%llu",
            mhz, CTModeName(g_powerMode), (int)g_scrollBoostActive, (int)g_ctDeepIdleActive, (int)g_ctVideoActive,
            bts, CTThermalPressureLevel(),
            (unsigned long long)CTHermesReadForegroundBundleHash());
    } else {
        CTD("[频率跟踪] 读取失败 err=%ld 模式=%s 提速=%d 深度=%d 视频=%d 电池=%s°C 热压=%d",
            (long)g_ctFreqErrCode, CTModeName(g_powerMode), (int)g_scrollBoostActive, (int)g_ctDeepIdleActive, (int)g_ctVideoActive,
            bts, CTThermalPressureLevel());
    }
}

static void CTChargeUnstickTick(void) {   // 1.4.93: pause-stuck guard (paused>60s without real reason => force release)
    static CFAbsoluteTime sPausedSince = 0;
    if (!g_ctcPaused) { sPausedSince = 0; return; }
    CFAbsoluteTime nowU = CFAbsoluteTimeGetCurrent();
    if (sPausedSince <= 0) { sPausedSince = nowU; return; }
    if ((nowU - sPausedSince) < 60.0) return;
    // ★ 1.4.123：按"上限/温度锁存中"的停充是【正当停充】（在等回差）——绝不强松；
    //   只强松"无任何理由的孤儿停充"（治"94% 就复充"：以前只要低于上限 60 秒就被强松）
    if (g_ctcLimitLatched || g_ctcTempLatched) return;
    BOOL overLimit = (g_ctcLimitOn && g_ctcLimitVal < 100 && g_ctcCapacity >= g_ctcLimitVal);
    BOOL tooHot = (g_ctcTempOn && ((CTCFTempFallbackC() > 0 ? CTCFTempFallbackC() : 0.0) >= (double)g_ctcTempVal));
    if (!overLimit && !tooHot) {
        CTChargeWriteInhibit(NO);
        CTChargeWriteInflow(YES);
        g_ctcPaused = NO; g_ctcLimitLatched = NO; g_ctcTempLatched = NO;
        sPausedSince = 0;
        CTD("[充电] 停充卡死兜底 ⇒ 已强制松手（未到限、未过热、停超 60 秒 ✓）");
    }
}

static void CTChargeResumeTimeoutTick(void) {   // ★ 1.4.92："恢复中"超时自动落（治一直挂"恢复中" ✓）
    if (g_ctcResumeWait && g_ctcResumeAt > 0 && (CFAbsoluteTimeGetCurrent() - g_ctcResumeAt) > 20.0) {
        g_ctcResumeWait = NO; g_ctcResumeAt = 0;
        {   // ★ 1.4.92：超时强制放行（停充整套松开 ✓）
            CTChargeWriteInhibit(NO);
            CTChargeWriteInflow(YES);
            CTD("[充电] 恢复中超时 ⇒ 已强制重放行（inhibit=NO inflow=YES ✓）");
        }
        CTD("[充电] 恢复中 → 超时 20 秒未见放行 ⇒ 回到真实状态显示（不再挂「恢复中」✓）");
    }
}

static void freqWatchdogTick(void) {
if (!runtimeProtectionEnabled() || !isLowPowerMode()) { g_wdHighTicks = 0; return; }
if (g_softSwingActive) return;
if (CTHermesScreenIsBlanked()) { g_wdHighTicks = 0; return; }
if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 12.0) return;
    {   // ★ 1.4.90：提速期间/刚提过(3秒内) ⇒ 频率高是我们提的，不算失控 ⇒ 不摆动（原保护保留 ✓）
        CFAbsoluteTime nowB = CFAbsoluteTimeGetCurrent();
        if (g_scrollBoostActive || (g_ctLastBoostAt > 0 && (nowB - g_ctLastBoostAt) < 3.0)) { g_wdHighTicks = 0; return; }
    }
double mhz = 0.0;
if (!CTFreqReadMHz(&mhz) || mhz <= 0.0) return;
if (mhz >= 2560.0) {
    g_wdHighTicks++;
    if (g_wdHighTicks >= 3) {
        CFAbsoluteTime nowW = CFAbsoluteTimeGetCurrent();
        if ((nowW - g_wdLastSwing) >= 40.0) {
            g_wdLastSwing = nowW;
            g_wdHighTicks = 0;
            CTD("[看门狗] 实测=%.0f MHz 连续超标 → 触发自愈摆动", mhz);
            runSoftModeSwing("watchdog");
        }
    }
} else {
    g_wdHighTicks = 0;
}
}

// 前台应用兜底轮询：SpringBoard 只在哈希变化时上报，通知一旦丢失（进程重启、
// 通知被覆盖、唤醒强制恢复用户模式等）指定应用低功耗就无法自愈。此处每 3 秒
// 重新核对一次前台应用，保证状态最终一致。
// ★ 模式保持循环（每秒一次）：
//   - 生效模式 = 低功耗 → 每秒重压低功耗限制（对抗系统/充电抬预算、覆盖）
//   - 生效模式 = 高性能   → 每 5 秒重申高性能（清掉可能残留的低功耗限制）
//   - 全部只做"重压"，绝不触发任何"重载/重建"（血的教训）
// ★ T7z5：前台"读空"轨迹（全文件共享）——旧实现把"上次看到真实 App"记在 resolve 内部、
//   只有 resolve 被调用时才刷新 → 长时间没调用后吸收失效，"切 App/多任务瞬间读空"
//   被误判成"回桌面"交还系统（实测短暂放开 0.2~5 秒，用户感觉"失效一下、切回去又生效"）。
//   现在由每秒心跳持续保鲜 + 吸收窗口 2→5 秒。
static uint64_t g_ctBlipHash = 0;
static CFAbsoluteTime g_ctBlipAt = 0;

// ★ 1.4.4：前台 App"正在享受高性能"时 = 与性能模式同级的防降频保护（极端发热也不降频）。
//   覆盖三种来源：① 智能模式下识别为游戏；② 任意模式下该 App 档位 = 高性能（含低功耗模式下的"指定 App"）；
//   ③ 智能下的"指定 App 高性能率"名单。其它情况一律不介入（低功耗等模式的原有行为不变）。
static BOOL shouldApplyAppFullProtection(void) {
    uint64_t fg = CTHermesReadForegroundBundleHash();
    if (fg == 0) fg = g_ctBlipHash;                 // 抖动吸收：沿用上一个真实 App
    if (fg == 0) return NO;
    // ① 智能模式 + 游戏（由「游戏强制高性能」开关控制）
    if (g_gameForceFull && g_smartEnabled && g_smartGameHashes && [g_smartGameHashes containsObject:@(fg)]) return YES;
    // ② App 档位 = 高性能（对三种常驻模式都生效；低功耗下的"指定 App"即走这里）
    if (CTHermesTierForHash(fg) == 1) return YES;
    // ③ 智能下的"指定 App 高性能率"名单
    if (g_smartFullListHashes && [g_smartFullListHashes containsObject:@(fg)]) return YES;
    return NO;
}
static void CTBlipTrackForeground(void) {
    uint64_t fg = CTHermesReadForegroundBundleHash();
    if (fg != 0 && fg != CTHermesBundleIDHash(S("com.apple.springboard"))) {
        g_ctBlipHash = fg;
        g_ctBlipAt = CFAbsoluteTimeGetCurrent();
    }
}

// ★ T7z5：注销/重启后"落地保证"——启动后首次进入低功耗：+2.5 秒实测一把，
//   已压住 → 不做任何事；读不到频率或没压住 → 自动完整摆动落地
//   （等价于"手动切到高性能再切回低功耗"，替用户自动完成）。
static BOOL g_ctBootLandingArmed = NO;
static BOOL g_ctBootLandingHandled = NO;
static CFAbsoluteTime g_ctBootStamp = 0;
static CFAbsoluteTime g_ctWakeStamp = 0;   // ★ 1.4.64

// ============================================================================
// ★ T7z16 新服务 A：状态文件（供 SpringBoard 状态浮窗读取）+ 一键自检（30 秒采样）
// ============================================================================
#define kCTStatusFilePathC  CTDiagFileC("CTHermesStatus.txt")     // ★ 2.0.38：隐根版走容器
#define kCTSelfTestReqPathC CTDiagFileC("CTHermesSelfTest.req")
#define kCTSelfTestResPathC CTDiagFileC("CTHermesSelfTest.txt")
static BOOL g_floatWindowEnabled = NO;   // 设置里的「悬浮窗」开关（loadPrefs 刷新）

// ---------- 状态文件：每秒写一行键值（freq/mode/deep/boost/video） ----------
// ---------- ★ 0929：浮窗「电流/网速」数据源 ----------
static CTChargeInfo CTChargeRead(void);   // 前置声明（定义在充电模块）
static uint64_t g_ctNetLastBytes = 0;
static CFAbsoluteTime g_ctNetLastAt = 0;
static int CTStatusNetBytesPerSec(void) {
    uint64_t total = 0;
    struct ifaddrs *addrs = NULL;
    if (getifaddrs(&addrs) == 0) {
        for (struct ifaddrs *ifa = addrs; ifa; ifa = ifa->ifa_next) {
            if (!ifa->ifa_addr || ifa->ifa_addr->sa_family != AF_LINK || !ifa->ifa_data) continue;
            const char *nm = ifa->ifa_name;
            if (!nm) continue;
            if (strcmp(nm, "en0") != 0 && strcmp(nm, "pdp_ip0") != 0) continue;
            struct if_data *di = (struct if_data *)ifa->ifa_data;
            total += (uint64_t)di->ifi_ibytes + (uint64_t)di->ifi_obytes;
        }
        freeifaddrs(addrs);
    }
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    int bps = 0;
    if (g_ctNetLastAt > 0 && now > g_ctNetLastAt + 0.25 && total >= g_ctNetLastBytes) {
        bps = (int)((total - g_ctNetLastBytes) / (now - g_ctNetLastAt));
    }
    g_ctNetLastBytes = total; g_ctNetLastAt = now;
    return bps;
}

// ★ 2.0.115：系统 CPU 占用率（只读计数，1 秒采样一次；失败返回 -1）
static int CTCpuPercent(void) {
    static unsigned long long sPrevTotal = 0, sPrevIdle = 0;
    host_cpu_load_info_data_t info; mach_msg_type_number_t cnt = HOST_CPU_LOAD_INFO_COUNT;
    if (host_statistics(mach_host_self(), HOST_CPU_LOAD_INFO, (host_info_t)&info, &cnt) != KERN_SUCCESS) return -1;
    unsigned long long t = info.cpu_ticks[CPU_STATE_USER] + info.cpu_ticks[CPU_STATE_SYSTEM] + info.cpu_ticks[CPU_STATE_IDLE] + info.cpu_ticks[CPU_STATE_NICE];
    unsigned long long i = info.cpu_ticks[CPU_STATE_IDLE];
    int pct = -1;
    if (sPrevTotal > 0 && t > sPrevTotal && i >= sPrevIdle) {
        unsigned long long dt = t - sPrevTotal, di = i - sPrevIdle;
        pct = (int)((100.0 * (double)(dt - di) / (double)dt) + 0.5);
        if (pct < 0) pct = 0; if (pct > 100) pct = 100;
    }
    sPrevTotal = t; sPrevIdle = i;
    return pct;
}

static void CTStatusFileTick(void) {

    if (!g_prefsLoaded) return;   // ★ 1.4.72：设置没读完之前【不发布状态】✗（杜绝开机头 2 秒闪出默认值"高性能"✓）
    // ★ 2.0.39：状态发布"永开门"——不再受"悬浮窗开关"门控（16 上开关读取异常会让整条数据链断供；成本可忽略）
    double mhz = 0.0;
    BOOL ok = CTFreqReadMHz(&mhz);
    const char *mname = CTModeName(g_powerMode);
    char buf[352];
    CTChargeInfo ci = CTChargeRead();
    int curMA = (int)(ci.amp_mA);
    int netBps = CTStatusNetBytesPerSec();
    double btc = CTBatteryTempC();
    int cpuPct = CTCpuPercent();   // ★ 2.0.115：CPU 占用（只读计数，1 秒一次）
    snprintf(buf, sizeof(buf), "freq=%.0f mode=%s deep=%d boost=%d video=%d chg=%d pw=%d cap=%d cr=%s cur=%d net=%d temp=%.1f cpu=%d",
             (ok && mhz > 0.0) ? mhz : 0.0, mname,
             g_ctDeepIdleActive ? 1 : 0, g_scrollBoostActive ? 1 : 0, g_ctVideoActive ? 1 : 0,
             g_ctcPubState, g_ctcPubW, g_ctcPubCap, g_ctcPubReason, curMA, netBps, btc, cpuPct);
    // ★ 0930-0207：多路兜底写——每个"能写的目录"都写一份（原子写），界面读时取最新那份。
    //   原因：温控进程与界面进程各自能访问的目录不同（沙盒差异），单一目录会断链。
    {   // ★ 0930-0207：通知通道——把频率/模式/温度/网速编码进"固定名字"的通知（心跳同款，唯一百分百能通）
        static int sLastF = -1, sLastM = -1, sLastT = -1, sLastN = -1;
        static CFAbsoluteTime sLastPost = 0;
        CFAbsoluteTime nowN = CFAbsoluteTimeGetCurrent();
        int fB = (ok && mhz > 0.0) ? (int)(mhz / 100.0 + 0.5) : -1;
        if (fB > CT_NS_FREQ_N - 1) fB = CT_NS_FREQ_N - 1;
        int mB = (int)g_powerMode; if (mB < 0 || mB > CT_NS_MODE_N - 1) mB = 0;
        int tB = (int)(btc + 0.5); if (tB < 0) tB = 0; if (tB > CT_NS_TEMP_N - 1) tB = CT_NS_TEMP_N - 1;
        int nB = CTNSNetBucket(netBps);
        BOOL chg = (fB != sLastF) || (mB != sLastM) || (tB != sLastT) || (nB != sLastN);
        if (chg && nowN - sLastPost > 3.0) {   // ★ 0200 回退：恢复 0199（仅变化时发）
            sLastPost = nowN;
            if (fB >= 0 && fB != sLastF) { sLastF = fB; notify_post(CTNSName([NSString stringWithFormat:@"f%d", fB]).UTF8String); }
            if (mB != sLastM) { sLastM = mB; notify_post(CTNSName([NSString stringWithFormat:@"m%d", mB]).UTF8String); }
            if (tB != sLastT) { sLastT = tB; notify_post(CTNSName([NSString stringWithFormat:@"t%d", tB]).UTF8String); }
            if (nB != sLastN) { sLastN = nB; notify_post(CTNSName([NSString stringWithFormat:@"n%d", nB]).UTF8String); }
        }
    }
    {   // ★ 2.0.39：状态心跳——每秒轮转 stk0..7（浮窗保鲜链用它判定"通知通道新鲜度"）
        static int sStk = 0;
        sStk = (sStk + 1) % CT_NS_STK_N;
        notify_post(CTNSName([NSString stringWithFormat:@"stk%d", sStk]).UTF8String);
    }

    CTStateWrite(@"CTHermesStatus.txt", [NSString stringWithUTF8String:buf]);
    {   // ★ 0930-0207：prefs 通道（部分机器上"文件通道"对温控进程不通）
        static CFAbsoluteTime sLastPub = 0; static NSString *sLastSt = nil;
        NSString *st = [NSString stringWithUTF8String:buf];
        CFAbsoluteTime nowP = CFAbsoluteTimeGetCurrent();
        if (st.length && (![st isEqualToString:sLastSt] || nowP - sLastPub > 10.0)) {
            sLastSt = st; sLastPub = nowP;
            CTPrefsSet(@{@"ctStatus": st, @"ctStatusAt": @(nowP)});
        }
    }

}

// ---------- 一键自检：请求文件触发 → 30 秒采样 → 出报告 ----------
static int  g_stState = 0;              // 0=空闲 1=采样中
static int  g_stTicks = 0;
static CTHermesPowerMode g_stMode0 = CTHermesPowerModeLow;
static double g_stFreqs[40]; static int g_stFreqN = 0;
static int  g_stFreqFail = 0;
static int  g_stHighCount = 0;
static int  g_stDeepEntries = 0; static BOOL g_stDeepWas = NO;
static int  g_stBoostTicks = 0, g_stVideoTicks = 0, g_stBlankTicks = 0;
static int  g_stModeChanges = 0; static int g_stLastMode = -1;
static double g_stTemp0 = -2.0, g_stTempEnd = -2.0, g_stTempMax = -2.0;
static int  g_stPressMax = 0;

static void CTSelfTestWriteReport(void) {
    double v[40]; int n = g_stFreqN;
    for (int i = 0; i < n; i++) v[i] = g_stFreqs[i];
    for (int i = 1; i < n; i++) { double x = v[i]; int j = i - 1; while (j >= 0 && v[j] > x) { v[j + 1] = v[j]; j--; } v[j + 1] = x; }
    double mn = (n > 0) ? v[0] : -1.0, med = (n > 0) ? v[n / 2] : -1.0, mx = (n > 0) ? v[n - 1] : -1.0;
    char verdict[160];
    if (g_stMode0 == CTHermesPowerModeLow) {
        if (n == 0)
            snprintf(verdict, sizeof(verdict), "◐ 没读到有效频率（失败 %d 次）——建议重测一次", g_stFreqFail);
        else if (mx <= 2200.0 && g_stHighCount == 0)
            snprintf(verdict, sizeof(verdict), "✅ 压制正常：峰值 %.0fMHz ≤ 2200，未发现漏压", mx);
        else
            snprintf(verdict, sizeof(verdict), "⚠ 发现 %d 个 >2200MHz 样本（峰值 %.0f）——可能没压住，建议复测", g_stHighCount, mx);
    } else {
        snprintf(verdict, sizeof(verdict), "放开/原生模式：中位 %.0fMHz（属于正常放开，无需压制）", med);
    }
    time_t tt = time(NULL); struct tm tmv; localtime_r(&tt, &tmv);
    char ts[40]; strftime(ts, sizeof(ts), "%m-%d %H:%M:%S", &tmv);
    // ★ 0930-0207：报告同样双通道（写不了原路径就落共享目录，界面从两边取较新的那份）
    const char *stResPath = CTWritableOrSharedPath(kCTSelfTestResPathC, "CTHermesSelfTest.txt");
    FILE *f = fopen(stResPath, "w");
    if (!f) return;
    fprintf(f, "CTHermes 一键自检报告\n");
    fprintf(f, "时间: %s ｜ 构建: %s%s\n", ts, kCTBuildTag, CTFpSuffix());
    fprintf(f, "采样: 30 秒 ｜ 起始模式: %s\n", CTModeName(g_stMode0));
    fprintf(f, "--------------------------------\n");
    fprintf(f, "频率: 最小 %.0f ／ 中位 %.0f ／ 最大 %.0f MHz（有效样本 %d，失败 %d）\n", mn, med, mx, n, g_stFreqFail);
    fprintf(f, "高频样本(>2200MHz): %d 个\n", g_stHighCount);
    fprintf(f, "深度档: 进入 %d 次 ｜ 提速占用 %d 秒 ｜ 视频档 %d 秒\n", g_stDeepEntries, g_stBoostTicks, g_stVideoTicks);
    fprintf(f, "熄屏: %d 秒 ｜ 模式变化: %d 次\n", g_stBlankTicks, g_stModeChanges);
    if (g_stTemp0 > -1.5)
        fprintf(f, "温度: %.1f°C → %.1f°C（最高 %.1f）｜ 热压峰值: %d\n", g_stTemp0, g_stTempEnd, g_stTempMax, g_stPressMax);
    else
        fprintf(f, "温度: 读不到（不影响结论）｜ 热压峰值: %d\n", g_stPressMax);
    fprintf(f, "--------------------------------\n");
    fprintf(f, "结论: %s\n", verdict);
    fclose(f);
    {   // ★ 0930-0207：报告写完后分发到每个能写的目录（写不了也不影响下面的结论通知）
        NSString *repTxt = [NSString stringWithContentsOfFile:[NSString stringWithUTF8String:stResPath] encoding:NSUTF8StringEncoding error:NULL];
        if (repTxt.length) {
            CTStateWrite(@"CTHermesSelfTest.txt", repTxt);
            CTPrefsSet(@{@"ctSelfTestReport": repTxt, @"ctSelfTestReportAt": @(CFAbsoluteTimeGetCurrent())});
        }
    }
    // ★ 0930-0207：完成信号 + 结论通知 —— 不依赖文件能否写入（写不了盘也能给出结论）
    notify_post("com.qq391160.cpucore/selfTestDone");
    {
        int vb = 0;
        if (verdict && strstr(verdict, "⚠")) vb = 1;
        if (verdict && strstr(verdict, "❌")) vb = 3;
        if (vb >= CT_NS_VERDICT_N) vb = CT_NS_VERDICT_N - 1;
        notify_post(CTNSName([NSString stringWithFormat:@"v%d", vb]).UTF8String);
    }
    CTD("[自检] 完成 → %s", verdict);
}

// ★ 0930-0207：核心侧——注册"通知触发"（文件通道不通时也能被叫醒）+ 自报可写目录
static volatile BOOL g_ctSelfTestNotify = NO;
static int g_ctSelfTestTok = -1;
static void CTSelfTestNotifyInit(void) {
    if (g_ctSelfTestTok >= 0) return;
    notify_register_dispatch("com.qq391160.cpucore/selfTest", &g_ctSelfTestTok, dispatch_get_global_queue(0, 0), ^(int t) {
        g_ctSelfTestNotify = YES;
    });
    NSMutableArray *ok = [NSMutableArray array];
    for (NSString *dir in CTStateWriteDirs()) {
        NSString *probe = [dir stringByAppendingPathComponent:@"CTHermesProbe.tmp"];
        if (CTFileWritable(probe.fileSystemRepresentation)) {
            [ok addObject:dir];
            [[NSFileManager defaultManager] removeItemAtPath:probe error:NULL];
        }
    }
    CTStateWrite(@"core-paths.txt", [NSString stringWithFormat:@"writable=%@\n", [ok componentsJoinedByString:@", "]]);
    notify_post("com.qq391160.cpucore/" CT_NS_BUILDTOK);   // ★ 0930-0207：版本令牌（证明核心跑的是本版代码）
}

static void CTSelfTestTick(void) {
    if (g_stState == 0) {
        CTSelfTestNotifyInit();
        static double sLastReqAt = 0;
        double reqAt = CTPrefsNum(@"ctSelfTestReqAt");
        if (g_ctSelfTestNotify || CTStateExists(@"CTHermesSelfTest.req") || reqAt > sLastReqAt + 0.5) {   // ★ 0930-0207：三条通道
            g_ctSelfTestNotify = NO;
            if (reqAt > sLastReqAt) sLastReqAt = reqAt;
            CTStateRemove(@"CTHermesSelfTest.req");
            g_stState = 1; g_stTicks = 0; g_stFreqN = 0; g_stFreqFail = 0; g_stHighCount = 0;
            g_stDeepEntries = 0; g_stDeepWas = NO; g_stBoostTicks = 0; g_stVideoTicks = 0;
            g_stBlankTicks = 0; g_stModeChanges = 0; g_stLastMode = -1;
            g_stTemp0 = CTBatteryTempC();
            g_stTempEnd = g_stTemp0; g_stTempMax = g_stTemp0;
            g_stPressMax = CTThermalPressureLevel();
            g_stMode0 = g_powerMode;
            CTD("[自检] 开始 30 秒采样（起始模式=%s）", CTModeName(g_stMode0));
        }
        return;
    }
    if (g_stLastMode >= 0 && g_stLastMode != (int)g_powerMode) g_stModeChanges++;
    g_stLastMode = (int)g_powerMode;
    double mhz = 0.0;
    if (CTFreqReadMHz(&mhz) && mhz > 0.0) {
        if (g_stFreqN < 40) g_stFreqs[g_stFreqN++] = mhz;
        if (mhz > 2200.0) g_stHighCount++;
    } else {
        g_stFreqFail++;
    }
    if (g_ctDeepIdleActive) { if (!g_stDeepWas) { g_stDeepEntries++; g_stDeepWas = YES; } } else { g_stDeepWas = NO; }
    if (g_scrollBoostActive) g_stBoostTicks++;
    if (g_ctVideoActive) g_stVideoTicks++;
    if (CTHermesScreenIsBlanked()) g_stBlankTicks++;
    double bt = CTBatteryTempC();
    if (bt > -1.5) { g_stTempEnd = bt; if (bt > g_stTempMax) g_stTempMax = bt; }
    int pr = CTThermalPressureLevel();
    if (pr > g_stPressMax) g_stPressMax = pr;
    g_stTicks++;
    if (g_stTicks >= 30) {
        CTSelfTestWriteReport();
        g_stState = 0;
    }
}


// ============================================================================
// ★ T7z16 新服务 B：定时切档（按周几+时段，临时覆盖"用户选择的模式"，结束自动恢复）
//   · 配置键：scheduleEnabled / seg1..2On / seg1..2Day0..6 / seg1..2Start / seg1..2End / seg1..2Mode
//   · 时段跨午夜自动处理；两段同时命中时"段一"优先；进/出时段各写一行日志
// ============================================================================
static BOOL g_schedEnabled = NO;
static BOOL g_schedSegOn[2] = {NO, NO};
static int  g_schedSegDays[2] = {0, 0};    // bit0=周一 … bit6=周日
static int  g_schedSegStart[2] = {0, 0};   // 分钟数（0~1439）
static int  g_schedSegEnd[2] = {0, 0};
static int  g_schedSegMode[2] = {0, 0};    // 0=低功耗 1=性能模式 2=智能
static int  g_schedActiveMode = -1;        // -1=未生效；0/1/2=当前时段目标
static void CTHermesSyncModeFromPrefs(void);   // 稍后定义（前置声明）

static NSString *CTScheduleModeName(int m) {
    if (m == 0) return S("lowPower");
    if (m == 2) return S("smart");
    return S("fullPower");
}

static void CTScheduleLoadFromPrefs(NSDictionary *d) {
    g_schedEnabled = [d[S("scheduleEnabled")] ?: @NO boolValue];
    for (int i = 0; i < 2; i++) {
        NSString *base = (i == 0) ? S("seg1") : S("seg2");
        g_schedSegOn[i] = [d[[base stringByAppendingString:S("On")]] ?: @NO boolValue];
        int days = 0;
        for (int b = 0; b < 7; b++) {
            NSString *k = [base stringByAppendingFormat:S("Day%d"), b];
            if ([d[k] ?: @NO boolValue]) days |= (1 << b);
        }
        g_schedSegDays[i] = days;
        g_schedSegStart[i] = [d[[base stringByAppendingString:S("Start")]] ?: @0 intValue];
        g_schedSegEnd[i] = [d[[base stringByAppendingString:S("End")]] ?: @0 intValue];
        NSString *mstr = d[[base stringByAppendingString:S("Mode")]];
        int mm = 0;
        if ([mstr isKindOfClass:[NSString class]]) {
            if ([mstr isEqualToString:S("smart")]) mm = 2;
            else if ([mstr isEqualToString:S("fullPower")]) mm = 1;
        }
        g_schedSegMode[i] = mm;
    }
    if (g_schedEnabled)
        CTD("[定时] 配置：段1(开=%d 天%02X %02d:%02d-%02d:%02d→%s) 段2(开=%d 天%02X %02d:%02d-%02d:%02d→%s)",
            (int)g_schedSegOn[0], g_schedSegDays[0], g_schedSegStart[0] / 60, g_schedSegStart[0] % 60, g_schedSegEnd[0] / 60, g_schedSegEnd[0] % 60, CTScheduleModeName(g_schedSegMode[0]).UTF8String,
            (int)g_schedSegOn[1], g_schedSegDays[1], g_schedSegStart[1] / 60, g_schedSegStart[1] % 60, g_schedSegEnd[1] / 60, g_schedSegEnd[1] % 60, CTScheduleModeName(g_schedSegMode[1]).UTF8String);
}

static void CTScheduleTick(void) {
    if (!g_schedEnabled) {
        if (g_schedActiveMode >= 0) {
            g_schedActiveMode = -1;
            CTD("[定时] 定时已关闭 → 恢复你选择的模式");
            CTHermesSyncModeFromPrefs();
        }
        return;
    }
    time_t tt = time(NULL); struct tm tmv; localtime_r(&tt, &tmv);
    int mon0 = (tmv.tm_wday + 6) % 7;         // 0=周一 … 6=周日
    int mins = tmv.tm_hour * 60 + tmv.tm_min;
    int desired = -1;
    for (int i = 0; i < 2; i++) {
        if (!g_schedSegOn[i]) continue;
        int s = g_schedSegStart[i], e = g_schedSegEnd[i];
        if (s == e) continue;
        BOOL hit = NO;
        if (s < e) {
            if ((g_schedSegDays[i] >> mon0) & 1) hit = (mins >= s && mins < e);
        } else {
            if (mins >= s) hit = ((g_schedSegDays[i] >> mon0) & 1) != 0;              // 晚段按"今天"
            else if (mins < e) hit = ((g_schedSegDays[i] >> ((mon0 + 6) % 7)) & 1) != 0;   // 早段按"昨天"
        }
        if (hit) { desired = g_schedSegMode[i]; break; }
    }
    if (desired != g_schedActiveMode) {
        g_schedActiveMode = desired;
        if (desired >= 0) CTD("[定时] 进入时段 → 切到 %s（%02d:%02d）", CTScheduleModeName(desired).UTF8String, tmv.tm_hour, tmv.tm_min);
        else CTD("[定时] 时段结束 → 恢复你选择的模式（%02d:%02d）", tmv.tm_hour, tmv.tm_min);
        CTHermesSyncModeFromPrefs();
    }
}

// ---------- ★ 1.4.6 身份完整性校验（③④：分散校验点之一；每 60 秒 + 启动各一次） ----------
//   · ① 设置包侧校验失败时会写入 __integrityTampered 旗标；这里读到即停用全部功能
//   · ② 跨组件指纹核对：自己的构建指纹 vs 设置包 Info.plist 里的 CTSourceFP（不一致 = 混装/被换）
//   · 读不到（未注入指纹 / 文件不存在）→ 跳过（不影响功能，防误伤）
static NSString *CTFindSettingsInfoPlist(void) {
    NSMutableArray *cands = [NSMutableArray array];
    [cands addObject:S("/var/jb/Library/PreferenceBundles/CTHermesSettings.bundle/Info.plist")];
    const char *jb = jbroot("/Library/PreferenceBundles/CTHermesSettings.bundle/Info.plist");
    if (jb) [cands addObject:[NSString stringWithUTF8String:jb]];
    [cands addObject:S("/Library/PreferenceBundles/CTHermesSettings.bundle/Info.plist")];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *cand in cands) {
        if (cand.length && [fm fileExistsAtPath:cand]) return cand;
    }
    return nil;
}
static void CTIdentityCheck(void) {
    static int sCtIdTick = 0;
    if (g_ctProcStart <= 0) g_ctProcStart = CFAbsoluteTimeGetCurrent();
    if ((++sCtIdTick % 60) != 1) return;
    BOOL intact = YES;
    NSString *ctWhy = nil;
    @try {
        NSDictionary *d = readPrefsDictionary();
        id flag = [d isKindOfClass:[NSDictionary class]] ? d[S("__integrityTampered")] : nil;
        if ([flag isKindOfClass:[NSNumber class]] && [flag boolValue]) { intact = NO; ctWhy = S("E31"); }
        id dbgFlag = [d isKindOfClass:[NSDictionary class]] ? d[S("__analysedFlag")] : nil;
        if (intact && [dbgFlag isKindOfClass:[NSNumber class]] && [dbgFlag boolValue]) { intact = NO; ctWhy = S("E32"); }
        if (intact && CT_SOURCE_FP[0]) {
            NSString *path = CTFindSettingsInfoPlist();
            if (path) {
                // ★ 1.4.6g：设置包晚于本进程启动才更新（=刚装包、还没重启用户空间）→ 暂缓指纹核对，防误伤
                NSDate *mtime = [[[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil] objectForKey:NSFileModificationDate];
                if (mtime && [mtime timeIntervalSince1970] > g_ctProcStart + 3.0) {
                    static BOOL sSkippedOnce = NO;
                    if (!sSkippedOnce) { sSkippedOnce = YES; CTD("[管理] 设置包更新晚于本次启动（可能刚安装未重启）→ 指纹核对暂缓，重启用户空间后恢复"); }
                } else {
                    NSDictionary *pl = [NSDictionary dictionaryWithContentsOfFile:path];
                    id fp = [pl isKindOfClass:[NSDictionary class]] ? pl[S("CTSourceFP")] : nil;
                    if ([fp isKindOfClass:[NSString class]] && [fp length] > 0 && ![fp isEqualToString:S(CT_SOURCE_FP)]) { intact = NO; ctWhy = S("指纹不一致"); }
                }
            }
        }
    } @catch (__unused NSException *e) {}
    static int sLastIntact = -1;
    if ((int)intact != sLastIntact) {
        sLastIntact = (int)intact;
        if (!intact) CTD("[管理] 综合核验未通过（%s）→ 功能暂缓", ctWhy ? ctWhy.UTF8String : "未知");
        else CTD("[管理] 身份校验通过 → 功能恢复正常");
    }
    g_ctIdentityIntact = intact;   // 允许恢复：文件回正/旗标清除后自动复活
}

// ★ 1.4.6s：过热自动保护（对齐作者引擎）——热压≥2 / 电池≥44°C → 临时切低功耗帮降温；恢复（约 5 秒）→ 切回你的模式
static void CTEngineApplyEffective(const char *why) {
    CTHermesPowerMode target = g_overheatActive ? CTHermesPowerModeLow : CTHermesResolveTargetMode(g_userSelectedPowerMode, CTHermesScreenIsBlanked(), g_foregroundAppForcesLowPower);
    os_unfair_lock_lock(&g_modeLock);
    BOOL chg = (g_powerMode != target);
    g_powerMode = target;
    os_unfair_lock_unlock(&g_modeLock);
    if (chg) {
        applyPowerModeToRuntime(NO);
        CTD("[过热保护] 模式 → %s（%s）", (target == CTHermesPowerModeLow) ? "低功耗" : "你的模式", why ? why : "");
    }
}
static void CTEngineOverheatCheck(void) {
    if (!g_overheatAutoProtect) {
        if (g_overheatActive) { g_overheatActive = NO; g_overheatNormalSince = 0; CTEngineApplyEffective("engine-off"); }
        return;
    }
    int ctPress = CTThermalPressureLevel();
    double ctTemp = CTBatteryTempC();
    BOOL hot = (ctPress >= 2) || (ctTemp >= 44.0);
    CFAbsoluteTime nowO = CFAbsoluteTimeGetCurrent();
    if (hot) {
        g_overheatNormalSince = 0;
        if (!g_overheatActive) {
            g_overheatActive = YES;
            CTD("[过热保护] 热压=%d 电池=%.1f°C → 临时切低功耗帮降温", ctPress, ctTemp);
            CTEngineApplyEffective("overheat");
        }
    } else if (g_overheatActive) {
        if (g_overheatNormalSince <= 0) g_overheatNormalSince = nowO;
        double hold = g_nominalAutoRecover ? 5.0 : 0.0;
        if (nowO - g_overheatNormalSince >= hold) {
            g_overheatActive = NO;
            g_overheatNormalSince = 0;
            CTD("[过热保护] 温度恢复（电池=%.1f°C）→ 切回你的模式", ctTemp);
            CTEngineApplyEffective("recovered");
        }
    }
}

static void startModeAssertTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        CTIdentityCheck();                     // ★ 1.4.6：身份校验先跑（被停用后仍持续核对 → 修复后可自动复活）
        g_ctMainBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6g：主队列心跳
        if (g_ctUninstalled) {   // ★ 1.4.100：卸载后停止一切周期动作（松开充电压制+交还功耗状态，然后静默）
            static BOOL sCtUnOnce = NO;
            if (!sCtUnOnce) {
                sCtUnOnce = YES;
                if (g_ctcPaused) { CTChargeWriteInhibit(NO); CTChargeWriteInflow(YES); g_ctcPaused = NO; }
                restoreNativeRuntimeAfterDisable();
            }
            return;
        }
        if (!runtimeProtectionEnabled()) {
            // ★ 1.4.20：未接管原因（每 60 秒最多一条）—— 支持排查用，发布版也可见
            static CFAbsoluteTime ctLastWhy = 0;
            CFAbsoluteTime ctNowW = CFAbsoluteTimeGetCurrent();
            if (ctNowW - ctLastWhy > 60.0) {
                ctLastWhy = ctNowW;
                BOOL __en = NO, __cp = NO;
                runtimeConfigSnapshot(&__en, &__cp, NULL, NULL, NULL);
                CTD("[核心] 暂未接管：总开关=%d CPU保护=%d 身份完整=%d 已激活=%d",
                    __en ? 1 : 0, __cp ? 1 : 0, g_ctIdentityIntact ? 1 : 0, g_ctAuthOK ? 1 : 0);
            }
            return;
        }
        g_ctMainPhase = 1;
        static int ctAssertTicks = 0;
        ctAssertTicks++;
        // ★ 启动标记（只写一次）
        static BOOL ctTagged = NO;
        if (!ctTagged) { ctTagged = YES; CTD("======== CTHermes %s%s ========", kCTBuildTag, CTFpSuffix()); }
        // ★ 每秒持续记录"当前生效模式"（只在屏幕亮着时）——
        //   唤醒时直接沿用它，不再依赖熄屏通知（实测该通知可能不触发）。
        if (!CTHermesScreenIsBlanked()) {
            // ★ 只记录"已稳定 3 秒以上"的模式：防止被两次心跳之间的瞬时误判污染
            static CTHermesPowerMode sSeenMode = CTHermesPowerModeFull;
            static int sSeenStableTicks = 0;
            os_unfair_lock_lock(&g_modeLock);
            CTHermesPowerMode ctCurMode = g_powerMode;
            os_unfair_lock_unlock(&g_modeLock);
            // ★ T6 诊断：模式变化追踪（任何来源改模式，≤1 秒内必被记录）
            static int sLastModeSeen = -1;
            if ((int)ctCurMode != sLastModeSeen) {
                CTD("[模式] 变化：%s → %s", (sLastModeSeen < 0) ? "?" : CTModeName((CTHermesPowerMode)sLastModeSeen),
                    CTModeName(ctCurMode));
                sLastModeSeen = (int)ctCurMode;
            }
            if (ctCurMode != sSeenMode) { sSeenMode = ctCurMode; sSeenStableTicks = 0; }
            else if (sSeenStableTicks < 100) { sSeenStableTicks++; }
            if (!g_softSwingActive && sSeenStableTicks >= 3) {
                static int sCtRecLast = -1;
                if ((int)ctCurMode != sCtRecLast) {
                    sCtRecLast = (int)ctCurMode;
                    CTD("[写睡前] tracker(稳定3秒): → %s", CTModeName(ctCurMode));
                }
                os_unfair_lock_lock(&g_modeLock);
                g_modeBeforeSleep = ctCurMode;
                os_unfair_lock_unlock(&g_modeLock);
            }
        }
        if (isLowPowerMode()) {
            g_ctMainPhase = 2;
            if (!g_scrollBoostActive) {
                applyLowPowerToCommonProduct();
                applyLowPowerLimitsToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
                g_ctApplyCount++;
            } else if (g_ctLastActivityAt > 0 && (CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt) < 1.5) {
                // ★ 1.4.124：手指还在动（或刚停<1.5秒）→ 操作期间保持放行并重申（治"连续切 App 时撞压回墙"）
                //   ★ 1.4.126：门槛 0.8→2.5 秒（治"收一下又开"的脉动：连串操作期间窗口不倒，真正停手才收）
                //   ★ 2.0.2：门槛 2.5→1.5 秒（回落更快、省一点电；接缝代价很小）
                g_scrollBoostUntil = CFAbsoluteTimeGetCurrent();
                ctScrollBoostApplyPass();
            } else if (CFAbsoluteTimeGetCurrent() > g_scrollBoostUntil + 0.75) {
                // ★ 1.4.124：停手约 1 秒 → 平滑收尾（不必等保险丝）
                g_scrollBoostActive = NO;
                applyPowerModeToRuntime(NO);
                CTD("[滑动] 升频结束（操作结束回落）");
            } else if (CFAbsoluteTimeGetCurrent() > g_scrollBoostUntil + 2.0) {
                // ★ T7x2 保险丝：提速状态异常滞留（>2.6 秒无新信号却没正常收尾）→ 强制解除，低功耗压制立即恢复
                g_scrollBoostActive = NO;
                applyLowPowerToCommonProduct();
                applyLowPowerLimitsToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
                g_ctApplyCount++;
                CTD("[滑动] 提速状态滞留 → 已强制解除（保险丝）");
            }
            CTDObjects("每秒心跳");
        } else {
            g_ctMainPhase = 3;
            if ((ctAssertTicks % 5) == 0) {
                applyFullPowerToCommonProduct();
                restoreFullPowerToTrackedControllers();
                applyCurrentModeToApplePPMCPU();
            }
            CTD("[心跳] 非低功耗分支运行中（模式=%s）", isNativeMode() ? "原生" : "高性能");
        }
        ctCarryFallbackLog();   // ★ 1.4.124：兜底日志搬运（root 侧；60 秒节流）
        g_ctMainPhase = 4;
    CTChargeResumeTimeoutTick();   // ★ 1.4.92：恢复中超时
    CTChargeUnstickTick();         // 1.4.93: pause-stuck guard
        if ((ctAssertTicks % 2) == 0) freqWatchdogTick();   // ★ 频率看门狗（每 2 秒，只读检测）
        // ★ 1.4.6g：充电引擎已迁到独立队列（startChargeEngineTimer）——主队列卡死不再连累充电
        CTIdentityCheck();                                  // ★ 1.4.6 身份完整性抽查（每 60 秒）
        g_ctMainPhase = 5;
        if ((ctAssertTicks % 2) == 1) CTDiagFreqLog();      // ★ T7z4 诊断：频率跟踪（每 2 秒，只写日志）
        {   // ★2.0.38：亮度条监视器（每 2 秒；记录任何"用户亮度"变化）
            static double sLastUB = -1.0;
            id ub = CTHermesCopyUserBrightness();
            double ubv = (ub && [ub respondsToSelector:@selector(doubleValue)]) ? [ub doubleValue] : -1.0;
            if (ubv > 0.0 && sLastUB >= 0.0 && ubv != sLastUB) {
                CTD("[自测·条] 用户亮度 %.1f → %.1f（屏=%s 模式=%s 提速=%d 深度=%d）", sLastUB, ubv, CTHermesScreenIsBlanked() ? "熄" : "亮", CTModeName(g_powerMode), (int)g_scrollBoostActive, (int)g_ctDeepIdleActive);
            }
            if (ubv > 0.0) sLastUB = ubv;
        }
        g_ctMainPhase = 6;
        // ★ 1.4.4：防降频每秒兜底重申——不依赖系统任何回调；含"智能模式 + 游戏前台"
        if (shouldApplyFullCPUProtection()) {
            CTHermesForceNominalCombined();
            static int sCTFreedomLogTick = 0;
            if ((++sCTFreedomLogTick % 5) == 0) {
                CTD("[防降频] 名义已重申（高性能=%d 保护=%d）", isFullPowerMode() ? 1 : 0,
                    (!isFullPowerMode() && shouldApplyAppFullProtection()) ? 1 : 0);
            }
        }
        // ★ 1.4.6s：性能模式强化（对齐"极限高性能"）——每 2 秒重申满功率预算与 PPM 等级
        if ((ctAssertTicks % 2) == 0 && isFullPowerMode() && !g_overheatActive) {
            applyCurrentModeToApplePPMCPU();
            restoreFullPowerToTrackedControllers();
        }
        // ★ 1.4.6s：过热自动保护检查（每 2 秒）
        if (ctAssertTicks % 2) CTEngineOverheatCheck();
        g_ctMainPhase = 7;
        CTBlipTrackForeground();                            // ★ T7z5：每秒保鲜"最近真实App"轨迹（读空防抖）
        g_ctMainPhase = 8;
        // ★ T7z5：落地保证（一次性）——注销/重启后首次进入低功耗时验证并自动落地
        if (g_ctBootStamp <= 0) g_ctBootStamp = CFAbsoluteTimeGetCurrent();
        if (!g_ctBootLandingHandled && !g_ctBootLandingArmed) {
            if (isLowPowerMode()) {
                g_ctBootLandingArmed = YES;
                CTD("[落地] 启动后首次进入低功耗 → 2.5 秒后验证是否压住");
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    g_ctBootLandingHandled = YES;
                    g_ctBootLandingArmed = NO;
                    if (!isLowPowerMode()) { CTD("[落地] 验证时已离开低功耗 → 跳过"); return; }
                    double m = 0.0;
                    BOOL ok = CTFreqReadMHz(&m);
                    if (ok && m > 0.0 && m < 2560.0) {
                        CTD("[落地] 实测 %.0f MHz 已压住 → 无需摆动", m);
                    } else {
                        CTD("[落地] 未压住（实测=%.0f 读取=%d）→ 完整摆动落地", m, (int)ok);
                        runSoftModeSwing("boot-landing");
                    }
                });
            } else if (g_ctBootStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctBootStamp) > 1800.0) {
                g_ctBootLandingHandled = YES;   // 30 分钟内没进过低功耗 → 不再跟踪
            }
        }
        // ★ T7z5：高性能落地保证（一次性）——启动后首次进入高性能
        if (!g_ctFullLandingHandled && !g_ctFullLandingArmed) {
            if (isFullPowerMode()) {
                g_ctFullLandingArmed = YES;
                CTD("[落地] 启动后首次进入高性能 → 2 秒后自动落地");
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    g_ctFullLandingHandled = YES;
                    g_ctFullLandingArmed = NO;
                    runFullModeLanding("boot-full");
                });
            } else if (g_ctBootStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctBootStamp) > 1800.0) {
                g_ctFullLandingHandled = YES;   // 30 分钟内没进过高性能 → 不再跟踪
            }
        }
        g_ctMainPhase = 9;
        // ★ T7z6/T7z8：无操作深度降频——低频率态 + 停手 ≥5 秒 → 换更深参数重压；有操作/换场景立即恢复
        //   ★ 1.4.125：介入时间 2→5 秒（减少"停两三秒再操作"时的"醒来"顿；真闲置时照常深度省电）
        if (g_ctLastActivityAt <= 0) g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();   // 启动初始化
        if (!g_ctIdleSinkEnabled) {
            if (g_ctDeepIdleActive) { g_ctDeepIdleActive = NO; applyPowerModeToRuntime(NO); CTD("[深度] 开关关闭 → 恢复常规低功耗"); }
        } else if (g_ctDeepIdleActive && (!isLowPowerMode() || CTHermesScreenIsBlanked() || g_scrollBoostActive || (g_ctVideoActive && !g_ctVideoDeepEnabled))) {
            g_ctDeepIdleActive = NO;   // 场景已变：下次压回按常规参数
            CTD("[深度] 退出（模式/提速/视频变化）");
        } else if (!g_ctDeepIdleActive && isLowPowerMode() && !CTHermesScreenIsBlanked() && !g_scrollBoostActive && !g_softSwingActive && !g_ctFullLandingRunning && (!g_ctVideoActive || g_ctVideoDeepEnabled) && (CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt) >= 5.0) {
            g_ctDeepIdleActive = YES;
            applyPowerModeToRuntime(NO);
            CTD("[深度] 无操作 %.1f 秒 → 深度降频（Level %d / %d mW）",
                CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt, CTLowPowerLevel(), CTLowPowerBudgetMW());
        }
        g_ctMainPhase = 10;
        // ★ T7z6：视频档自查——绑定 App 不再在前台 → 结束；开关关闭 → 结束
        if (g_ctVideoActive && g_ctVideoActiveHash != 0) {
            uint64_t ctFgNow6 = CTHermesReadForegroundBundleHash();
            if (ctFgNow6 != 0 && ctFgNow6 != CTHermesBundleIDHash(S("com.apple.springboard")) && ctFgNow6 != g_ctVideoActiveHash) {
                g_ctVideoActive = NO;
                CTD("[视频档] App 已切换 → 结束");
            }
        }
        if (!g_ctVideoOptEnabled && !g_ctVideoDeepEnabled && g_ctVideoActive) { g_ctVideoActive = NO; CTD("[视频档] 开关关闭 → 结束"); }
        // ★ 1.4.6h：状态文件/自检/定时 已迁到独立队列（startPerSecondServicesTimer）
        g_ctMainPhase = 0;
    });
    dispatch_resume(t);
}


// ★ 周期重申（2026-09-16 晚）：亮屏每 2 秒 / 熄屏每 5 秒 重发"模式变更"通知
//   （完整重应用，等价于手动切一次 CC 开关）—— 用户需求："解锁后一直重申，别停"。
//   实现：1 秒检查 + 到点即发（真定时器，不再依赖唤醒事件次数）。
//   ⚠️ 熄屏期间系统会反复挂起本进程（日志心跳断档即证据）：熄屏 5 秒属"能跑就跑"——
//      系统每隔约 5~15 秒会给一次执行机会，到点就补一枪；深度睡眠时以"唤醒必恢复"兜底。
static CFAbsoluteTime g_lastPeriodicReassert = 0;
static void startPeriodicReassertTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        CTIdentityCheck();                     // ★ 1.4.6：身份校验先跑（被停用后仍持续核对 → 修复后可自动复活）
        if (g_ctUninstalled) return;           // ★ 1.4.100：卸载后不再重申任何模式
        if (!runtimeProtectionEnabled()) return;
        BOOL blanked = CTHermesScreenIsBlanked();
        if (isNativeMode()) return; double period = blanked ? 5.0 : 2.0;   // ★ 原生：不重申
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (g_lastPeriodicReassert > 0 && (now - g_lastPeriodicReassert) < (period - 0.25)) return;
        g_lastPeriodicReassert = now;
        notify_post("com.qq391160.cpucore/powerModeChanged");
        CTD("[周期] 重申模式变更（%s，每 %.0f 秒一次）", blanked ? "熄屏" : "亮屏", period);
    });
    dispatch_resume(t);
}


// ★ 1.4.6g：充电引擎独立定时器（独立队列）——即使主队列卡死，充电管家照常工作
static void startChargeEngineTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.cpucore.chargeengine", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        g_ctEngineBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6h：引擎队列心跳
        if (!runtimeProtectionEnabled()) return;   // 与全局门一致：身份未过则保持停用
        CTChargeTick();
    });
    dispatch_resume(t);
}

// ============================================================================
// ★ 1.4.6i：卡死自动抓栈器 —— 心跳断档时，把「所有线程的调用栈」写进日志
//   （卡住的线程不会自己说话；由看门狗线程去采样它到底卡在哪一行）
// ============================================================================
#include <mach/mach.h>
#include <mach/arm/thread_status.h>
#include <mach/vm_region.h>
#include <dlfcn.h>
static uint64_t CTStripPAC(uint64_t a) { return a & 0x0000000FFFFFFFFFULL; }
static BOOL CTAddressReadable(uintptr_t addr) {
    vm_address_t region = (vm_address_t)addr; vm_size_t size = 0; mach_port_t obj = MACH_PORT_NULL;
    vm_region_basic_info_data_64_t info; mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    kern_return_t kr = vm_region_64(mach_task_self(), &region, &size, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj);
    if (obj != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), obj);
    if (kr != KERN_SUCCESS) return NO;
    return (addr >= region && addr + 16 <= region + size && (info.protection & VM_PROT_READ));
}
static void CTLogFrameLine(mach_msg_type_number_t ti, int idx, uintptr_t addr) {
    if (!addr) return;
    Dl_info info; const char *img = "?"; const char *sym = NULL;
    if (dladdr((void *)addr, &info)) {
        if (info.dli_fname) img = info.dli_fname;
        if (info.dli_sname) sym = info.dli_sname;
    }
    if (sym) CTD("[抓栈] T%u #%02d %s  (%s)", (unsigned)ti, idx, sym, img);
    else CTD("[抓栈] T%u #%02d 0x%llx  (%s)", (unsigned)ti, idx, (unsigned long long)addr, img);
}
static void CTDumpAllThreads(const char *why) {
    @try {
        CTD("[抓栈] %s —— 抓取线程栈开始…", why);
        thread_act_array_t list = NULL; mach_msg_type_number_t count = 0;
        if (task_threads(mach_task_self(), &list, &count) != KERN_SUCCESS || !list) {
            CTD("[抓栈] %s：task_threads 失败", why); return;
        }
        CTD("[抓栈] 共 %u 个线程，开始采样：", (unsigned)count);
        for (mach_msg_type_number_t ti = 0; ti < count && ti < 12; ti++) {
            arm_thread_state64_t st; mach_msg_type_number_t cnt = ARM_THREAD_STATE64_COUNT;
            if (thread_get_state(list[ti], ARM_THREAD_STATE64, (thread_state_t)&st, &cnt) != KERN_SUCCESS) continue;
            uintptr_t pc = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_pc(st));
            uintptr_t lr = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_lr(st));
            uintptr_t sp = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_sp(st));
            uintptr_t fp = (uintptr_t)CTStripPAC((uint64_t)__darwin_arm_thread_state64_get_fp(st));
            CTLogFrameLine(ti, 0, pc);
            if (lr && lr != pc) CTLogFrameLine(ti, 1, lr);
            int idx = 2; uintptr_t cur = fp; int walked = 0;
            while (idx < 26 && walked < 40 && cur && !(cur & 7)) {
                walked++;
                if (!CTAddressReadable(cur)) break;
                uintptr_t next = *(uintptr_t *)cur;
                uintptr_t ret  = *(uintptr_t *)(cur + 8);
                if (!ret) break;
                next = (uintptr_t)CTStripPAC((uint64_t)next);
                ret  = (uintptr_t)CTStripPAC((uint64_t)ret);
                if (next <= cur || next < sp) break;
                CTLogFrameLine(ti, idx, ret);
                cur = next; idx++;
            }
        }
        for (mach_msg_type_number_t ti = 0; ti < count; ti++) {
            if (list[ti] != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), list[ti]);
        }
        vm_deallocate(mach_task_self(), (vm_address_t)list, count * sizeof(thread_act_t));
    } @catch (__unused NSException *e) {}
}

// ★ 1.4.6g：主队列健康看门狗（独立队列）——主队列心跳断档超 90 秒 → 写日志（下次看一眼日志就能定位“卡死”）
static void startMainQueueWatchdog(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.cpucore.watchdog", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 15ull * NSEC_PER_SEC),
                              15ull * NSEC_PER_SEC, 1ull * NSEC_PER_SEC);
    dispatch_source_set_event_handler(t, ^{
        static CFAbsoluteTime sPrevFire = 0;
        CFAbsoluteTime nowW = CFAbsoluteTimeGetCurrent();
        BOOL selfCont = (sPrevFire > 0 && (nowW - sPrevFire) < 45.0);   // 自身连续（排除熄屏挂起误判）
        sPrevFire = nowW;
        if (!selfCont) return;
        double mB = (g_ctMainBeat > 0) ? (nowW - g_ctMainBeat) : 0;
        double eB = (g_ctEngineBeat > 0) ? (nowW - g_ctEngineBeat) : 0;
        double sB = (g_ctSvcBeat > 0) ? (nowW - g_ctSvcBeat) : 0;
        // ★ 1.4.6q：自愈最优先——先写日志、立即 _exit（不跑清理流程，防退出阶段再卡）；任何旁路都挡不住它
        if (mB > 120.0 || eB > 120.0 || sB > 120.0) {
            CTD("[健康] %s卡死 %.0f 秒（阶段=%d/%d）→ 自动重启后台进程（自愈）",
                (mB > 120.0) ? "主队列" : ((eB > 120.0) ? "充电引擎" : "每秒服务"),
                (mB > 120.0) ? mB : ((eB > 120.0) ? eB : sB), g_ctMainPhase, g_ctSvcPhase);
            _exit(0);
        }
        // ★ 1.4.6q：抓栈改为旁路线程——抓栈自己卡住也不影响自愈（上次就是因为同步抓栈把自愈卡没了）
        static BOOL sStallDumped = NO;
        if (mB < 30.0 && eB < 30.0 && sB < 30.0) sStallDumped = NO;   // 心跳恢复 → 允许下轮再抓
        if (!sStallDumped && (mB > 60.0 || eB > 60.0 || sB > 60.0)) {
            sStallDumped = YES;
            double vm = mB, ve = eB, vs = sB;
            dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                @autoreleasepool {
                    const char *ctWhy = (vm > 60.0) ? "主队列冻结" : ((ve > 60.0) ? "充电引擎冻结" : "每秒服务冻结");
                    CTDumpAllThreads(ctWhy);   // ★ 旁路：写进日志；若它也卡住，不影响自愈
                }
            });
        }
    });
    dispatch_resume(t);
}

static void CTHermesLockBrightnessTick(void);   // ★ 2.0.45：亮度锁定（前置声明，每秒服务调用）
// ★ 1.4.6h：每秒服务独立队列（状态文件/一键自检/定时切档）——减轻主队列负担，且主队列卡死时浮窗数字照跑
static void startPerSecondServicesTimer(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    dispatch_queue_t q = dispatch_queue_create("com.qq391160.cpucore.persec", NULL);
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        g_ctSvcBeat = CFAbsoluteTimeGetCurrent();   // ★ 1.4.6h：服务队列心跳
        // ★ 授权周期复核（未激活也要跑：设备码/状态持续发布给设置页）
        { static int sCTAuthTick = 0; if ((++sCTAuthTick % 60) == 0) CTAuthRefresh(); }
        { static int sCTDbgTick = 0; if ((++sCTDbgTick % 300) == 0) CTAnalysisAuditTick(); }   // ★ 反调试周期复核（约 5 分钟）
        if (!runtimeProtectionEnabled()) {
            // ★ 1.4.20：未接管也让「一键自检 / 状态文件」能回话（否则前端只能显示"插件无响应"，看不出真相）
            g_ctSvcPhase = 1; CTStatusFileTick();
            g_ctSvcPhase = 2; CTSelfTestTick();
            g_ctSvcPhase = 0;
            return;
        }
        g_ctSvcPhase = 1; CTStatusFileTick();
        g_ctSvcPhase = 2; CTSelfTestTick();
        g_ctSvcPhase = 3; CTScheduleTick();
        CTHermesLockBrightnessTick();   // ★ 2.0.45：亮度锁定（拉到哪里定在哪里；内部自带 5 秒节流）
        g_ctSvcPhase = 0;
    });
    dispatch_resume(t);
}

static void startForegroundRecheckTimer(void) {
    static dispatch_source_t timer = NULL; // 必须强引用，避免离开作用域被释放
    if (timer) return;
    timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!timer) return;
    dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 200ull * NSEC_PER_MSEC);   // ★加速：3秒→1秒
    dispatch_source_set_event_handler(timer, ^{
        if (!runtimeProtectionEnabled()) return;
        CTHermesSyncModeFromPrefs();   // 面板写文件可能晚于通知，这里兜底同步
        applyForegroundDecision("recheck");
    });
    dispatch_resume(timer);
}
static void applyCurrentModeToApplePPMCPU(void) {
if (!runtimeProtectionEnabled()) return;
NSArray *instances = trackedApplePPMInstancesSnapshot();
BOOL restoring = isFullPowerMode();
BOOL previousRestoring = g_restoringFullPower;
@try {
if (restoring) g_restoringFullPower = YES;
for (id ppm in instances) {
if (!ppm) continue;
if ([ppm respondsToSelector:CTObfSel("bc40e66dd6532ed2322643564cc959d4")]) {
((void (*)(id, SEL, int))objc_msgSend)(ppm, CTObfSel("dd861f2fb5c1322e1b5b6a789dcda4ec"), targetCPUPerformanceLevel());
}
if ([ppm respondsToSelector:CTObfSel("10138b3c15375b2c0e0c2070dd")]) {
((void (*)(id, SEL))objc_msgSend)(ppm, CTObfSel("0f9ed00850a5ef78d2347960d8"));
}
// updateCPU 可能重新应用旧 Level；确保最终状态仍为当前模式。
if ([ppm respondsToSelector:CTObfSel("14f1e7580a62f68e22e1194e43e1650d")]) {
((void (*)(id, SEL, int))objc_msgSend)(ppm, CTObfSel("ec86d9aced3ef7be07a9ea59b599a819"), targetCPUPerformanceLevel());
}
}
} @finally {
if (restoring) g_restoringFullPower = previousRestoring;
}
}

// 性能模式使用事件驱动 hook，不创建周期保活定时器。

static const double kCTHermesMinimumPlausibleBacklightLimit = 400.0;
// 部分显示键（如 AppleCLCD2 的 BLNitsCap）使用 16.16 定点 nits，
// 直接写 nits 会把上限写成 0.x nits 级别，必须按同一空间换算。
static const double kCTHermesFixedPointScale = 65536.0;
static const char * const kCTHermesBacklightLimitKeys[] = {
    "IOMFB_brightness_limit","IOMFB_max_brightness","IOMFB_brightness_max",
    "brightness-limit","brightness_limit","brightness-max","brightness-cap",
    "max-brightness","maxbrightness","MaxBrightness","brightnesscap","BrightnessCap",
    "BLNitsCap",NULL};

// 亮度量值取最大（兼容 数值/字符串/字典/数组 嵌套）
static double CTHermesMaximumNumericInValue(id value) {
    if ([value isKindOfClass:[NSNumber class]] || [value isKindOfClass:[NSString class]])
        return [value respondsToSelector:@selector(doubleValue)] ? [value doubleValue] : 0.0;
    if ([value isKindOfClass:[NSDictionary class]]) {
        double best = 0.0;
        for (id child in [(NSDictionary *)value allValues]) {
            double v = CTHermesMaximumNumericInValue(child);
            if (v > best) best = v;
        }
        return best;
    }
    if ([value isKindOfClass:[NSArray class]]) {
        double best = 0.0;
        for (id child in (NSArray *)value) {
            double v = CTHermesMaximumNumericInValue(child);
            if (v > best) best = v;
        }
        return best;
    }
    return 0.0;
}

// 亮度事件日志（并入主诊断日志，前缀 [亮度]，便于随 CTHermesDiag.log 一起排查）
static void CTBLog(NSString *message) {
    if (message.length == 0) return;
    CTD("[亮度] %s", message.UTF8String);
}

// ★ 弹窗拦截证据日志（限频：前 3 条必记 + 之后每 60 秒最多 1 条）
static int g_ctPopupLogCount = 0;
static CFAbsoluteTime g_ctPopupLastLog = 0;
static void CTPopupLog(NSString *what) {
    g_ctPopupN++; CTHostAlivePost();   // 自测增强：弹窗拦截计数
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    g_ctPopupLogCount++;
    if (g_ctPopupLogCount > 3 && (now - g_ctPopupLastLog) < 60.0) return;
    g_ctPopupLastLog = now;
    CTD("[弹窗] 已拦截 %s（屏蔽高温警告在岗）", what.UTF8String);
}

static NSNumber *g_maxBacklightBrightnessValue = nil; // 设备自身亮度 cap（如13Pro=1060），动态发现，不硬编码
static NSNumber *g_userBrightnessBeforeModeChange = nil; // 切换前用户滑块/实际亮度（如850.1）
static BOOL g_backlightRecoveryScheduled = NO;
static os_unfair_lock g_brightnessRecommitLock = OS_UNFAIR_LOCK_INIT;
static CFAbsoluteTime g_lastBrightnessRecommitSchedule = 0;

// ★ 2.0.94：读取"滑块值"（带失败原因输出；供"读不到"的机器一轮定案）
static id CTHermesCopyUserBrightnessDiag(NSString **whyOut) {
    if (whyOut) *whyOut = nil;
    const char *paths[]={
        "/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness",
        "/System/Library/PrivateFrameworks/corebrightness.framework/corebrightness",NULL};
    BOOL dlOK = NO;
    for(int i=0;paths[i];i++)if(dlopen(paths[i],RTLD_NOW|RTLD_LOCAL)){dlOK=YES;break;}
    Class cls=CTObfCls("267b41485daff1f43615bd3e0cfc6071315288911ee691bf9442");
    if(!cls){ if(whyOut)*whyOut=[NSString stringWithFormat:@"dl=%d 类=空", dlOK?1:0]; return nil; }
    id client=[[cls alloc]init]; SEL cp=CTObfSel("1ff424a475d54cc20e7acc2e32819563053c95b1278143");
    if(![client respondsToSelector:cp]){ if(whyOut)*whyOut=@"方法缺"; return nil; }
    id display=((id(*)(id,SEL,id))objc_msgSend)(client,cp,S("DisplayBrightness"));
    id b=[display isKindOfClass:[NSDictionary class]]?display[S("Brightness")]:nil;
    if(![b respondsToSelector:@selector(doubleValue)]){ if(whyOut)*whyOut=(display?@"返回=空值":@"返回=非字典"); return nil; }
    if([b doubleValue]<=0.0){ if(whyOut)*whyOut=@"返回≤0"; return nil; }
    return b;
}
static id CTHermesCopyUserBrightness(void) {
    return CTHermesCopyUserBrightnessDiag(NULL);
}

static void CTHermesCaptureBrightnessBeforeModeChange(void) {
    if(!thermalDimmingPreventionEnabled()||CTHermesScreenIsBlanked())return;
    id b=CTHermesCopyUserBrightness();
    if([b respondsToSelector:@selector(doubleValue)]&&[b doubleValue]>0.0)
        g_userBrightnessBeforeModeChange=[NSNumber numberWithDouble:[b doubleValue]];
}

static void CTHermesRecommitUserBrightness(void) {
    if(CTHermesScreenIsBlanked())return;
    g_ctRWN++; CTHostAlivePost(); return;   // ★2.0.38：用户亮度“零写入”（只计数不动手）——拉到哪里就永远在哪里
    if (!g_userBrightnessBeforeModeChange) return;   // ★2.0.38：回写只许“切换恢复”窗口内发生（绝不顶升非切换时刻的手动亮度）
    {   // ★ 1.4.64：同闸（双保险 ✓）
        // ★ 1.4.67：同上 ✓
    }
    Class cls=CTObfCls("557761ecd56782e2c80d45302455bfe58fab0eca8aef5bac39bb"); if(!cls)return;
    id client=[[cls alloc]init]; SEL set=CTObfSel("918d5816231799dafc920893feba366683abea1b864135");
    if(![client respondsToSelector:set])return;
    id brightness=g_userBrightnessBeforeModeChange?:CTHermesCopyUserBrightness();
    if(![brightness respondsToSelector:@selector(doubleValue)]||[brightness doubleValue]<=0.0)return;
    {   // ★ 1.4.67：只往上写 —— 想写一个【比当前实际更低】的值 ⇒ 直接不写（"拉低"的手就此断 ✓）
        id curNow = CTHermesCopyUserBrightness();
        if (curNow && [curNow respondsToSelector:@selector(doubleValue)] && [brightness respondsToSelector:@selector(doubleValue)]) {
            if ([brightness doubleValue] + 0.02 < [curNow doubleValue]) return;
        }
    }
    { id ctCur = CTHermesCopyUserBrightness(); CTD("[自测·回写] 回写亮度=%.3f（当前=%.3f）", [brightness doubleValue], ctCur ? [ctCur doubleValue] : -1.0); }   // 自测增强
    g_ctRWN++; g_ctRWV10 = (uint32_t)([brightness doubleValue] * 10.0); CTHostAlivePost();   // 自测增强：回写数字表
    NSDictionary *request=@{S("Brightness"):brightness,S("Commit"):@YES};
    ((void(*)(id,SEL,id,id))objc_msgSend)(client,set,request,S("DisplayBrightness"));
}

// ★ 2.0.45：亮度锁定（"拉到哪里定在哪里"）——防暗屏开启时，每 5 秒把"滑块上的亮度原值"写回一次（Commit）。
//   安全护栏：①只照抄"用户亮度"读数（系统偷着压低时它不变，不会因此锁暗）②读数≤0.05 绝不出手
//   ③开关/授权双门控（关=零写入，沿用 2.0.38 规矩）④与抬升链并肩上，双保险。
static void CTHermesLockBrightnessTick(void) {
    if (!thermalDimmingPreventionEnabled()) return;   // ③ 开关+授权门控
    if (CTHermesScreenIsBlanked()) return;
    static CFAbsoluteTime sLockLast = 0;
    CFAbsoluteTime nowL = CFAbsoluteTimeGetCurrent();
    if (sLockLast > 0 && (nowL - sLockLast) < 5.0) return;   // 5 秒一拍
    sLockLast = nowL;
    NSString *ctWhyR = nil;
    id br = CTHermesCopyUserBrightnessDiag(&ctWhyR);  // ① 读"滑块值"（带失败原因）
    if (![br respondsToSelector:@selector(doubleValue)]) {
        static CFAbsoluteTime sLockRLogAt = 0;
        CFAbsoluteTime nLR = CFAbsoluteTimeGetCurrent();
        if (nLR - sLockRLogAt > 60.0) { sLockRLogAt = nLR; CTD("[锁定] 读失败（%s）→ 本拍跳过", ctWhyR ? ctWhyR.UTF8String : "?"); }
        return;
    }
    double v = [br doubleValue];
    if (v <= 0.05) {                                  // ② 绝不锁暗
        static CFAbsoluteTime sLockLLogAt = 0;
        CFAbsoluteTime nLL = CFAbsoluteTimeGetCurrent();
        if (nLL - sLockLLogAt > 60.0) { sLockLLogAt = nLL; CTD("[锁定] 读数过低（%.3f）→ 按护栏不出手（绝不锁暗）", v); }
        return;
    }
    Class cls = CTObfCls("557761ecd56782e2c80d45302455bfe58fab0eca8aef5bac39bb");
    if (!cls) return;
    id client = [[cls alloc] init];
    SEL set = CTObfSel("918d5816231799dafc920893feba366683abea1b864135");
    if (![client respondsToSelector:set]) return;
    NSDictionary *request = @{S("Brightness"): br, S("Commit"): @YES};
    @try {
        ((void (*)(id, SEL, id, id))objc_msgSend)(client, set, request, S("DisplayBrightness"));
    } @catch (__unused NSException *e) { return; }
    static int sLockN = 0; sLockN++;
    if (sLockN <= 3 || (sLockN % 6) == 0) CTD("[锁定] 亮度已重写=%.3f（拉到哪里定在哪里）", v);
}

static void CTHermesRecommitUserBrightnessSoon(void) {
    if (CTHermesScreenIsBlanked()) return;
    {   // ★ 1.4.64：注销/开机后 90 秒内 ⇒ 不写回亮度（治"刚亮屏被拉低"✓）
        // ★ 1.4.67：不再整封（改由"只往上写"规则把关 ✓）
    }
    CFAbsoluteTime now=CFAbsoluteTimeGetCurrent();
    os_unfair_lock_lock(&g_brightnessRecommitLock);
    BOOL allowed=(now-g_lastBrightnessRecommitSchedule)>=0.20;
    if(allowed)g_lastBrightnessRecommitSchedule=now;
    os_unfair_lock_unlock(&g_brightnessRecommitLock);
    if(!allowed)return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,50ull*NSEC_PER_MSEC),dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{CTHermesRecommitUserBrightness();});
}

static void CTHermesRememberBacklightMaximum(id value) {
    if(![value respondsToSelector:@selector(doubleValue)])return;
    double v=[value doubleValue];
    // ★ 2026-09-29（对照老源码修复）：低于 400 nits 的一律不采信为原生上限，
    //   避免把被温控压低的值（如配置表低档 163.3）学成"上限"→ 写回后把屏幕压暗。
    if (v > 10000.0 && v <= 4294967295.0) { v = v / 65536.0; }   // ★2.0.38：16.16 定点键换算后再判定
    if(v<kCTHermesMinimumPlausibleBacklightLimit||v>10000.0)return;
    if(!g_maxBacklightBrightnessValue||v>[g_maxBacklightBrightnessValue doubleValue]){
        g_maxBacklightBrightnessValue=[NSNumber numberWithDouble:v];
        CTBLog([NSString stringWithFormat:@"显示上限已记录: %.1f nits",v]);
    }
}

// 尽力而为：从 CoreBrightness 客户端读取亮度信息（纯数字 0~1 的滑块值会被
// 400 nits 下限过滤掉，不会污染原生上限）。
static void CTHermesRememberCoreBrightnessMaximum(void) {
    static BOOL tried = NO;
    if (tried) return;
    tried = YES;
    const char *paths[]={"/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness",
                         "/System/Library/PrivateFrameworks/corebrightness.framework/corebrightness",NULL};
    for (int i=0;paths[i];i++) if (dlopen(paths[i], RTLD_NOW|RTLD_LOCAL)) break;
    Class cls = CTObfCls("82a5eaf780a5aca3532f11cc0f2e322160cce2f23cd4e3d55cd2");
    if (!cls) return;
    id client = nil;
    @try { client = [[cls alloc] init]; } @catch (__unused NSException *e) { return; }
    if (!client || ![client respondsToSelector:CTObfSel("ea6270e5b31a51768007719a34ce9db2d245a2a7da3f1a")]) return;
    NSArray *keys = @[@"DisplayBrightness", @"DisplayBrightnessLimit", @"BrightnessLimit"];
    for (NSString *key in keys) {
        id value = nil;
        @try { value = ((id(*)(id,SEL,id))objc_msgSend)(client, CTObfSel("4c51801d8383402bc2199134e31b9551294a2d07cfcf33"), key); }
        @catch (__unused NSException *e) { value = nil; }
        if (!value) continue;
        double v = CTHermesMaximumNumericInValue(value);
        if (v > 0.0) CTHermesRememberBacklightMaximum(@(v));
    }
}

static void CTHermesCaptureExistingBacklightMaximum(void) {
    if(!thermalDimmingPreventionEnabled()||CTHermesScreenIsBlanked())return;
    CTHermesRememberCoreBrightnessMaximum();
    io_iterator_t it=IO_OBJECT_NULL;
    if(IORegistryCreateIterator(kIOMasterPortDefault,kIOServicePlane,kIORegistryIterateRecursively,&it)!=KERN_SUCCESS||it==IO_OBJECT_NULL)return;
    io_registry_entry_t e;
    while((e=IOIteratorNext(it))!=IO_OBJECT_NULL){
        for(int i=0;kCTHermesBacklightLimitKeys[i];i++){
            CFStringRef k=CFStringCreateWithCString(NULL,kCTHermesBacklightLimitKeys[i],kCFStringEncodingUTF8); if(!k)continue;
            CFTypeRef v=IORegistryEntryCreateCFProperty(e,k,NULL,0);
            if(v){ if(CFGetTypeID(v)==CFNumberGetTypeID()||CFGetTypeID(v)==CFStringGetTypeID())CTHermesRememberBacklightMaximum((__bridge id)v); CFRelease(v); }
            CFRelease(k);
        }
        IOObjectRelease(e);
    }
    IOObjectRelease(it);
}

// ★ 2026-09-29：状态自适应——同一键"写了不动"（节点自行钳制），120 秒冷却内不再反复写；
//   数值真的被压下去（低于上次所见）时立即再拉，防无意义拉锯（实测 44 次/分 → 收敛）。
typedef struct { char key[24]; double lastSeen; CFAbsoluteTime lastAttempt; BOOL noted; int strikes; } CTBrightKeyState;
static CTBrightKeyState g_brState[12];
static CTBrightKeyState *CTBrightStateFor(const char *key) {
    CTBrightKeyState *freeSlot = NULL;
    for (int i = 0; i < 12; i++) {
        if (g_brState[i].key[0] && strcmp(g_brState[i].key, key) == 0) return &g_brState[i];
        if (!g_brState[i].key[0] && !freeSlot) freeSlot = &g_brState[i];
    }
    if (freeSlot) { strncpy(freeSlot->key, key, sizeof(freeSlot->key) - 1); freeSlot->lastSeen = 0; freeSlot->lastAttempt = 0; freeSlot->noted = NO; freeSlot->strikes = 0; }
    return freeSlot;
}

// 只"调整"不"压低"：仅当节点当前值低于已发现的原生上限时才写回，任何情况下都不会把屏幕压暗。
// ★ 2026-09-29（对照老源码修复）：旧实现无条件写回，配合被污染的上限值会把屏幕锁暗（用户实报"解锁变暗"）。
static int g_ctRaiseStuck = 0;   // 自测增强：抬不动计数
static NSUInteger CTHermesRaiseExistingBacklightLimits(void) {
    if(!thermalDimmingPreventionEnabled()||CTHermesScreenIsBlanked())return 0;
    { static BOOL sSilDone37 = NO; if (ctBootSilence()) return 0; if (!sSilDone37) { sSilDone37 = YES; CTD("[自测] 开机静默期结束（90 秒）→ 显示链开始上岗"); } }   // ★2.0.38
    if(!g_maxBacklightBrightnessValue)CTHermesCaptureExistingBacklightMaximum();
    double target=g_maxBacklightBrightnessValue?[g_maxBacklightBrightnessValue doubleValue]:0.0;
    if(target<kCTHermesMinimumPlausibleBacklightLimit)return 0;
    io_iterator_t iterator = IO_OBJECT_NULL;
    if (IORegistryCreateIterator(kIOMasterPortDefault, kIOServicePlane, kIORegistryIterateRecursively, &iterator) != KERN_SUCCESS || iterator == IO_OBJECT_NULL) return 0;
    NSUInteger raised = 0;
    const char *firstKey = NULL; double firstCur = 0.0;
    io_registry_entry_t entry;
    while ((entry = IOIteratorNext(iterator)) != IO_OBJECT_NULL) {
    if (CTHermesScreenIsBlanked()) return 0;   // ★ 0930-0207：息屏不查不写 0930-0207：息屏不查不写（省电+零风险）
        for (int i=0; kCTHermesBacklightLimitKeys[i]; i++) {
            CFStringRef key = CFStringCreateWithCString(kCFAllocatorDefault, kCTHermesBacklightLimitKeys[i], kCFStringEncodingUTF8);
            if (!key) continue;
            CFTypeRef existing = IORegistryEntryCreateCFProperty(entry, key, kCFAllocatorDefault, 0);
            if (existing) {
                BOOL numeric = NO; double current = 0.0;
                if (CFGetTypeID(existing)==CFNumberGetTypeID()) { current=[(__bridge NSNumber *)existing doubleValue]; numeric=YES; }
                else if (CFGetTypeID(existing)==CFStringGetTypeID()) { current=[(__bridge NSString *)existing doubleValue]; numeric=YES; }
                if (numeric && current > 0.0 && target > 0.0) {
                    BOOL fixedPoint = (current > kCTHermesFixedPointScale);
                    double scaled = fixedPoint ? target * kCTHermesFixedPointScale : target;
                    // 定点键按 16.16 换算后比较，避免误写 0.x nits
                    CTBrightKeyState *st = CTBrightStateFor(kCTHermesBacklightLimitKeys[i]);
                    if (current + 0.5 < scaled) {
                        CFAbsoluteTime bnow = CFAbsoluteTimeGetCurrent();
                        BOOL noProgress = (st && st->lastSeen > 0.0 && current >= st->lastSeen - 0.25);
                        BOOL cooling = (st && st->lastAttempt > 0.0 && (bnow - st->lastAttempt) < 60.0);
                        double ctBT = CTBatteryTempC();   // ★ 0930-0207 加强：热到 50°C 才真正放手（保底安全）
                        if (ctBT >= 50.0) {
                            if (st && !st->noted) {
                                st->noted = YES;
                                CTBLog([NSString stringWithFormat:@"%@ 电池 %.1f°C 过热(≥50) → 暂停顶亮度（凉了自动继续）", [NSString stringWithUTF8String:kCTHermesBacklightLimitKeys[i]], ctBT]);   // ★ 2.0.38：修 %@ 误传 C 字符串指针（tm 实崩教训）
                            }
                        } else if (noProgress && cooling && st && (++st->strikes < 3)) {
                            id writeValue = fixedPoint ? @((long long)(scaled + 0.5)) : g_maxBacklightBrightnessValue;
                            IORegistryEntrySetCFProperty(entry, key, (__bridge CFTypeRef)writeValue);
                            {   // ★ 2.0.44：写入回读探针——写=什么、立即回读=什么、节点/进程（判定"写不进"还是"被压回"）
                                char __nb[128] = {0}; IORegistryEntryGetName(entry, __nb);
                                double __wv = [writeValue doubleValue]; double __rb = -1.0;
                                CFTypeRef __rv = IORegistryEntryCreateCFProperty(entry, key, NULL, 0);
                                if (__rv) { __rb = CTHermesMaximumNumericInValue((__bridge id)__rv); CFRelease(__rv); }
                                CTBLog([NSString stringWithFormat:@"写回读[%s]: 键=%s 节点=%s 写=%.0f 回=%.0f 目标=%.0f",
                                        getprogname(), kCTHermesBacklightLimitKeys[i], __nb, __wv, __rb, target]);
                            }
                            raised++;
                            if (raised == 1) { firstKey = kCTHermesBacklightLimitKeys[i]; firstCur = current; }
                            st->lastAttempt = bnow; st->noted = NO;
                        } else if (noProgress && cooling) {
            g_ctRaiseStuck++;   // 自测增强
                            if (st && !st->noted) {
                                st->noted = YES;
                                CTBLog([NSString stringWithFormat:@"%@ 疑似到顶（当前 %.1f / 目标 %.1f），暂停反复拉高", [NSString stringWithUTF8String:kCTHermesBacklightLimitKeys[i]], current, target]);
                            }
                        } else {
                            id writeValue = fixedPoint ? @((long long)(scaled + 0.5)) : g_maxBacklightBrightnessValue;
                            IORegistryEntrySetCFProperty(entry, key, (__bridge CFTypeRef)writeValue);
                            {   // ★ 2.0.44：写入回读探针——写=什么、立即回读=什么、节点/进程（判定"写不进"还是"被压回"）
                                char __nb[128] = {0}; IORegistryEntryGetName(entry, __nb);
                                double __wv = [writeValue doubleValue]; double __rb = -1.0;
                                CFTypeRef __rv = IORegistryEntryCreateCFProperty(entry, key, NULL, 0);
                                if (__rv) { __rb = CTHermesMaximumNumericInValue((__bridge id)__rv); CFRelease(__rv); }
                                CTBLog([NSString stringWithFormat:@"写回读[%s]: 键=%s 节点=%s 写=%.0f 回=%.0f 目标=%.0f",
                                        getprogname(), kCTHermesBacklightLimitKeys[i], __nb, __wv, __rb, target]);
                            }
                            raised++;
                            if (raised == 1) { firstKey = kCTHermesBacklightLimitKeys[i]; firstCur = current; }
                            if (st) { st->lastAttempt = bnow; st->noted = NO; st->strikes = 0; }
                        }
                    }
                    if (st && st->lastSeen > 0.0 && current + 1.0 < st->lastSeen) {
                        static CFAbsoluteTime sDropAt = 0; CFAbsoluteTime dnow = CFAbsoluteTimeGetCurrent();
                        if (dnow - sDropAt > 60.0) {
                            sDropAt = dnow;
                            CTBLog([NSString stringWithFormat:@"[亮度] 上限被压下：%s %.1f → %.1f（外部压制留痕）", kCTHermesBacklightLimitKeys[i], st->lastSeen, current]);   // ★ 2.0.53
                        }
                    }
                    if (st) st->lastSeen = current;
                }
                CFRelease(existing);
            }
            CFRelease(key);
        }
        IOObjectRelease(entry);
    }
    IOObjectRelease(iterator);
    if (raised) {
        if (firstKey) CTBLog([NSString stringWithFormat:@"raised %lu node(s) → %.1f nits（首个 %s 由 %.1f 拉高）", (unsigned long)raised, target, firstKey, firstCur]);
        else CTBLog([NSString stringWithFormat:@"raised %lu node(s) → %.1f nits", (unsigned long)raised, target]);
    }
    return raised;
}

static void CTHermesRestoreExistingBacklightLimit(void) {
    if (!thermalDimmingPreventionEnabled() || CTHermesScreenIsBlanked()) return;
    CTHermesRaiseExistingBacklightLimits();
    CTHermesRecommitUserBrightness();
}

// 周期自检（仅调整限制，不动用户滑块，避免与自动亮度打架）：
// 覆盖"限制被别的进程写入 / 注销 SpringBoard 后无人复位"的场景。
static void CTHermesBacklightAuditTick(void) {
    static int sSelfTick = 0;   // 自测增强
    if (thermalDimmingPreventionEnabled()) {
        CTHermesCaptureExistingBacklightMaximum();
        NSUInteger ctRaised = CTHermesRaiseExistingBacklightLimits();
        if ((++sSelfTick % 3) == 1) CTD("[自测·显示] 开关=1 目标=%.0f 本次调整=%lu 卡住累计=%d", g_maxBacklightBrightnessValue ? [g_maxBacklightBrightnessValue doubleValue] : 0.0, (unsigned long)ctRaised, g_ctRaiseStuck);
    } else {
        if ((++sSelfTick % 15) == 1) CTD("[自测·显示] 开关=0 → 显示链被门控（在岗但不动手）");
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,20ull*NSEC_PER_SEC),dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{CTHermesBacklightAuditTick();});
}

static void CTHermesStartBacklightAuditTimer(void) {
    static BOOL started = NO;
    if (started) return;
    started = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,20ull*NSEC_PER_SEC),dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{CTHermesBacklightAuditTick();});
}

static void CTHermesScheduleBacklightRecovery(void) {
    if (!thermalDimmingPreventionEnabled() || g_backlightRecoveryScheduled) return;
    g_backlightRecoveryScheduled = YES;
    { static BOOL sSelfIgOnce = NO; if (!sSelfIgOnce) { sSelfIgOnce = YES; CTD("[自测·点火] 显示链已点火（开关=1）"); } }   // 自测增强
    CTHermesStartBacklightAuditTimer();
    const double delays[] = {0.02,0.10,0.25,0.50,1.00,2.00,4.00};
    for (NSUInteger i=0;i<sizeof(delays)/sizeof(delays[0]);i++) {
        BOOL finalAttempt=(i+1==sizeof(delays)/sizeof(delays[0]));
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(delays[i]*NSEC_PER_SEC)),dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{CTHermesRestoreExistingBacklightLimit();if(finalAttempt)dispatch_async(dispatch_get_main_queue(),^{g_backlightRecoveryScheduled=NO;g_userBrightnessBeforeModeChange=nil;});});
    }
}

// ★ 2.0.38：显示变暗"写入层拦截"——若本进程内有谁把背光上限"往下压"，当场挡掉（只拦向下；防暗屏关=全放行）
static kern_return_t (*orig_IORegSetProp)(io_registry_entry_t, CFStringRef, CFTypeRef) = NULL;
static kern_return_t ctDimWriteGuardHook(io_registry_entry_t entry, CFStringRef key, CFTypeRef value) {
    @try {
        if (thermalDimmingPreventionEnabled() && key && CFGetTypeID(key) == CFStringGetTypeID()) {
            const char *k = [(__bridge NSString *)key UTF8String];
            if (k) {
                for (int i = 0; kCTHermesBacklightLimitKeys[i]; i++) {
                    if (strcmp(k, kCTHermesBacklightLimitKeys[i]) == 0) {
                        g_ctBlkSeen++;   // 自测增强
                        CFTypeRef cur = IORegistryEntryCreateCFProperty(entry, key, kCFAllocatorDefault, 0);
                        if (cur) {
                            double cv = 0.0, nv = 0.0; BOOL okc = NO, okn = NO;
                            if (CFGetTypeID(cur) == CFNumberGetTypeID()) { cv = [(__bridge NSNumber *)cur doubleValue]; okc = YES; }
                            else if (CFGetTypeID(cur) == CFStringGetTypeID()) { cv = [(__bridge NSString *)cur doubleValue]; okc = YES; }
                            if (CFGetTypeID(value) == CFNumberGetTypeID()) { nv = [(__bridge NSNumber *)value doubleValue]; okn = YES; }
                            else if (CFGetTypeID(value) == CFStringGetTypeID()) { nv = [(__bridge NSString *)value doubleValue]; okn = YES; }
                            CFRelease(cur);
                            if (okc && okn && nv > 0.0 && cv > 0.0 && nv + 0.5 < cv) {
                                g_ctBlkClamp++;   // 自测增强
                                { static int sBD = 0; sBD++; if (sBD <= 5 || (sBD % 20) == 0) CTD("[自测·拦写] 挡下一笔向下写（%s）", k); }
                                return kIOReturnSuccess;   // 假装成功：这一笔"变暗"不落地
                            }
                        }
                    }
                }
            }
        }
    } @catch (__unused NSException *e) {}
    return orig_IORegSetProp ? orig_IORegSetProp(entry, key, value) : kIOReturnError;
}
static void CTDimWriteGuardInstall(void) {
    static BOOL done = NO;
    if (done) return;
    done = YES;
    @try {
        void *p = dlsym(RTLD_DEFAULT, "IORegistryEntrySetCFProperty");
        if (p && !orig_IORegSetProp) MSHookFunction(p, (void *)ctDimWriteGuardHook, (void **)&orig_IORegSetProp);
    } @catch (__unused NSException *e) {}
}
static BOOL keyIsDisplayLifecycleProperty(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
return [lower containsString:S("idle")] || [lower containsString:S("autolock")] ||
       [lower containsString:S("lockstate")] || [lower containsString:S("sleep")] ||
       [lower containsString:S("blank")] || [lower containsString:S("screenoff")] ||
       [lower containsString:S("screen-off")] || [lower containsString:S("powerstate")] ||
       [lower containsString:S("power-state")] || [lower containsString:S("displaystate")] ||
       [lower containsString:S("screenstate")] || [lower containsString:S("wake")] ||
       [lower containsString:S("proximity")] || [lower containsString:S("backlightpower")];
}

static BOOL keyIsBacklightThermalLimit(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
if (keyIsDisplayLifecycleProperty(key)) return NO;
if ([lower isEqualToString:S("iomfb_brightness_limit")] ||
    [lower isEqualToString:S("max-brightness")] ||
    [lower isEqualToString:S("brightness-limit")] ||
    [lower isEqualToString:S("brightness_limit")] ||
    [lower isEqualToString:S("maxbrightness")] ||
    [lower isEqualToString:S("brightnesscap")]) return YES;
BOOL explicitThermal = [lower containsString:S("thermal")] ||
                       [lower containsString:S("mitigation")] ||
                       [lower containsString:S("temperature")];
BOOL explicitCap = [lower containsString:S("limit")] ||
                   [lower containsString:S("ceiling")] ||
                   [lower containsString:S("maximum")] ||
                   [lower containsString:S("max-")] ||
                   [lower containsString:S("cap")];
BOOL brightnessValue = [lower containsString:S("brightness")] ||
                       [lower containsString:S("luminance")] ||
                       [lower containsString:S("nits")];
BOOL displayOwner = [lower containsString:S("iomfb")] ||
                    [lower containsString:S("backlight")] ||
                    [lower containsString:S("display")];
return brightnessValue && explicitCap && (explicitThermal || displayOwner);
}

static id maximumBacklightReplacementForKey(NSString *key) {
return g_maxBacklightBrightnessValue;
}

static id backlightReplacementMatchingValue(NSString *key, id originalValue) {
CTHermesRememberBacklightMaximum(originalValue);
id maximum = maximumBacklightReplacementForKey(key);
if (!maximum) return nil;
if ([originalValue isKindOfClass:[NSString class]]) {
double v = [(NSString *)originalValue doubleValue];
if (v <= 0.0) return nil;
if (v > kCTHermesFixedPointScale) {
double raw = [(NSNumber *)maximum doubleValue] * kCTHermesFixedPointScale;
return [NSString stringWithFormat:@"%.0f", raw];
}
return [(NSNumber *)maximum stringValue];
}
if ([originalValue isKindOfClass:[NSNumber class]]) {
double v = [(NSNumber *)originalValue doubleValue];
if (v <= 0.0) return nil;
if (v > kCTHermesFixedPointScale)
return @([(NSNumber *)maximum doubleValue] * kCTHermesFixedPointScale);
return maximum;
}
return nil;
}

// 判断是否为 thermalmonitord 发出的约束属性。
// 这里只丢弃用户态温控上限写入，不向内核写固定频点，因此不会锁死原生 DVFS。
static BOOL keyIsThermalThrottleProperty(NSString *key) {
if (!key || key.length == 0) return NO;
NSString *lower = [key lowercaseString];
if (keyIsDisplayLifecycleProperty(key)) return NO;

// Floor/Minimum 属于性能下限而非热降频上限，不能拦截。
if ([lower containsString:S("floor")]) return NO;

// 明确的温控缓解关键词 — 无条件拦截
if ([lower containsString:S("throttle")]) return YES;
if ([lower containsString:S("mitigation")]) return YES;

BOOL mentionsCPU = [lower containsString:S("cpu")] ||
[lower containsString:S("core")] ||
[lower containsString:S("ppm")] ||
[lower containsString:S("processor")];
BOOL mentionsGPU = [lower containsString:S("gpu")];
BOOL mentionsPackage = [lower containsString:S("package")] ||
[lower containsString:S("component")];
BOOL mentionsThermal = [lower containsString:S("thermal")];
BOOL mentionsFreq = [lower containsString:S("freq")] ||
[lower containsString:S("frequency")];
BOOL mentionsLimit = [lower containsString:S("limit")] ||
[lower containsString:S("cap")] ||
[lower containsString:S("ceiling")] ||
[lower containsString:S("floor")] ||
[lower containsString:S("target")] ||
[lower containsString:S("maximum")] ||
[lower containsString:S("minimum")];
BOOL mentionsSpeed = [lower containsString:S("speed")];
BOOL mentionsPower = [lower containsString:S("power")];
BOOL mentionsState = [lower containsString:S("level")] ||
[lower containsString:S("state")];

BOOL protectedComponent = mentionsCPU || mentionsGPU || mentionsPackage || mentionsThermal;
if (protectedComponent) {
// 日常性能模式只保护 CPU；高性能模式额外保护 GPU 与 Package 功率墙。
if (mentionsLimit || mentionsFreq || mentionsSpeed || mentionsPower || mentionsState) {
return YES;
}
}
return NO;
}

static CFDictionaryRef copyPropertiesByRemovingThermalLimits(CFTypeRef properties) {
if (!properties || CFGetTypeID(properties) != CFDictionaryGetTypeID()) return NULL;
NSDictionary *source = (__bridge NSDictionary *)properties;
NSMutableDictionary *filtered = [source mutableCopy];
if (!filtered) return NULL;
BOOL changed = NO;

for (id rawKey in source) {
if (![rawKey isKindOfClass:[NSString class]]) continue;
NSString *key = (NSString *)rawKey;
if (thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(key)) {
    id original = [source objectForKey:key];
    id replacement = backlightReplacementMatchingValue(key, original);
    if (replacement) [filtered setObject:replacement forKey:key];
    changed = YES;
    continue;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(key) && g_ctcCapacity < 99 && CTChargeHotGate()) {   // ★ 2.0.51：真热门——不热一律放行
    id original = [source objectForKey:key];
    if (valueMeansStopChargingCF(key, (__bridge CFTypeRef)original)) {
        [filtered removeObjectForKey:key];
        changed = YES;
        CTChargeNoteIntercept(key);
        continue;
    }
}
BOOL shouldDrop = isNetworkThrottleProperty((__bridge CFStringRef)key);
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(key)) {
shouldDrop = YES;
}
if (!shouldDrop) continue;
[filtered removeObjectForKey:key];
changed = YES;
}

return changed ? CFBridgingRetain(filtered) : NULL;
}

// ============================================================================
// ★ 2026-09-29（对照原版 1.6.2-103 移植）：iOS 16 热压链补全
//   原版在 iOS 16 把同一批方法「双保险」挂两层：
//     ①名字层（CTHermesThermalManager / CTHermesThermalControl / CommonProduct）
//     ②真实类层（TableDrivenDecisionTree / NotificationManager / SupervisorControl /
//       ComponentControl / ApplePPM —— iOS 16 thermalmonitord 热压链的实际执行者）
//   本段 = 真实类层补全 + 热写入丢弃判定 + 温度读数归一；
//   全部按「运行时真实签名」安装（float/double/int 自适应），避免 ABI 错配。
// ============================================================================

static NSDictionary *patchThermalPlist(NSDictionary *dict);   // 前置声明（定义在本文件后部）
static void installConfigLayerHook(void);   // ★ 2.0.38：配置层"自寻挂载"前置声明（防暗屏复活；定义在本文件后部）

// 配置补丁首次接管标记（防暗屏根因修复的验证日志用）
static BOOL g_ctCfgHookLogged = NO;

// 热相关服务键判定 —— 解除温控下丢弃热压写入（对照原版 CTHermesIsThermalServiceKey）
static BOOL CTIsThermalServiceKey(id key) {
    if (![key isKindOfClass:[NSString class]]) return NO;
    const char *k = [[key lowercaseString] UTF8String];
    if (!k) return NO;
    static const char *tokens[] = {"thermal","temperature","die","skin","pressure","throttle","mitigation",
        "cpms","hippocket","pocket","powerzone","p-state","pstate", NULL};
    for (int i = 0; tokens[i]; i++) { if (strstr(k, tokens[i])) return YES; }
    return NO;
}

// 参数是否为通用寄存器类型（非 float/double/结构体）——安全安装别名用
static BOOL CTArgMaybeGeneral(Class cls, SEL sel, unsigned int index) {
    Method m = class_getInstanceMethod(cls, sel);
    if (!m || index >= method_getNumberOfArguments(m)) return NO;
    char type[16] = {0}; method_getArgumentType(m, index, type, sizeof(type));
    const char *c = type; while (*c && strchr("rnNoORV", *c)) c++;
    return *c && !strchr("fd{D(", *c);
}

// —— 真实类层：包装函数与原始指针（2026-09-29 移植）——
static double (*origTDT_GetReleaseD)(id, SEL, uintptr_t) = NULL;
static double aliasTDT_GetReleaseD(id self, SEL cmd, uintptr_t component) {
    if (shouldApplyFullCPUProtection()) return 0.0;
    return origTDT_GetReleaseD ? origTDT_GetReleaseD(self, cmd, component) : 0.0;
}
static double (*origSupervisor_EffortD)(id, SEL, uintptr_t, uintptr_t) = NULL;
static float (*origSupervisor_EffortF)(id, SEL, uintptr_t, uintptr_t) = NULL;
static double aliasSupervisor_EffortD(id self, SEL cmd, uintptr_t effort, uintptr_t trigger) {
    if (shouldApplyFullCPUProtection()) return 0.0;
    return origSupervisor_EffortD ? origSupervisor_EffortD(self, cmd, effort, trigger) : 0.0;
}
static float aliasSupervisor_EffortF(id self, SEL cmd, uintptr_t effort, uintptr_t trigger) {
    if (shouldApplyFullCPUProtection()) return 0.0f;
    return origSupervisor_EffortF ? origSupervisor_EffortF(self, cmd, effort, trigger) : 0.0f;
}
static void (*origApplePPM_SetLevel)(id, SEL, int) = NULL;
static void aliasApplePPM_SetLevel(id self, SEL cmd, int level) {
    if (shouldApplyFullCPUProtection()) { CTD("[热链] ApplePPM setCPULevel(%d) → 阻断", level); return; }
    if (origApplePPM_SetLevel) origApplePPM_SetLevel(self, cmd, level);
}
static void (*origComponent_UpdateParams)(id, SEL, uintptr_t) = NULL;
static void aliasComponent_UpdateParams(id self, SEL cmd, uintptr_t params) {
    if (shouldApplyFullCPUProtection()) return;
    if (origComponent_UpdateParams) origComponent_UpdateParams(self, cmd, params);
}
static void (*origComponent_UpdatePackage)(id, SEL) = NULL;
static void aliasComponent_UpdatePackage(id self, SEL cmd) {
    if (shouldApplyFullCPUProtection()) return;
    if (origComponent_UpdatePackage) origComponent_UpdatePackage(self, cmd);
}
static void (*origComponent_SetPkgLPTarget)(id, SEL) = NULL;
static void aliasComponent_SetPkgLPTarget(id self, SEL cmd) {
    if (shouldApplyFullCPUProtection()) return;
    if (origComponent_SetPkgLPTarget) origComponent_SetPkgLPTarget(self, cmd);
}
static BOOL (*origComponent_PowerSaveActive)(id, SEL) = NULL;
static BOOL aliasComponent_PowerSaveActive(id self, SEL cmd) {
    if (shouldApplyFullCPUProtection()) return NO;
    return origComponent_PowerSaveActive ? origComponent_PowerSaveActive(self, cmd) : NO;
}
static BOOL (*origComponent_SetSvcProp)(id, SEL, uintptr_t, id, uintptr_t, BOOL) = NULL;
static BOOL aliasComponent_SetSvcProp(id self, SEL cmd, uintptr_t service, id key, uintptr_t value, BOOL scale) {
    if (shouldApplyFullCPUProtection() && CTIsThermalServiceKey(key)) {
        CTD("[热写入] 丢弃 CC setServiceProperty %s (value=%p)", ((NSString *)key).UTF8String, (void *)value);
        return NO;
    }
    return origComponent_SetSvcProp ? origComponent_SetSvcProp(self, cmd, service, key, value, scale) : NO;
}
static void (*origNotification_Level)(id, SEL, int, BOOL) = NULL;
static void aliasNotification_Level(id self, SEL cmd, int level, BOOL force) {
    if (shouldApplyFullCPUProtection()) return;
    if (origNotification_Level) origNotification_Level(self, cmd, level, force);
}
static void (*origNotification_ThermalInt)(id, SEL, int) = NULL;
static void aliasNotification_ThermalInt(id self, SEL cmd, int notification) {
    if (shouldApplyFullCPUProtection() || thermalPopupBlockingEnabled()) {
        if (thermalPopupBlockingEnabled()) CTPopupLog(@"热通知（NM int）");
        return;
    }
    if (origNotification_ThermalInt) origNotification_ThermalInt(self, cmd, notification);
}
static void (*origNotification_ThermalQ)(id, SEL, unsigned long long) = NULL;
static void aliasNotification_ThermalQ(id self, SEL cmd, unsigned long long notification) {
    if (shouldApplyFullCPUProtection() || thermalPopupBlockingEnabled()) {
        if (thermalPopupBlockingEnabled()) CTPopupLog(@"热通知（NM Q）");
        return;
    }
    if (origNotification_ThermalQ) origNotification_ThermalQ(self, cmd, notification);
}

// —— 温度读数归一（CP=CommonProduct / TC=CTHermesThermalControl；按运行时真实签名安装）——
static float (*origCP_DieTempF)(id, SEL) = NULL;
static int (*origCP_DieTempI)(id, SEL) = NULL;
static float (*origCP_SkinTempF)(id, SEL) = NULL;
static int (*origCP_SkinTempI)(id, SEL) = NULL;
static float (*origTC_DieTempF)(id, SEL) = NULL;
static int (*origTC_DieTempI)(id, SEL) = NULL;
static float (*origTC_SkinTempF)(id, SEL) = NULL;
static int (*origTC_SkinTempI)(id, SEL) = NULL;
static float aliasCP_DieTempF(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0.0f; return origCP_DieTempF ? origCP_DieTempF(self, cmd) : 0.0f; }
static int   aliasCP_DieTempI(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 2600; return origCP_DieTempI ? origCP_DieTempI(self, cmd) : 0; }
static float aliasCP_SkinTempF(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0.0f; return origCP_SkinTempF ? origCP_SkinTempF(self, cmd) : 0.0f; }
static int   aliasCP_SkinTempI(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0; return origCP_SkinTempI ? origCP_SkinTempI(self, cmd) : 0; }
static float aliasTC_DieTempF(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0.0f; return origTC_DieTempF ? origTC_DieTempF(self, cmd) : 0.0f; }
static int   aliasTC_DieTempI(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 2600; return origTC_DieTempI ? origTC_DieTempI(self, cmd) : 0; }
static float aliasTC_SkinTempF(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0.0f; return origTC_SkinTempF ? origTC_SkinTempF(self, cmd) : 0.0f; }
static int   aliasTC_SkinTempI(id self, SEL cmd) { if (shouldApplyFullCPUProtection()) return 0; return origTC_SkinTempI ? origTC_SkinTempI(self, cmd) : 0; }

// ★ 2.0.38：安全"取方法"（不触发 +initialize）——class_getInstanceMethod 会强制初始化类，
//   在 powerd/tm 里会连锁加载 WebKit → 崩溃/白屏。改用 class_copyMethodList 沿父类链有界查找，找到即返回。
static Method CTHermesClsFindMethod(Class cls, SEL sel) {
    Class c = cls;
    for (int d = 0; c && d < 32; d++) {
        unsigned int n = 0;
        Method *ms = class_copyMethodList(c, &n);
        if (ms) {
            Method hit = NULL;
            for (unsigned int i = 0; i < n; i++) {
                if (method_getName(ms[i]) == sel) { hit = ms[i]; break; }
            }
            free(ms);
            if (hit) return hit;
        }
        c = class_getSuperclass(c);
    }
    return NULL;
}
static BOOL CTHermesClsHasSel(Class cls, SEL sel) {
    return CTHermesClsFindMethod(cls, sel) != NULL;
}

// iOS 15~17 热管理私有类存在命名差异；以下别名 Hook 按方法签名动态安装。
static void (*origTDT_Evaluate)(id, SEL) = NULL;
static void (*origTDT_Action)(id, SEL) = NULL;
static void (*origTDT_ReadRelease)(id, SEL) = NULL;
static float (*origTDT_GetRelease)(id, SEL, id) = NULL;
static void (*origComponent_CPMS)(id, SEL, int) = NULL;
static void (*origNotification_Thermal)(id, SEL, id) = NULL;

static void aliasTDT_Evaluate(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) { correctNominalStateIfNeeded(); return; }
if (origTDT_Evaluate) origTDT_Evaluate(self, cmd);
}
static void aliasTDT_Action(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) return;
if (origTDT_Action) origTDT_Action(self, cmd);
}
static void aliasTDT_ReadRelease(id self, SEL cmd) {
if (shouldApplyFullCPUProtection()) return;
if (origTDT_ReadRelease) origTDT_ReadRelease(self, cmd);
}
static float aliasTDT_GetRelease(id self, SEL cmd, id component) {
if (shouldApplyFullCPUProtection()) return 0.0f;
return origTDT_GetRelease ? origTDT_GetRelease(self, cmd, component) : 0.0f;
}
static void aliasComponent_CPMS(id self, SEL cmd, int state) {
if (shouldApplyFullCPUProtection()) { if (origComponent_CPMS) origComponent_CPMS(self, cmd, 0); return; }
if (origComponent_CPMS) origComponent_CPMS(self, cmd, state);
}
static void aliasNotification_Thermal(id self, SEL cmd, id notification) {
if (thermalPopupBlockingEnabled()) { CTPopupLog(@"热通知（NM id）"); return; }
if (origNotification_Thermal) origNotification_Thermal(self, cmd, notification);
}

static BOOL CTHermesMethodMatches(Class cls, SEL sel, unsigned int arguments, char returnType) {
Method method = class_getInstanceMethod(cls, sel);
if (!method || method_getNumberOfArguments(method) != arguments) return NO;
char type[16] = {0}; method_getReturnType(method, type, sizeof(type));
const char *cursor = type; while (*cursor && strchr("rnNoORV", *cursor)) cursor++;
return *cursor == returnType;
}

static BOOL CTHermesMethodArgumentMatches(Class cls, SEL sel, unsigned int index, const char *allowed) {
Method method = class_getInstanceMethod(cls, sel); if (!method || index >= method_getNumberOfArguments(method)) return NO;
char type[16]={0}; method_getArgumentType(method,index,type,sizeof(type)); const char *cursor=type;
while(*cursor&&strchr("rnNoORV",*cursor))cursor++; return *cursor && strchr(allowed,*cursor)!=NULL;
}

static void installCrossVersionThermalAliases(void) {
Class tree = CTObfCls("342fe62b79c61609c4706951bacf8103517f919f02bfe51f4cc2c5");
if (tree) {
SEL eval = CTObfSel("77f8f8138896a723a76c0151e8c2689bb6ff5915cf1d13c2");
SEL action = CTObfSel("542e45569036060cca360a519d007a193d033d077fec4db8db1b");
SEL read = CTObfSel("ae8e65fd898808bcd775eba958c39e34d4a0e8ac3aa6630362cfa6e26440deac8aae94");
SEL release = CTObfSel("42d88a15abe3ec012a11da2e8bf847259a8cd8c764ffb3fb583449643d8554");
if (!origTDT_Evaluate && CTHermesMethodMatches(tree, eval, 2, 'v')) MSHookMessageEx(tree, eval, (IMP)aliasTDT_Evaluate, (IMP *)&origTDT_Evaluate);
if (!origTDT_Action && CTHermesMethodMatches(tree, action, 2, 'v')) MSHookMessageEx(tree, action, (IMP)aliasTDT_Action, (IMP *)&origTDT_Action);
if (!origTDT_ReadRelease && CTHermesMethodMatches(tree, read, 2, 'v')) MSHookMessageEx(tree, read, (IMP)aliasTDT_ReadRelease, (IMP *)&origTDT_ReadRelease);
if (!origTDT_GetRelease && CTHermesMethodMatches(tree, release, 3, 'f') && CTArgMaybeGeneral(tree, release, 2)) MSHookMessageEx(tree, release, (IMP)aliasTDT_GetRelease, (IMP *)&origTDT_GetRelease);
if (!origTDT_GetReleaseD && CTHermesMethodMatches(tree, release, 3, 'd') && CTArgMaybeGeneral(tree, release, 2)) MSHookMessageEx(tree, release, (IMP)aliasTDT_GetReleaseD, (IMP *)&origTDT_GetReleaseD);
}
Class component = CTObfCls("c8b6b3a3cea90742c385f15165973412e10ad392");
SEL cpms = CTObfSel("2c1c28d0c02d200a5db8c381d59dd6170b6574223f6060d727115b");
if (component && !origComponent_CPMS && CTHermesMethodMatches(component, cpms, 3, 'v') && CTHermesMethodArgumentMatches(component, cpms, 2, "cCsSiIlLqQB")) MSHookMessageEx(component, cpms, (IMP)aliasComponent_CPMS, (IMP *)&origComponent_CPMS);
Class notification = CTObfCls("96b4d0edf06bae6cfaceccee4751f2f55e45ee766a1de6");
SEL update = CTObfSel("b57d7270d6c1f3678602bceb0e0adf529935ebab8643ce737e833ed68591");
if (notification && !origNotification_Thermal && CTHermesMethodMatches(notification, update, 3, 'v') && CTHermesMethodArgumentMatches(notification, update, 2, "@")) MSHookMessageEx(notification, update, (IMP)aliasNotification_Thermal, (IMP *)&origNotification_Thermal);
// —— ★ 2026-09-29 补全：iOS 16 真实类层（SupervisorControl / ApplePPM / ComponentControl / NotificationManager / CP·TC 温度）——
Class supervisor = CTObfCls("e303c71d29964c30761ec11218a4567b58ef614a03");
if (supervisor) {
SEL effort = CTObfSel("319190ebadb29ae28df24dc363eeb1f34d564d996b1c59a4493dd2cd1f139459807b74");
if (!origSupervisor_EffortD && CTHermesMethodMatches(supervisor, effort, 4, 'd') && CTArgMaybeGeneral(supervisor, effort, 2) && CTArgMaybeGeneral(supervisor, effort, 3)) { MSHookMessageEx(supervisor, effort, (IMP)aliasSupervisor_EffortD, (IMP *)&origSupervisor_EffortD); CTD("[热链] 已挂 SupervisorControl 控制力度(d)"); }
if (!origSupervisor_EffortF && CTHermesMethodMatches(supervisor, effort, 4, 'f') && CTArgMaybeGeneral(supervisor, effort, 2) && CTArgMaybeGeneral(supervisor, effort, 3)) { MSHookMessageEx(supervisor, effort, (IMP)aliasSupervisor_EffortF, (IMP *)&origSupervisor_EffortF); CTD("[热链] 已挂 SupervisorControl 控制力度(f)"); }
}
Class appleppm = CTObfCls("67f6e1295310985a15e0586b");
if (appleppm) {
SEL lvl = CTObfSel("add3ab13fbbc5b2f6f7a6e09978c03ac");
if (!origApplePPM_SetLevel && CTHermesMethodMatches(appleppm, lvl, 3, 'v') && CTHermesMethodArgumentMatches(appleppm, lvl, 2, "iIlLcCsSqQ")) { MSHookMessageEx(appleppm, lvl, (IMP)aliasApplePPM_SetLevel, (IMP *)&origApplePPM_SetLevel); CTD("[热链] 已挂 ApplePPM.setCPULevel"); }
}
if (component) {
SEL cUp = CTObfSel("3e7d4fdfc92939772ecd26d6d0aba411ce87dfcedce1b6ab2946");
if (!origComponent_UpdateParams && CTHermesMethodMatches(component, cUp, 3, 'v') && CTArgMaybeGeneral(component, cUp, 2)) { MSHookMessageEx(component, cUp, (IMP)aliasComponent_UpdateParams, (IMP *)&origComponent_UpdateParams); CTD("[热链] 已挂 ComponentControl 参数更新"); }
SEL cPkg = CTObfSel("cae9fca96d315843ee8c9ef0e7b8c0d356");
if (!origComponent_UpdatePackage && CTHermesMethodMatches(component, cPkg, 2, 'v')) { MSHookMessageEx(component, cPkg, (IMP)aliasComponent_UpdatePackage, (IMP *)&origComponent_UpdatePackage); CTD("[热链] 已挂 ComponentControl 包更新"); }
SEL cLp = CTObfSel("31a02ff8a2d9506308e95d8cb28226955d025b3af74194ba928ad08b");
if (!origComponent_SetPkgLPTarget && CTHermesMethodMatches(component, cLp, 2, 'v')) { MSHookMessageEx(component, cLp, (IMP)aliasComponent_SetPkgLPTarget, (IMP *)&origComponent_SetPkgLPTarget); CTD("[热链] 已挂 ComponentControl 低功耗目标"); }
SEL cPs = CTObfSel("3179e9fa8557a46c84c6efba6ad84746c44231");
if (!origComponent_PowerSaveActive && (CTHermesMethodMatches(component, cPs, 2, 'c') || CTHermesMethodMatches(component, cPs, 2, 'B'))) { MSHookMessageEx(component, cPs, (IMP)aliasComponent_PowerSaveActive, (IMP *)&origComponent_PowerSaveActive); CTD("[热链] 已挂 ComponentControl 省电状态"); }
SEL cSp = CTObfSel("c1e485686cd38175835ff844df2ee04edeb7ab8f5109219ec1eab7bd153ed3dcb939f3e6205d34dd4476bb850b9bbfb037f5d2");
if (!origComponent_SetSvcProp && (CTHermesMethodMatches(component, cSp, 6, 'c') || CTHermesMethodMatches(component, cSp, 6, 'B')) && CTHermesMethodArgumentMatches(component, cSp, 3, "@")) { MSHookMessageEx(component, cSp, (IMP)aliasComponent_SetSvcProp, (IMP *)&origComponent_SetSvcProp); CTD("[热链] 已挂 ComponentControl 服务写入丢弃"); }
}
if (notification) {
SEL nLv = CTObfSel("5aadc73cfe3b57f2566d602f8cc622f531c31bf5d4ce85c614515734fe2d11bb2d05bbf57c5aa7cc64861e729487f5131c0dc446f4dacfbcd8a6b72726ac6cf6f02d4342f240");
if (!origNotification_Level && CTHermesMethodMatches(notification, nLv, 4, 'v') && CTHermesMethodArgumentMatches(notification, nLv, 2, "iIlLcCsS") && CTHermesMethodArgumentMatches(notification, nLv, 3, "cCsSB")) { MSHookMessageEx(notification, nLv, (IMP)aliasNotification_Level, (IMP *)&origNotification_Level); CTD("[热链] 已挂 NotificationManager 压力通知"); }
if (!origNotification_ThermalInt && !origNotification_ThermalQ && CTHermesMethodMatches(notification, update, 3, 'v') && CTHermesMethodArgumentMatches(notification, update, 2, "iIlLcCsS")) { MSHookMessageEx(notification, update, (IMP)aliasNotification_ThermalInt, (IMP *)&origNotification_ThermalInt); CTD("[热链] 已挂 NotificationManager 热通知(int)"); }
if (!origNotification_ThermalQ && CTHermesMethodMatches(notification, update, 3, 'v') && CTHermesMethodArgumentMatches(notification, update, 2, "qQ")) { MSHookMessageEx(notification, update, (IMP)aliasNotification_ThermalQ, (IMP *)&origNotification_ThermalQ); CTD("[热链] 已挂 NotificationManager 热通知(Q)"); }
}
Class cpCls = CTObfCls("b381f61c9419e0d0730ebdd7f40c10354e");
if (cpCls) {
SEL cDie = CTObfSel("54597cc2a7e4f37865c1dc6044c4c7f7428d4bcf63ef86eee6645b915d");
SEL cSkin = CTObfSel("1a78a427a7a9e95899cf2165a31205ab9119fc2df9c5");
if (!origCP_DieTempF && CTHermesMethodMatches(cpCls, cDie, 2, 'f')) { MSHookMessageEx(cpCls, cDie, (IMP)aliasCP_DieTempF, (IMP *)&origCP_DieTempF); CTD("[热链] 已挂 CommonProduct die 温度(f)"); }
if (!origCP_DieTempI && CTHermesMethodMatches(cpCls, cDie, 2, 'i')) { MSHookMessageEx(cpCls, cDie, (IMP)aliasCP_DieTempI, (IMP *)&origCP_DieTempI); CTD("[热链] 已挂 CommonProduct die 温度(i)"); }
if (!origCP_SkinTempF && CTHermesMethodMatches(cpCls, cSkin, 2, 'f')) { MSHookMessageEx(cpCls, cSkin, (IMP)aliasCP_SkinTempF, (IMP *)&origCP_SkinTempF); CTD("[热链] 已挂 CommonProduct 表皮温度(f)"); }
if (!origCP_SkinTempI && CTHermesMethodMatches(cpCls, cSkin, 2, 'i')) { MSHookMessageEx(cpCls, cSkin, (IMP)aliasCP_SkinTempI, (IMP *)&origCP_SkinTempI); CTD("[热链] 已挂 CommonProduct 表皮温度(i)"); }
}
Class tcCls = CTObfCls("8cf3034c3be94d93f352c277d660971b8412");
if (tcCls) {
SEL cDie2 = CTObfSel("78b27ba95e8d873ebe7c6b5f89fec5da2c17eb86069a2c3fe8ead32b76");
SEL cSkin2 = CTObfSel("bbd9769699e74cb7fecf067b5c3cd4ccc1665000f11c");
if (!origTC_DieTempF && CTHermesMethodMatches(tcCls, cDie2, 2, 'f')) { MSHookMessageEx(tcCls, cDie2, (IMP)aliasTC_DieTempF, (IMP *)&origTC_DieTempF); CTD("[热链] 已挂 CTHermesThermalControl die 温度(f)"); }
if (!origTC_DieTempI && CTHermesMethodMatches(tcCls, cDie2, 2, 'i')) { MSHookMessageEx(tcCls, cDie2, (IMP)aliasTC_DieTempI, (IMP *)&origTC_DieTempI); CTD("[热链] 已挂 CTHermesThermalControl die 温度(i)"); }
if (!origTC_SkinTempF && CTHermesMethodMatches(tcCls, cSkin2, 2, 'f')) { MSHookMessageEx(tcCls, cSkin2, (IMP)aliasTC_SkinTempF, (IMP *)&origTC_SkinTempF); CTD("[热链] 已挂 CTHermesThermalControl 表皮温度(f)"); }
if (!origTC_SkinTempI && CTHermesMethodMatches(tcCls, cSkin2, 2, 'i')) { MSHookMessageEx(tcCls, cSkin2, (IMP)aliasTC_SkinTempI, (IMP *)&origTC_SkinTempI); CTD("[热链] 已挂 CTHermesThermalControl 表皮温度(i)"); }
}
// ★ 2.0.38（热修）：配置层"自寻挂载"恢复启用——扫描已全面安全化（零 class_getInstanceMethod、有界查找）；
//   挂载/类数/到达全部进心跳状态位（tm 写不了日志也能被读到）
installConfigLayerHook();
}

// ★ 2.0.38：配置层"按签名自寻挂载" —— 旧挂点在"名字层"假名类上（CTHermesThermalManager，全包无任何注册 → 从未真正接管）；
//   现在改为：运行时按"方法签名"扫描实现 getConfigurationFor: 的类并挂载背光热限制补丁（挂上谁/挂几个，全部出声）。
static id (*g_ctCfgOrigImp[8])(id, SEL, id) = {NULL};
static id (*g_ctCfgOrigImp4[8])(id, SEL, id, id) = {NULL};   // ★ 2.0.38：4 参形态的原始实现
static void *(*g_ctCfgOrigImpTM[8])(id, SEL, uintptr_t) = {NULL};   // ★ 2.0.38：TM 形态（^指针返回 + 基础类型参数）原始实现
static Class  g_ctCfgClsList[8] = {NULL};
static int    g_ctCfgHookedN = 0;
static id ctConfigLayerAlias(id self, SEL cmd, id key) {
    id cfg = nil;
    @try {
        Class c = object_getClass(self);
        BOOL found = NO;
        for (int i = 0; i < g_ctCfgHookedN; i++) {
            if (g_ctCfgClsList[i] && (c == g_ctCfgClsList[i] || [c isSubclassOfClass:g_ctCfgClsList[i]])) {
                found = YES;
                if (g_ctCfgOrigImp[i]) cfg = g_ctCfgOrigImp[i](self, cmd, key);
                break;
            }
        }
        if (!found && g_ctCfgHookedN > 0 && g_ctCfgOrigImp[0]) cfg = g_ctCfgOrigImp[0](self, cmd, key);   // 兜底：防漏匹配时误返回空
        static BOOL sCfgFired = NO;
        if (!sCfgFired) {
            sCfgFired = YES;
            CTD("[防暗屏] getConfigurationFor 已到达（自寻挂钩 %s，开关=%d）", c ? class_getName(c) : "?", thermalDimmingPreventionEnabled() ? 1 : 0);
            g_ctAliveFlags |= (1ULL << 8); CTHostAlivePost();   // 自测增强
        }
    } @catch (__unused NSException *e) {}
    if (!thermalDimmingPreventionEnabled()) return cfg;
    @try { return patchThermalPlist(cfg); } @catch (__unused NSException *e) { return cfg; }
}
// ★ 2.0.38：4 参形态别名（自适应——实测签名是 4 参时用它挂）
static id ctConfigLayerAlias4(id self, SEL cmd, id k1, id k2) {
    id cfg = nil;
    @try {
        Class c = object_getClass(self);
        BOOL found = NO;
        for (int i = 0; i < g_ctCfgHookedN; i++) {
            if (g_ctCfgClsList[i] && (c == g_ctCfgClsList[i] || [c isSubclassOfClass:g_ctCfgClsList[i]])) {
                found = YES;
                if (g_ctCfgOrigImp4[i]) cfg = g_ctCfgOrigImp4[i](self, cmd, k1, k2);
                break;
            }
        }
        if (!found && g_ctCfgHookedN > 0 && g_ctCfgOrigImp4[0]) cfg = g_ctCfgOrigImp4[0](self, cmd, k1, k2);
        static BOOL sCfgFired4 = NO;
        if (!sCfgFired4) {
            sCfgFired4 = YES;
            CTD("[防暗屏] getConfigurationFor(4参) 已到达（自寻挂钩 %s，开关=%d）", c ? class_getName(c) : "?", thermalDimmingPreventionEnabled() ? 1 : 0);
            g_ctAliveFlags |= (1ULL << 8); CTHostAlivePost();   // 自测增强
        }
    } @catch (__unused NSException *e) {}
    if (!thermalDimmingPreventionEnabled()) return cfg;
    @try { return patchThermalPlist(cfg); } @catch (__unused NSException *e) { return cfg; }
}
// ★ 2.0.38：TM 形态别名——真身 ThermalManager：`^{__CFDictionary} getConfigurationFor:(基础类型)`
static void *ctConfigLayerAliasTM(id self, SEL cmd, uintptr_t arg) {
    void *r = NULL;
    @try {
        Class c = object_getClass(self);
        BOOL found = NO;
        for (int i = 0; i < g_ctCfgHookedN; i++) {
            if (g_ctCfgClsList[i] && (c == g_ctCfgClsList[i] || [c isSubclassOfClass:g_ctCfgClsList[i]])) {
                found = YES;
                if (g_ctCfgOrigImpTM[i]) r = g_ctCfgOrigImpTM[i](self, cmd, arg);
                break;
            }
        }
        if (!found) { for (int i = 0; i < g_ctCfgHookedN; i++) if (g_ctCfgOrigImpTM[i]) { r = g_ctCfgOrigImpTM[i](self, cmd, arg); break; } }
        static BOOL sTMFired = NO;
        if (!sTMFired) {
            sTMFired = YES;
            CTD("[防暗屏] getConfigurationFor(TM形态) 已到达（%s，开关=%d）", c ? class_getName(c) : "?", thermalDimmingPreventionEnabled() ? 1 : 0);
            g_ctAliveFlags |= (1ULL << 8); CTHostAlivePost();   // 自测增强
        }
        if (r && thermalDimmingPreventionEnabled()) {
            uintptr_t ctFirst = 0;   // ★ 2.0.38：对象安全探针——先验证首字像正经对象指针，才敢走对象判断
            __builtin_memcpy(&ctFirst, r, sizeof(ctFirst));
            if (ctFirst > 0x100000000ULL && ctFirst < 0x800000000000ULL && (ctFirst & 7) == 0) {
                id d = (__bridge id)r;
                if ([d isKindOfClass:[NSDictionary class]]) {
                    id p = patchThermalPlist(d);
                    if (p && p != d) return (__bridge_retained void *)p;
                }
            }
        }
    } @catch (__unused NSException *e) {}
    return r;
}
static void installConfigLayerHook(void) {
    @try {
        int total = objc_getClassList(NULL, 0);
        if (total <= 0) return;
        Class *all = (Class *)malloc(sizeof(Class) * (size_t)total);
        if (!all) return;
        total = objc_getClassList(all, total);
        SEL cfgs = @selector(getConfigurationFor:);
        for (int i = 0; i < total && g_ctCfgHookedN < 8; i++) {
            Class c = all[i];
            if (!c) continue;
            Method m = CTHermesClsFindMethod(c, cfgs);   // ★ 2.0.38：安全取值（全程零触发类初始化）
            if (!m) continue;
            unsigned int na = method_getNumberOfArguments(m);
            char rt2[32] = {0}; method_getReturnType(m, rt2, sizeof(rt2));   // ★ 2.0.38：修截断（^{__CFDictionary=} 需要 ≥17 字节）
            const char *rc2 = rt2; while (*rc2 && strchr("rnNoORV", *rc2)) rc2++;
            char a2[8] = {0}; if (na >= 3) method_getArgumentType(m, 2, a2, sizeof(a2));
            char a3[8] = {0}; if (na >= 4) method_getArgumentType(m, 3, a3, sizeof(a3));
            // ★ 2.0.38：按实测签名"自适应"选挂载形态；不匹配的只留证（细节通道），不硬挂
            BOOL shapeA = (na == 3 && a2[0] == '@' && rc2 && *rc2 == '@');
            BOOL shapeC = (na == 4 && a2[0] == '@' && a3[0] == '@' && rc2 && *rc2 == '@');
            // ★ 2.0.38：TM 形态放宽 = 指针返回 + 指针参数 + 3 参（实测两处都是 '^'；精确名字走 diag5 留证）
            BOOL shapeTM = (na == 3 && rc2 && rc2[0] == '^' && a2[0] == '^');
            if (!shapeA && !shapeC && !shapeTM) continue;
            BOOL already = NO;
            for (int k = 0; k < g_ctCfgHookedN; k++) if (g_ctCfgClsList[k] == c) { already = YES; break; }
            if (already) continue;
            IMP orig = NULL;
            if (shapeA)       MSHookMessageEx(c, cfgs, (IMP)ctConfigLayerAlias, &orig);
            else if (shapeC)  MSHookMessageEx(c, cfgs, (IMP)ctConfigLayerAlias4, &orig);
            else              MSHookMessageEx(c, cfgs, (IMP)ctConfigLayerAliasTM, &orig);
            g_ctCfgClsList[g_ctCfgHookedN] = c;
            g_ctCfgOrigImp[g_ctCfgHookedN]  = shapeA ? (id (*)(id, SEL, id))orig : NULL;
            g_ctCfgOrigImp4[g_ctCfgHookedN] = shapeC ? (id (*)(id, SEL, id, id))orig : NULL;
            g_ctCfgOrigImpTM[g_ctCfgHookedN] = shapeTM ? (void *(*)(id, SEL, uintptr_t))orig : NULL;
            g_ctCfgHookedN++;
            CTD("[防暗屏] 配置层已挂 %s（自寻·%s）", class_getName(c), shapeA ? "3参" : (shapeC ? "4参" : "TM"));
        }
        g_ctAliveFlags |= 2ULL;
        g_ctAliveFlags = (g_ctAliveFlags & ~(0xFULL << 2)) | ((uint64_t)(g_ctCfgHookedN & 0xF) << 2);
        CTHostAlivePost();   // 自测增强：挂载进度
        free(all);
    } @catch (__unused NSException *e) {}
}

static NSDictionary *readPrefsDictionary(void) {
return CTHermesReadPrefs();
}

static BOOL foregroundAppShouldUseLowPower(NSDictionary *prefs) {
if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
if (CTHermesTierSystemActive(prefs)) return NO;   // ★ T7x：旧名单退役（档位"低频率"由 resolve 的档位优先处理）
uint64_t foregroundHash = CTHermesReadForegroundBundleHash();
NSArray *selected = [prefs[S("lowPowerApps")] isKindOfClass:[NSArray class]] ? prefs[S("lowPowerApps")] : nil;
if (foregroundHash == 0 || selected.count == 0) return NO;
if (foregroundHash == CTHermesBundleIDHash(S("com.apple.springboard"))) return NO;   // ★ 桌面进程永不匹配名单
for (id rawBundleID in selected) {
if ([rawBundleID isKindOfClass:[NSString class]] && CTHermesBundleIDHash(rawBundleID) == foregroundHash) return YES;
}
return NO;
}

// 例外名单（面板上的「指定应用低功耗」）：跟着常驻模式反着走 ——
//   常驻「低功耗」   → 名单内应用改为高性能运行（不卡；微信/相机/扫码这类）
//   常驻「性能模式」 → 名单内应用照旧执行低功耗（省电；抖音这类耗电大户）
// 熄屏低功耗与高温自动低功耗不受名单影响（安全优先）。
// 两份独立名单，各归各的模式：
//   常驻「低功耗」  + 高性能名单命中   → 高性能运行（不卡；微信/相机/扫码放这份名单）
//   常驻「性能模式」+ 低功耗名单命中 → 执行低功耗（省电；抖音这类放这份名单）
// ★★★ 智能模式（T7h）：应用分类 —— 靠 App Store 元数据认"游戏"
// 返回：2 = 游戏；1 = 可识别的普通应用；0 = 识别不到（无分类信息，如自签）→ 走"原生"
static NSInteger CTSmartAppClassAtPath(NSString *bundlePath) {
    if (![bundlePath isKindOfClass:[NSString class]] || bundlePath.length == 0) return 0;
    NSInteger cls = 0;
    @try {
        NSDictionary *meta = [NSDictionary dictionaryWithContentsOfFile:
            [bundlePath stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
        if (![meta isKindOfClass:[NSDictionary class]]) {
            // ★ T7l：有些环境元数据放在包"旁边"（同一父目录）而不是包内
            NSString *ctParentDir = [bundlePath stringByDeletingLastPathComponent];
            meta = [NSDictionary dictionaryWithContentsOfFile:
                [ctParentDir stringByAppendingPathComponent:S("iTunesMetadata.plist")]];
        }
        if ([meta isKindOfClass:[NSDictionary class]]) {
            cls = 1;                                                        // 有 App Store 元数据 = 可识别
            id gid = meta[S("genreId")];
            NSInteger g = [gid respondsToSelector:@selector(integerValue)] ? [gid integerValue] : -1;
            if (g == 6014 || (g >= 7001 && g <= 7019)) cls = 2;             // 「游戏」主类 / 子类
            id genre = meta[S("genre")];
            if ([genre isKindOfClass:[NSString class]] &&
                ([genre containsString:S("游戏")] || [genre caseInsensitiveCompare:S("Games")] == NSOrderedSame)) cls = 2;
        }
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:
            [bundlePath stringByAppendingPathComponent:S("Info.plist")]];
        id cat = [info isKindOfClass:[NSDictionary class]] ? info[S("LSApplicationCategoryType")] : nil;
        if ([cat isKindOfClass:[NSString class]] && [cat length] > 0) {
            if (cls == 0) cls = 1;                                          // 有分类字段 = 可识别
            if ([cat rangeOfString:S("games")].location != NSNotFound) cls = 2;
        }
    } @catch (__unused NSException *e) { }
    return cls;
}

// ★ T7x：档位体系是否已接管（有档位表 appTiers 或已迁移标记）——
//   接管后旧"两份名单"（fullPowerApps / lowPowerApps）正式退役，钉档一律走「App 档位」。
static BOOL CTHermesTierSystemActive(NSDictionary *prefs) {
    if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
    if ([prefs[S("appTiers")] isKindOfClass:[NSDictionary class]]) return YES;
    return prefs[S("appTiersMigrated")] != nil;
}

static void CTHermesRebuildSmartAppClasses(NSDictionary *prefs) {
    NSMutableSet *games = [NSMutableSet set];
    NSMutableSet *knownApps = [NSMutableSet set];
    NSMutableSet *pinned = [NSMutableSet set];
    NSMutableSet *seenBundles = [NSMutableSet set];
    __block int metaInside = 0, metaBeside = 0;
    NSFileManager *ctFMProbe = [NSFileManager defaultManager];
    __block NSString *ctFirstAppPath = nil;
    __block NSString *ctLolmAppPath = nil;
    // ★ T7o：先读“跨进程扫描”产出的分类缓存（thermalmonitord 沙箱看不到应用目录 —— T7n 诊断：扫描根全 0）
    @try {
        NSDictionary *ctCache = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("smartClasses")] isKindOfClass:[NSDictionary class]])
            ? prefs[S("smartClasses")] : nil;
        if (ctCache) {
            NSInteger ctCG = 0, ctCK = 0;
            for (id ctV in ctCache[S("games")]) if ([ctV isKindOfClass:[NSNumber class]]) { [games addObject:ctV]; [knownApps addObject:ctV]; ctCG++; }
            for (id ctV in ctCache[S("known")]) if ([ctV isKindOfClass:[NSNumber class]]) { [knownApps addObject:ctV]; ctCK++; }
            NSString *ctCacheTsStr = [ctCache[S("ts")] description] ?: @"?";
            CTD("[智能] 缓存载入：游戏 %ld / 可识别 %ld（写入时间 %s）", (long)ctCG, (long)ctCK, ctCacheTsStr.UTF8String);
        } else {
            CTD("[智能] 缓存：无（等挂载工具/前台插件产出）");
        }
    } @catch (__unused NSException *e) { }
    void (^ctHandleApp)(NSString *, NSString *) = ^(NSString *bid, NSString *path) {
        if (![bid isKindOfClass:[NSString class]] || bid.length == 0) return;
        if ([seenBundles containsObject:bid]) return;
        [seenBundles addObject:bid];
        if ([path isKindOfClass:[NSString class]] && path.length > 0) {
            if (!ctFirstAppPath) ctFirstAppPath = path;
            if (!ctLolmAppPath && [[path lowercaseString] rangeOfString:S("lolm")].location != NSNotFound) ctLolmAppPath = path;
            NSString *metaIn = [path stringByAppendingPathComponent:S("iTunesMetadata.plist")];
            NSString *metaP  = [[path stringByDeletingLastPathComponent] stringByAppendingPathComponent:S("iTunesMetadata.plist")];
            if ([ctFMProbe fileExistsAtPath:metaIn]) metaInside++;
            else if ([ctFMProbe fileExistsAtPath:metaP]) metaBeside++;
        }
        NSInteger cls = CTSmartAppClassAtPath(path);
        if (cls == 2) { [games addObject:@(CTHermesBundleIDHash(bid))]; [knownApps addObject:@(CTHermesBundleIDHash(bid))]; }
        else if (cls == 1) { [knownApps addObject:@(CTHermesBundleIDHash(bid))]; }
    };
    @try {
        // ★ T7k：文件系统扫描（兜底 —— thermalmonitord 沙箱常挡住这里；主路径＝上面的缓存）
        NSFileManager *ctFM = [NSFileManager defaultManager];
        for (NSString *root in @[S("/var/containers/Bundle/Application"), S("/var/mobile/Containers/Bundle/Application"), S("/private/var/containers/Bundle/Application")]) {
            NSError *ctRootErr = nil;
            NSArray *children = [ctFM contentsOfDirectoryAtPath:root error:&ctRootErr];
            CTD("[智能] 扫描根 %s：%lu 项 (err=%ld)", root.UTF8String, (unsigned long)children.count, (long)ctRootErr.code);
            for (NSString *child in children) {
                NSString *full = [root stringByAppendingPathComponent:child];
                if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) {
                    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[full stringByAppendingPathComponent:S("Info.plist")]];
                    ctHandleApp([info isKindOfClass:[NSDictionary class]] ? info[S("CFBundleIdentifier")] : nil, full);
                    continue;
                }
                NSArray *inner = [ctFM contentsOfDirectoryAtPath:full error:nil];
                for (NSString *entry in inner) {
                    if ([[entry pathExtension] caseInsensitiveCompare:S("app")] != NSOrderedSame) continue;
                    NSString *appPath = [full stringByAppendingPathComponent:entry];
                    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:S("Info.plist")]];
                    ctHandleApp([info isKindOfClass:[NSDictionary class]] ? info[S("CFBundleIdentifier")] : nil, appPath);
                }
            }
        }
    } @catch (__unused NSException *e) { }
    if (ctFirstAppPath.length) {
        NSString *ctSib1 = [ctFirstAppPath stringByDeletingLastPathComponent];
        NSArray *ctSibL = [ctFMProbe contentsOfDirectoryAtPath:ctSib1 error:nil];
        NSString *ctSibS = ctSibL ? [ctSibL componentsJoinedByString:S(" | ")] : S("(读不到)");
        CTD("[智能] 目录样例：%s → %s", ctSib1.UTF8String, ctSibS.UTF8String);
    }
    if (ctLolmAppPath.length) {
        NSString *ctSib2 = [ctLolmAppPath stringByDeletingLastPathComponent];
        NSArray *ctSibL2 = [ctFMProbe contentsOfDirectoryAtPath:ctSib2 error:nil];
        NSString *ctSibS2 = ctSibL2 ? [ctSibL2 componentsJoinedByString:S(" | ")] : S("(读不到)");
        CTD("[智能] lolm 目录样例：%s → %s", ctSib2.UTF8String, ctSibS2.UTF8String);
    }
    @try {
        // LSApplicationWorkspace 补充扫描（能拿到什么算什么）
        Class wsClass = CTObfCls("218e654d623e5665231a9d4efbe75b561942af3b1f83a93579c3");
        id ws = (wsClass && [wsClass respondsToSelector:CTObfSel("e3e28f70a93656807adcf86e15ecd9fb8fb64f22")])
            ? ((id (*)(id, SEL))objc_msgSend)(wsClass, CTObfSel("543c6b9d65e2d6ba443b94f9ff60316f75974844")) : nil;
        NSArray *apps = (ws && [ws respondsToSelector:CTObfSel("0032022b425f26a70a30d5d25813e774ac1eaa")])
            ? ((id (*)(id, SEL))objc_msgSend)(ws, CTObfSel("5e2b907e37a6f6e8e2d57c6cb31ab7218587a0")) : nil;
        if ([apps isKindOfClass:[NSArray class]]) {
            for (id proxy in apps) {
                NSString *bid = nil;
                for (NSString *selName in @[S("applicationIdentifier"), S("bundleIdentifier")]) {
                    SEL s = NSSelectorFromString(selName);
                    if (![proxy respondsToSelector:s]) continue;
                    id v = ((id (*)(id, SEL))objc_msgSend)(proxy, s);
                    if ([v isKindOfClass:[NSString class]] && [v length] > 0) { bid = v; break; }
                }
                if (bid.length == 0) continue;
                NSString *path = nil;
                SEL urlSel = CTObfSel("182cbc33d5b6e03d5f482d4511");
                if ([proxy respondsToSelector:urlSel]) {
                    id url = ((id (*)(id, SEL))objc_msgSend)(proxy, urlSel);
                    if ([url isKindOfClass:[NSURL class]]) path = ((NSURL *)url).path;
                }
                ctHandleApp(bid, path);
            }
        }
    } @catch (__unused NSException *e) { }
    // ★ T7x：档位体系接管后，旧"两份名单"退役——不再作为隐形钉档（钉档走「App 档位」的档位优先）。
    //   未接管（老设备首次升级、还没开过档位页）时仍读旧名单，保证不丢用户设置（打开档位页会自动迁移）。
    NSMutableSet *lowPinned = [NSMutableSet set];
    if (!CTHermesTierSystemActive(prefs)) {
        NSArray *fullList = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("fullPowerApps")] isKindOfClass:[NSArray class]])
            ? prefs[S("fullPowerApps")] : nil;
        for (id raw in fullList) if ([raw isKindOfClass:[NSString class]]) [pinned addObject:@(CTHermesBundleIDHash(raw))];
        NSArray *lowList = ([prefs isKindOfClass:[NSDictionary class]] && [prefs[S("lowPowerApps")] isKindOfClass:[NSArray class]])
            ? prefs[S("lowPowerApps")] : nil;
        for (id raw in lowList) if ([raw isKindOfClass:[NSString class]]) [lowPinned addObject:@(CTHermesBundleIDHash(raw))];
    }
    g_smartGameHashes = [games copy];
    g_smartKnownAppHashes = [knownApps copy];
    g_smartFullListHashes = [pinned copy];
    g_smartLowListHashes = [lowPinned copy];
    g_smartScanDone = YES;
    CTD("[智能] 分类扫描：bundle %lu 个 / iTunesMetadata 包内 %d + 包旁 %d / 游戏 %lu / 可识别 %lu / 高性能名单 %lu / 低频名单 %lu", (unsigned long)seenBundles.count, metaInside, metaBeside, (unsigned long)games.count, (unsigned long)knownApps.count, (unsigned long)pinned.count, (unsigned long)lowPinned.count);
}

static CTHermesPowerMode CTHermesSmartResolveTarget(BOOL blanked) {
    if (blanked) return CTHermesPowerModeLow;                                     // 熄屏：一律低功耗（照旧）
    uint64_t fg = CTHermesReadForegroundBundleHash();
    // ★ T7u：系统组件误报 → 保持上次结果（不参与判定）
    if (fg == CTHermesBundleIDHash(S("com.apple.chrono.WidgetRenderer-Default"))) {
        return g_smartLastTarget;
    }
    uint64_t sb = CTHermesBundleIDHash(S("com.apple.springboard"));
    if (fg == 0) { g_smartLastTarget = CTHermesPowerModeNative; return CTHermesPowerModeNative; }   // 识别不到：一律原生（不干预）
    if (fg == sb) { g_smartLastTarget = CTHermesPowerModeNative; return CTHermesPowerModeNative; }      // 桌面 / 系统界面：原生
    if (g_smartFullListHashes && [g_smartFullListHashes containsObject:@(fg)]) { g_smartLastTarget = CTHermesPowerModeFull; return CTHermesPowerModeFull; } // 手动：高性能名单 → 高性能
    if (g_smartLowListHashes && [g_smartLowListHashes containsObject:@(fg)]) { g_smartLastTarget = CTHermesPowerModeLow; return CTHermesPowerModeLow; }    // 手动：低频率名单 → 低频率
    if (g_smartGameHashes && [g_smartGameHashes containsObject:@(fg)]) { g_smartLastTarget = CTHermesPowerModeFull; return CTHermesPowerModeFull; }   // 自动：游戏 → 高性能
    if (g_smartKnownAppHashes && [g_smartKnownAppHashes containsObject:@(fg)]) { g_smartLastTarget = CTHermesPowerModeLow; return CTHermesPowerModeLow; }   // 自动：可识别普通应用 → 低频率
    // ★ T7o：认不出且不是桌面 → 请求重扫分类缓存（每个 App 一次；≥20 秒间隔）
    {
        static uint64_t sCtScanAsked[96];
        static int sCtScanAskedN = 0;
        static CFAbsoluteTime sCtScanAskT = 0;
        BOOL ctAsked = NO;
        for (int ctQi = 0; ctQi < sCtScanAskedN; ctQi++) if (sCtScanAsked[ctQi] == fg) { ctAsked = YES; break; }
        CFAbsoluteTime ctNowQ = CFAbsoluteTimeGetCurrent();
        if (!ctAsked && (ctNowQ - sCtScanAskT) > 20.0) {
            sCtScanAskT = ctNowQ;
            if (sCtScanAskedN < 96) sCtScanAsked[sCtScanAskedN++] = fg;
            notify_post("com.qq391160.cpucore/scanRequest");
            CTD("[智能] 未识别应用（hash=%llu）→ 请求重扫分类缓存", (unsigned long long)fg);
        }
    }
    g_smartLastTarget = CTHermesPowerModeNative;
    return CTHermesPowerModeNative;                                               // 识别不到（无分类信息，如自签）：原生（可手动加两个名单）
}
// ★ T7w：App 档位查询（1=高性能 2=低频率 3=原生 0=无/自动）
static int CTHermesTierForHash(uint64_t ctHv) {
    if (!ctHv) return 0;
    if (g_tierFullHashes && [g_tierFullHashes containsObject:@(ctHv)]) return 1;
    if (g_tierLowHashes && [g_tierLowHashes containsObject:@(ctHv)]) return 2;
    if (g_tierNativeHashes && [g_tierNativeHashes containsObject:@(ctHv)]) return 3;
    return 0;
}
static CTHermesPowerMode CTHermesResolveTargetModeRaw(CTHermesPowerMode selected, BOOL blanked, BOOL appLowPower) {
    if (!blanked) {
        // ★ T7x5/T7z5："读数抖动吸收"——前台读数会瞬时空一下（切 App / 进多任务瞬间尤甚，
        //   日志实锤最长 ~5 秒）。T7z5 升级：轨迹由每秒心跳持续保鲜（CTBlipTrackForeground），
        //   吸收窗口 2→5 秒；5 秒内的读空一律沿用"上一个真实 App"继续判定，不再误判成
        //   "回桌面"而交还系统。（代价：真回桌面切原生最多晚 ~5 秒）
        uint64_t ctT7Fg = CTHermesReadForegroundBundleHash();
        if (ctT7Fg != 0 && ctT7Fg != CTHermesBundleIDHash(S("com.apple.springboard"))) {
            g_ctBlipHash = ctT7Fg;
            g_ctBlipAt = CFAbsoluteTimeGetCurrent();
        }
        if (ctT7Fg == 0) {
            if (g_ctBlipHash != 0 && (CFAbsoluteTimeGetCurrent() - g_ctBlipAt) < 5.0) {
                ctT7Fg = g_ctBlipHash;   // 抖动/间隙：按"上一个真实 App"继续判定（走下面的档位/智能逻辑）
            } else {
                // 桌面（无应用）——低功耗模式：桌面也压（开关打开则交还系统=原生）；智能 / 性能模式仍交还系统
                if (!g_smartEnabled && selected == CTHermesPowerModeLow && !g_lowPowerDesktopNative) return CTHermesPowerModeLow;
                return CTHermesPowerModeNative;
            }
        }
        // ★ T7w：每 App 档位优先（三种模式通用）
        int ctTier = CTHermesTierForHash(ctT7Fg);
        if (ctTier == 1) return CTHermesPowerModeFull;
        if (ctTier == 2) return CTHermesPowerModeLow;
        if (ctTier == 3) return CTHermesPowerModeNative;
        // ★ T7z26：游戏强制高性能——识别为"游戏"的 App 一律按高性能执行（无视常驻模式；仅档位可覆盖）
        if (g_gameForceFull && g_smartGameHashes && [g_smartGameHashes containsObject:@(ctT7Fg)]) {
            return CTHermesPowerModeFull;
        }
    }
    if (g_smartEnabled) return CTHermesSmartResolveTarget(blanked);
    if (blanked) return CTHermesPowerModeLow;
    if (appLowPower) return (selected == CTHermesPowerModeLow) ? CTHermesPowerModeFull : CTHermesPowerModeLow;
    return selected;
}
static CTHermesPowerMode CTHermesResolveTargetMode(CTHermesPowerMode selected, BOOL blanked, BOOL appLowPower) {
    // ★ 269：滑动放行改为"静默"实现（不再改变模式/不再产生模式跳变记录），这里纯透传
    CTHermesPowerMode ctRM = CTHermesResolveTargetModeRaw(selected, blanked, appLowPower);
    if (g_overheatActive && ctRM != CTHermesPowerModeLow) ctRM = CTHermesPowerModeLow;   // ★ 1.4.6s：过热保护优先（临时低功耗）
    return ctRM;
}

// 常驻模式（从偏好读，避免各调用点重复取值）
static CTHermesPowerMode CTHermesSelectedModeFromPrefs(NSDictionary *prefs) {
    NSString *mode = [prefs isKindOfClass:[NSDictionary class]] ? prefs[S("powerMode")] : nil;
    return ([mode isKindOfClass:[NSString class]] && [mode isEqualToString:S("lowPower")])
        ? CTHermesPowerModeLow : CTHermesPowerModeFull;
}

// 低功耗模式的「高性能名单」：命中后该 App 不套低功耗，高性能运行（不卡）
static BOOL foregroundAppForcesFullPower(NSDictionary *prefs) {
    if (![prefs isKindOfClass:[NSDictionary class]]) return NO;
    if (CTHermesTierSystemActive(prefs)) return NO;   // ★ T7x：旧名单退役（档位"高性能"由 resolve 的档位优先处理）
    NSArray *list = [prefs[S("fullPowerApps")] isKindOfClass:[NSArray class]] ? prefs[S("fullPowerApps")] : nil;
    if (list.count == 0) return NO;
    uint64_t foregroundHash = CTHermesReadForegroundBundleHash();
    if (foregroundHash == 0) return NO;
    if (foregroundHash == CTHermesBundleIDHash(S("com.apple.springboard"))) return NO;   // ★ 桌面进程永不匹配名单（旧版残留勾选也不生效）
    for (id rawBundleID in list) {
        if ([rawBundleID isKindOfClass:[NSString class]] && CTHermesBundleIDHash(rawBundleID) == foregroundHash) return YES;
    }
    return NO;
}

// 两份名单互相独立：常驻「低功耗」用高性能名单；常驻「性能模式」用低功耗名单。
static BOOL foregroundAppListHit(CTHermesPowerMode selected, NSDictionary *prefs) {
    if (g_smartEnabled) return NO;   // ★ 智能模式：两份名单不参与判定（高性能例外走内部缓存）
    return (selected == CTHermesPowerModeLow) ? foregroundAppForcesFullPower(prefs)
                                               : foregroundAppShouldUseLowPower(prefs);
}

// ★★★ 统一规则（2026-09-15）：名单例外生效期间，只有"前台确实变成了另一个真实 App"才允许改变运行模式。
//      其余一切情况（读不到 / 锁屏界面 / 仍触发例外的那个 App）→ 一律保持，绝不撤销。
static BOOL CTHermesForegroundAllowsModeChange(void) {
    if (!g_foregroundAppForcesLowPower) return YES;                 // 没有例外在生效 → 正常判定
    uint64_t fg = CTHermesReadForegroundBundleHash();
    if (fg == 0) return NO;                                        // 读不到 → 保持
    if (fg == CTHermesBundleIDHash(S("com.apple.springboard"))) return NO;  // 锁屏界面/桌面 → 保持
    if (fg == g_exceptionAppHash) return NO;                       // 还是触发例外的那个 App → 保持
    return YES;                                                    // 确实是另一个真实 App → 允许改
}

// 从配置文件直接同步“用户选择的模式”并立即应用（解决：面板写 plist 与发通知有先后延迟，导致要切换多次才生效）
static void CTHermesSyncModeFromPrefs(void) {
    // ★ ④ 静默降级：检出被改包/hook → 不接管（不报错、不弹窗）
    if (g_ctHardTampered) return;
    if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
    NSDictionary *prefs = readPrefsDictionary();
    if (!prefs) return;
    id raw = [prefs objectForKey:S("powerMode")];
    if (g_schedActiveMode >= 0) raw = CTScheduleModeName(g_schedActiveMode);   // ★ T7z16：定时时段覆盖档位
    if (![raw isKindOfClass:[NSString class]]) return;
    // ★ T7v：同步刷新"智能模式"标志（防"切换失效"）
    g_smartEnabled = [raw isEqualToString:S(kCTHermesSmartModeC)];
    CTHermesPowerMode selected = [raw isEqualToString:S("lowPower")] ? CTHermesPowerModeLow : CTHermesPowerModeFull;
    // ★★ 关键修复：唤醒/解锁后 8 秒内"只更新用户选择的模式"，不重算运行模式。
    //     否则锁屏界面上前台=SpringBoard → 名单不命中 → 按常驻模式重算 → 把刚恢复的低功耗顶成高性能。
    if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
        g_userSelectedPowerMode = selected;
        return;
    }
    // ★ 统一规则：例外生效期间，前台不是"另一个真实 App"→ 不重算运行模式
    if (!CTHermesForegroundAllowsModeChange()) {
        g_userSelectedPowerMode = selected;
        return;
    }
    BOOL blanked = CTHermesScreenIsBlanked();
    BOOL appLowPower = foregroundAppListHit(selected, prefs);
    CTHermesPowerMode prev = g_powerMode;
    g_userSelectedPowerMode = selected;
    g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("sync-prefs", appLowPower);
    CTAuditMode("sync-prefs", CTHermesResolveTargetMode(selected, blanked, appLowPower));
    if (prev != g_powerMode) applyPowerModeToRuntime(NO);
}

// ============================================================================
// 授权刷新（CTAuth）：激活态核对 + 设备码/状态发布（供设置页与充电工具读取）
//   · 未激活 → g_ctAuthOK=NO → 各总闸全部为假 → 插件不接管（系统原生）
// ============================================================================
static void CTAuthRefresh(void) {
    static int sCTAuthCalls = 0;
    ++sCTAuthCalls;
    NSString *dev = CTAuthDeviceCode();
    g_ctAuthDevCode = dev;
    NSDictionary *prefs = CTHermesReadPrefs();
    NSString *code = (prefs && [prefs[kCTKeyActivationCode] isKindOfClass:[NSString class]]) ? prefs[kCTKeyActivationCode] : nil;
    // ★ 0930-0207：跨权限票据通道 —— 某些机器上温控进程读不到 /var/mobile/Library/…（权限/隐根视图不同），
    //   会让授权判定退化成"未激活"、核心全程待命（日志里一行都不出）。root 守护进程会把授权码另存
    //   一份到任何进程都读得到的路径；这里优先读它：票据=我们私钥签发的授权码，能验签就照常激活（伪造不了）。
    if (code.length == 0 && dev.length > 0) {
        NSString *tk = CTAuthTicketRead();
        if (tk.length > 0 && CTAuthVerifyCode(dev, tk)) {
            NSMutableDictionary *ctTkFix = prefs ? [prefs mutableCopy] : [NSMutableDictionary dictionary];
            ctTkFix[kCTKeyActivationCode] = tk;
            CTHermesWritePrefs(ctTkFix);
            code = tk;
            CTD("[授权] 配置读不到 → 经跨权限票据读到有效授权码（0930-0207 兼容通道）");
        }
    }
    // ★ 1.4.10：配置里读不到授权码 → 用本进程已验证过的码兜底，并立刻写回配置（自愈）。
    //   ★ 关键：只有"本进程曾经验证通过"才有兜底 —— 全新未激活的机器依然完全不生效。
    if (code.length == 0 && sCTLastGoodCode.length > 0 && dev.length > 0 && CTAuthVerifyCode(dev, sCTLastGoodCode)) {
        NSMutableDictionary *ctFix = prefs ? [prefs mutableCopy] : [NSMutableDictionary dictionary];
        ctFix[kCTKeyActivationCode] = sCTLastGoodCode;
        CTHermesWritePrefs(ctFix);
        code = sCTLastGoodCode;
        CTD("[授权] 配置读不到授权码 → 已用内存备份恢复并写回（1.4.11）");
    }
    BOOL activated = NO;
    if (dev.length > 0 && code.length > 0 && CTAuthVerifyCode(dev, code)) {
        // ★ 缺零件解锁：验签通过 → 从激活码尾部解出零件钥匙 S → 字符串体系可用
        uint8_t parts[32];
        if (CTAuthExtractParts(dev, code, parts)) {
            CTObfUnlock(parts);
            memset(parts, 0, sizeof(parts));
            activated = YES;
            sCTLastGoodCode = [code copy];   // ★ 1.4.10：记住已验证通过的码
        } else {
            CTD("[授权] 零件校验未通过（激活码缺零件或已损坏）");
        }
    }
    if (!activated) CTObfScrub();   // 未激活 / 被撤 / 缺零件 → 字符串体系保持锁定
    BOOL wasOK = g_ctAuthOK;
    g_ctAuthOK = activated;

    // ★ ③ 校验分散（0930-0185）：独立代码路径再复核签名 —— 只在"能明确判定伪造"时否决，
    //    取不到值/异常一律保持原判定，绝不影响正常用户
    if (g_ctAuthOK) {
        id __rc = CTHermesReadPrefs()[kCTKeyActivationCode];
        NSString *__rd = CTAuthDeviceCode();
        if ([__rc isKindOfClass:[NSString class]] && [(NSString *)__rc length] > 0 &&
            __rd.length > 0 && !CTAuthVerifyCode(__rd, (NSString *)__rc)) {
            // ★ 1.4.8c：只记录，不再撤销（撤销会造成授权抖动 → 触发自动注销）
            static int sCtAuthMismatch = 0;
            if (++sCtAuthMismatch <= 3) CTD("[授权] 独立复核未通过（第 %d 次，仅记录，不影响使用）", sCtAuthMismatch);
        }
    }
    // ★ ④ 自校验（随授权刷新一起跑）
    // —— 状态发布：①文件（充电工具读）②prefs（设置页读）——
    {
        static int sLastAuth = -1;
        static NSString *sLastDev = nil;
        BOOL devChanged = (dev && ![dev isEqualToString:sLastDev ?: @""] );
        BOOL authChanged = (sLastAuth != (activated ? 1 : 0));
        // ★ 1.4.11：授权文件内容 = 「授权码」本身（可独立验签），不再写裸 "1"（杜绝"写个 1 就上岗"）；
        //           文件缺失 / 内容不符也补写一次（自愈），保证守护进程随时能独立校验
        NSString *__tok = nil;
        if (activated) {
            __tok = (sCTLastGoodCode.length > 0) ? sCTLastGoodCode
                 : [[CTHermesReadPrefs() objectForKey:kCTKeyActivationCode] isKindOfClass:[NSString class]]
                       ? [CTHermesReadPrefs() objectForKey:kCTKeyActivationCode] : nil;
        }
        if (__tok.length == 0) __tok = @"0";
        NSString *__cur = [[NSString stringWithContentsOfFile:kCTPathAuthFile encoding:NSUTF8StringEncoding error:nil]
                              stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        BOOL __fileStale = !(__cur.length > 0 && [__cur isEqualToString:__tok]);
        if (devChanged || authChanged || __fileStale) {
            sLastAuth = activated ? 1 : 0;
            sLastDev = dev;
            FILE *f = fopen(kCTPathAuthFile.UTF8String, "w");
            if (f) { fputs([[__tok stringByAppendingString:@"\n"] UTF8String], f); fclose(f); }
            NSMutableDictionary *p = CTHermesReadMutablePrefs();
            if (p) {
                if (dev) p[kCTKeyDevCode] = dev;
                p[kCTKeyAuthState] = @(activated ? 1 : 0);
                CTHermesWritePrefs(p);
            }
            CTD("[授权] 状态 = %s（设备码 %s）", activated ? "已激活" : "未激活", dev.length ? dev.UTF8String : "?");
            if (activated) CTD("[水印] 构建 %s · 已授权给 设备码 %s", kCTBuildTag, dev.length ? dev.UTF8String : "?");
        }
    }
    if (wasOK != g_ctAuthOK) {
        CTD("[授权] 生效变化 → %s", g_ctAuthOK ? "接管温控" : "不接管（系统原生）");
        if (g_ctAuthOK) {
            installCrossVersionThermalAliases();   // ★ 激活瞬间补装"零件解锁后"的动态钩子（兜底）
            static BOOL sCtRespringScheduled = NO;
            // ★ 1.4.10：彻底取消"激活后自动注销"。曾因授权状态抖动 → 反复注销（死循环）。
            //   今后任何情况都不自动注销，是否重启用户空间完全由用户手动决定。
            if (sCTAuthCalls > 1 && !sCtRespringScheduled) {
                sCtRespringScheduled = YES;
                CTD("[授权] 已生效（1.4.11：不自动注销）");
            }
        } else {
            // ★ 2.0.40：撤销/重置授权 → 立即交还系统（清低功耗残留；全功能停用）
            ctNativeReleasePass();
            CTD("[授权] 已撤销 → 交还系统（清低功耗残留，功能全部停用）");
        }
        applyCurrentPowerModeToRuntime();
    }

    // ★ 0930-0207：把授权码同步到"跨权限票据"路径（本进程有权限时；读不到 /var/mobile/… 的进程由 root 守护进程写）
    if (g_ctAuthOK && code.length > 0) CTAuthTicketWrite(code);
    // ★ 0930-0207：跨权限心跳 —— 经"通知"通道上报"核心已注入"，由移动侧组件记进日志（诊断用，谁都能收到）
    CTAuthHeartbeatPost();
}

// ============================================================================
// ★ 轻量反调试（仅"被调试 / 被注入分析框架"时触发 → 与"被改"同套处置）
//   检测：P_TRACED / Frida·Cycript 映像 / 127.0.0.1:27042
//   处置：写 __analysedFlag（功能停用 + 设置页温和提示）；持续干净约 2 小时自动恢复
// ============================================================================
static BOOL g_ctAnalysed = NO;
static int  g_ctAnalysisCleanStreak = 0;

// ★ 1.4.7：记录"命中原因"，便于分辨"真有调试器"还是"误报"
static const char *CTDebuggerReasonC(void) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()};
    struct kinfo_proc info2; size_t sz2 = sizeof(info2);
    memset(&info2, 0, sizeof(info2));
    if (sysctl(mib, 4, &info2, &sz2, NULL, 0) == 0 && (info2.kp_proc.p_flag & P_TRACED) != 0) {
        return "D1";
    }
    uint32_t n2 = _dyld_image_count();
    for (uint32_t i2 = 0; i2 < n2; i2++) {
        const char *nm = _dyld_get_image_name(i2);
        if (nm && (strcasestr(nm, "FridaGadget") || strcasestr(nm, "frida-agent") ||
                   strcasestr(nm, "frida_agent") || strcasestr(nm, "libfrida") ||
                   strcasestr(nm, "libcycript") || strcasestr(nm, "Cycript"))) {
            return "D2";
        }
    }
    return "D3";
}

static BOOL CTDebuggerPresent(void) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()};
    struct kinfo_proc info; size_t sz = sizeof(info);
    memset(&info, 0, sizeof(info));
    if (sysctl(mib, 4, &info, &sz, NULL, 0) == 0 && (info.kp_proc.p_flag & P_TRACED) != 0) return YES;
    // ★ 1.4.7 收窄：只认"真正注入用"的组件名（不再对任何含 frida 的路径一票否决，避免误伤正版客户）
    static const char *kInjectNeedles[] = {
        "FridaGadget", "frida-agent", "frida_agent", "libfrida",
        "libcycript", "Cycript", "/usr/lib/frida", NULL
    };
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        for (int k = 0; kInjectNeedles[k]; k++) {
            if (strcasestr(name, kInjectNeedles[k])) return YES;
        }
    }
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd >= 0) {
        struct sockaddr_in sa; memset(&sa, 0, sizeof(sa));
        sa.sin_family = AF_INET; sa.sin_port = htons(27042);
        sa.sin_addr.s_addr = htonl(0x7F000001);
        int fl = fcntl(fd, F_GETFL, 0); fcntl(fd, F_SETFL, fl | O_NONBLOCK);
        BOOL hit = NO;
        if (connect(fd, (struct sockaddr *)&sa, sizeof(sa)) == 0) hit = YES;
        else {
            struct pollfd pfd = {fd, POLLOUT, 0};
            if (poll(&pfd, 1, 40) > 0) {
                int err = 0; socklen_t el = sizeof(err);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &el);
                if (err == 0) hit = YES;
            }
        }
        close(fd);
        // ★ 1.4.7 收窄：只是"装着/开着 Frida 服务端"不再停用功能，只记一行日志
        if (hit) CTD("[守护] 环境探测记录（D3）");
    }
    return NO;
}

// ★ ④ 自校验（0930-0185）：关键函数入口若被改成"跳转"（inline hook / 改包打补丁）→ 静默降级
static BOOL g_ctHardTampered = NO;

static void CTAnalysisAuditTick(void) {
    if (CTDebuggerPresent()) {
        g_ctAnalysisCleanStreak = 0;
        if (!g_ctAnalysed) {
            g_ctAnalysed = YES;
            CTD("[守护] 环境核验异常（%s）→ 功能暂缓", CTDebuggerReasonC());
            NSMutableDictionary *p = CTHermesReadMutablePrefs();
            if (p) { p[@"__analysedFlag"] = @YES; CTHermesWritePrefs(p); }
        }
    } else if (g_ctAnalysed) {
        if (++g_ctAnalysisCleanStreak >= 24) {
            g_ctAnalysed = NO; g_ctAnalysisCleanStreak = 0;
            NSMutableDictionary *p = CTHermesReadMutablePrefs();
            if (p) { [p removeObjectForKey:@"__analysedFlag"]; CTHermesWritePrefs(p); }
            CTD("[守护] 环境恢复正常 → 功能恢复");
        }
    }
}

// ★ 激活后自动注销：重启 SpringBoard（视觉"注销"）+ 本宿主 thermalmonitord（全新状态加载，全部功能完全生效）
//   多重保险：① 枚举进程直接杀 ② killall 兜底 ③ 交 root 守护进程代做（写请求文件 + 通知）
static void __attribute__((unused)) CTRespringForActivation(void) {
    unlink(kCTPathRespringReq.UTF8String);   // 清掉可能的旧请求
    BOOL killed = NO;
    // ① 枚举进程 → SIGKILL（缓冲区不足自动放大重试）
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    for (int attempt = 0; attempt < 4 && !killed; attempt++) {
        size_t len = 0;
        if (sysctl(mib, 4, NULL, &len, NULL, 0) != 0 || len == 0) { CTD("[注销] 进程表不可用"); break; }
        len = len * 3 / 2 + 8192;
        struct kinfo_proc *buf = malloc(len);
        if (!buf) break;
        size_t got = len;
        if (sysctl(mib, 4, buf, &got, NULL, 0) == 0) {
            int n = (int)(got / sizeof(struct kinfo_proc));
            for (int i = 0; i < n; i++) {
                if (strcmp(buf[i].kp_proc.p_comm, "SpringBoard") == 0) {
                    pid_t spid = buf[i].kp_proc.p_pid;
                    if (kill(spid, SIGKILL) == 0) { killed = YES; CTD("[注销] 已向 SpringBoard(%d) 发 SIGKILL", (int)spid); }
                    else CTD("[注销] kill(SpringBoard %d) 失败 errno=%d", (int)spid, errno);
                }
            }
        } else {
            CTD("[注销] 进程枚举失败（第 %d 次）", attempt + 1);
        }
        free(buf);
    }
    // ② 兜底：killall / launchctl kickstart（多路径 + PATH 查找；兼容 rootless / RootHide）
    if (!killed) {
        const char *paths[] = {"/var/jb/usr/bin/killall", "/usr/bin/killall", "/bin/killall", "/var/jb/bin/killall", NULL};
        for (int i = 0; paths[i] && !killed; i++) {
            if (access(paths[i], X_OK) != 0) continue;
            pid_t p = fork();
            if (p == 0) { execl(paths[i], "killall", "-9", "SpringBoard", (char *)NULL); _exit(127); }
            else if (p > 0) { int st = 0; waitpid(p, &st, 0); CTD("[注销] killall 兜底：%s 状态=%d", paths[i], st); killed = YES; }
        }
        if (!killed) {   // PATH 里找 killall（RootHide 的 jb 路径是随机的，写死不可靠）
            pid_t p = fork();
            if (p == 0) { execlp("killall", "killall", "-9", "SpringBoard", (char *)NULL); _exit(127); }
            else if (p > 0) { int st = 0; waitpid(p, &st, 0); if (st == 0) { CTD("[注销] killall(PATH) 状态=%d", st); killed = YES; } }
        }
        if (!killed) {   // launchctl kickstart 再兜一层
            const char *lc[] = {"/var/jb/usr/bin/launchctl", "/bin/launchctl", "/usr/bin/launchctl", NULL};
            for (int i = 0; lc[i] && !killed; i++) {
                if (access(lc[i], X_OK) != 0) continue;
                pid_t p = fork();
                if (p == 0) { execl(lc[i], "launchctl", "kickstart", "-k", "system/com.apple.SpringBoard", (char *)NULL); _exit(127); }
                else if (p > 0) { int st = 0; waitpid(p, &st, 0); CTD("[注销] launchctl 兜底：%s 状态=%d", lc[i], st); if (st == 0) killed = YES; }
            }
        }
    }
    // ③ 兜底：请 root 守护进程代做（写请求文件 + 发通知；守护进程 5 秒内会处理）
    if (!killed) {
        FILE *f = fopen(kCTPathRespringReq.UTF8String, "w");
        if (f) { fputs("1\n", f); fclose(f); CTD("[注销] 本宿主权限不足，已请求守护进程代做"); }
        notify_post(kCTHermesSettingsChangedNotifC);
    }
    kill(getpid(), SIGKILL);   // 本宿主随 launchd 自动重启（安装脚本同款操作，已验证安全）
}

static void loadPrefs(void) {
@autoreleasepool {
NSDictionary *d = readPrefsDictionary();
// 关键修复：读取失败时立即返回，保留当前内存中正确的 g_powerMode，防止回退到性能模式
if (!d || d.count == 0) return;

BOOL enabled = YES;
BOOL blockPopup = [d[S("thermalBlockNotifPopup")] ?: @NO boolValue];
BOOL preventDimming = [d[S("thermalPreventDimmingEnabled")] ?: @NO boolValue];
g_overheatAutoProtect = [d[S("thermalPressureAutoProtectionEnabled")] ?: @NO boolValue];
g_nominalAutoRecover  = [d[S("thermalNominalAutoRecoveryEnabled")] ?: @NO boolValue];
os_unfair_lock_lock(&g_stateLock);
g_enabled = enabled;
g_thermalBlockNotifPopup = blockPopup;
g_thermalPreventDimmingEnabled = preventDimming;
os_unfair_lock_unlock(&g_stateLock);

NSString *mode = [d[S("powerMode")] isKindOfClass:[NSString class]] ? d[S("powerMode")] : nil;
if (g_schedActiveMode >= 0) mode = CTScheduleModeName(g_schedActiveMode);   // ★ T7z16：定时时段覆盖档位
CTHermesPowerMode selected;
if (mode) {
    selected = [mode isEqualToString:S("lowPower")] ? CTHermesPowerModeLow : CTHermesPowerModeFull;
} else {
    // ★ T7x3：键缺失（读取不完整）→ 保持当前用户模式，绝不默认"性能模式"（否则智能被关掉+高性能乱跳）
    os_unfair_lock_lock(&g_modeLock);
    selected = g_userSelectedPowerMode;
    os_unfair_lock_unlock(&g_modeLock);
}
// ★ 智能模式（T7h）：读取开关 + 重建分类缓存（关着时=原有两档逻辑，一行不受影响）
// ★ T7x3：只有确实读到模式字符串才刷新智能开关——读不到时保持原值
BOOL smartNow = (mode && [mode isEqualToString:S(kCTHermesSmartModeC)]);
if (mode) g_smartEnabled = smartNow;
g_gameForceFull = [d[S("gameForceFullEnabled")] ?: @NO boolValue];   // ★ T7z26：游戏强制高性能（默认开）
if (smartNow || g_gameForceFull) {
    CTHermesRebuildSmartAppClasses(d);
    if (smartNow) CTD("[智能] 已启用：游戏→高性能 / 其他应用→低功耗 / 桌面→原生");
    CTD("[游戏高性能] 开关=%d（识别为游戏的 App 一律高性能）", g_gameForceFull ? 1 : 0);
}

    // ★ T7w：App 档位表（appTiers）→ 哈希集合；未迁移时用旧名单兜底（三种模式通用）
    {
        NSMutableSet *ctTf = [NSMutableSet set], *ctTl = [NSMutableSet set], *ctTn = [NSMutableSet set];
        NSDictionary *ctTiers = [d[S("appTiers")] isKindOfClass:[NSDictionary class]] ? d[S("appTiers")] : nil;
        // ★ T7x：档位体系接管后，旧名单不再"兜底"——否则"全部重置为自动"后旧钉档仍在偷偷生效（微信仍高性能的元凶）
        BOOL ctTierSystem = CTHermesTierSystemActive(d);
        if (ctTierSystem) {
            for (id ctBid in ctTiers) {
                if (![ctBid isKindOfClass:[NSString class]] || ![ctBid length]) continue;
                NSString *ctT = ctTiers[ctBid];
                if (![ctT isKindOfClass:[NSString class]]) continue;
                uint64_t ctHv = CTHermesBundleIDHash(ctBid);
                if ([ctT isEqualToString:S("full")]) [ctTf addObject:@(ctHv)];
                else if ([ctT isEqualToString:S("low")]) [ctTl addObject:@(ctHv)];
                else if ([ctT isEqualToString:S("native")]) [ctTn addObject:@(ctHv)];
            }
        } else {
            id ctF = d[S("fullPowerApps")], ctL = d[S("lowPowerApps")];
            if ([ctF isKindOfClass:[NSArray class]]) for (id ctBid in ctF) if ([ctBid isKindOfClass:[NSString class]]) [ctTf addObject:@(CTHermesBundleIDHash(ctBid))];
            if ([ctL isKindOfClass:[NSArray class]]) for (id ctBid in ctL) if ([ctBid isKindOfClass:[NSString class]]) [ctTl addObject:@(CTHermesBundleIDHash(ctBid))];
        }
        g_tierFullHashes = ctTf; g_tierLowHashes = ctTl; g_tierNativeHashes = ctTn;
        CTD("[档位] 已加载：高性能 %lu / 低功耗 %lu / 原生 %lu（其余自动）", (unsigned long)ctTf.count, (unsigned long)ctTl.count, (unsigned long)ctTn.count);
    }

    // ★ T7w：滑动提速开关（默认开）
    g_scrollBoostEnabled = [d[S("scrollBoostEnabled")] ?: @NO boolValue];   // 默认关（设置页打开才生效）
    g_ctAppBoostEnabled = [d[S("appBoostEnabled")] ?: @NO boolValue];       // ★ 2.0.1：开合提速通道（默认关）
    g_ctIdleSinkEnabled = [d[S("idleSinkEnabled")] ?: @NO boolValue];      // ★ T7z6：无操作深度省电（默认开）
    g_ctVideoOptEnabled = [d[S("videoProfileEnabled")] ?: @NO boolValue];  // ★ T7z6：视频场景优化（默认开）
    g_ctVideoDeepEnabled = [d[S("videoDeepEnabled")] ?: @NO boolValue];    // ★ T7z7：视频中也深度省电（默认关）
    g_lowPowerDesktopNative = [d[S("lowPowerDesktopNative")] ?: @NO boolValue];   // ★ T7x6：低功耗模式「桌面原生频率」（默认关=桌面也压）
    // ★ 1.4.6 充电管家（默认：数据显示开、其余全关）
    g_ctcLimitOn   = [d[S("chargeLimitEnabled")] ?: @NO boolValue];
    g_ctcLimitVal  = [d[S("chargeLimitValue")] ?: @100 intValue];
    if (g_ctcLimitVal < 50) g_ctcLimitVal = 50;
    if (g_ctcLimitVal > 100) g_ctcLimitVal = 100;
    if (g_ctcLimitOn && d[S("chargeLimitValue")] == nil) g_ctcLimitOn = NO;   // ★ 2.0.113：值读不到 → 不许按停（fail-open，防默认 80）
    {   // ★ 2.0.113：上限"实读值"留痕（治"界面 90 / 引擎 80"分裂）
        static int sLastLimOn = -1, sLastLimVal = -1;
        if ((int)g_ctcLimitOn != sLastLimOn || g_ctcLimitVal != sLastLimVal) {
            sLastLimOn = (int)g_ctcLimitOn; sLastLimVal = g_ctcLimitVal;
            CTD("[充电] 上限实读：开=%d 值=%d", (int)g_ctcLimitOn, g_ctcLimitVal);
        }
    }
    g_ctcTempOn    = NO;   // ★ 1.4.61：该功能已按用户要求取消（不再生效 ✓）；原：读 chargeTempProtectEnabled
    g_ctcTempVal   = [d[S("chargeTempThreshold")] ?: @42 intValue];
    if (g_ctcTempVal < 35) g_ctcTempVal = 35;
    if (g_ctcTempVal > 55) g_ctcTempVal = 55;
    g_ctcForceOn   = [d[S("chargeForceEnabled")] ?: @NO boolValue];   // ★ 2.0.114：防停充回归（2.0.96 版；默认关）
    g_ctcDisplayOn = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];   // ★ 2.0.114：默认开（浮窗显示模块默认全选）
    if (!g_ctAuthOK) {   // ★ 未激活：充电管理待命（不接管；守护工具同样会读授权文件待命）
        g_ctcLimitOn = NO; g_ctcTempOn = NO; g_ctcForceOn = NO;
    }
    g_floatWindowEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];          // ★ T7z16：悬浮窗开关
    CTScheduleLoadFromPrefs(d);                                                    // ★ T7z16：定时切档配置
BOOL blanked = CTHermesScreenIsBlanked();
BOOL appLowPower=foregroundAppListHit(selected, d);
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
if (CTHermesForegroundAllowsModeChange()) {          // ★ 统一规则守卫
    g_foregroundAppForcesLowPower=appLowPower;
    CTAuditMode("loadPrefs", CTHermesResolveTargetMode(selected, blanked, appLowPower));
}
os_unfair_lock_unlock(&g_modeLock);
}

// ★ T5：设置读取成功后——①标记已读 ②若不在锁屏中，把"锁屏前模式"同步为当前模式（防止残留默认值被解锁恢复用上）
g_prefsLoaded = YES;
if (!CTHermesScreenIsBlanked()) {
os_unfair_lock_lock(&g_modeLock);
g_modeBeforeSleep = g_powerMode;
os_unfair_lock_unlock(&g_modeLock);
CTD("[写睡前] loadPrefs同步: → %s", g_modeBeforeSleep == CTHermesPowerModeLow ? "低功耗" : "高性能");
}
}

// ============================================================================
// 热管理 IOKit 服务名
// ============================================================================
static const char *g_hotServices[] = {
"AppleSPU", "AppleSPU.original",
"AppleARMPlatform",
"pmu", "ApplePMGR",
"AppleGPU", "AGXDriver",
"ANECompilerService", "AppleANE",
"AppleM2ScalerCSC", "IOSurface",
NULL
};

#define SELECTOR_IS_MITIGATION(s)  ((s) >= 0x20 && (s) <= 0x5F)  // 拦截 0x20-0x5F（扩展低频管理+温控）
#define SELECTOR_IS_CRITICAL(s)    ((s) >= 0x60)                  // 紧急保护 — 不拦截

// ============================================================================
// connection 追踪
// ============================================================================
#define MAX_CONN 64

typedef struct {
io_connect_t conn;
BOOL         isThermal;
} ConnEntry;

static ConnEntry g_conns[MAX_CONN];
static int g_connCount = 0;
static os_unfair_lock g_connLock = OS_UNFAIR_LOCK_INIT;  // 线程安全：保护 g_conns/g_connCount

static void trackConnection(io_connect_t conn, BOOL thermal) {
if (conn == MACH_PORT_NULL) return;
os_unfair_lock_lock(&g_connLock);
if (g_connCount < MAX_CONN) {
g_conns[g_connCount].conn     = conn;
g_conns[g_connCount].isThermal = thermal;
g_connCount++;
}
os_unfair_lock_unlock(&g_connLock);
}

static BOOL serviceIsThermal(io_service_t service) {
if (service == MACH_PORT_NULL) return NO;
io_name_t name = {0};
if (IORegistryEntryGetName(service, name) != KERN_SUCCESS) return NO;
for (int i = 0; g_hotServices[i]; i++) {
if (strcmp(name, g_hotServices[i]) == 0) return YES;
}
return NO;
}

// ============================================================================
// IOKit 层钩子
// ============================================================================

// --- IOServiceOpen — 追踪 thermal connection ---
%hookf(kern_return_t, IOServiceOpen, io_service_t service, task_t task, uint32_t type, io_connect_t *connect) {
kern_return_t ret = %orig;
if (ret == KERN_SUCCESS && connect && *connect != MACH_PORT_NULL) {
trackConnection(*connect, serviceIsThermal(service));
}
return ret;
}

// --- IOServiceClose — 清理已断开的 thermal connection（防止 g_conns 数组溢出后拦截失效）---
%hookf(kern_return_t, IOServiceClose, io_connect_t connect) {
if (connect == MACH_PORT_NULL) return %orig(connect);
os_unfair_lock_lock(&g_connLock);
for (int i = 0; i < g_connCount; i++) {
if (g_conns[i].conn == connect) {
for (int j = i; j < g_connCount - 1; j++) {
g_conns[j] = g_conns[j + 1];
}
g_connCount--;
break;
}
}
os_unfair_lock_unlock(&g_connLock);
return %orig(connect);
}

// --- IOConnectCallMethod — 保留连接追踪，不再按 selector 范围盲拦截 ---
%hookf(kern_return_t, IOConnectCallMethod, mach_port_t connection, uint32_t selector, const uint64_t *input, uint32_t inputCnt, const void *inputStruct, size_t inputStructCnt, uint64_t *output, uint32_t *outputCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

// 异步与结构体调用必须放行，否则 ObjC 层强制后的目标也无法真正写入 ApplePPM。
%hookf(kern_return_t, IOConnectCallAsyncMethod, mach_port_t connection, uint32_t selector, mach_port_t wakePort, mach_port_t *asyncRef, uint32_t asyncRefCnt, const void *inputStruct, size_t inputStructCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

%hookf(kern_return_t, IOConnectCallStructMethod, mach_port_t connection, uint32_t selector, const void *inputStruct, size_t inputStructCnt, void *outputStruct, size_t *outputStructCnt) {
if (connection == MACH_PORT_NULL) return %orig;
return %orig;
}

// --- IOServiceSetProperty — 丢弃 thermalmonitord 的频率/功耗约束属性 ---
static kern_return_t (*orig_IOServiceSetProperty)(io_service_t, CFStringRef, CFTypeRef) = NULL;

static kern_return_t hooked_IOServiceSetProperty(io_service_t service, CFStringRef key, CFTypeRef value) {
if (!orig_IOServiceSetProperty) return KERN_FAILURE;
if (service == MACH_PORT_NULL || !key || !value) return orig_IOServiceSetProperty(service, key, value);
if (!runtimeEnabled() || g_restoringFullPower) {
return orig_IOServiceSetProperty(service, key, value);
}

if (isNetworkThrottleProperty(key)) {
return KERN_SUCCESS;
}

NSString *keyString = (__bridge NSString *)key;
if (!ctBootSilence() && thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(keyString)) {
    id replacement = nil;
    if (CFGetTypeID(value) == CFNumberGetTypeID() || CFGetTypeID(value) == CFStringGetTypeID()) {
        replacement = backlightReplacementMatchingValue(keyString, (__bridge id)value);
    }
    kern_return_t result = replacement ? orig_IOServiceSetProperty(service, key, (__bridge CFTypeRef)replacement) : orig_IOServiceSetProperty(service, key, value);
    { static int sBS = 0; sBS++; g_ctHHN++; CTHostAlivePost(); if (sBS <= 5 || (sBS % 20) == 0) CTD("[自测·拦写] 命中上限键写入 key=%s（已改写/回写）", keyString.UTF8String); }   // 自测增强
    CTHermesRecommitUserBrightnessSoon();
    return result;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(keyString) && valueMeansStopChargingCF(keyString, value) && g_ctcCapacity < 99 && CTChargeHotGate()) {   // ★ 2.0.51：真热门——不热一律放行
CTChargeNoteIntercept(keyString);
return KERN_SUCCESS;
}
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(keyString)) {
return KERN_SUCCESS;
}
return orig_IOServiceSetProperty(service, key, value);
}

%hookf(kern_return_t, IORegistryEntrySetCFProperty, io_registry_entry_t entry, CFStringRef key, CFTypeRef value) {
if (entry == MACH_PORT_NULL || !key || !value) return %orig(entry, key, value);
if (!runtimeEnabled() || g_restoringFullPower) return %orig(entry, key, value);
if (isNetworkThrottleProperty(key)) return KERN_SUCCESS;
NSString *keyString = (__bridge NSString *)key;
if (!ctBootSilence() && thermalDimmingPreventionEnabled() && keyIsBacklightThermalLimit(keyString)) {
    id replacement = nil;
    if (CFGetTypeID(value) == CFNumberGetTypeID() || CFGetTypeID(value) == CFStringGetTypeID()) {
        replacement = backlightReplacementMatchingValue(keyString, (__bridge id)value);
    }
    kern_return_t result;
    if (replacement) {
        result = %orig(entry, key, (__bridge CFTypeRef)replacement);
    } else {
        result = %orig(entry, key, value);
    }
    { static int sBS = 0; sBS++; g_ctHHN++; CTHostAlivePost(); if (sBS <= 5 || (sBS % 20) == 0) CTD("[自测·拦写] 命中上限键写入 key=%s（已改写/回写）", keyString.UTF8String); }   // 自测增强
    CTHermesRecommitUserBrightnessSoon();
    return result;
}
if (g_ctcForceOn && !g_ctcSelfWrite && keyIsChargeControlKey(keyString) && valueMeansStopChargingCF(keyString, value) && g_ctcCapacity < 99 && CTChargeHotGate()) {   // ★ 2.0.51：真热门——不热一律放行
CTChargeNoteIntercept(keyString);
return KERN_SUCCESS;
}
if (shouldApplyFullCPUProtection() && keyIsThermalThrottleProperty(keyString)) {
return KERN_SUCCESS;
}
return %orig(entry, key, value);
}

%hookf(kern_return_t, IORegistryEntrySetCFProperties, io_registry_entry_t entry, CFTypeRef properties) {
if (entry == MACH_PORT_NULL || !properties) return %orig(entry, properties);
if (g_ctcSelfWrite) return %orig(entry, properties);   // ★ 1.4.6：我们自己写的充电属性直接放行
if (!runtimeEnabled() || g_restoringFullPower) return %orig(entry, properties);
CFDictionaryRef replacement = copyPropertiesByRemovingThermalLimits(properties);
if (!replacement) return %orig(entry, properties);
if (CFDictionaryGetCount(replacement) == 0) {
CFRelease(replacement);
return KERN_SUCCESS;
}
kern_return_t result = %orig(entry, replacement);
CFRelease(replacement);
return result;
}

// ============================================================================
// ObjC 类钩子（第1层: CommonProduct / HidSensors — 已有）
// ============================================================================

// --- CommonProduct: thermalmonitord 核心热管理对象 ---
%hook CommonProduct

- (id)initProduct:(id)arg1 {
id res = %orig;
if (res && runtimeEnabled()) {
installCrossVersionThermalAliases();
setCommonProduct((CommonProduct *)res);
if (shouldApplyFullCPUProtection()) {
{ SEL ctTSSel = CTObfSel("b1e5f482b63c1f431fb7513558f69d83d21296b5eccecbdc22bf524dc615243835d00da5e7"); if (ctTSSel) ((void (*)(id, SEL, id))objc_msgSend)((id)res, ctTSSel, CTObfStr("b1c440e5392825b579daeb")); }
}
applyCurrentPowerModeToRuntime();
CTLOG(S("[CTHermes] CommonProduct init, 功率模式:%@"), isLowPowerMode() ? S("低功耗") : S("性能模式"));
}
return res;
}

- (void)tryTakeAction {
if (shouldApplyFullCPUProtection()) {
// 强制热压力为 Nominal（最多每秒校正一次，避免快循环广播）
correctNominalStateIfNeeded();
// 阻止所有热缓解动作
return;
}
%orig;
}

- (void)simulateLightThermalPressure {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

- (void)updatePowerzoneTelemetry {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

// 低功耗开启 CPU CPMS 使 Level2/预算落硬件；性能模式关闭 CPMS。
- (void)setCPMSMitigationsEnabled:(BOOL)enabled {
if (g_restoringFullPower) {
%orig(enabled);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(YES);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(enabled);
}

// 性能模式: 直接阻断 CPU 节流等级写入，拒绝执行降频指令。
- (void)setCPULevel:(int)level {
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setGPUPowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setPackagePowerCeiling:(int)ceiling fromDecisionSource:(id)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

// ★ 2026-09-29（对照原版 1.6.2-103 移植）：iOS 16 热压链补充
// 热压写入 IOKit/SMC — 解除温控下丢弃热相关键
- (BOOL)setServiceProperty:(uintptr_t)service key:(id)key value:(uintptr_t)value scaleToFixedPoint:(BOOL)scale {
if (shouldApplyFullCPUProtection() && CTIsThermalServiceKey(key)) {
CTD("[热写入] 丢弃 CP setServiceProperty %s (value=%p)", ((NSString *)key).UTF8String, (void *)value);
return NO;
}
return %orig(service, key, value, scale);
}

// 轻度热压力 — 解除温控下强制 NO
- (BOOL)shouldEnforceLightThermalPressure {
if (shouldApplyFullCPUProtection()) return NO;
return %orig;
}

// 强制热级别 / 强制热压力级别 — 解除温控下归 0
- (int)getPotentialForcedThermalLevel:(id)component {
if (shouldApplyFullCPUProtection()) return 0;
return %orig(component);
}

- (int)getPotentialForcedThermalPressureLevel {
if (shouldApplyFullCPUProtection()) return 0;
return %orig;
}
%end

// --- HidSensors: HID 温度事件处理（与「屏蔽高温温度计警告」共用开关）---
%hook HidSensors

- (void)handleTemperatureEvent:(int)arg1 service:(id)arg2 {
if (thermalPopupBlockingEnabled()) {
if (shouldApplyFullCPUProtection()) CTHermesForceNominalCombined();
CTPopupLog(@"高温事件（HidSensors）");
return;
}
%orig(arg1, arg2);
}

%end

// ============================================================================
// ObjC 类钩子（第2层: CTHermesThermalManager 决策层）
//
// 冲突避免说明:
//   - 传感器读数 getHighestSkinTemp/dieTempFilteredMaxAverage/thermalSensorValuesMaxFromIndexSet
//     不在此处 hook (IOKit 层已拦截)
//   - putDeviceInThermalSimulationMode: 不 hook (CTHermes 自已调用会递归)
//   - setCPMSMitigationState: 直接在决策层拦截，避免进入 CPMS 写路径
//   - setHiPFeatureEnabled: 不 hook
// ============================================================================

static void ctMntBitsRefresh(void) {   // 自测增强：弹窗链上岗位（每拍刷新）
    uint32_t b = 0;
    if (objc_getClass("HidSensors")) b |= (1u << 0);
    if (origNotification_ThermalInt) b |= (1u << 1);
    if (origNotification_ThermalQ) b |= (1u << 2);
    if (origNotification_Thermal) b |= (1u << 3);
    if (origNotification_Level) b |= (1u << 4);
    if (objc_getClass("CTHermesThermalManager")) b |= (1u << 5);
    g_ctMntBits = b;
}

// --- CTHermesThermalManager: hook 决策树和热压力升级 ---
%hook CTHermesThermalManager

// 决策树评估 — 这是 thermalmonitord 判断"要不要降频"的核心
- (void)evaluateDecisionTree {
// 全功率模式: 阻止决策树运行，避免温控降频
if (shouldApplyFullCPUProtection()) {
correctNominalStateIfNeeded();
return;
}
%orig;
}

- (void)setCPMSMitigationState:(int)state {
if (shouldApplyFullCPUProtection()) {
%orig(0);
return;
}
%orig(state);
}

// 热压力升级通知 — 不再主动阻断
- (void)updateThermalPressureLevelNotification:(id)notification shouldForceThermalPressure:(BOOL)force {
if (thermalPopupBlockingEnabled()) {
if (shouldApplyFullCPUProtection()) CTHermesForceNominalCombined();
CTPopupLog(@"热压力通知");
return;
}
%orig(notification, force);
}

// 热通知 — 受 thermalBlockNotifPopup 开关控制
- (void)updateThermalNotification:(id)notification {
@autoreleasepool {
if (thermalPopupBlockingEnabled()) {
CTPopupLog(@"热通知");
return;
}
}
%orig;
}

// 是否应执行轻度热压力 — 解除温控下强制 NO（对照原版 1.6.2-103）
- (BOOL)shouldEnforceLightThermalPressure {
if (shouldApplyFullCPUProtection()) return NO;
return %orig;
}

// 获取组件释放速率 — 可以降低不放 0
- (float)getReleaseRateForComponent:(id)component {
if (shouldApplyFullCPUProtection()) {
return 0.0;  // 彻底归零
}
return %orig(component);
}

// 获取强制热级别 — 解除温控下归 0（对照原版 1.6.2-103）
- (int)getPotentialForcedThermalLevel:(id)component {
if (shouldApplyFullCPUProtection()) return 0;
return %orig(component);
}

// 获取强制热压力级别 — 解除温控下归 0（对照原版 1.6.2-103）
- (int)getPotentialForcedThermalPressureLevel {
if (shouldApplyFullCPUProtection()) return 0;
return %orig;
}

// 散热/电池服务建议 — 不拦截
- (id)getBatteryServiceSuggestion:(id)suggestion {
return %orig(suggestion);
}

// ★ 2026-09-29（对照原版 1.6.2-103 移植）：配置级入口 —— 防温控暗屏的「真正根因修复」
//   thermalmonitord 通过 -[CTHermesThermalManager getConfigurationFor:] 取回各组件热配置；
//   旧版只挂了 DeviceMonitor 的 C 函数 _getConfigurationFor（该函数实际不存在）→
//   配置级补丁（背光热限制复位）从未生效。原版用本方法原地替换整份热配置。
- (id)getConfigurationFor:(id)key {
id config = %orig(key);
if (!g_ctCfgHookLogged) { g_ctCfgHookLogged = YES; CTD("[防暗屏] getConfigurationFor 已到达（开关=%d，补丁%s）", thermalDimmingPreventionEnabled() ? 1 : 0, thermalDimmingPreventionEnabled() ? "生效" : "未开"); }
if (!thermalDimmingPreventionEnabled()) return config;
@try { return patchThermalPlist(config); }
@catch (__unused NSException *e) { return config; }
}
%end

// --- CTHermesThermalControl: hook 控制力度计算 ---
%hook CTHermesThermalControl

- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams {
id res = %orig(fastLoop, noDisplay, saveParams, zoneParams);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (id)initWithParams:(id)params {
id res = %orig(params);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (BOOL)powerSaveActive {
if (g_restoringFullPower) return %orig;
// 手动低功耗仅限 CPU，不向系统/显示层暴露全局 PowerSave。
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return NO;
return %orig;
}

- (void)setPowerSaveActive:(BOOL)active {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(active);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(active);
}

- (void)setPowerSaveToken:(id)token {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(token);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(nil);
return;
}
%orig(token);
}

// 计算控制力度 — 这是 throttle 量的核心
// soften 模式下减半但不归零，保留基础调节能力
- (float)calculateControlEffort:(id)trigger trigger:(id)arg2 {
if (shouldApplyFullCPUProtection()) {
return 0.0;  // 彻底归零，不降频
}
return %orig(trigger, arg2);
}

// actionComponentControl — 组件控制动作
- (void)actionComponentControl {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

// readReleaseRateForAllComponents — 全组件释放速率
- (void)readReleaseRateForAllComponents {
if (shouldApplyFullCPUProtection()) {
return;
}
%orig;
}

// ★ 2026-09-29（对照原版 1.6.2-103 移植）：热写入丢弃（解除温控下）
- (BOOL)setServiceProperty:(uintptr_t)service key:(id)key value:(uintptr_t)value scaleToFixedPoint:(BOOL)scale {
if (shouldApplyFullCPUProtection() && CTIsThermalServiceKey(key)) {
CTD("[热写入] 丢弃 TC setServiceProperty %s (value=%p)", ((NSString *)key).UTF8String, (void *)value);
return NO;
}
return %orig(service, key, value, scale);
}
%end

// --- ApplePPMCPU: 兼容部分系统版本；当前主路径由 MitigationController 执行 ---
%hook ApplePPMCPU

// 修复：追踪实例，确保 keep-alive 能强制重应用（弱引用防止僵尸实例泄漏）
- (id)init {
id res = %orig;
if (res) {
trackApplePPMInstance(res);
}
return res;
}

- (void)setCPULevel:(int)level {
// 修复：每次调用都自注册实例，确保唤醒后重建的实例不被漏追踪
trackApplePPMInstance(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
// 性能模式: 直接阻断节流等级，ApplePPM 保持内核原生 DVFS 自由调频
return;
}
%orig;
}

- (void)updateCPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyLowPowerLimit()) {
if (self && [self respondsToSelector:CTObfSel("d2c86f714ad2e68be490c6839d531356")]) {
[self setCPULevel:CTLowPowerLevel()];
}
%orig;
return;
}
// 性能模式只在模式切换时清除 Level 2；后续放行原生 DVFS 更新。
%orig;
}

%end

// --- MitigationController: 功率目标控制 ---
%hook MitigationController

- (id)initForFastLoop:(BOOL)fastLoop noDisplay:(BOOL)noDisplay powerSaveParams:(id)saveParams powerZoneParams:(id)zoneParams {
id res = %orig(fastLoop, noDisplay, saveParams, zoneParams);
if (res) {
trackPowerController(res);
applyCurrentPowerModeToRuntime();
}
return res;
}

- (void)setCPMSMitigationsEnabled:(BOOL)enabled {
if (g_restoringFullPower) {
%orig(enabled);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(YES);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(enabled);
}

- (BOOL)powerSaveActive {
if (g_restoringFullPower) return %orig;
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return NO;
return %orig;
}

- (void)setPowerSaveActive:(BOOL)active {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(active);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(NO);
return;
}
%orig(active);
}

- (void)setPowerSaveToken:(int)token {
if (g_restoringFullPower) {
%orig(token);
return;
}
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) {
%orig(0);
return;
}
%orig(token);
}

// 性能模式: 直接阻断 CPU 节流等级写入（MitigationController 使用 0~100 百分比）。
- (void)setCPULevel:(int)level {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerLevel());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

// 性能模式: 直接阻断 CPU 温控缓解等级写入。
- (void)setCPUMitigationLevel:(int)level {
trackPowerController(self);
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(level);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)setDVD1Level:(int)level {
if (g_restoringFullPower) {
%orig(level);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(level);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kFullPowerCPULevel);
return;
}
%orig(level);
}

- (void)updateCPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyLowPowerLimit()) {
reassertLowPowerStateWithoutUpdate(self);
%orig;
reassertLowPowerStateWithoutUpdate(self);
return;
}
if (shouldApplyFullCPUProtection()) {
trackPowerController(self);
%orig;
return;
}
%orig;
}

- (void)updateGPU {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyFullCPUProtection()) {
%orig;
return;
}
%orig;
}

- (void)updatePackage {
if (g_restoringFullPower) {
%orig;
return;
}
if (shouldApplyFullCPUProtection()) {
%orig;
return;
}
%orig;
}

- (void)setCPULowPowerTarget:(int)target {
if (shouldApplyLowPowerLimit() && target != CTLowPowerBudgetMW()) {
CTD("★系统抢值 setCPULowPowerTarget 系统=%d → 我们强制=%d", target, CTLowPowerBudgetMW());
}
if (g_restoringFullPower) {
%orig(target);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerBudgetMW());
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPowerLimitMW);
return;
}
%orig(target);
}

- (void)setPackageLowPowerTarget {
if (g_restoringFullPower) {
%orig;
return;
}
// 两种用户模式都不允许 Package 低功耗联动；低功耗只由 CPU 专用 setter 实现。
if (shouldApplyLowPowerLimit() || shouldApplyFullCPUProtection()) return;
%orig;
}

- (void)setMaxCPUPowerTarget:(int)target useLegacyPath:(BOOL)legacy setProperty:(uintptr_t)property {
uintptr_t propertyArg = normalizedSetMaxCPUPowerPropertyArgument(self, property);
if (g_restoringFullPower) {
%orig(target, legacy, propertyArg);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(CTLowPowerBudgetMW(), NO, propertyArg);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPowerLimitMW, NO, propertyArg);
return;
}
%orig(target, legacy, propertyArg);
}

- (void)setCPUPowerCeiling:(int)ceiling fromDecisionSource:(uintptr_t)source {
if (g_restoringFullPower) {
%orig(ceiling, source);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent, source);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, source);
return;
}
%orig(ceiling, source);
}

- (void)setCPUPowerCeiling:(int)ceiling forDVD1Contributor:(int)contributor {
if (g_restoringFullPower) {
%orig(ceiling, contributor);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent, contributor);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent, contributor);
return;
}
%orig(ceiling, contributor);
}

- (void)setCPUPowerFloor:(int)floor fromDecisionSource:(uintptr_t)source {
if (g_restoringFullPower) {
%orig(floor, source);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(0, source);
return;
}
if (shouldApplyFullCPUProtection()) {
// Ceiling 保持 100，但 Floor 固定为 0，让无负载核心进入原生空闲频点。
%orig(0, source);
return;
}
%orig(floor, source);
}

- (void)setCPUPowerZoneTarget:(int)target {
if (g_restoringFullPower) {
%orig(target);
return;
}
if (shouldApplyLowPowerLimit()) {
%orig(kLowPowerPerformancePercent);
return;
}
if (shouldApplyFullCPUProtection()) {
%orig(kUnrestrictedPerformancePercent);
return;
}
%orig(target);
}

%end

// ============================================================================
// 防温控暗屏 — 修补热配置 plist 中的背光参数
// 由 thermalPreventDimmingEnabled 开关控制
// ============================================================================

// 取表内"最高档"元素（兼容 数值/字符串/字典/数组）
static id CTHermesMaximumElementOfBacklightArray(NSArray *source) {
    id best = nil;
    double bestValue = 0.0;
    for (id element in source) {
        double v = CTHermesMaximumNumericInValue(element);
        if (v > bestValue) { bestValue = v; best = element; }
    }
    return best;
}

// 填充背光表时使用的目标值：优先用本机已发现的真实亮度上限（nits 空间），
// 避免"表内最高档"本身仍低于面板能力（例如表内最高只有 337，面板却支持 1060）。
static NSNumber *CTHermesBacklightFillValue(void) {
    if (!g_maxBacklightBrightnessValue) CTHermesCaptureExistingBacklightMaximum();
    if (g_maxBacklightBrightnessValue &&
        [g_maxBacklightBrightnessValue doubleValue] >= kCTHermesMinimumPlausibleBacklightLimit)
        return g_maxBacklightBrightnessValue;
    return nil;
}

// ★ 2026-09-29（对照老源码修复）：用"表内最高档"填充（而不是旧实现的"首个元素"）——
//   旧实现把表内首档（可能低至 163.3）直接赋给上限，随后被写进 DCP 亮度限制节点锁死屏幕。
static NSMutableArray *CTHermesMaximizeBacklightArray(NSArray *source) {
    if (![source isKindOfClass:[NSArray class]] || source.count == 0) return nil;
    id best = CTHermesMaximumElementOfBacklightArray(source);
    if (!best) return nil;
    double bestValue = CTHermesMaximumNumericInValue(best);
    id replacement = [best copy];
    // 数值型表：若已知真实上限高于表内最高档，直接用真实上限。
    // 字典型表（{level,down,up}）保持结构，只整体抬到最高档。
    NSNumber *fill = CTHermesBacklightFillValue();
    if (fill && [best isKindOfClass:[NSNumber class]] && [fill doubleValue] > bestValue)
        replacement = [fill copy];
    // 表内最高档也参与"原生上限"学习（低于 400 nits 会被过滤掉）。
    if (bestValue > 0.0) CTHermesRememberBacklightMaximum(@(bestValue));
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:source.count];
    for (NSUInteger i = 0; i < source.count; i++) [result addObject:replacement];
    return result;
}

static BOOL CTHermesIsDisplayMitigationKey(NSString *key);
static id CTHermesZeroDisplayMitigationValue(id original);

static void CTHermesPatchBacklightControl(NSMutableDictionary *backlight) {
    if (![backlight isKindOfClass:[NSMutableDictionary class]]) return;
    NSArray *brightness = [backlight[S("BacklightBrightness")] isKindOfClass:[NSArray class]]
        ? backlight[S("BacklightBrightness")] : nil;
    NSMutableArray *brightnessPatched = CTHermesMaximizeBacklightArray(brightness);
    if (brightnessPatched) {
        backlight[S("BacklightBrightness")] = brightnessPatched;
        // ★ 2026-09-29（对照老源码修复）：只允许"调整"观测到的原生上限——
        //   旧实现直接把表内首档赋给 cap，随后被写进 DCP 亮度限制节点锁死屏幕。
        double peak = CTHermesMaximumNumericInValue(brightnessPatched.firstObject);
        if (peak > 0.0) CTHermesRememberBacklightMaximum(@(peak));
    }
    NSArray *power = [backlight[S("BacklightPower")] isKindOfClass:[NSArray class]]
        ? backlight[S("BacklightPower")] : nil;
    NSMutableArray *powerPatched = CTHermesMaximizeBacklightArray(power);
    if (powerPatched) backlight[S("BacklightPower")] = powerPatched;
    backlight[S("expectsCPMSSupport")] = [NSNumber numberWithBool:NO];
    backlight[S("maxThermalPower")] = [NSNumber numberWithInt:kUnrestrictedPowerLimitMW];
    backlight[S("minThermalPower")] = [NSNumber numberWithInt:kUnrestrictedPowerLimitMW];
    for(id rawKey in [backlight.allKeys copy]) if([rawKey isKindOfClass:[NSString class]] && CTHermesIsDisplayMitigationKey(rawKey))
        backlight[rawKey]=CTHermesZeroDisplayMitigationValue(backlight[rawKey]);
    CTHermesScheduleBacklightRecovery();
}

static BOOL CTHermesIsDisplayMitigationKey(NSString *key) {
    if (![key isKindOfClass:[NSString class]]) return NO;
    const char *keys[]={"needsPushingTSFDtoDisplayDriver","displayBrightnessMitigation","displayMitigation","eventDimmingEnabled","needsContextualClamp","shouldEnforceLightThermalPressure","shouldEnforceThermalPressure","thermalPressureMitigation","performanceMitigation",NULL};
    for(int i=0;keys[i];i++)if([key caseInsensitiveCompare:S(keys[i])]==NSOrderedSame)return YES;
    return NO;
}

static id CTHermesZeroDisplayMitigationValue(id original) {
    if ([original isKindOfClass:[NSString class]]) return S("0");
    if ([original isKindOfClass:[NSNumber class]]) return [NSNumber numberWithInt:0];
    return original;
}

// ★ 2.0.38：递归/环保护——本函数现在也会用于"运行时对象"（自寻挂载后的首用场景），
//   统一加"深度封顶"（12 层），任何异常结构都不可能造成失控递归。
static id CTHermesPatchBacklightNodeDepth(id node, int depth) {
    if (depth <= 0) return node;
    if ([node isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *result = [(NSDictionary *)node mutableCopy];
        for (id rawKey in [(NSDictionary *)node allKeys]) {
            id value = [(NSDictionary *)node objectForKey:rawKey];
            if ([rawKey isKindOfClass:[NSString class]] && CTHermesIsDisplayMitigationKey(rawKey)) {
                result[rawKey]=CTHermesZeroDisplayMitigationValue(value);
                continue;
            }
            if ([rawKey isKindOfClass:[NSString class]] &&
                [(NSString *)rawKey caseInsensitiveCompare:S("backlightComponentControl")] == NSOrderedSame &&
                [value isKindOfClass:[NSDictionary class]]) {
                NSMutableDictionary *backlight = [value mutableCopy];
                CTHermesPatchBacklightControl(backlight);
                result[rawKey] = backlight;
            } else {
                result[rawKey] = CTHermesPatchBacklightNodeDepth(value, depth - 1) ?: value;
            }
        }
        return result;
    }
    if ([node isKindOfClass:[NSArray class]]) {
        NSMutableArray *result = [NSMutableArray arrayWithCapacity:[node count]];
        for (id value in node) [result addObject:CTHermesPatchBacklightNodeDepth(value, depth - 1) ?: value];
        return result;
    }
    return node;
}
static id CTHermesPatchBacklightNode(id node) { return CTHermesPatchBacklightNodeDepth(node, 12); }

static NSDictionary *patchThermalPlist(NSDictionary *dict) {
    g_ctPatchN = (g_ctPatchN < 255) ? (g_ctPatchN + 1) : 255;   // 自测增强：补丁执行计数
    if (![dict isKindOfClass:[NSDictionary class]] || !thermalDimmingPreventionEnabled()) return dict;
    // DeviceMonitor 的 _getConfigurationFor 可能直接返回 backlightComponentControl 子字典。
    if ([dict[S("BacklightBrightness")] isKindOfClass:[NSArray class]]) {
        NSMutableDictionary *direct = [dict mutableCopy];
        CTHermesPatchBacklightControl(direct);
        return direct;
    }
    id patched = CTHermesPatchBacklightNode(dict);
    return [patched isKindOfClass:[NSDictionary class]] ? patched : dict;
}

// ============================================================================
// %hook: NSDictionary — 拦截热配置 plist 加载，应用防暗屏补丁
// ============================================================================
%hook NSDictionary

+ (id)dictionaryWithContentsOfFile:(id)path {
id res = %orig(path);
if (thermalDimmingPreventionEnabled() &&
    [path isKindOfClass:[NSString class]] && [path containsString:S("/System/Library/ThermalMonitor")]) {
if ([res isKindOfClass:[NSDictionary class]]) {
NSDictionary *patched = patchThermalPlist(res);
return patched;
}
}
return res;
}

%end

// ============================================================================
// C 函数钩子: _getConfigurationFor → ___New_getConfigurationFor___
//
// 在 thermalmonitord 初始化时，会调用 _getConfigurationFor(NSString*)
// 来获取热配置字典。通过返回修改后的配置，可以影响所有热管理参数。
// ============================================================================

// 原函数类型: NSDictionary* _getConfigurationFor(NSString *key)
static NSDictionary* (*orig_getConfigurationFor)(NSString *key) = NULL;

// _getConfigurationFor 替换实现：调用原始函数后应用热配置补丁（防温控暗屏）
static NSDictionary *new_getConfigurationFor(NSString *key) {
    NSDictionary *config = orig_getConfigurationFor ? orig_getConfigurationFor(key) : nil;
    return patchThermalPlist(config);
}

static void onPowerModeChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTHermesSyncModeFromPrefs(); });   // ★加速
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTHermesSyncModeFromPrefs(); });   // ★加速
dispatch_block_t block = ^{
if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
// ★ 修复（2026-09-17）：模式判定一律以【设置文件】为准，不再读"通知状态缓存"——
//   该缓存在重启/长期未写时会回 0（=高性能），与设置文件互相对冲（低功耗 ↔ 高性能每 2 秒来回拨）。
NSDictionary *prefs = readPrefsDictionary();
id rawMode = [prefs isKindOfClass:[NSDictionary class]] ? prefs[S("powerMode")] : nil;
// ★ T7v：模式切换（CC/设置页只发 powerModeChanged）必须同步刷新"智能模式"标志——
//   否则从智能切到低功耗/性能模式后会继续跑智能逻辑（表现为"切换失效"）。
// ★ T7x3：只有确实读到模式字符串才刷新——一次读取失败不能把智能关掉（否则解析退回高性能 →"高性能乱跳"）
if ([rawMode isKindOfClass:[NSString class]]) {
    g_smartEnabled = [rawMode isEqualToString:S(kCTHermesSmartModeC)];
}
CTHermesPowerMode selected;
if ([rawMode isKindOfClass:[NSString class]]) {
selected = [rawMode isEqualToString:S("lowPower")] ? CTHermesPowerModeLow : CTHermesPowerModeFull;
} else {
os_unfair_lock_lock(&g_modeLock);
selected = g_userSelectedPowerMode;   // 读不到 → 保持当前，绝不默认高性能
os_unfair_lock_unlock(&g_modeLock);
}
// ★ 2026-09-17 加固：唤醒/解锁保护窗（8 秒）内：只记录用户模式，不重算运行模式（与 sync-prefs 行为一致）——
//   否则"兜底映射"会在窗口内每 2 秒把锁屏前的名单 App 顶回来，和正确的"降回低功耗"来回打架。
if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
os_unfair_lock_lock(&g_modeLock);
g_userSelectedPowerMode = selected;
os_unfair_lock_unlock(&g_modeLock);
CTD("[窗口] notify-sync: 唤醒窗口内只记用户模式（%s），不重算", selected == CTHermesPowerModeLow ? "低功耗" : "高性能");
return;
}
BOOL blanked = CTHermesScreenIsBlanked();
BOOL appLowPower = foregroundAppListHit(selected, prefs);
CTHermesPowerMode previous;
os_unfair_lock_lock(&g_modeLock);
previous = g_powerMode;
g_userSelectedPowerMode = selected;
g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("notify-sync", appLowPower);
CTAuditMode("notify-sync", CTHermesResolveTargetMode(selected, blanked, appLowPower));
CTHermesPowerMode runtimeMode = g_powerMode;
os_unfair_lock_unlock(&g_modeLock);
if (previous != runtimeMode) {
applyPowerModeToRuntime(NO);
// 低→解除改为完整软恢复；重启会中断 3 秒 DCP/亮度恢复任务。
}
CTLOG(S("[CTHermes] 用户模式已选择:%@，当前屏幕:%@，运行模式:%@"),
      selected == CTHermesPowerModeLow ? S("低功耗") : S("性能模式"),
      blanked ? S("熄屏") : S("亮屏"),
      runtimeMode == CTHermesPowerModeLow ? S("低功耗") : S("性能模式"));
};
if ([NSThread isMainThread]) block();
else dispatch_async(dispatch_get_main_queue(), block);
}

static void onSettingsChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    CTAuthRefresh();   // ★ 激活码变更即时生效
    CTHermesReloadLowPowerPreset(CTHermesReadPrefs());
dispatch_block_t block = ^{
BOOL wasEnabled = runtimeEnabled();
BOOL previousPreventDimming = g_thermalPreventDimmingEnabled;
loadPrefs();
BOOL enabled = NO;
BOOL cpuProtection = NO;
BOOL blockPopup = NO;
BOOL preventDimming = NO;
runtimeConfigSnapshot(&enabled, &cpuProtection, NULL, &blockPopup, &preventDimming);
if (enabled) applyPowerModeToRuntime(NO);
else if (wasEnabled) restoreNativeRuntimeAfterDisable();
// 低→解除由软恢复完成；仅防暗屏设置本身变化时才重载配置。
if (previousPreventDimming != g_thermalPreventDimmingEnabled) scheduleThermalConfigurationReload();
CTLOG(S("[CTHermes] 设置已重载 enabled:%d CPU:%d 弹窗:%d 防暗屏:%d DVFS:原生 level:%d"),
enabled, cpuProtection, blockPopup, preventDimming, targetCPUPerformanceLevel());
};
if ([NSThread isMainThread]) block();
else dispatch_async(dispatch_get_main_queue(), block);
}

// 退出指定应用去抖：SpringBoard 的 100ms 轮询在应用启动、转场、全屏视频切换
// 等瞬间可能返回 nil 或上一个应用，直接采信就会出现"刚生效马上失效"。退出统一
// 延迟 1.5 秒，并在触发时按最新状态二次确认；中途回到指定应用则自动作废。
static void scheduleForegroundExitApply(void) {
    if (g_foregroundExitPending) return;
    g_foregroundExitPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{   // ★加速：退出去抖 1.5s→0.6s
        g_foregroundExitPending = NO;
        @autoreleasepool {
            if (CTHermesScreenIsBlanked()) return;   // ★ 熄屏/锁屏：不撤销，留到亮屏后再判断
            NSDictionary *prefs = readPrefsDictionary();
            if (foregroundAppListHit(CTHermesSelectedModeFromPrefs(prefs), prefs)) return; // 已回到名单内应用，保持现状
            // ★★ 唤醒后 10 秒内：前台报成"锁屏界面/桌面(SpringBoard)"或读不到 → 一律不撤销。
            //    这两个值是解锁瞬间最常见的"假前台"，之前就是它把 QQ 的低功耗例外误撤销掉。
            // ★ 统一规则 + 连续确认 3 秒：只有"另一个真实 App 被持续激活"才允许撤销
            if (!CTHermesForegroundAllowsModeChange()) return;
            {
                static CFAbsoluteTime sOtherAppFirstSeen = 0.0;
                CFAbsoluteTime ctNowT = CFAbsoluteTimeGetCurrent();
                if (sOtherAppFirstSeen == 0.0) { sOtherAppFirstSeen = ctNowT; scheduleForegroundExitApply(); return; }
                if ((ctNowT - sOtherAppFirstSeen) < 3.0) { scheduleForegroundExitApply(); return; }
                sOtherAppFirstSeen = 0.0;
            }
            BOOL blanked = CTHermesScreenIsBlanked();
            CTHermesPowerMode previous;
            CTHermesPowerMode target;
            os_unfair_lock_lock(&g_modeLock);
            previous = g_powerMode;
            g_foregroundAppForcesLowPower = NO; CTAuditFlag("exit-debounce", NO);
            target = CTHermesResolveTargetMode(g_userSelectedPowerMode, blanked, NO);
            CTAuditMode("exit-debounce", target);
            os_unfair_lock_unlock(&g_modeLock);
            CTLOG(S("[CTHermes] 退出指定应用(去抖确认) 运行模式:%@"),
                  target == CTHermesPowerModeLow ? S("低功耗") : (target == CTHermesPowerModeFull ? S("高性能") : S("原生")));
            if (previous != target) applyPowerModeToRuntime(NO);
        }
    });
}

// 前台状态统一评估入口：进入指定应用立即生效；退出走 1.5s 去抖确认。
static void applyForegroundDecision(const char *reason) {
    if (g_softSwingActive) return;   // ★ 自愈摆动期间冻结重算
    // ★★ 唤醒/解锁后 8 秒内：解锁瞬间前后系统报的前台不可信（锁屏界面或旧 App），
    //     此时不接受任何前台变化，沿用"锁屏前的模式"，避免把名单方向判反。
    if (g_lastWakeStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_lastWakeStamp) < 8.0) {
        g_lastAppliedForegroundHash = CTHermesReadForegroundBundleHash();
        return;
    }
    uint64_t foregroundHash = CTHermesReadForegroundBundleHash();
    // ★ T7u：系统组件（小组件渲染器等）误报为前台 → 忽略，保持当前模式
    if (foregroundHash == CTHermesBundleIDHash(S("com.apple.chrono.WidgetRenderer-Default"))) {
        static int ctCompIgnored = 0;
        if (ctCompIgnored < 3) { ctCompIgnored++; CTD("[前台] 系统组件（WidgetRenderer）误报 → 忽略（保持当前模式）"); }
        g_lastAppliedForegroundHash = foregroundHash;
        return;
    }
    // ★ T7v/269：fg=0 防抖（v2）——"切 App 瞬间"的假"无应用"必须自己撑满 0.75 秒才生效；
    //   无残留状态（修掉 v1 的 confirmed 泄漏：特殊时序下假 0 会"直通"→模式反复放行="应用全高性能"）。
    {
        static CFAbsoluteTime sCtT7vZeroSince = 0;
        static int sCtT7vZeroGen = 0;
        if (foregroundHash == 0 && !CTHermesScreenIsBlanked()) {
            CFAbsoluteTime ctNowZ = CFAbsoluteTimeGetCurrent();
            if (sCtT7vZeroSince == 0) sCtT7vZeroSince = ctNowZ;
            if ((ctNowZ - sCtT7vZeroSince) >= 0.40) {     // ★ 270：去抖 0.75→0.40 秒（回桌面/多任务响应更快；读空小抖已在源头被顶住）
                // 已持续 ≥0.75 秒：确认无应用，落下面正常流程（0 → 原生）
            } else {
                int ctGen = ++sCtT7vZeroGen;
                double ctWait = (sCtT7vZeroSince + 0.40) - ctNowZ;
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ctWait * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (ctGen != sCtT7vZeroGen) return;
                    if (CTHermesReadForegroundBundleHash() != 0) return;
                    applyForegroundDecision("zero-confirm");
                });
                g_lastAppliedForegroundHash = foregroundHash;
                return;
            }
        } else {
            sCtT7vZeroSince = 0;
            sCtT7vZeroGen++;
        }
    }
    NSDictionary *prefs = readPrefsDictionary();
    BOOL appLowPower = foregroundAppListHit(CTHermesSelectedModeFromPrefs(prefs), prefs);
    BOOL blanked = CTHermesScreenIsBlanked();
    CTHermesPowerMode previous;
    CTHermesPowerMode target;
    BOOL wasAppDriven = NO;
    os_unfair_lock_lock(&g_modeLock);
    previous = g_powerMode;
    wasAppDriven = g_foregroundAppForcesLowPower;
    // ★ 熄屏/锁屏期间：一律不做"退出指定 App"的撤销（屏幕黑着不算退出），把状态留到亮屏后再重算
    if (blanked && wasAppDriven) {
        os_unfair_lock_unlock(&g_modeLock);
        g_lastAppliedForegroundHash = foregroundHash;
        return;
    }
    if (!appLowPower && !blanked && wasAppDriven && CTHermesForegroundAllowsModeChange()) {
        // ★★ 终极规则：只有"前台真的变成了另一个真实 App"才允许撤销名单例外。
        //    0（读不到）和 SpringBoard（锁屏界面/桌面）都视为"不确定" → 保持不变。
        //    —— 用户的实测规律：切出 App 再切回来就正确，说明"切换"是可靠信号，"模糊的前台"不是。
        if (foregroundHash == 0 || foregroundHash == CTHermesBundleIDHash(S("com.apple.springboard"))) {
            os_unfair_lock_unlock(&g_modeLock);
            g_lastAppliedForegroundHash = foregroundHash;
            return;
        }
        // 前台确实换成了别的真实 App → 交给去抖确认（去抖里还会再查一次名单）
        os_unfair_lock_unlock(&g_modeLock);
        g_lastAppliedForegroundHash = foregroundHash;
        scheduleForegroundExitApply();
        return;
    }
    g_foregroundAppForcesLowPower = appLowPower; CTAuditFlag("fg-decision", appLowPower);
    if (appLowPower && foregroundHash != 0) g_exceptionAppHash = foregroundHash;   // ★ 记住是谁触发的例外
    target = CTHermesResolveTargetMode(g_userSelectedPowerMode, blanked, appLowPower);
    CTAuditMode("fg-decision", target);
    os_unfair_lock_unlock(&g_modeLock);
    g_lastAppliedForegroundHash = foregroundHash;
    // 诊断日志：前台哈希 / 指定应用命中 / 最终运行模式，便于确认检测链路是否正常。
    CTLOG(S("[CTHermes] 前台状态(%s) hash=%llu 名单命中:%d 熄屏:%d 运行模式:%@"),
          reason ?: "event", (unsigned long long)foregroundHash, appLowPower, blanked,
          target == CTHermesPowerModeLow ? S("低功耗") : (target == CTHermesPowerModeFull ? S("高性能") : S("原生")));
    // 模式真正变化时才做完整切换；仅"心跳重申"（仍在指定应用但模式未变）时走轻量路径
    // 重申预算即可，避免每 2 秒重复整套切换（亮度捕获/脉冲/亮度恢复）。
    if (previous != target) {
        applyPowerModeToRuntime(NO);
    } else if (appLowPower) {
        applyLowPowerToCommonProduct();
        applyLowPowerLimitsToTrackedControllers();
        applyCurrentModeToApplePPMCPU();
    }
}

static void onForegroundAppChanged(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
    (void)center; (void)observer; (void)name; (void)object; (void)userInfo;
    @autoreleasepool {
        applyForegroundDecision("notify");
    }
}

// ★ 2.0.1：提速信号"双通道"共用处理器——滑动通道（"滑动时自动提速"）与开合通道（"开合 App 提速"）
//   共用同一套窗口逻辑（单引擎、多来源）：谁先到谁开窗，另一个只负责续期；打开/收尾/保险丝全部沿用原逻辑。
static void ctBoostSignalArrived(void) {
    // ★ 1.4.124：校准探针——"信号到达（新一波）"/"被忽略原因"留痕，用于对齐前台触发时刻、定位提速延迟
    {
        static CFAbsoluteTime sCtPingLastAt = 0;
        CFAbsoluteTime ctPingNow = CFAbsoluteTimeGetCurrent();
        if (ctPingNow - sCtPingLastAt > 1.5) CTD("[滑动] 提速信号到达（新一波）");
        sCtPingLastAt = ctPingNow;
    }
    g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();      // ★ T7z6：滑动/开合也算"用户操作"
    if (g_ctVideoActive && g_ctVideoOptEnabled) {          // ★ T7z6：视频档期间不提速（省电）
        static CFAbsoluteTime sCtVidSkipAt = 0;
        CFAbsoluteTime ctVidNow = CFAbsoluteTimeGetCurrent();
        if (ctVidNow - sCtVidSkipAt > 5.0) { sCtVidSkipAt = ctVidNow; CTD("[滑动] 提速信号被忽略（视频档）"); }
        return;
    }
    CFAbsoluteTime ctNowB = CFAbsoluteTimeGetCurrent();
    g_scrollBoostUntil = ctNowB + 0.6;   // ★ T7x2：回落判决窗口 0.9→0.6 秒（停手后更快回落）
    static CFAbsoluteTime sCtBoostLastApply = 0;   // ★ T7x：上次"提到高性能"时刻（持续滑动时定期重申）
    static CFAbsoluteTime sCtBoostBegan = 0;       // ★ T7x2：本次提速开始时刻（结束日志里带"持续 x.xs"，方便看是微触发还是真滑动）
    if (!g_scrollBoostActive) {
        if (!isLowPowerMode() && !isNativeMode()) return;   // ★ 270：低功耗或原生都可立即放行（原生时释放=无害）；高性能模式不动
        g_scrollBoostActive = YES;
        g_ctDeepIdleActive = NO;    // ★ T7z6：提速开始 → 退出深度档
        ctScrollBoostApplyPass();   // ★ 270：临时"提到高性能"（比只放开更跟手）
        sCtBoostLastApply = ctNowB;
        sCtBoostBegan = ctNowB;
        CTD("[滑动] 升频开始（临时提高性能，模式名义不变）");
    } else if (isLowPowerMode() && (ctNowB - sCtBoostLastApply) >= 0.60) {
        // ★ T7x：持续滑动中每 0.6 秒重申一次（防任何回写，跟手保障）
        sCtBoostLastApply = ctNowB;
        ctScrollBoostApplyPass();
    }
    static int sCtBoostGen = 0;
    sCtBoostGen++;
    int ctGen = sCtBoostGen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{   // ★ T7x2：检查间隔 1.0→0.75 秒
        if (ctGen != sCtBoostGen) return;
        if (CFAbsoluteTimeGetCurrent() < g_scrollBoostUntil) return;
        // ★ 1.4.126：操作期不收——停手满 2.5 秒才允许收（收口统一交给"操作结束回落"）
                //   ★ 2.0.2：收口门槛 2.5→1.5 秒
        if (g_ctLastActivityAt > 0 && (CFAbsoluteTimeGetCurrent() - g_ctLastActivityAt) < 1.5) return;
        if (g_scrollBoostActive) {
            g_scrollBoostActive = NO;
            double ctBoostDur = CFAbsoluteTimeGetCurrent() - sCtBoostBegan;
            if (isLowPowerMode()) {
                applyPowerModeToRuntime(NO);
                CTD("[滑动] 升频结束（静默压回低功耗，持续 %.1fs）", ctBoostDur);
            } else {
                ctNativeReleasePass();
                CTD("[滑动] 升频结束（交还系统，持续 %.1fs）", ctBoostDur);
            }
        }
    });
}

// ============================================================================
// ★ 2.0.48：浮窗"位置环线"——核心侧（root 代写 + 回传）
//   客户机 16 实证：SpringBoard 侧浮窗组件写不出任何文件（日志 [浮窗] 记录 0 条），
//   但通知通道可用（心跳实锤）。⇒ 位置经通知进核心（root 能写），并回传供启动落位。
static double gCtWBPX = 0.0, gCtWBPY = 0.0;
static int    gCtWBLock = 0;
static BOOL   gCtWBHave = NO;

static BOOL CTCoreWinPosLoad(void) {
    if (gCtWBHave) return YES;
    NSString *s = CTFloatReadNewest(S("CTHermesFloat.pos"), NULL);
    if (!s.length) return NO;
    NSArray *a = [s componentsSeparatedByString:S(",")];
    if (a.count < 2) return NO;
    double x = [a[0] doubleValue], y = [a[1] doubleValue];
    if (x < 1.0 || y < 1.0) return NO;
    gCtWBPX = x; gCtWBPY = y;
    gCtWBLock = (a.count >= 3 && [a[2] boolValue]) ? 1 : 0;
    gCtWBHave = YES;
    return YES;
}
static void CTCoreWinPosBcast(void) {
    if (!CTCoreWinPosLoad()) return;
    CTPosBusSend(CT_POSBUS_CH_BCAST, CTPosBusPack(gCtWBPX, gCtWBPY, gCtWBLock));
}
static void CTCoreWinPosStore(double x, double y, int lk) {
    if (x < 1.0 || y < 1.0) return;
    gCtWBPX = x; gCtWBPY = y; gCtWBLock = lk; gCtWBHave = YES;
    NSString *s = [NSString stringWithFormat:S("%.1f,%.1f,%d"), x, y, lk];
    if (CTFloatWriteAll(S("CTHermesFloat.pos"), s))
        CTD("[浮窗·代写] 收到位置并落盘 (%.0f,%.0f) 锁=%d", x, y, lk);
    else
        CTD("[浮窗·代写] 落盘失败（自报目录不可写？）(%.0f,%.0f)", x, y);
}
// ★ 2.0.49：横屏位同款（保存=x,y,"手设"标记）
static double gCtWBLX = 0.0, gCtWBLY = 0.0;
static int    gCtWBLSet = 0;
static BOOL   gCtWBLHave = NO;
static BOOL CTCoreWinPosLoadLand(void) {
    if (gCtWBLHave) return YES;
    NSString *s = CTFloatReadNewest(S("CTHermesFloat.land"), NULL);
    if (!s.length) return NO;
    NSArray *a = [s componentsSeparatedByString:S(",")];
    if (a.count < 3) return NO;
    double x = [a[0] doubleValue], y = [a[1] doubleValue];
    if (x < 1.0 || y < 1.0) return NO;
    gCtWBLX = x; gCtWBLY = y; gCtWBLSet = [a[2] boolValue] ? 1 : 0;
    gCtWBLHave = YES;
    return YES;
}
static void CTCoreWinPosBcastLand(void) {
    if (!CTCoreWinPosLoadLand()) return;
    CTPosBusSend(CT_POSBUS_CH_BCAST_L, CTPosBusPack(gCtWBLX, gCtWBLY, gCtWBLSet));
}
static void CTCoreWinPosStoreLand(double x, double y, int us) {
    if (x < 1.0 || y < 1.0) return;
    gCtWBLX = x; gCtWBLY = y; gCtWBLSet = us; gCtWBLHave = YES;
    NSString *s = [NSString stringWithFormat:S("%.1f,%.1f,%d"), x, y, us];
    if (CTFloatWriteAll(S("CTHermesFloat.land"), s))
        CTD("[浮窗·代写] 收到横屏位并落盘 (%.0f,%.0f) 手设=%d", x, y, us);
    else
        CTD("[浮窗·代写] 横屏位落盘失败（自报目录不可写？）(%.0f,%.0f)", x, y);
}
// ★ 2.0.111：菜单档位「通知通道代写」——核心侧收单（root 落盘；零文件）
static int gTierBusGoTok = -1;
static void CTMenuBusCoreInit(void) {
    if (gTierBusGoTok >= 0) return;
    notify_register_dispatch(CT_TIERBUS_GO, &gTierBusGoTok, dispatch_get_global_queue(0, 0), ^(int t) {
        (void)t;
        @try {
            uint64_t meta = CTTierBusGetChannel(CT_TIERBUS_META);
            int len = (int)(meta & 0xFF);
            int code = (int)((meta >> 8) & 0xFF);
            if (len <= 0 || len > 63) return;
            char buf[80];
            for (int i = 0; i < 8; i++) {
                uint64_t w = CTTierBusGetWord(i);
                for (int k = 0; k < 8; k++) buf[i * 8 + k] = ((const char *)&w)[k];
            }
            buf[len] = 0;
            NSString *bundle = [NSString stringWithUTF8String:buf];
            if (!bundle.length) return;
            NSString *val = (code == 1) ? S("full") : ((code == 2) ? S("low") : ((code == 3) ? S("native") : S("auto")));
            NSMutableDictionary *prefs = CTHermesReadMutablePrefs() ?: [NSMutableDictionary dictionary];
            NSMutableDictionary *tiers = [prefs[S("appTiers")] isKindOfClass:[NSDictionary class]] ? [prefs[S("appTiers")] mutableCopy] : [NSMutableDictionary dictionary];
            if ([val isEqualToString:S("auto")]) [tiers removeObjectForKey:bundle];
            else if (bundle.length) tiers[bundle] = val;
            prefs[S("appTiers")] = tiers;
            prefs[S("appTiersMigrated")] = @YES;
            BOOL ok = CTHermesWritePrefs(prefs);
            notify_post(kCTHermesSettingsChangedNotifC);
            CTD("[菜单·代写] 通知通道落盘 %s → %s（写入=%d）", bundle.UTF8String ?: "?", val.UTF8String ?: "?", ok ? 1 : 0);
        } @catch (__unused NSException *e) {}
    });
}

static void CTWinPosBusCoreInit(void) {
    static int sPB1 = -1;
    if (sPB1 >= 0) return;
    notify_register_dispatch(CT_POSBUS_CH_SAVE, &sPB1, dispatch_get_global_queue(0, 0), ^(int t) {
        uint64_t st = 0;
        if (notify_get_state(t, &st) != NOTIFY_STATUS_OK || st == 0) return;
        double x = 0, y = 0; int lk = 0;
        CTPosBusUnpack(st, &x, &y, &lk);
        CTCoreWinPosStore(x, y, lk);
    });
    {   static int sPB2 = -1;
        notify_register_dispatch(CT_POSBUS_CH_REQ, &sPB2, dispatch_get_global_queue(0, 0), ^(int t) {
            (void)t;
            CTCoreWinPosBcast();
            CTCoreWinPosBcastLand();   // ★ 2.0.49：横屏位一并回传
            if (gCtWBHave) CTD("[浮窗·代写] 窗口请求取位 → 已回传 (%.0f,%.0f)", gCtWBPX, gCtWBPY);
        });
    }
    {   static int sPB4 = -1;
        notify_register_dispatch(CT_POSBUS_CH_SAVE_L, &sPB4, dispatch_get_global_queue(0, 0), ^(int t) {
            uint64_t st = 0;
            if (notify_get_state(t, &st) != NOTIFY_STATUS_OK || st == 0) return;
            double x = 0, y = 0; int us = 0;
            CTPosBusUnpack(st, &x, &y, &us);
            CTCoreWinPosStoreLand(x, y, us);
        });
    }
    {   static int sPB3 = -1;
        notify_register_dispatch(CT_POSBUS_CH_ACT, &sPB3, dispatch_get_global_queue(0, 0), ^(int t) {
            uint64_t st = 0;
            if (notify_get_state(t, &st) != NOTIFY_STATUS_OK) return;
            int code = (int)(st >> 56);
            uint64_t pl = st & 0x00FFFFFFFFFFFFFFULL;
            double x = 0, y = 0;
            CTPosBusUnpack(pl, &x, &y, NULL);
            if (code == (int)CT_POSBUS_ACT_SAVED) CTD("[浮窗·转报] 保存=成功（窗口文件可写）(%.0f,%.0f)", x, y);
            else if (code == (int)CT_POSBUS_ACT_SAVEFAIL) CTD("[浮窗·转报] 保存=窗口文件全不可写（环线已兜）(%.0f,%.0f)", x, y);
            else if (code == (int)CT_POSBUS_ACT_LOADBUS) CTD("[浮窗·转报] 启动取位=通知回传命中 (%.0f,%.0f)", x, y);
            else if (code == (int)CT_POSBUS_ACT_SAVED_L) CTD("[浮窗·转报] 横屏位保存=成功（窗口文件可写）(%.0f,%.0f)", x, y);
            else if (code == (int)CT_POSBUS_ACT_SAVEFAIL_L) CTD("[浮窗·转报] 横屏位保存=窗口文件全不可写（环线已兜）(%.0f,%.0f)", x, y);
            else if (code == (int)CT_POSBUS_ACT_LOADBUS_L) CTD("[浮窗·转报] 横屏取位=通知回传命中 (%.0f,%.0f)", x, y);
        });
    }
}

// ============================================================================
// ★ 2.0.39：监听"浮窗心跳"——SpringBoard 侧每 30 秒一次 notify 广播；
//   收到即证明"浮窗组件活着"（文件日志写不进时的兜底取证，16/17 通用）。
static void CTWinBeatWatchInit(void) {
    static int sWBTok = -1;
    if (sWBTok >= 0) return;
    notify_register_dispatch("com.qq391160.cpucore/winbeat", &sWBTok, dispatch_get_global_queue(0, 0), ^(int t) {
        (void)t;
        static int sWBN = 0; static CFAbsoluteTime sWBLast = 0;
        sWBN++;
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (sWBLast <= 0.0 || now - sWBLast > 600.0) {
            sWBLast = now;
            CTD("[浮窗心跳] 收到第 %d 次（浮窗组件活着 ✓）", sWBN);
        }
        CTCoreWinPosBcast();   // ★ 2.0.48：顺手把"最后已知位置"回喊一声（浮窗靠它落位）
        CTCoreWinPosBcastLand();   // ★ 2.0.49：横屏位一并回喊
    });
}

// ★ 2.0.40：根侧"重置授权"执行器——设置页是 mobile，删不了 root 的票根/文件；由 root 引擎当代手
static void CTAuthResetExec(void) {
    sCTLastGoodCode = nil;   // ★ 2.0.41：连进程内存备份一起清（否则会"内存兜底"把授权码写回来 = 自动恢复）
    @try {
        // ★ 2.0.110b：先把配置里的授权码清掉（根进程权威清；防"清文件后又被配置读回重新授权+回写票根"）
        NSMutableDictionary *__rp = [[CTHermesReadPrefs() mutableCopy] ?: [NSMutableDictionary dictionary] mutableCopy];
        if (__rp[kCTKeyActivationCode]) {
            [__rp removeObjectForKey:kCTKeyActivationCode];
            CTHermesWritePrefsReplace(__rp);   // ★ 2.0.111
        }
        CTAuthRemoveAllPaths();
        NSFileManager *__rfm = [NSFileManager defaultManager];
        for (NSString *__rp in CTAuthTicketPaths()) [__rfm removeItemAtPath:__rp error:NULL];
        for (NSString *__rp in CTAuthFilePaths()) [__rfm removeItemAtPath:__rp error:NULL];
        CTObfScrub();
        CTD("[授权] 重置执行（root）：票根+多路授权文件已清，等待重新输入");
    } @catch (__unused NSException *e) {}
}
static void CTAuthResetInstall(void) {
    static int sAROk = -1;
    if (sAROk >= 0) return;
    notify_register_dispatch("com.qq391160.cpucore/authReset", &sAROk, dispatch_get_main_queue(), ^(int t) {
        (void)t;
        CTAuthResetExec();
        CTAuthRefresh();
    });
}

// %ctor — 构造函数（配置仅在进程启动时加载一次）
// ============================================================================
%ctor {
@autoreleasepool {
    CTHostAliveStart();   // 自测增强：宿主状态心跳
    CTAuthResetInstall();   // ★ 2.0.40：根侧"重置授权"（清票根+全关）
    CTWinBeatWatchInit();   // ★ 2.0.39：监听浮窗心跳（16/17 取证 + 日志兜底）
    {   // ★ 2.0.99：浮窗跟色"保底探针"接收端（桌面侧写不出日志时经通知通道送达）
        static int ctWinProbeTok = 0;
        notify_register_dispatch("com.qq391160.cpucore/winProbe", &ctWinProbeTok, dispatch_get_main_queue(), ^(int t) {
            uint64_t v = 0;
            if (notify_get_state(t, &v) != NOTIFY_STATUS_OK) return;
            int seq = (int)(v & 0xF);
            int rhOK = (int)((v >> 4) & 1);
            int follow = (int)((v >> 5) & 1);
            int mainW = (int)((v >> 6) & 1);
            int wEn = (int)((v >> 7) & 1);
            int blanked = (int)((v >> 8) & 1);
            int srcTag = (int)((v >> 9) & 7);
            int found = (int)((v >> 36) & 1);
            int r = (int)((v >> 12) & 0xFF), g = (int)((v >> 20) & 0xFF), b = (int)((v >> 28) & 0xFF);
            CTD("[浮窗·桥] 跟色探针 seq=%d rh=%d 跟随=%d 主写=%d 窗=%d 熄=%d 源=%d 找到=%d rgb=%d,%d,%d", seq, rhOK, follow, mainW, wEn, blanked, srcTag, found, r, g, b);
        });
    }
    CTWinPosBusCoreInit();   // ★ 2.0.48：浮窗位置环线（通知通道：root 代写 + 回传）
    CTMenuBusCoreInit();   // ★ 2.0.111：菜单档位代写（通知通道收单；零文件）
    g_ctProcStartAt = CFAbsoluteTimeGetCurrent();   // ★2.0.38：开机静默窗口起点
    CTD("[自测] 2.0.128：配置合并导入+写端防清空 + 路径单根收敛 + 假热键两功能移除·开机清理 + 菜单写盘老路补写 + 桌面侧日志免容器兜底 + 防停充回归（2.0.96 版：拦停+救援+名义重申+降流护航）+ 浮窗显示默认全选 + 门控快照（热路径零磁盘IO）+ 浮窗模块排序 + CPU占用模块 + 充电管家安全加固（卸载必松开/读不到不按停）+ 文字亮度反色档修复 + 排序区高度修复 + 拖动层级/锁滚修复 + 防停充门槛38→40 + 亮度滑杆全值生效 + 重置顺序修复 + 拖动让位防抖修复 + 亮度改灰化层（不再依赖滤镜） + 状态点亮度跟随文字 + App 档位显示跟随主模式 + 档位页微调（去「跟随」后缀·顶部重置按钮即时刷新） + 桌面长按菜单显示对齐主模式 + 含 2.0.110 全部");
    {   // ★ 2.0.109 体检版：路径自检（每进程一行；只读无副作用）
        NSString *ctRep = CTHermesAuditReport(@"核心");
        if (ctRep.length) CTD("%s", ctRep.UTF8String);
    }
    CTDimWriteGuardInstall();   // ★ 2.0.38：显示变暗写入拦截（tm 内源头挡）
    // ★ 定向探路已收口（写盘取证完成）：从此不再向 /var/root、/var/tmp 等宿主位置写任何文件
#ifdef CT_SCHEME_ROOTHIDE
    CTNormalizeOwnedDirsForMobile();   // ★ 2.0.38：自家目录放开给 mobile（修"浮窗位置锁不住"；只碰自家）
#endif
    // ★ 1.4.82 侦察（零钩子 ✗）：枚举 PMChargingManager 的方法名 ⇒ 写日志 ✓
    @try {
        CTD("[recon] proc=%s pid=%d", getprogname(), getpid());   // ★ 1.4.85：ASCII 进程标记（防乱码 ✓ 一眼看出是不是 powerd ✓）
        CTD("[recon] isPowerd=%d", strcmp(getprogname(), "powerd") == 0);
        int ctTotal = 0;   // ★ 2.0.94：侦察刷屏停用（原为枚举类/方法表——日志被刷爆、留存被吃）
        if (ctTotal > 0) {
            Class *ctAll = (Class *)malloc(sizeof(Class) * ctTotal);
            if (ctAll) {
                ctTotal = objc_getClassList(ctAll, ctTotal);
                for (int i = 0; i < ctTotal; i++) {
                    const char *cn = class_getName(ctAll[i]);
                    if (!cn) continue;
                    if (strstr(cn, "Charg") || strstr(cn, "Power") || strstr(cn, "Batt") ||
                        strstr(cn, "BMS") || strstr(cn, "PM") || strstr(cn, "USB") ||
                        strstr(cn, "Port") || strstr(cn, "Electric")) {
                        CTD("[侦察·充电V3] 类=%s", cn);   // ★ V3：命中即连"整套方法表"打出来 ✓
                        unsigned int mN = 0;
                        Method *mL = class_copyMethodList(ctAll[i], &mN);
                        for (unsigned int k = 0; k < mN; k++) {
                            const char *nm = sel_getName(method_getName(mL[k]));
                            if (nm) CTD("[侦察·充电V3]   %s", nm);
                        }
                        if (mL) free(mL);
                    }
                }
                free(ctAll);
            }
        }
    } @catch (__unused NSException *e) {}

    g_ctBootStamp = CFAbsoluteTimeGetCurrent();
CTAuthRefresh();   // ★ 授权核对（先于 loadPrefs：未激活时充电开关会被压平）
loadPrefs();

    // ★ 1.4.100：收到「卸载中」通知 → 本进程停止一切周期动作（核心副本不再"按住"任何状态）
    {
        static int ctUnTok = 0;
        notify_register_dispatch("com.qq391160.cpucore/uninstalling", &ctUnTok, dispatch_get_main_queue(), ^(int t) {
            (void)t;
            g_ctUninstalled = YES;
            CTHermesWipeLeftovers();   // ★ 1.4.102：当场自清"本层"（用户可见层）全部残留——脚本删不到的就由这里删
        });
    }

// 确保 IOKit 已加载
void *iokit = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW | RTLD_GLOBAL);
if (iokit) {
kern_return_t (*ptr)(io_service_t, CFStringRef, CFTypeRef) = (kern_return_t (*)(io_service_t, CFStringRef, CFTypeRef))dlsym(iokit, "IOServiceSetProperty");
if (ptr) {
MSHookFunction((void *)ptr, (void *)hooked_IOServiceSetProperty, (void **)&orig_IOServiceSetProperty);
CTLOG(S("[CTHermes] IOServiceSetProperty hook 已安装"));
} else {
CTLOG(S("[CTHermes] 警告: 未找到 IOServiceSetProperty"));
}
}

// _getConfigurationFor — C 函数钩子
void *monitor = dlopen("/System/Library/PrivateFrameworks/DeviceMonitor.framework/DeviceMonitor", RTLD_NOW | RTLD_GLOBAL);
if (monitor) {
void *getConfig = dlsym(monitor, "_getConfigurationFor");
if (getConfig) {
MSHookFunction(getConfig, (void *)new_getConfigurationFor, (void **)&orig_getConfigurationFor);
CTLOG(S("[CTHermes] _getConfigurationFor hook 已安装"));
} else {
CTLOG(S("[CTHermes] 未找到 _getConfigurationFor (非致命)"));
}
} else {
CTLOG(S("[CTHermes] 未找到 DeviceMonitor.framework (非致命)"));
}

// 仅性能模式伪造 Nominal；低功耗或禁用时保留系统真实状态。
if (shouldApplyFullCPUProtection()) CTHermesForceNominalCombined();

BOOL cpuProtection = NO;
runtimeConfigSnapshot(NULL, &cpuProtection, NULL, NULL, NULL);
CTLOG(S("[CTHermes] 温控防护已激活 — 安全阀:已禁用 CPU性能:%d"), cpuProtection);

// 功率模式与常规设置均通过 Darwin 通知实时重载，无需重启用户空间。

CFNotificationCenterRef c = CFNotificationCenterGetDarwinNotifyCenter();
if (c) {
CFNotificationCenterAddObserver(c, NULL, onSettingsChanged,
(__bridge CFStringRef)S(kCTHermesSettingsChangedNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
CFNotificationCenterAddObserver(c, NULL, onPowerModeChanged,
(__bridge CFStringRef)S(kCTHermesPowerModeChangedNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
CFNotificationCenterAddObserver(c, NULL, onForegroundAppChanged,
(__bridge CFStringRef)S(kCTHermesForegroundAppNotifC),
NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    // ★ T7z6：无操作深度降频——"用户操作"探针（App 内触摸，限频上报）
    {
        static int ctUA = 0;
        notify_register_dispatch(kCTHermesUserActivityNotifC, &ctUA, dispatch_get_main_queue(), ^(int ctUAt) {
            (void)ctUAt;
            // ★ 2.0.1：触摸即醒收窄——"随便点一下屏幕"不再提速（只更新"用户操作"时间戳 + 退出深度省电档）；
            //   开合场景的"起手即醒"由开合通道承担（图标 / 底部起手 / 切换瞬间，见 kCTHermesAppBoostNotifC）
            g_ctLastActivityAt = CFAbsoluteTimeGetCurrent();
            if (g_ctDeepIdleActive) {
                g_ctDeepIdleActive = NO;
                applyPowerModeToRuntime(NO);
                CTD("[深度] 用户操作 → 恢复常规低功耗");
            }
        });
    }
    // ★ T7z6：视频场景优化——播放开始/结束（豁免深度降频、暂停滑动提速）
    {
        static int ctVOn = 0;
        notify_register_dispatch(kCTHermesVideoOnNotifC, &ctVOn, dispatch_get_main_queue(), ^(int ctV1) {
            (void)ctV1;
            if (!g_ctVideoOptEnabled && !g_ctVideoDeepEnabled) return;
            g_ctVideoActiveHash = CTHermesReadForegroundBundleHash();
            if (!g_ctVideoActive) {
                g_ctVideoActive = YES;
                CTD("[视频档] 检测到视频/直播播放（App=%llu）→ 豁免深度+暂停提速", (unsigned long long)g_ctVideoActiveHash);
            }
            if (g_ctDeepIdleActive && !g_ctVideoDeepEnabled) { g_ctDeepIdleActive = NO; applyPowerModeToRuntime(NO); }
        });
        static int ctVOff = 0;
        notify_register_dispatch(kCTHermesVideoOffNotifC, &ctVOff, dispatch_get_main_queue(), ^(int ctV2) {
            (void)ctV2;
            if (g_ctVideoActive) { g_ctVideoActive = NO; CTD("[视频档] 播放结束 → 恢复正常档"); }
        });
    }
    // ★ T7w：滑动升频 + ★ 2.0.1：提速"双通道"——滑动信号（"滑动时自动提速"开关）与
    //   开合信号（"开合 App 提速"开关）各走各的通道，共用同一套窗口逻辑；两个开关从此互不牵连。
    {
        static int ctBoostToken = 0;
        static int ctAppBoostToken = 0;
        // 通道①：滑动信号——由前台滚动 ping 发来；只认"滑动时自动提速"
        notify_register_dispatch(kCTHermesScrollBoostNotifC, &ctBoostToken, dispatch_get_main_queue(), ^(int ctBt) {
            (void)ctBt;
            if (!g_scrollBoostEnabled || !g_ctAuthOK) return;   // ★ 2.0.41：安全红线（未授权=全关）
            ctBoostSignalArrived();
        });
        // 通道②：开合信号——由前台在"图标 / 底部起手 / 切换瞬间"发来；只认"开合 App 提速" ★ 2.0.1
        notify_register_dispatch(kCTHermesAppBoostNotifC, &ctAppBoostToken, dispatch_get_main_queue(), ^(int ctBt) {
            (void)ctBt;
            if (!g_ctAppBoostEnabled || !g_ctAuthOK) return;   // ★ 2.0.41：安全红线（未授权=全关）
            ctBoostSignalArrived();
        });
    }
}

installCrossVersionThermalAliases();
// iOS 15/16/17 私有类可能晚于构造函数加载；只进行4次有界补装。
for (int retry=1;retry<=4;retry++) dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(retry*0.75*NSEC_PER_SEC)),dispatch_get_main_queue(),^{ installCrossVersionThermalAliases(); });
// ★ 2.0.38：慢班补扫（懒加载场景）——+10/+30/+60/+180/+300 秒各补一次（有界，不常驻）
{ static const double ctLaterSec[5] = {10, 30, 60, 180, 300};
  for (int li = 0; li < 5; li++) dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(ctLaterSec[li]*NSEC_PER_SEC)),dispatch_get_main_queue(),^{ installCrossVersionThermalAliases(); }); }

registerThermalLevelResetObservers();
registerScreenWakeObservers();
registerDeepAliveObservers();   // ★ 2.0.94：深层心跳收账
if (getprogname() && strcmp(getprogname(), "thermalmonitord") == 0) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(12.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTLegacyResidueOne(); });   // ★ 2.0.95：残留自检（延迟、运行期）
}
startForegroundRecheckTimer();
startModeAssertTimer();   // ★ 模式保持循环（每秒核对 + 重压）
startPeriodicReassertTimer();   // ★ 周期重申：亮屏每 2 秒 / 熄屏每 5 秒（重发模式变更通知）
startChargeEngineTimer();   // ★ 1.4.6g：充电引擎独立队列（防主队列卡死连累）
startMainQueueWatchdog();   // ★ 1.4.6g：主队列健康看门狗（卡死写日志）
startPerSecondServicesTimer();   // ★ 1.4.6h：每秒服务独立队列（状态文件/自检/定时）
// ★ T7s：启动时重置"前台通知状态"——防跳 respring 残留旧值被误读
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    CTHermesPostForegroundBundleID(nil);
    CTD("[前台状态] 启动清理：前台通知状态已重置（防残留）");
});
applyCurrentPowerModeToRuntime();
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTAnalysisAuditTick(); });   // ★ 反调试首查
CTLOG(S("[CTHermes] 启动完成，当前功率模式:%@，低功耗将在下次亮屏/解锁后自动结束"), isLowPowerMode() ? S("低功耗") : S("性能模式"));
}
}
