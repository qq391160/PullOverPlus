#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <spawn.h>
#import <sys/wait.h>
#import <notify.h>
#import <dlfcn.h>
#import <CTHermesPaths.h>
#include <sys/time.h>
#include <stdio.h>
#import <CTHardening.h>   // ★ 0930-0207：多路授权读写（CTAuthWriteCodeAllPaths 等）
#include <mach-o/dyld.h>
#import <CTObf.h>
#include <CTActivation.h>
#import <CTFingerprint.h>
#import <CTCrashLog.h>

#include <time.h>
#include <stdio.h>
#import <CTLit.h>

// ★ 1.4.7 修复（iOS16 显示"获取中"）：插件没把 ctDevCode 写进偏好时（偏好路径不一致 / 插件尚未加载），
//   设置页用同一套算法本地算一次 —— 保证任何环境都能显示/复制设备码
static NSString *CTSettingsDeviceCode(NSDictionary *p) {
    id v = p ? [p objectForKey:S("ctDevCode")] : nil;
    if ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 0) {
        return (NSString *)v;
    }
    NSString *local = CTAuthDeviceCode();
    return (local.length > 0) ? local : nil;
}

// ★ 1.4.6b：设置页诊断行（追加到 CTHermesDiag.log）—— 用于核对“点选”等交互是否真正触发
static void CTSettingsDiagLine(NSString *msg) {
    @try {
        char tbuf[32]; time_t t = time(NULL); struct tm tmv; localtime_r(&t, &tmv);
        strftime(tbuf, sizeof(tbuf), "%H:%M:%S", &tmv);
        NSString *line = [NSString stringWithFormat:S("[%s] [设置] %@\n"), tbuf, msg];
        FILE *f = fopen(CTDiagLogPathC(), "a");
        if (f) { fputs(line.UTF8String, f); fclose(f); }
    } @catch (__unused NSException *e) {}
}

// ============================================================
// 注意: 禁止使用 @"" ObjC 字符串常量
// roothide 重映射会破坏 __cfstring 内部指针，导致 SIGBUS
// 所有字符串通过 C 字符串 + stringWithUTF8String: 动态创建
// ============================================================

// ============================================================
// ★ 1.4.2：设置页「重新排版」——
//   · 根页面：分类导航（英雄区 / 常驻模式三卡 / 主要功能 / 高级功能 / 支持与关于）
//   · 子页面：原有开关分组原样搬入（键值、默认值、行为一律未动）
//   · 所有偏好写入路径统一走 CTSentryBaseController：键值处理、整数夹取、
//     notify 通知与旧版逐字一致，只是界面换了组织方式。
// ============================================================

// 本机 stub 头未声明 UITableView 协议方法，这里补声明以便调用父类实现
@interface PSListController (CTSentryTableInternal)
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;   // ★ 2.0.5：动作行拦截用
@end

#pragma mark - 通用写入逻辑（根页面与子页面共用，行为=旧版 CTHermesRootListController）

@interface CTSentryBaseController : PSListController
@end

@implementation CTSentryBaseController
+ (void)load { CTCrashLogInstall("Settings"); CTCrashLogInstallSignals("Settings"); }   // ★ 1.4.6：装上崩溃捕手（异常原文+调用栈 → CTHermesDiag.log）

- (NSString *)prefPath {
    return CTHermesCurrentPrefPath();
}

- (NSMutableDictionary *)prefs {
    NSMutableDictionary *d = CTHermesReadMutablePrefs();
    if (!d) d = [NSMutableDictionary dictionary];
    return d;
}

- (void)runThermalToolCommand:(const char *)command value:(BOOL)value hasValue:(BOOL)hasValue {
    NSString *toolPath = CTHermesToolPath();
    if (!toolPath.length || !command) return;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        pid_t pid = 0;
        char valueBuffer[2] = { value ? '1' : '0', '\0' };
        char *argsWithValue[] = {(char *)"CTHermesTool", (char *)command, valueBuffer, NULL};
        char *argsNoValue[] = {(char *)"CTHermesTool", (char *)command, NULL};
        char **arguments = hasValue ? argsWithValue : argsNoValue;
        if (posix_spawn(&pid, toolPath.fileSystemRepresentation, NULL, NULL, arguments, NULL) == 0) waitpid(pid, NULL, 0);
    });
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return;

    NSMutableDictionary *prefs = [self prefs];

    // 功率模式统一规范为字符串，防止框架传入 NSNumber 索引
    if ([key isEqualToString:S("powerMode")]) {
        if ([value isKindOfClass:[NSNumber class]]) {
            NSInteger ctModeIdx = [value integerValue];
            value = (ctModeIdx == 0) ? S("lowPower") : ((ctModeIdx == 1) ? S("fullPower") : S("smart"));
        } else if (![value isKindOfClass:[NSString class]]) {
            value = S("fullPower");
        }
    }

    prefs[key] = value;
    if ([key isEqualToString:S("floatWindowFontSize")]) {
        // ★ T7z18c：浮窗字号 —— 取整并夹在 6~20（滑块连续拖动也只存整数）
        double fs = [value doubleValue];
        if (fs < 6.0) fs = 6.0;
        if (fs > 20.0) fs = 20.0;
        prefs[key] = [NSNumber numberWithInt:(int)(fs + 0.5)];
    }
    if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        [prefs removeObjectForKey:S("sunlightAutomatic")];
        [prefs removeObjectForKey:S("sunlightOverride")];
    }
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        [prefs removeObjectForKey:S("hipProtectionEnabled")];
        [prefs removeObjectForKey:S("simulateHIP")];
        [prefs removeObjectForKey:S("hipLockedMode")];
    }
    CTHermesWritePrefs(prefs);
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        // 设置页为亮屏：固定“仅锁屏”时立即恢复原生；锁屏后由 thermalmonitord 自动启用。
        [self runThermalToolCommand:"hip-lock" value:NO hasValue:YES];
    } else if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        if ([value boolValue]) [self runThermalToolCommand:"sunlight-override" value:YES hasValue:YES];
        else [self runThermalToolCommand:"sunlight-auto" value:NO hasValue:NO];
    }

    // 功率模式只发专用通知，避免 settingsChanged + powerModeChanged 重复应用。
    if ([key isEqualToString:S("powerMode")]) {
        notify_post(kCTHermesPowerModeChangedNotifC);
        _specifiers = nil;
        [self reloadSpecifiers];
    } else {
        notify_post(kCTHermesSettingsChangedNotifC);
    }
}

- (id)readPreferenceValue:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return nil;

    // 功率模式为字符串值，默认满血(性能模式)
    if ([key isEqualToString:S("powerMode")]) {
        id mode = [self prefs][key];
        if (mode && [mode isKindOfClass:[NSString class]]) return mode;
        return S("fullPower");
    }

    id val = [self prefs][key];
    if (val) return val;

    // ★ T7z18：浮窗字号默认 12（滑块初始位置）
    if ([key isEqualToString:S("floatWindowFontSize")]) return [NSNumber numberWithInt:12];
    if ([key isEqualToString:S("gameForceFullEnabled")]) return [NSNumber numberWithBool:NO];   // ★ 2.0.40：默认关（客户自选）

    // ★ 1.4.6b：带自定义默认档的行（滑块/档位）先取默认档，避免读成 0 造成显示错位
    id ctDef = [spec propertyForKey:S("ctDefault")];
    if (ctDef) return ctDef;

    // 其余功能开关默认关闭，仅用户主动开启后生效。
    return [NSNumber numberWithBool:NO];
}

// ★ 2.0.5：动作行拦截——"action=选择子 且 无 detail 类"的行，点击只执行动作，不再交给框架默认行为
//   ★ rev3（关键修正）：动作归属**只以"这一格自己的 specifier"为准**——它是设置框架渲染这一格时配上的、
//     与用户看到的文字 100% 对应的那个设置项（设置页其它渲染/箭头/滑块全部用的同一个来源）。
//     不再用任何"按行序号猜"的方式（那个在部分 iOS 上会偏行 → 点A跑出B）。
//     取不到就原样交给系统（= 与旧版行为一致），绝不猜。
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        PSSpecifier *sp = nil;
        @try {
            UITableViewCell *cell0 = [tableView cellForRowAtIndexPath:indexPath];
            if (cell0) {
                id s0 = [cell0 valueForKey:S("specifier")];
                if ([s0 isKindOfClass:[PSSpecifier class]]) sp = (PSSpecifier *)s0;
            }
        } @catch (__unused NSException *e) {}
        if (sp) {
            NSString *actStr = [sp propertyForKey:S("action")];
            SEL sel = (actStr.length > 0) ? NSSelectorFromString(actStr) : (SEL)0;
            BOOL hasDetail = NO;
            @try {
                id d = [sp performSelector:NSSelectorFromString(S("detailControllerClass"))];
                hasDetail = (d != nil);
            } @catch (__unused NSException *e) {}
            if (sel != (SEL)0 && !hasDetail) {
                [tableView deselectRowAtIndexPath:indexPath animated:YES];
                id tgt = self;
                @try {
                    Ivar ivT = class_getInstanceVariable([PSSpecifier class], "target");
                    if (ivT) { id tmp = object_getIvar(sp, ivT); if (tmp) tgt = tmp; }
                } @catch (__unused NSException *e) {}
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
                if ([tgt respondsToSelector:sel]) [tgt performSelector:sel];
                else if ([self respondsToSelector:sel]) [self performSelector:sel];
#pragma clang diagnostic pop
                return;   // ★ 关键：不调 super，杜绝"无 detail 的链接行被框架推空白页"
            }
        }
    } @catch (__unused NSException *e) {}
    [super tableView:tableView didSelectRowAtIndexPath:indexPath];
}

@end

#pragma mark - 自定义外观元件

@interface CTSentryCell : UITableViewCell
@property(nonatomic, strong) PSSpecifier *ctSpecifier;
@property(nonatomic, strong) PSSpecifier *specifier;
@property(nonatomic, strong) UIImageView *ctIconView;
@property(nonatomic, strong) UILabel *ctTitleLabel;
@property(nonatomic, strong) UILabel *ctSubLabel;
@property(nonatomic, strong) UIImageView *ctChevron;
@end

@implementation CTSentryCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.contentView.backgroundColor = [UIColor clearColor];

    _ctIconView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _ctIconView.contentMode = UIViewContentModeCenter;
    _ctTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctTitleLabel.font = [UIFont systemFontOfSize:16.5];
    _ctTitleLabel.textColor = [UIColor labelColor];
    _ctSubLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctSubLabel.font = [UIFont systemFontOfSize:12.0];
    _ctSubLabel.textColor = [UIColor secondaryLabelColor];
    _ctChevron = [[UIImageView alloc] initWithFrame:CGRectZero];
    _ctChevron.contentMode = UIViewContentModeCenter;

    [self.contentView addSubview:_ctIconView];
    [self.contentView addSubview:_ctTitleLabel];
    [self.contentView addSubview:_ctSubLabel];
    [self.contentView addSubview:_ctChevron];
    return self;
}

// ★ 1.4.7 修复（iOS 16 设置页闪退）：iOS 16 的 Preferences 在点按行时会读 cell.title（苹果 PSTableCell 接口），
//   我们的自绘行没实现 → unrecognized selector → 设置 App 崩溃。这里按"用户看到的那行标题"返回，并补齐同族接口。
- (NSString *)title {
    PSSpecifier *sp = [self specifier];
    if (sp) {
        NSString *label = [sp propertyForKey:S("label")];
        if ([label isKindOfClass:[NSString class]] && label.length > 0) return label;
        NSString *name = [sp propertyForKey:S("name")];
        if ([name isKindOfClass:[NSString class]] && name.length > 0) return name;
    }
    NSString *t = _ctTitleLabel.text;
    return [t isKindOfClass:[NSString class]] ? t : @"";
}
- (void)setTitle:(NSString *)title { (void)title; }          // 防御：吞掉，绝不崩
- (NSString *)subtitle {
    NSString *t = _ctSubLabel.text;
    return [t isKindOfClass:[NSString class]] ? t : @"";
}
- (void)setSubtitle:(NSString *)subtitle { (void)subtitle; }
- (UILabel *)titleLabel { return _ctTitleLabel; }
- (UILabel *)subtitleLabel { return _ctSubLabel; }

// ★ 1.4.7 修复（iOS16 点按闪退·全类覆盖）：iOS 16 的 Preferences 会向我们的自绘行发送
//   一批 PSTableCell 的接口（checked / cellTarget / cellAction / refresh…），任何一个没实现都会让设置 App 崩。
//   这里把常用的补齐（全部安全空实现），并加一道"未实现调用不崩溃"的兜底。
- (void)setChecked:(BOOL)checked { (void)checked; }
- (BOOL)isChecked { return NO; }
- (id)cellTarget { return nil; }
- (void)setCellTarget:(id)target { (void)target; }
- (SEL)cellAction { return NULL; }
- (void)setCellAction:(SEL)action { (void)action; }
- (void)refreshCellContentsWithSpecifier:(PSSpecifier *)sp {
    if (sp) [self configureWithSpecifier:sp];
}
// 兜底：任何"我们没实现的调用"一律忽略并记日志（绝不崩设置 App；日志里能看到是谁漏了，方便下版补齐）
- (void)doesNotRecognizeSelector:(SEL)aSelector {
    CTSettingsDiagLine([NSString stringWithFormat:S("[行][容错] 忽略未实现调用：%@"), NSStringFromSelector(aSelector)]);
}

- (void)configureWithSpecifier:(PSSpecifier *)sp {
    self.ctSpecifier = sp;
    self.specifier = sp;
    NSString *icon = [sp propertyForKey:S("ctIcon")];
    UIImage *img = nil;
    if ([icon isKindOfClass:[NSString class]] && icon.length) {
        img = [UIImage systemImageNamed:icon];
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:19.0 weight:UIImageSymbolWeightRegular];
        if (img && cfg) img = [img imageWithConfiguration:cfg];
        if (img) img = [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    }
    self.ctIconView.image = img;
    self.ctIconView.tintColor = [UIColor systemBlueColor];
    NSString *tint = [sp propertyForKey:S("ctIconTint")];
    if ([tint isKindOfClass:[NSString class]] && tint.length) {
        if ([tint isEqualToString:S("green")]) self.ctIconView.tintColor = [UIColor systemGreenColor];
        else if ([tint isEqualToString:S("orange")]) self.ctIconView.tintColor = [UIColor systemOrangeColor];
        else if ([tint isEqualToString:S("red")]) self.ctIconView.tintColor = [UIColor systemRedColor];
    }
    self.ctIconView.hidden = (img == nil);

    id label = [sp propertyForKey:S("label")];
    self.ctTitleLabel.text = [label isKindOfClass:[NSString class]] ? label : S("");
    id sub = [sp propertyForKey:S("ctSub")];
    self.ctSubLabel.text = [sub isKindOfClass:[NSString class]] ? sub : S("");
    self.ctSubLabel.hidden = (self.ctSubLabel.text.length == 0);

    UIImage *chev = [UIImage systemImageNamed:S("chevron.right")];
    UIImageSymbolConfiguration *ccfg = [UIImageSymbolConfiguration configurationWithPointSize:13.5 weight:UIImageSymbolWeightSemibold];
    if (chev && ccfg) chev = [chev imageWithConfiguration:ccfg];
    if (chev) chev = [chev imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    self.ctChevron.image = chev;
    // 和字体同色：深色模式=白 / 浅色模式=黑（自动跟随系统）
    self.ctChevron.tintColor = [UIColor labelColor];
    [self setNeedsLayout];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat iconSize = 26.0;
    CGFloat x = 16.0;
    self.ctIconView.frame = CGRectMake(x, (b.size.height - iconSize) / 2.0, iconSize, iconSize);
    CGFloat textX = x + iconSize + 12.0;
    CGFloat chevW = 14.0;
    CGFloat chevX = b.size.width - 16.0 - chevW;
    self.ctChevron.frame = CGRectMake(chevX, (b.size.height - 16.0) / 2.0, chevW, 16.0);
    CGFloat textW = chevX - textX - 8.0;
    if (!self.ctSubLabel.hidden) {
        self.ctTitleLabel.frame = CGRectMake(textX, b.size.height / 2.0 - 20.0, textW, 20.0);
        self.ctSubLabel.frame = CGRectMake(textX, b.size.height / 2.0 + 1.0, textW, 16.0);
    } else {
        self.ctTitleLabel.frame = CGRectMake(textX, 0, textW, b.size.height);
    }
}
@end

@interface CTSentryModeCell : UITableViewCell
@property(nonatomic, strong) PSSpecifier *ctSpecifier;
@property(nonatomic, strong) PSSpecifier *specifier;
@property(nonatomic, strong) UIView *ctTrack;
@property(nonatomic, copy) void (^onPick)(NSString *value);
@property(nonatomic, strong) NSMutableArray *chips;
@property(nonatomic, strong) NSMutableArray *chipNames;
@property(nonatomic, strong) NSMutableArray *chipSubs;
@property(nonatomic, strong) NSArray *values;
@property(nonatomic) double ctLastPickStamp;   // ★ 1.4.6b：点选去抖时间戳
- (void)ctConfigureTitles:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values;
- (void)setSelectedValue:(NSString *)value;
- (void)ctHandlePickIndex:(NSUInteger)idx;
- (void)ctWholeCellTapped:(UITapGestureRecognizer *)g;
@end

@implementation CTSentryModeCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _chips = [NSMutableArray array];
    _chipNames = [NSMutableArray array];
    _chipSubs = [NSMutableArray array];
    _ctTrack = [[UIView alloc] initWithFrame:CGRectZero];
    _ctTrack.backgroundColor = [UIColor clearColor];   // ★ 1.4.2：不加第二层背景（直接坐在卡片上）
    _ctTrack.layer.cornerRadius = 13.0;
    _ctTrack.layer.masksToBounds = YES;
    [self.contentView addSubview:_ctTrack];
    NSArray *titles = @[S("智能"), S("低功耗"), S("性能模式")];
    NSArray *subs   = @[S("自动识别"), S("全局省电"), S("全局高性能")];
    _values = @[S("smart"), S("lowPower"), S("fullPower")];
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:14.0];
        nm.textAlignment = NSTextAlignmentCenter;
        UILabel *sb = [[UILabel alloc] initWithFrame:CGRectZero];
        sb.text = subs[i];
        sb.font = [UIFont systemFontOfSize:10.0];
        sb.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        [chip addSubview:sb];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [_chips addObject:chip];
        [_chipNames addObject:nm];
        [_chipSubs addObject:sb];
    }
    UITapGestureRecognizer *ctWhole = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctWholeCellTapped:)];
    ctWhole.cancelsTouchesInView = NO;
    [self.contentView addGestureRecognizer:ctWhole];   // ★ 1.4.6b：整卡兜底点选（子块手势万一没吃到，这里也能选中）
    return self;
}

- (void)ctConfigureTitles:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)vals {
    if (![titles isKindOfClass:[NSArray class]] || titles.count == 0) return;
    NSArray *useSubs = [subs isKindOfClass:[NSArray class]] ? subs : @[];
    NSArray *useVals = [vals isKindOfClass:[NSArray class]] ? vals : @[];
    if (self.chips.count == titles.count && [self.values isEqualToArray:useVals]) return;   // 同构复用 → 跳过重建
    for (UIView *c in self.chips) [c removeFromSuperview];
    [self.chips removeAllObjects];
    [self.chipNames removeAllObjects];
    [self.chipSubs removeAllObjects];
    self.values = useVals;
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:14.0];
        nm.textAlignment = NSTextAlignmentCenter;
        UILabel *sb = [[UILabel alloc] initWithFrame:CGRectZero];
        sb.text = (i < useSubs.count) ? useSubs[i] : @"";
        sb.font = [UIFont systemFontOfSize:10.0];
        sb.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        [chip addSubview:sb];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [self.chips addObject:chip];
        [self.chipNames addObject:nm];
        [self.chipSubs addObject:sb];
    }
    [self setNeedsLayout];
}

- (void)ctChipTapped:(UITapGestureRecognizer *)g {
    [self ctHandlePickIndex:(NSUInteger)g.view.tag];
}

- (void)ctHandlePickIndex:(NSUInteger)idx {
    if (idx >= self.values.count) return;
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (now - self.ctLastPickStamp < 0.15) return;   // ★ 1.4.6b 去抖：两个手势同时命中只算一次
    self.ctLastPickStamp = now;
    if (self.onPick) self.onPick(self.values[idx]);
}

- (void)ctWholeCellTapped:(UITapGestureRecognizer *)g {
    CGPoint p = [g locationInView:self.contentView];
    for (UIView *chip in self.chips) {
        if (CGRectContainsPoint(chip.frame, p)) { [self ctHandlePickIndex:(NSUInteger)chip.tag]; return; }
    }
}

- (void)setSelectedValue:(NSString *)value {
    for (NSUInteger i = 0; i < self.chips.count; i++) {
        BOOL on = (i < self.values.count) && [self.values[i] isEqualToString:value];
        UIView *chip = self.chips[i];
        UILabel *nm = self.chipNames[i];
        UILabel *sb = self.chipSubs[i];
        if (on) {
            chip.backgroundColor = [UIColor systemBlueColor];
            nm.textColor = [UIColor whiteColor];
            sb.textColor = [UIColor colorWithWhite:1.0 alpha:0.8];
        } else {
            chip.backgroundColor = [UIColor clearColor];
            nm.textColor = [UIColor labelColor];
            sb.textColor = [UIColor secondaryLabelColor];
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 12.0, top = 2.0, inset = 2.0;
    CGFloat trackH = b.size.height - top - 2.0;
    CGFloat trackW = b.size.width - pad * 2.0;
    self.ctTrack.frame = CGRectMake(pad, top, trackW, trackH);
    if (self.chips.count == 0) return;
    CGFloat segW = (trackW - inset * 2.0) / (CGFloat)self.chips.count;
    CGFloat segH = trackH - inset * 2.0;
    for (NSUInteger i = 0; i < self.chips.count; i++) {
        UIView *chip = self.chips[i];
        chip.frame = CGRectMake(pad + inset + i * segW, top + inset, segW, segH);
        UILabel *nm = self.chipNames[i];
        UILabel *sb = self.chipSubs[i];
        if (sb.text.length == 0) {
            nm.frame = CGRectMake(0, segH / 2.0 - 10.0, segW, 20.0);   // 无副标题 → 主标题居中
        } else {
            nm.frame = CGRectMake(0, segH / 2.0 - 17.0, segW, 18.0);
            sb.frame = CGRectMake(0, segH / 2.0 + 3.0, segW, 14.0);
        }
    }
}
@end

// ============================================================
// ★ 0928-2：「显示内容」多选芯片行（样式与模式卡一致；点选/取消，可多选）
// ============================================================
@interface CTSentryMultiChipCell : UITableViewCell
@property(nonatomic, strong) NSMutableArray *ctmChips;
@property(nonatomic, strong) NSMutableArray *ctmNames;
@property(nonatomic, strong) NSMutableArray *ctmKeys;
@property(nonatomic, strong) NSMutableArray *ctmStates;
@property(nonatomic, assign) NSTimeInterval ctmLastStamp;
@property(nonatomic, copy) void (^onToggle)(NSString *key, BOOL on);
@property(nonatomic, strong) PSSpecifier *specifier;   // ★ 2.0.41：补齐"同族接口"（缺了 iOS16/17 点按会 unrecognized selector 闪退）
@end
@implementation CTSentryMultiChipCell
- (NSString *)title { return @""; }                 // ★ 2.0.41：防御补齐（点按会读）
- (void)setTitle:(NSString *)title {}
- (NSString *)subtitle { return @""; }
- (void)setSubtitle:(NSString *)subtitle {}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _ctmChips = [NSMutableArray array];
    _ctmNames = [NSMutableArray array];
    _ctmKeys = [NSMutableArray array];
    _ctmStates = [NSMutableArray array];
    {   // ★ 1.4.122：整卡兜底点选只装一次（旧版每次重建都会再加一个 → 越滚越多）
        UITapGestureRecognizer *whole = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctmWholeTapped:)];
        whole.cancelsTouchesInView = NO;
        [self.contentView addGestureRecognizer:whole];
    }
    return self;
}
- (void)ctmConfigureTitles:(NSArray *)titles keys:(NSArray *)keys selected:(NSArray *)sel {
    if (![titles isKindOfClass:[NSArray class]] || titles.count == 0) return;
    if (self.ctmChips.count == titles.count && [self.ctmKeys isEqualToArray:(keys ?: @[])]) {
        [self ctmApplyStates:sel];
        [self setNeedsLayout];
        return;
    }
    for (UIView *c in self.ctmChips) {
        for (UIGestureRecognizer *g in [c.gestureRecognizers copy]) [c removeGestureRecognizer:g];   // ★ 1.4.122：先摘手势再拆（防点按中拆除 → 闪退）
        [c removeFromSuperview];
    }
    [self.ctmChips removeAllObjects];
    [self.ctmNames removeAllObjects];
    [self.ctmKeys removeAllObjects];
    [self.ctmStates removeAllObjects];
    [self.ctmKeys addObjectsFromArray:(keys ?: @[])];
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:13.0];
        nm.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctmChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [self.ctmChips addObject:chip];
        [self.ctmNames addObject:nm];
    }
    // ★ 1.4.122：整卡手势已移到 init（只装一次）
    [self ctmApplyStates:sel];
    [self setNeedsLayout];
}
- (void)ctmApplyStates:(NSArray *)sel {
    [self.ctmStates removeAllObjects];
    for (NSUInteger i = 0; i < self.ctmChips.count; i++) {
        BOOL on = (i < sel.count) && [sel[i] boolValue];
        [self.ctmStates addObject:[NSNumber numberWithBool:on]];
        UIView *chip = self.ctmChips[i];
        UILabel *nm = self.ctmNames[i];
        chip.backgroundColor = on ? [UIColor systemBlueColor] : [UIColor clearColor];
        nm.textColor = on ? [UIColor whiteColor] : [UIColor labelColor];
    }
}
- (void)ctmSetChip:(NSUInteger)idx on:(BOOL)on {
    if (idx >= self.ctmChips.count) return;
    self.ctmStates[idx] = [NSNumber numberWithBool:on];
    UIView *chip = self.ctmChips[idx];
    UILabel *nm = self.ctmNames[idx];
    chip.backgroundColor = on ? [UIColor systemBlueColor] : [UIColor clearColor];
    nm.textColor = on ? [UIColor whiteColor] : [UIColor labelColor];
}
- (void)ctmToggleIndex:(NSUInteger)idx {
    if (idx >= self.ctmChips.count || idx >= self.ctmKeys.count) return;
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (now - self.ctmLastStamp < 0.15) return;   // 去抖：两个手势同时命中只算一次
    self.ctmLastStamp = now;
    if (idx >= self.ctmStates.count) return;   // ★ 1.4.122：越界防护
    BOOL newOn = ![self.ctmStates[idx] boolValue];
    [self ctmSetChip:idx on:newOn];
    void (^cb)(NSString *, BOOL) = self.onToggle;   // ★ 1.4.122：解耦到手势之后（点按栈内不做写入/刷新 → 防闪退）
    NSString *k = self.ctmKeys[idx];
    if (cb) dispatch_async(dispatch_get_main_queue(), ^{ cb(k, newOn); });
}
- (void)ctmChipTapped:(UITapGestureRecognizer *)g { [self ctmToggleIndex:(NSUInteger)g.view.tag]; }
- (void)ctmWholeTapped:(UITapGestureRecognizer *)g {
    CGPoint p = [g locationInView:self.contentView];
    for (UIView *chip in self.ctmChips) {
        if (CGRectContainsPoint(chip.frame, p)) { [self ctmToggleIndex:(NSUInteger)chip.tag]; return; }
    }
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 12.0, top = 2.0, inset = 2.0;
    CGFloat trackH = b.size.height - top - 2.0;
    CGFloat trackW = b.size.width - pad * 2.0;
    if (self.ctmChips.count == 0) return;
    CGFloat segW = (trackW - inset * 2.0) / (CGFloat)self.ctmChips.count;
    CGFloat segH = trackH - inset * 2.0;
    for (NSUInteger i = 0; i < self.ctmChips.count; i++) {
        UIView *chip = self.ctmChips[i];
        chip.frame = CGRectMake(pad + inset + i * segW, top + inset, segW, segH);
        UILabel *nm = self.ctmNames[i];
        nm.frame = CGRectMake(0, segH / 2.0 - 10.0, segW, 20.0);
    }
}
@end

// ============================================================
// ★ 1.4.6b：自绘滑块行（替代框架 PSSliderCell）——
//   拖动中即时更新数值显示；松手才写盘+通知（一次交互一次写入，且不依赖框架刷新）。
// ============================================================
@interface CTSentrySliderCell : UITableViewCell
@property(nonatomic, strong) UISlider *ctSlider;
@property(nonatomic, strong) UILabel *ctValueLabel;
@property(nonatomic, copy) NSString *ctFmt;
@property(nonatomic, copy) void (^onValue)(double value, BOOL committed);
@property(nonatomic, strong) PSSpecifier *specifier;   // ★ 2.0.41：同族接口补齐（防同款闪退）
@end

@implementation CTSentrySliderCell
- (NSString *)title { return @""; }
- (void)setTitle:(NSString *)title {}
- (NSString *)subtitle { return @""; }
- (void)setSubtitle:(NSString *)subtitle {}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _ctFmt = S("%.1f");
    _ctSlider = [[UISlider alloc] initWithFrame:CGRectZero];
    _ctSlider.continuous = YES;
    [_ctSlider addTarget:self action:@selector(ctSliderChanged:) forControlEvents:UIControlEventValueChanged];
    [_ctSlider addTarget:self action:@selector(ctSliderDone:) forControlEvents:(UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel)];
    [self.contentView addSubview:_ctSlider];
    _ctValueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctValueLabel.font = [UIFont systemFontOfSize:14.0];
    _ctValueLabel.textColor = [UIColor secondaryLabelColor];
    _ctValueLabel.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:_ctValueLabel];
    return self;
}

- (void)ctConfigureMin:(double)mn max:(double)mx value:(double)v fmt:(NSString *)fmt {
    self.ctSlider.minimumValue = (float)mn;
    self.ctSlider.maximumValue = (float)mx;
    if (v < mn) v = mn;
    if (v > mx) v = mx;
    self.ctSlider.value = (float)v;
    if (fmt.length) self.ctFmt = fmt;
    [self ctRefreshLabel:v];
}

- (void)ctRefreshLabel:(double)v {
    self.ctValueLabel.text = [NSString stringWithFormat:self.ctFmt, v];
}

- (void)ctSliderChanged:(UISlider *)s {
    [self ctRefreshLabel:s.value];
    if (self.onValue) self.onValue((double)s.value, NO);
}

- (void)ctSliderDone:(UISlider *)s {
    if (self.onValue) self.onValue((double)s.value, YES);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 16.0, labelW = 48.0;
    self.ctSlider.frame = CGRectMake(pad, 2.0, b.size.width - pad * 2.0 - labelW - 6.0, b.size.height - 4.0);
    self.ctValueLabel.frame = CGRectMake(b.size.width - pad - labelW, b.size.height / 2.0 - 12.0, labelW, 24.0);
}
@end

@interface CTSentryHeaderView : UIView
@end

@implementation CTSentryHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectZero];
    UIImage *img = [UIImage imageNamed:S("icon") inBundle:[NSBundle bundleForClass:[self class]] compatibleWithTraitCollection:nil];
    icon.image = img;
    icon.contentMode = UIViewContentModeScaleAspectFit;
    icon.tag = 101;
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectZero];
    name.text = S("CPU 智能温控");
    name.font = [UIFont systemFontOfSize:17.0];
    name.textColor = [UIColor labelColor];
    name.textAlignment = NSTextAlignmentCenter;
    name.tag = 102;
    UILabel *tag = [[UILabel alloc] initWithFrame:CGRectZero];
    tag.text = S("智能温控 · 省电与性能自由切换");
    tag.font = [UIFont systemFontOfSize:12.5];
    tag.textColor = [UIColor secondaryLabelColor];
    tag.textAlignment = NSTextAlignmentCenter;
    tag.tag = 103;
    [self addSubview:icon];
    [self addSubview:name];
    [self addSubview:tag];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    UIImageView *icon = (UIImageView *)[self viewWithTag:101];
    UILabel *name = (UILabel *)[self viewWithTag:102];
    UILabel *tag = (UILabel *)[self viewWithTag:103];
    CGFloat iconSize = 56.0;
    icon.frame = CGRectMake((b.size.width - iconSize) / 2.0, 14.0, iconSize, iconSize);
    name.frame = CGRectMake(16.0, 78.0, b.size.width - 32.0, 22.0);
    tag.frame = CGRectMake(16.0, 100.0, b.size.width - 32.0, 17.0);
}
@end

#pragma mark - 子页面（6 个类，specifier 全部「代码生成」；写入行为随基类）

// ★ 1.4.2 修订：子页不再从 pane_*.plist 动态加载（该路径在本机框架上不生效），
//   改为代码生成 specifier —— 与 App 档位 / 定时切换 / 一键自检 同款机制。
@interface CTSentryPaneBase : CTSentryBaseController
- (NSMutableArray *)ctBuildSpecifiers;
- (NSString *)ctPaneTitleText;
- (PSSpecifier *)ctGroupWithFooter:(NSString *)footer;
- (PSSpecifier *)ctSwitch:(NSString *)label key:(NSString *)key default:(BOOL)def;
- (PSSpecifier *)ctSlider:(NSString *)label key:(NSString *)key def:(double)def min:(double)mn max:(double)mx fmt:(NSString *)fmt;
- (PSSpecifier *)ctActionRow:(NSString *)label action:(NSString *)action;
- (PSSpecifier *)ctSegmentRow:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values key:(NSString *)key default:(NSString *)def;
- (PSSpecifier *)ctMultiChipRow:(NSArray *)titles keys:(NSArray *)keys;
- (id)ctGetPref:(PSSpecifier *)spec;
- (void)ctSetPref:(id)value specifier:(PSSpecifier *)spec;
@end

// ★ 1.4.6：运行时绑定 specifier 的 action/target。
//   各环境头文件声明不一致（有的把 target 声明为 property、有的声明为 ivar）→ 用运行时写，两边兼容。
static void ctBindSpecifierActionTarget(PSSpecifier *sp, SEL sel, id target) {
    @try {
        Ivar ivA = class_getInstanceVariable([PSSpecifier class], "action");
        if (ivA) *(SEL *)((uint8_t *)(__bridge void *)sp + ivar_getOffset(ivA)) = sel;
        Ivar ivT = class_getInstanceVariable([PSSpecifier class], "target");
        if (ivT) object_setIvar(sp, ivT, target);
    } @catch (__unused NSException *e) {}
}

@implementation CTSentryPaneBase
- (NSString *)ctPaneTitleText { return S(""); }

- (NSMutableArray *)ctBuildSpecifiers { return [NSMutableArray array]; }

static NSArray *CTConflictScan(void) {
    NSMutableArray *h = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *d in @[@"/var/jb/Library/MobileSubstrate/DynamicLibraries", @"/Library/MobileSubstrate/DynamicLibraries"]) {
        for (NSString *f in ([fm contentsOfDirectoryAtPath:d error:nil] ?: @[])) {
            NSString *l = [f lowercaseString];
            if ([f hasPrefix:@"CTHermesDisplay"] || [f hasPrefix:@"CTHermesPrefHook"] || [f hasPrefix:@"CTHermesRefreshRate"]) { [h addObject:[f stringByAppendingString:S("（旧版残留）")]]; continue; }
            if ([f hasPrefix:@"CTHermes"] || [l hasPrefix:@"com.qq391160"]) continue;
            if (![l hasSuffix:@".dylib"]) continue;
            for (NSString *k in @[@"chargelimit", @"charginglimit", @"batterycharge", @"batterylimit", @"powercuff", @"turboboost", @"thermal"]) if ([l containsString:k]) { [h addObject:f]; break; }
        }
    }
    if ([fm fileExistsAtPath:@"/var/jb/Library/LaunchDaemons/com.huayuarc.cputhermal.charge.plist"]) [h addObject:S("旧版充电守护")];
    return h;
}
// ★ 0930r2：环境自检「扫描缓存 + 限制读取」（原来每次进页面都在主线程把每个第三方 dylib 整文件读进内存 → 明显卡顿）
//   ① 大文件只读「头 256KB + 尾 256KB」（小文件照读全）→ 读取量降到 1/10 以下，特征串漏报风险≈0
//   ② 结果落盘缓存：键 = 本设置 bundle 修改时间 + 注入目录清单指纹（装了/卸了插件自动失效）；同一状态 7 天内直接吃缓存
#define CT_SUSPECTS_CACHE_PATH CTDiagFileC("CTHermesSuspects.plist")   // ★ 2.0.38：隐根版走容器
#define CT_SUSPECTS_CACHE_TTL  604800.0                 // 7 天
#define CT_SUSPECTS_READ_CAP   (256 * 1024)             // 头/尾各读这么多

static NSString *CTSelfBuildStamp(void) {
    // 用本设置 bundle 的修改时间当"版本戳"：重装/升级必然变化 → 缓存自动失效
    @try {
        NSString *bp = [[NSBundle bundleForClass:NSClassFromString(S("CTHermesRootListController"))] bundlePath];
        if (bp.length) {
            NSDictionary *a = [[NSFileManager defaultManager] attributesOfItemAtPath:bp error:nil];
            NSDate *d = a[NSFileModificationDate];
            if (d) return [NSString stringWithFormat:S("%.0f"), [d timeIntervalSince1970]];
        }
    } @catch (__unused NSException *e) {}
    NSString *fp = [NSString stringWithUTF8String:CT_SOURCE_FP];
    return (fp.length ? fp : S("0"));
}

static NSArray *CTSuspectDirs(void) {
    NSMutableArray *dirs = [NSMutableArray arrayWithObjects:
        @"/var/jb/Library/MobileSubstrate/DynamicLibraries",
        @"/var/jb/usr/lib/TweakInject",
        @"/Library/MobileSubstrate/DynamicLibraries",
        @"/usr/lib/TweakInject", nil];
    NSFileManager *fm = [NSFileManager defaultManager];
    // ★ 1.4.20：RootHide 的真实注入目录藏在 .jbroot-XXXX 里
    for (NSString *base in @[@"/var/mobile/Containers/Shared/AppGroup", @"/var/containers/Shared/SystemGroup", @"/var/mobile/Library"]) {
        for (NSString *sub in ([fm contentsOfDirectoryAtPath:base error:nil] ?: @[])) {
            if ([sub hasPrefix:@".jbroot-"]) {
                [dirs addObject:[base stringByAppendingPathComponent:
                    [sub stringByAppendingPathComponent:@"var/jb/Library/MobileSubstrate/DynamicLibraries"]]];
            }
        }
    }
    return dirs;
}

// 注入目录清单指纹（只列目录，不读文件 → 毫秒级）：装了/卸了插件就变 → 缓存失效
static NSString *CTDirsSignature(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSMutableArray *names = [NSMutableArray array];
    for (NSString *dir in CTSuspectDirs()) {
        for (NSString *f in ([fm contentsOfDirectoryAtPath:dir error:nil] ?: @[])) [names addObject:f];
    }
    [names sortUsingSelector:@selector(compare:)];
    const char *c = [[names componentsJoinedByString:S("|")] UTF8String];
    uint32_t h = 2166136261u;
    if (c) { for (; *c; c++) { h ^= (uint8_t)*c; h *= 16777619u; } }
    return [NSString stringWithFormat:S("%@#%lu#%u"), CTSelfBuildStamp(), (unsigned long)names.count, h];
}

static NSData *CTSuspectBytesAtPath(NSString *path) {
    @try {
        NSDictionary *a = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
        unsigned long long sz = [a[NSFileSize] unsignedLongLongValue];
        if (sz <= (unsigned long long)(CT_SUSPECTS_READ_CAP * 2)) {
            return [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
        }
        NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:path];
        if (!fh) return nil;
        NSMutableData *md = [NSMutableData dataWithCapacity:(NSUInteger)(CT_SUSPECTS_READ_CAP * 2)];
        NSData *head = [fh readDataOfLength:CT_SUSPECTS_READ_CAP];
        if (head) [md appendData:head];
        @try { [fh seekToFileOffset:(unsigned long long)(sz - CT_SUSPECTS_READ_CAP)]; } @catch (__unused NSException *e) {}
        NSData *tail = [fh readDataOfLength:CT_SUSPECTS_READ_CAP];
        if (tail) [md appendData:tail];
        [fh closeFile];
        return md;
    } @catch (__unused NSException *e) {}
    return nil;
}

static NSArray *CTSuspectsCacheRead(void) {
    static NSArray *sMemo = nil;      // 同一进程内只读一次磁盘
    static BOOL sTried = NO;
    if (sTried) return sMemo;
    sTried = YES;
    @try {
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:S(CT_SUSPECTS_CACHE_PATH)];
        if ([d isKindOfClass:[NSDictionary class]]) {
            NSString *ver = d[S("ver")]; NSNumber *ts = d[S("ts")]; NSArray *items = d[S("items")];
            if ([ver isKindOfClass:[NSString class]] && [items isKindOfClass:[NSArray class]] && [ts isKindOfClass:[NSNumber class]]) {
                if ([ver isEqualToString:CTDirsSignature()] &&
                    ([[NSDate date] timeIntervalSince1970] - [ts doubleValue]) < CT_SUSPECTS_CACHE_TTL) {
                    sMemo = items;
                }
            }
        }
    } @catch (__unused NSException *e) {}
    return sMemo;
}

static void CTSuspectsCacheSave(NSArray *items) {
    @try {
        NSDictionary *d = [NSDictionary dictionaryWithObjectsAndKeys:
            CTDirsSignature(), S("ver"),
            [NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]], S("ts"),
            (items ?: @[]), S("items"), nil];
        [d writeToFile:S(CT_SUSPECTS_CACHE_PATH) atomically:YES];
    } @catch (__unused NSException *e) {}
}

static NSArray *CTThermalSuspects(void);   // 前置声明（定义在下方）
static NSArray *CTConflictGroup(void) {
    NSArray *h = [CTConflictScan() arrayByAddingObjectsFromArray:CTThermalSuspects()];
    PSSpecifier *g = [PSSpecifier emptyGroupSpecifier];
    [g setProperty:(h.count ? [NSString stringWithFormat:S("环境自检 ⚠️ 检出可能冲突的插件：%@。\n温控类 / 充电类插件只能留一个，否则会出现读不到频率温度、充电异常、浮窗异常等现象。建议卸载多余的插件后重启用户空间。"), [h componentsJoinedByString:S("、")]] : S("环境自检：未检测到可能冲突的插件 ✓")) forKey:S("footerText")];
    NSString *t = h.count ? [NSString stringWithFormat:S("⚠️ 检出可能冲突的插件 %lu 个"), (unsigned long)h.count] : S("✅ 环境自检：未检测到冲突插件");
    PSSpecifier *r = [PSSpecifier preferenceSpecifierNamed:t target:nil set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
    return @[g, r];
}

static NSArray *CTThermalSuspects(void) {
    NSArray *cached = CTSuspectsCacheRead();
    if (cached) return cached;          // ★ 0930r2：命中缓存 → 秒开（不再扫盘）
    NSMutableArray *out = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *marks = @[@"PredictiveChargingInhibit", @"thermalmonitord", @"Powercuff", @"CPUThermalLevel", @"kIOPMPSIsChargingKey"];
    NSArray *dirs = CTSuspectDirs();
    NSMutableSet *seen = [NSMutableSet set];
    for (NSString *dir in dirs) {
        for (NSString *f in ([fm contentsOfDirectoryAtPath:dir error:nil] ?: @[])) {
            NSString *low = [f lowercaseString];
            if (![low hasSuffix:@".dylib"]) continue;
            if ([f hasPrefix:@"CTHermes"] || [low hasPrefix:@"com.qq391160"]) continue;
            if ([seen containsObject:f]) continue;
            BOOL hit = NO;
            NSData *d = CTSuspectBytesAtPath([dir stringByAppendingPathComponent:f]);   // ★ 0930r2：大文件只读头尾
            if (d) { for (NSString *m in marks) {
                if ([d rangeOfData:[m dataUsingEncoding:NSUTF8StringEncoding] options:0 range:NSMakeRange(0, d.length)].location != NSNotFound) { hit = YES; break; } } }
            NSString *bp = [[dir stringByAppendingPathComponent:f] stringByDeletingPathExtension];
            NSDictionary *fi = [NSDictionary dictionaryWithContentsOfFile:[bp stringByAppendingPathExtension:@"plist"]];
            if (fi && [[fi description].lowercaseString containsString:@"thermalmonitord"]) hit = YES;
            if (hit) { [seen addObject:f]; [out addObject:f]; }
        }
    }
    // ★ 1.4.20：再补一圈——本进程已加载的第三方 dylib（最可靠；只报名字带温控/充电关键字的，避免误报）
    NSArray *kw = @[@"chargelimit", @"chargelimiter", @"powercuff", @"batterylimit", @"turboboost",
                    @"cpufreq", @"thermal", @"batterycharge", @"batteryhealth", @"chargecap"];
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *nm = _dyld_get_image_name(i);
        if (!nm) continue;
        NSString *p = [NSString stringWithUTF8String:nm];
        if (p.length == 0) continue;
        NSString *low = [p lowercaseString];
        if ([low containsString:@"cputhermal"] || [low containsString:@"com.qq391160"]) continue;
        if (![low containsString:@"/library/mobilesubstrate/"] && ![low containsString:@"/tweak"] && ![low containsString:@"/substrate/"]) continue;
        for (NSString *k in kw) {
            if ([low containsString:k]) {
                NSString *bn = [p lastPathComponent];
                if (![seen containsObject:bn]) { [seen addObject:bn]; [out addObject:[@"（已加载）" stringByAppendingString:bn]]; }
                break;
            }
        }
    }
    CTSuspectsCacheSave(out);   // ★ 0930r2：本次扫描结果落盘，下次进页面直接吃缓存
    return out;
}

- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self ctBuildSpecifiers];
    return _specifiers;
}

- (PSSpecifier *)ctGroupWithFooter:(NSString *)footer {
    PSSpecifier *g = [PSSpecifier emptyGroupSpecifier];
    if (footer.length) [g setProperty:footer forKey:S("footerText")];
    return g;
}

- (PSSpecifier *)ctSwitch:(NSString *)label key:(NSString *)key default:(BOOL)def {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:@selector(ctSetPref:specifier:) get:@selector(ctGetPref:) detail:nil cell:PSSwitchCell edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:[NSNumber numberWithBool:def] forKey:S("ctDefault")];
    return sp;
}

- (PSSpecifier *)ctSlider:(NSString *)label key:(NSString *)key def:(double)def min:(double)mn max:(double)mx fmt:(NSString *)fmt {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:@selector(ctSetPref:specifier:) get:@selector(ctGetPref:) detail:nil cell:(PSCellType)5 /* PSSliderCell 的枚举真值 */ edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:[NSNumber numberWithDouble:def] forKey:S("ctDefault")];
    [sp setProperty:[NSNumber numberWithDouble:def] forKey:S("default")];
    [sp setProperty:[NSNumber numberWithDouble:mn] forKey:S("min")];
    [sp setProperty:[NSNumber numberWithDouble:mx] forKey:S("max")];
    [sp setProperty:[NSNumber numberWithBool:YES] forKey:S("isContinuous")];
    [sp setProperty:[NSNumber numberWithBool:YES] forKey:S("showValue")];
    [sp setProperty:@YES forKey:S("ctSliderRow")];   // ★ 1.4.6b：自绘滑块行标记
    [sp setProperty:fmt forKey:S("ctSliderFmt")];
    return sp;
}

- (PSSpecifier *)ctActionRow:(NSString *)label action:(NSString *)action {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:nil get:nil detail:nil cell:(PSCellType)1 edit:nil];   // ★ 1.4.73：链接样式（箭头贴行尾 ✓）
    [sp setProperty:action forKey:S("action")];
    [sp setProperty:@"" forKey:S("default")];
    ctBindSpecifierActionTarget(sp, NSSelectorFromString(action), self);   // ★ 关键：代码生成的行动作要直接绑定（运行时写，兼容各环境头文件差异；只 setProperty → 点了没反应）
    return sp;
}

- (PSSpecifier *)ctSegmentRow:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values key:(NSString *)key default:(NSString *)def {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:S("") target:self set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:def forKey:S("ctDefault")];
    [sp setProperty:@YES forKey:S("ctSegment")];
    [sp setProperty:titles forKey:S("ctSegTitles")];
    if (subs) [sp setProperty:subs forKey:S("ctSegSubs")];
    [sp setProperty:values forKey:S("ctSegValues")];
    return sp;
}

- (PSSpecifier *)ctMultiChipRow:(NSArray *)titles keys:(NSArray *)keys {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:S("") target:self set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
    [sp setProperty:@YES forKey:S("ctMultiChip")];
    [sp setProperty:titles forKey:S("ctmTitles")];
    [sp setProperty:keys forKey:S("ctmKeys")];
    return sp;
}

- (PSSpecifier *)ctPaneSpecifierAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        NSInteger section = -1, row = 0;
        for (PSSpecifier *sp in _specifiers) {
            NSString *cellProp = [sp propertyForKey:S("cell")];
            BOOL isGroup = [cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")];
            if (isGroup) { section++; row = 0; continue; }
            if (section == (NSInteger)indexPath.section && row == (NSInteger)indexPath.row) return sp;
            row++;
        }
        if (indexPath.section == 0 && indexPath.row < (NSInteger)_specifiers.count) return _specifiers[indexPath.row];
    } @catch (__unused NSException *e) {}
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    @try {
        id sp = nil;
        @try { sp = [cell valueForKey:S("specifier")]; } @catch (__unused NSException *e) {}
        if (!sp) return cell;
        if ([sp propertyForKey:S("action")]) {   // ★ 1.4.78：动作行 ⇒ 自绘【白色箭头】替换系统灰（彻底解决 ✓）
            @try {
                UIImage *ch = [UIImage systemImageNamed:S("chevron.right")];
                @try { ch = [ch imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:13.0 weight:UIFontWeightSemibold]]; } @catch (__unused NSException *e) {}   // ★ 1.4.79：缩到 13 号（和系统箭头同款 ✓）
                UIImageView *iv = [[UIImageView alloc] initWithImage:ch];
                iv.tintColor = [UIColor labelColor];
                iv.contentMode = UIViewContentModeScaleAspectFit;
                iv.frame = CGRectMake(0, 0, 10, 16);
                cell.accessoryView = iv;
            } @catch (__unused NSException *e) {}
        }
        if ([sp propertyForKey:S("ctSegment")]) {
            CTSentryModeCell *seg = [tableView dequeueReusableCellWithIdentifier:S("CTSentryModeCell")];
            if (!seg) seg = [[CTSentryModeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryModeCell")];
            NSArray *titles = [sp propertyForKey:S("ctSegTitles")] ?: @[];
            NSArray *subs = [sp propertyForKey:S("ctSegSubs")] ?: @[];
            NSArray *vals = [sp propertyForKey:S("ctSegValues")] ?: @[];
            [seg ctConfigureTitles:titles subs:subs values:vals];
            id cur = [self ctGetPref:sp];   // ★ 1.4.6b：按 key 读（含默认档）—— 修“打开时无选中高亮”
            if (cur && ![cur isKindOfClass:[NSString class]]) cur = [cur stringValue];
            [seg setSelectedValue:cur];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            __weak CTSentryModeCell *weakSeg = seg;
            seg.onPick = ^(NSString *value) {
                [weakSelf setPreferenceValue:value specifier:weakSpec];
                [weakSeg setSelectedValue:value];   // ★ 1.4.6b：点选立即高亮（即时反馈）
                CTSettingsDiagLine([NSString stringWithFormat:S("充电管家：选择 %@"), value]);   // ★ 诊断
            };
            return seg;
        }
        if ([sp propertyForKey:S("ctMultiChip")]) {
            NSArray *titles = [sp propertyForKey:S("ctmTitles")] ?: @[];
            NSArray *keys = [sp propertyForKey:S("ctmKeys")] ?: @[];
            // ★ 1.4.122：每排内容独立复用标识（防不同排互相复用触发重建 → 点按中拆除闪退）
            NSString *ctmReuse = [S("CTMCC-") stringByAppendingString:[titles componentsJoinedByString:S("|")]];
            CTSentryMultiChipCell *mc = [tableView dequeueReusableCellWithIdentifier:ctmReuse];
            if (!mc) mc = [[CTSentryMultiChipCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ctmReuse];
            mc.specifier = sp;   // ★ 2.0.41：配上本行 specifier（框架点按/刷新要读）
            NSDictionary *prefs = [self prefs];
            NSMutableArray *states = [NSMutableArray array];
            for (NSString *k in keys) [states addObject:[NSNumber numberWithBool:[(prefs[k] ?: @YES) boolValue]]];
            [mc ctmConfigureTitles:titles keys:keys selected:states];
            __weak typeof(self) weakSelf = self;
            mc.onToggle = ^(NSString *key, BOOL on) {
                @try {
                    PSSpecifier *ps = [PSSpecifier preferenceSpecifierNamed:S("") target:nil set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
                    [ps setProperty:key forKey:S("key")];
                    [weakSelf setPreferenceValue:[NSNumber numberWithBool:on] specifier:ps];
                    CTSettingsDiagLine([NSString stringWithFormat:S("显示内容：%@ = %@"), key, on ? S("开") : S("关")]);
                } @catch (__unused NSException *e) {}
            };
            return mc;
        }
        if ([sp propertyForKey:S("ctSliderRow")]) {
            CTSentrySliderCell *sl = [tableView dequeueReusableCellWithIdentifier:S("CTSentrySliderCell")];
            if (!sl) sl = [[CTSentrySliderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentrySliderCell")];
            sl.specifier = sp;   // ★ 2.0.41：同上
            id cur = [self ctGetPref:sp];
            double v = cur ? [cur doubleValue] : 0.0;
            double mn = [[sp propertyForKey:S("min")] doubleValue];
            double mx = [[sp propertyForKey:S("max")] doubleValue];
            NSString *fmt = [sp propertyForKey:S("ctSliderFmt")];
            [sl ctConfigureMin:mn max:mx value:v fmt:fmt];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            sl.onValue = ^(double value, BOOL committed) {
                if (!committed) return;   // ★ 拖动中只更新显示；松手才写盘
                [weakSelf setPreferenceValue:[NSNumber numberWithDouble:value] specifier:weakSpec];
                CTSettingsDiagLine([NSString stringWithFormat:S("滑块 %@ = %.2f"), [weakSpec propertyForKey:S("key")], value]);   // ★ 诊断
            };
            return sl;
        }
    } @catch (__unused NSException *e) {}
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    PSSpecifier *sp = [self ctPaneSpecifierAtIndexPath:indexPath];
    if (sp) {
        if ([sp propertyForKey:S("ctSegment")]) return 68.0;
        if ([sp propertyForKey:S("ctMultiChip")]) return 68.0;
        if ([sp propertyForKey:S("ctSliderRow")]) return 60.0;
        // 空白分组行 = 卡片间黑缝（与根页面一致）
        NSString *cellProp = [sp propertyForKey:S("cell")];
        NSString *groupLabel = [sp propertyForKey:S("label")];
        if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
            && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) return 16.0;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

- (id)ctGetPref:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    id v = key.length ? [self prefs][key] : nil;
    if (v) return v;
    id d = [spec propertyForKey:S("ctDefault")];
    return d ?: [NSNumber numberWithBool:NO];
}

- (void)ctSetPref:(id)value specifier:(PSSpecifier *)spec {
    [self setPreferenceValue:value specifier:spec];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *t = [self ctPaneTitleText];
    if (t.length) {
        self.title = t;
        self.navigationItem.title = t;
    }
}

// ★ 2.0.5：弹窗方法补到面板基类——2.0.4 的「重置浮窗位置」提示框调用的这个方法当时只写在主页类里，
//   浮窗页（面板）上找不到实现 → 点击时出错、设置框架顺手补推一个"空白页"（就是用户看到的空页面）。
//   放到基类：全部面板都能正常弹提示（重置提示框从此正常显示）。
- (void)showSimpleAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:title
        message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end

@interface CTSentryPaneSmartController : CTSentryPaneBase @end
@implementation CTSentryPaneSmartController
- (NSString *)ctPaneTitleText { return S("深度省电"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("无操作深度省电：界面停手 2 秒后进入深度压制（更省电、机身更凉），触碰屏幕立即恢复；仅作用于低频率时段，游戏与性能模式不受影响。\n视频场景优化：检测到视频或直播播放时，自动豁免深度降频并暂停滑动提速（防卡顿、更省电）。\n视频中也深度省电：开启后，视频与直播播放时也允许进入深度档（更省电；个别软解直播可能卡顿，默认关闭）。")]];
    [a addObject:[self ctSwitch:S("无操作深度省电") key:S("idleSinkEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("视频场景优化") key:S("videoProfileEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("视频中也深度省电") key:S("videoDeepEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneGameController : CTSentryPaneBase @end
@implementation CTSentryPaneGameController
- (NSString *)ctPaneTitleText { return S("游戏加速"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("识别为「游戏」的应用（依据 App Store 分类元数据判定）运行时一律按高性能执行，无视当前模式；自签、侧载等无法识别的游戏，请到「App 档位」中将其设为「高性能」。\n（自 1.4.4 起：游戏运行期间不会被系统发热降频打断，极端发热下也保持高性能。）")]];
    [a addObject:[self ctSwitch:S("游戏强制高性能") key:S("gameForceFullEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneScrollController : CTSentryPaneBase @end
@implementation CTSentryPaneScrollController
- (NSString *)ctPaneTitleText { return S("智能提速"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("开合 App 提速：桌面与 App 相互切换时临时提速（覆盖冷启动与首帧）。默认关闭。")]];
    [a addObject:[self ctSwitch:S("开合 App 提速") key:S("appBoostEnabled") default:NO]];
    [a addObject:[self ctSlider:S("提速时长（秒）") key:S("appBoostSecs") def:3.0 min:2.0 max:5.0 fmt:S("%.0f")]];
    [a addObject:[self ctGroupWithFooter:S("作用：在 App 内滑动（滚动）时，处于低频率档的应用会临时提速（约 1 秒后自动回落）——滑动更跟手，停手立即回落省电。默认关闭。")]];
    [a addObject:[self ctSwitch:S("滑动时自动提速") key:S("scrollBoostEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneFloatController : CTSentryPaneBase <UIColorPickerViewControllerDelegate>
// ★ 2.0.4：前置声明（"重置浮窗位置"按钮的提示弹窗用；实现见本类下方）
- (void)showSimpleAlertWithTitle:(NSString *)title message:(NSString *)message;
@end
@implementation CTSentryPaneFloatController
// ★ 2.0.4：重置浮窗位置（治"拖到屏幕底部、被小白条手势区卡住拖不回"）
//   只做两件事：清掉浮窗的"位置记忆文件"（竖屏 .pos + 横屏 .land）+ 发专用通知。
//   不写任何设置键、不碰任何其他逻辑 —— 对其它功能零影响。
- (void)ctResetFloatPos {
    static CFAbsoluteTime sLastAt = 0;                    // ★ 2.0.5：防双触发（300ms 内只认一次）
    CFAbsoluteTime nowAt = CFAbsoluteTimeGetCurrent();
    if (nowAt - sLastAt < 0.3) return;
    sLastAt = nowAt;
    CTFloatRemoveAll(S("CTHermesFloat.pos"));   // ★ 2.0.46：全候选一起清（含各层/各目录）
    CTFloatRemoveAll(S("CTHermesFloat.land"));
    notify_post("com.qq391160.cpucore/resetFloatPos");
    [self showSimpleAlertWithTitle:S("已重置浮窗位置") message:S("浮窗已回到默认位置（右上角）。\n若浮窗未开启，下次开启即为默认位置。")];
}

- (void)ctPickFloatTextColor {
    static CFAbsoluteTime sPickAt = 0;                    // ★ 2.0.5：防双触发（300ms 内只认一次）
    CFAbsoluteTime pickNow = CFAbsoluteTimeGetCurrent();
    if (pickNow - sPickAt < 0.3) return;
    sPickAt = pickNow;
    UIColorPickerViewController *vc = [[UIColorPickerViewController alloc] init];
    vc.delegate = self;
    vc.selectedColor = [UIColor whiteColor];
    vc.supportsAlpha = NO;
    UIViewController *host = self.navigationController ?: self;
    [host presentViewController:vc animated:YES completion:nil];
}
- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)vc {
    CGFloat r=0,g=0,b=0,a=0;
    [vc.selectedColor getRed:&r green:&g blue:&b alpha:&a];
    NSString *hex = [NSString stringWithFormat:@"#%02X%02X%02X", (int)(r*255+0.5), (int)(g*255+0.5), (int)(b*255+0.5)];
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:S("") target:nil set:nil get:nil detail:nil cell:(PSCellType)6 edit:nil];
    [sp setProperty:S("floatTextColorHex") forKey:S("key")];
    [self ctSetPref:hex specifier:sp];
    PSSpecifier *sp2 = [PSSpecifier preferenceSpecifierNamed:S("") target:nil set:nil get:nil detail:nil cell:(PSCellType)6 edit:nil];
    [sp2 setProperty:S("floatTextColorOn") forKey:S("key")];
    // ★ 1.4.71：选色【只把颜色存起来】✗ 不再自动打开开关（开关=总闸 ✓ 关了就不生效 ✓）
    (void)sp2;
    // ★ 1.4.69：不自动关闭（避免"点一下界面全消失" ✓ 由用户点×关 ✓）
}
- (NSString *)ctPaneTitleText { return S("状态浮窗"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("悬浮窗：屏幕最上层实时显示「频率 · 模式 · 深度/提速状态」的小胶囊；可拖动、位置自动记忆、锁屏是否显示见「锁屏时隐藏」（默认锁屏照常显示、颜色自动跟大时钟）；内容过长时自动缩小字号以保证完整显示。长按胶囊锁定位置（再次长按解锁）。「浮窗字号」可在 6～20 之间调节；「隐藏悬浮窗背景」开启后仅保留文字与状态点。「跟随状态栏」：窗口文字颜色与状态栏时间完全一致（黑配黑、白配白）。开启「跟随状态栏」时，「浮窗文字颜色自定义」暂不生效。默认关闭。\n状态点颜色：白点代表常规（浅色模式下自动转为深色点）；橙代表提速中；绿代表深度降频；紫代表视频档。")]];
    [a addObject:[self ctSwitch:S("悬浮窗（实时状态）") key:S("floatWindowEnabled") default:NO]];
    [a addObject:[self ctSlider:S("浮窗字号") key:S("floatWindowFontSize") def:12.0 min:6.0 max:20.0 fmt:S("%.0f")]];
    [a addObject:[self ctSwitch:S("隐藏悬浮窗背景") key:S("floatWindowHideBg") default:NO]];
    [a addObject:[self ctSwitch:S("锁屏时隐藏") key:S("floatHideOnLock") default:NO]];   // ★ 2.0.92：打开后锁屏（含常亮显示）不显示浮窗；默认关=锁屏照常显示
    // ★ 2.0.79：颜色自适应开关已下架（功能代码保留休眠；颜色开关仅剩「跟随状态栏」）
    [a addObject:[self ctSwitch:S("跟随状态栏") key:S("floatWindowFollowTime") default:NO]];
    [a addObject:[self ctSwitch:S("浮窗文字颜色自定义") key:S("floatTextColorOn") default:NO]];
    [a addObject:[self ctActionRow:S("选择浮窗颜色") action:S("ctPickFloatTextColor")]];
    [a addObject:[self ctActionRow:S("重置浮窗位置") action:S("ctResetFloatPos")]];   // ★ 2.0.4：治"拖到屏幕底部被小白条卡住"——只清位置+回默认，不碰其他
    [a addObject:[self ctGroupWithFooter:S("显示内容：点一下选中（蓝色）、再点取消——只有选中的模块才会显示在浮窗里。「充电」与「充电管家 → 充电实时数据」是同一个开关；「电流」：实时电池电流（正值进电、负值放电）；「网速」：实时网速（上下行合计，空闲显示 0K/s）；「电量」：当前剩余电量（如 90%）；「温度」：电池温度；「帧率」：实时帧率（FPS，可用于验证 120 高刷是否拉满）。全部取消时悬浮窗整体隐藏（不显示任何内容、无白点）。默认全选。")]];
    [a addObject:[self ctMultiChipRow:@[S("状态点"), S("频率"), S("模式"), S("标记"), S("充电")] keys:@[S("floatShowDot"), S("floatShowFreq"), S("floatShowMode"), S("floatShowFlags"), S("chargeDisplayEnabled")]]];
    // ★ 0929：第二排（一排最多 5 个）——电流 / 网速
    [a addObject:[self ctMultiChipRow:@[S("电流"), S("网速"), S("电量"), S("温度"), S("帧率")] keys:@[S("floatShowCurrent"), S("floatShowNetSpeed"), S("floatShowBattery"), S("floatShowTemp"), S("floatShowFPS")]]];
    return a;
}
@end

@interface CTSentryPaneProtectController : CTSentryPaneBase @end
@implementation CTSentryPaneProtectController
- (NSString *)ctPaneTitleText { return S("温控保护"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("· 防温控暗屏：所有模式下均保护显示亮度，动态读取本机亮度上限，并拦截系统热亮度限制；\n· 屏蔽高温温度计警告：阻止全屏「iPhone 需要冷却」警告及其高温强制锁屏行为；\n· 锁屏模拟口袋过热：仅在锁屏或熄屏时锁定 HIP 与 simulateHip，亮屏后自动恢复系统原生判断；\n· 锁定阳光暴晒：将 sunlightOverride 持久锁定为 true，关闭后恢复系统自动检测；\n· 设备朝下自动锁屏：检测到屏幕朝下时模拟按下锁屏键（仅注入 SpringBoard）；\n· 过热自动保护：热压升高或电池达到 44°C 时临时切换低功耗帮助降温，温度恢复约 5 秒后自动切回当前模式；\n· 屏蔽部件与维修记录：把「电池需要维修 / 非正品部件」相关提示按住不显示——电池页状态、关于本机信息、重要电池信息卡、桌面小红点一并处理（只影响显示，不改电池状态；容量百分比照实显示）。默认全部关闭。")]];
    [a addObject:[self ctSwitch:S("防温控暗屏") key:S("thermalPreventDimmingEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("屏蔽高温温度计警告") key:S("thermalBlockNotifPopup") default:NO]];
    [a addObject:[self ctSwitch:S("屏蔽部件与维修记录") key:S("suppressBatteryServiceWarnings") default:NO]];   // ★ 2.0.90：把「电池维修/非正品部件」相关提示按住（只影响显示）
    [a addObject:[self ctSwitch:S("锁屏模拟口袋过热") key:S("hipLockedEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("锁定阳光暴晒模式") key:S("sunlightLockedEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("设备朝下自动锁屏") key:S("lockWhenFaceDown") default:NO]];
    [a addObject:[self ctSwitch:S("过热自动保护") key:S("thermalPressureAutoProtectionEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("温度正常后自动恢复") key:S("thermalNominalAutoRecoveryEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneLowPowerController : CTSentryPaneBase @end
@implementation CTSentryPaneLowPowerController
- (NSString *)ctPaneTitleText { return S("低功耗增强"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("常驻「低功耗」时用到的设置。\n仅影响「低功耗」时段，「性能模式」不受影响。\n「桌面原生频率」：开启后，回到桌面时交还系统（原生）；关闭后，桌面也保持低功耗（默认）。")]];
    [a addObject:[self ctSwitch:S("桌面原生频率") key:S("lowPowerDesktopNative") default:NO]];
    return a;
}
@end

// ============================================================
// ★ 2.0.68：「高刷解锁」子页——由独立组件 CTHermesProMotion 执行
// ============================================================
static BOOL CTPaneDevice120(void) {   // 本机是否支持 120Hz（缓存；纯运行时查，不额外依赖框架）
    static int c120 = -1;
    if (c120 >= 0) return c120 == 1;
    c120 = 0;
    @try {
        Class dc = NSClassFromString(S("CADisplay"));
        SEL ms = NSSelectorFromString(S("mainDisplay"));
        if (dc && [dc respondsToSelector:ms]) {
            id disp = [dc performSelector:ms];
            SEL as = NSSelectorFromString(S("availableModes"));
            if (disp && [disp respondsToSelector:as]) {
                NSArray *modes = (NSArray *)[disp performSelector:as];
                for (id m in modes) {
                    if ([[m valueForKey:S("refreshRate")] doubleValue] >= 119.0) { c120 = 1; break; }
                }
            }
        }
    } @catch (__unused NSException *e) {}
    return c120 == 1;
}

@interface CTSentryPaneHighRefreshController : CTSentryPaneBase @end
@implementation CTSentryPaneHighRefreshController
- (NSString *)ctPaneTitleText { return S("高刷解锁"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    NSString *sup = CTPaneDevice120()
        ? S("本机支持：✅ 是（ProMotion 机型）")
        : S("本机支持：❌ 否（本机没有 120Hz 屏，开关将不生效）");
    [a addObject:[self ctGroupWithFooter:[NSString stringWithFormat:
        S("%@\n· 解锁全速刷新（解除系统对第三方 App 的 80Hz 限制）：App、系统界面、游戏与网页全链路顶到 120 帧；\n· 由独立组件执行，开关打开后才生效，关闭后完全还原系统（不残留、不冲突）；\n· 开启后动画与滑动更顺滑，耗电会略有增加；需要省电时可随时关闭。默认关闭。\n· 安装或升级后：重启一次用户空间 → 之后开关可随时切换、即时生效。\n· 验证方法：打开开关，去任意第三方 App（微信、微博、抖音）快速滑动列表；再关闭开关滑动一次——顺滑度的差别即可确认是否生效。\n· 「全局注入」：把全速刷新覆盖得更彻底，滑动时更「拉满」；属进阶项（略增耗电；默认关闭，可随时开启）。\n· 「智能锁帧 120」：只在滑动/拖动时把帧率顶满 120（点按、打字不触发，跟随系统）；松手约 1.5 秒自动松开省电；游戏与滑动期间锁满；看电影/直播时整个让路省电（默认关闭，可随时开关）。\n· 查看数值：到「状态浮窗 → 显示内容」勾选「帧率」，滑动时接近 120 即已生效。"), sup]]];
    [a addObject:[self ctSwitch:S("开启高刷（持续 120Hz）") key:S("proMotion120Enabled") default:NO]];
    [a addObject:[self ctSwitch:S("全局注入") key:S("proMotionGlobalEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("智能锁帧 120（流畅又省电）") key:S("proMotionLockEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneChargeController : CTSentryPaneBase @end
@implementation CTSentryPaneChargeController
- (NSString *)ctPaneTitleText { return S("充电管家"); }
- (int)ctChargeCurrentPct {
    id v = [self prefs][S("chargeLimitValue")];
    return v ? [v intValue] : 80;
}
- (PSSpecifier *)ctChargeLimitRow:(int)pct {
    NSString *label = ([self ctChargeCurrentPct] == pct)
        ? [NSString stringWithFormat:S("✓ %d%%"), pct]
        : [NSString stringWithFormat:S("　%d%%"), pct];
    NSString *sel = [NSString stringWithFormat:S("ctChargeLimit%d"), pct];
    return [self ctActionRow:label action:sel];
}
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    // ① 充电上限（独立卡 + 说明；五档点选）
    [a addObject:[self ctGroupWithFooter:S("充到设定档位后自动暂停，电量回落 5% 后继续充电；选择 100% 即不限制。")]];
    [a addObject:[self ctSwitch:S("充电上限") key:S("chargeLimitEnabled") default:NO]];
    [a addObject:[self ctSegmentRow:@[S("80%"), S("85%"), S("90%"), S("95%"), S("100%")]
                               subs:@[]
                             values:@[S("80"), S("85"), S("90"), S("95"), S("100")]
                                key:S("chargeLimitValue") default:S("80")]];
    // ② 温度保护充电
    // ③ 平稳限流已按用户要求取消（引擎代码保留休眠，可随时恢复）
    // ④ 发热也要充
    [a addObject:[self ctGroupWithFooter:S("防停充：仅在电池发热时介入——拦住系统的「高温停充」，能充则一直充；不发热时完全不干预充电（电池会更热、老化更快，请自行权衡）。")]];
    [a addObject:[self ctSwitch:S("防停充") key:S("chargeForceEnabled") default:NO]];
    // ⑥ 充电数据显示
    [a addObject:[self ctGroupWithFooter:S("浮窗显示 ⚡ 图标与实时瓦数：绿色表示正常、红色表示防停充、黑色表示已暂停、橙色表示恢复中。")]];
    [a addObject:[self ctSwitch:S("充电实时数据") key:S("chargeDisplayEnabled") default:YES]];
    return a;
}
- (void)ctChargeSetValue:(id)v forKey:(NSString *)key {
    NSMutableDictionary *prefs = [self prefs];
    prefs[key] = v;
    CTHermesWritePrefs(prefs);
    notify_post(kCTHermesSettingsChangedNotifC);
    [self reloadSpecifiers];
}
- (void)ctChargeLimit80  { [self ctChargeSetValue:@80  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit85  { [self ctChargeSetValue:@85  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit90  { [self ctChargeSetValue:@90  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit95  { [self ctChargeSetValue:@95  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit100 { [self ctChargeSetValue:@100 forKey:S("chargeLimitValue")]; }
@end

#pragma mark - 根页面

@interface CTHermesRootListController : CTSentryBaseController
@end

// ★ 0930-0207：检测"老版温控插件"（huayuarc / 老 CTHermes）是否还在机上 —— 用于插件内提醒
static BOOL ctLegacyPluginFound(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *daemons = @[@"/Library/LaunchDaemons/com.huayuarc.cputhermal.mount.plist",
                         @"/var/jb/Library/LaunchDaemons/com.huayuarc.cputhermal.mount.plist",
                         @"/Library/LaunchDaemons/com.huayuarc.cputhermal.charge.plist"];
    for (NSString *p in daemons) if ([fm fileExistsAtPath:p]) return YES;
    NSArray *dirs = @[@"/Library/MobileSubstrate/DynamicLibraries",
                      @"/var/jb/Library/MobileSubstrate/DynamicLibraries",
                      @"/usr/lib/TweakInject", @"/var/jb/usr/lib/TweakInject"];
    NSData *mark = [@"主插件已注入" dataUsingEncoding:NSUTF8StringEncoding];
    for (NSString *d in dirs) {
        NSString *dylib = [d stringByAppendingPathComponent:@"CTHermes.dylib"];
        if (![fm fileExistsAtPath:dylib]) continue;
        NSData *head = [NSData dataWithContentsOfFile:dylib options:NSDataReadingMappedIfSafe error:NULL];
        if (head.length == 0) return YES;
        if ([head rangeOfData:mark options:0 range:NSMakeRange(0, head.length)].location == NSNotFound) return YES;   // 没有我们的标记 ⇒ 是老版
    }
    return NO;
}
static void ctLegacyWarnLog(void) {
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; localtime_r(&tv.tv_sec, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    FILE *f = fopen(CTDiagLogPathC(), "a");
    if (f) { fprintf(f, "[%s][检测] 发现老版温控插件残留（huayuarc / 老 CTHermes）—— 已在设置页提醒用户卸载\n", ts); fclose(f); }
}

@implementation CTHermesRootListController

- (void)purgeRemovedFeaturePrefs {
    // 清理已删除功能遗留的配置键：避免旧值在插件里“复活”或与新逻辑冲突
    NSMutableDictionary *prefs = [self prefs];
    if (!prefs.count) return;
    NSArray *dead = [NSArray arrayWithObjects:
        S("simulateMaximumCapacity"),
        S("smartChargeEnabled"), S("smartChargeUseSmartBatteryAPI"),
        S("smartChargeDisableInflow"), S("smartChargeStopLevel"),
        S("__smartChargeOwnsInhibit"), S("__smartChargeOwnsInflowDisable"),
        S("__smartChargeOwnershipPreferSmart"),
        S("forceFastChargeEnabled"), S("killThermalStopCharging"),
        S("force120HzEnable"), S("highPerformanceModeEnabled"),
        S("thermalAutoLowPowerEnabled"),
        S("chargeNotifyEnabled"),   // 1.4.6b：充电提醒功能已取消 → 清理残留
        S("chargeSlowEnabled"), S("chargeGameLimit"), S("chargeGameLimitEnabled"),   // 1.4.6o：慢速充电已取消 → 清理残留
        S("chargeSimLevel"),   // 1.4.6u：平稳限流已取消 → 清理残留
        S("chargeHoldMode"),   // 1.4.6z7：涓流保持已取消 → 清理残留
        S("chargeTrickleEnabled"),   // 0929-2130：涓流充电（短暂实验版）已取消 → 清理残留
        nil];
    BOOL changed = NO;
    for (NSString *k in dead) {
        if (prefs[k]) { [prefs removeObjectForKey:k]; changed = YES; }
    }
    if (changed) CTHermesWritePrefs(prefs);
}

// ★ 1.4.6 身份校验（③）：明文"来源/署名"与其加密副本双重核对；不一致 → 写篡改旗标（插件侧读到后全部功能静默停用）
//   ⚠️ 维护须知：将来若修改下面任一明文串（URL / 品牌词），必须同步更新其 hex 副本，否则会被误判！
- (void)ctAuthUnlockIfPossible {
    @try {
        NSDictionary *p = [self prefs];
        NSString *dev = CTSettingsDeviceCode(p);
        NSString *code = [p[kCTKeyActivationCode] isKindOfClass:[NSString class]] ? p[kCTKeyActivationCode] : nil;
        uint8_t parts[32];
        if (dev.length > 0 && code.length > 0 &&
            CTAuthVerifyCode(dev, code) && CTAuthExtractParts(dev, code, parts)) {
            CTObfUnlock(parts);
            memset(parts, 0, sizeof(parts));
        } else {
            CTObfScrub();
        }
    } @catch (__unused NSException *e) { CTObfScrub(); }
}

- (void)ctIdentityCanary {
    if (!CTObfReady()) return;   // ★ 缺零件未解锁：无法判真伪，跳过（勿误报）
    @try {
        NSMutableDictionary *prefs = [self prefs];
        BOOL tampered = NO;
        NSString *decURL = CTObfStr("9bd30737de91a262118b70e0e621fb6892092b2ff4e7d527cd1718f6240ca1e8c550b27b");
        NSString *litURL = S("https://qq391160.github.io/repo/");
        if (!([decURL containsString:S("qq391160")] && [litURL containsString:S("qq391160")])) tampered = YES;
        if (decURL.length > 0 && litURL.length > 0 && ![decURL isEqualToString:litURL]) tampered = YES;
        NSString *decBrand = CTObfStr("ab2f775eb41c6480360583787f0c406a50b5a5");   // ★ 1.4.6k：修正编码笔误（原值解码=乱码 → 曾误判"被篡改"）
        NSString *litBrand = S("木子清风源");
        if (!([decBrand containsString:S("清风")] && [litBrand containsString:S("清风")])) tampered = YES;
        id cur = prefs[S("__integrityTampered")];
        BOOL curB = [cur isKindOfClass:[NSNumber class]] && [cur boolValue];
        if (tampered && !curB) {
            prefs[S("__integrityTampered")] = @YES;
            CTHermesWritePrefs(prefs);
            notify_post(kCTHermesSettingsChangedNotifC);
            CTSettingsDiagLine(S("来源校验：未通过（已写停用标记）"));   // ★ 1.4.6k：留痕
        } else if (!tampered && curB) {
            [prefs removeObjectForKey:S("__integrityTampered")];
            CTHermesWritePrefs(prefs);
            notify_post(kCTHermesSettingsChangedNotifC);
            CTSettingsDiagLine(S("来源校验：通过（已清停用标记 → 插件自动恢复）"));   // ★ 1.4.6k：留痕
        }
    } @catch (__unused NSException *e) {}
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self purgeRemovedFeaturePrefs];
    [self ctAuthUnlockIfPossible];   // ★ 缺零件：先解锁字符串体系（零件钥匙来自授权码）
    [self ctIdentityCanary];   // ★ 1.4.6 身份校验（③）
    CTSentryHeaderView *hero = [[CTSentryHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 124.0)];
    self.table.tableHeaderView = hero;
    [self ctSetupTableFooter];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self ctSetupTableFooter];
    {   // ★ 0930-0207：插件内提醒——检测到老版温控插件就提示一次（每个进程只提醒一次）
        static BOOL ctWarnedLegacy = NO;
        if (!ctWarnedLegacy && ctLegacyPluginFound()) {
            ctWarnedLegacy = YES;
            ctLegacyWarnLog();
            UIAlertController *a = [UIAlertController alertControllerWithTitle:S("检测到老版温控插件")
                message:S("机上还有老版（huayuarc / 老 CTHermes）。它和本插件会争抢温控，可能导致功能异常、甚至手机重启。\n\n建议：先卸载老版插件 → 必须重启手机（重启后自动启用，无需重装）→ 再使用本插件。")
                preferredStyle:UIAlertControllerStyleAlert];
            [a addAction:[UIAlertAction actionWithTitle:S("知道了") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:a animated:YES completion:nil];
        }
    }
}

// ★ 1.4.2：版本号固定在页面最底部（居中，与参考一致）
- (void)ctSetupTableFooter {
    UILabel *foot = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 36.0)];
    NSString *ctFootFp = [NSString stringWithUTF8String:CT_SOURCE_FP];
    foot.text = (ctFootFp.length > 0) ? [NSString stringWithFormat:S("Build 2.0.96 · 木子清风源 · %@"), ctFootFp] : S("Build 2.0.96 · 木子清风源");
    foot.font = [UIFont systemFontOfSize:12.0];
    foot.textColor = [UIColor secondaryLabelColor];
    foot.textAlignment = NSTextAlignmentCenter;
    self.table.tableFooterView = foot;
}

#pragma mark - 工具方法（打开链接 / 弹窗）

- (void)openURLString:(NSString *)urlString fallback:(NSString *)fallbackURL failureMessage:(NSString *)failureMessage {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;

    [[UIApplication sharedApplication] openURL:url
                                       options:[NSDictionary dictionary]
                             completionHandler:^(BOOL success) {
        if (success) return;
        if (fallbackURL) {
            NSURL *fallback = [NSURL URLWithString:fallbackURL];
            if (fallback) {
                [[UIApplication sharedApplication] openURL:fallback options:[NSDictionary dictionary] completionHandler:nil];
                return;
            }
        }
        if (failureMessage) {
            [self showSimpleAlertWithTitle:S("提示") message:failureMessage];
        }
    }];
}

- (void)showSimpleAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:title
        message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 木子清风源（添加源 / 兜底打开网页）

- (void)ctTryOpenURLs:(NSArray *)urls index:(NSUInteger)i failure:(NSString *)failure {
    if (i >= urls.count) {
        [self showSimpleAlertWithTitle:S("提示") message:failure];
        return;
    }
    NSURL *u = [NSURL URLWithString:urls[i]];
    if (!u) { [self ctTryOpenURLs:urls index:i + 1 failure:failure]; return; }
    [[UIApplication sharedApplication] openURL:u options:[NSDictionary dictionary] completionHandler:^(BOOL ok) {
        if (!ok) [self ctTryOpenURLs:urls index:i + 1 failure:failure];
    }];
}

- (BOOL)ctSpawnUIopen:(NSString *)urlString {
    NSArray *paths = [NSArray arrayWithObjects:S("/var/jb/usr/bin/uiopen"), S("/usr/bin/uiopen"), S("/var/jb/usr/local/bin/uiopen"), nil];
    NSString *tool = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *p in paths) {
        if ([fm isExecutableFileAtPath:p]) { tool = p; break; }
    }
    if (!tool.length) return NO;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        pid_t pid = 0;
        char *args[] = {(char *)"uiopen", (char *)urlString.UTF8String, NULL};
        if (posix_spawn(&pid, tool.fileSystemRepresentation, NULL, NULL, args, NULL) == 0) waitpid(pid, NULL, 0);
    });
    return YES;
}

- (BOOL)ctOpenViaLaunchServices:(NSURL *)url {
    @try {
        void *lsHandle = dlopen("/System/Library/PrivateFrameworks/LaunchServices.framework/LaunchServices", RTLD_NOW);
        (void)lsHandle;
        Class wsCls = NSClassFromString(S("LSApplicationWorkspace"));
        if (!wsCls) return NO;
        id ws = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        ws = [wsCls performSelector:NSSelectorFromString(S("defaultWorkspace"))];
#pragma clang diagnostic pop
        if (!ws) return NO;
        SEL sensitiveSel = NSSelectorFromString(S("openSensitiveURL:withOptions:"));
        if ([ws respondsToSelector:sensitiveSel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [ws performSelector:sensitiveSel withObject:url withObject:[NSDictionary dictionary]];
#pragma clang diagnostic pop
            return YES;
        }
        SEL plainSel = NSSelectorFromString(S("openURL:"));
        if ([ws respondsToSelector:plainSel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [ws performSelector:plainSel withObject:url];
#pragma clang diagnostic pop
            return YES;
        }
    } @catch (__unused NSException *e) {}
    return NO;
}

// ★ 1.4.5：部分设备（装了越狱伪装类插件）会拦截"标准 openURL"对 sileo:// 的跳转。
//   优先走系统内部通道（uiopen / LaunchServices 私有接口），每步做"是否已被接管"检测防抢跳。
- (void)openSourceRepo {
    NSString *repoURL = S("https://qq391160.github.io/repo/");
    NSString *sileoURLString = [NSString stringWithFormat:S("sileo://source/%@"), repoURL];
    NSURL *sileoURL = [NSURL URLWithString:sileoURLString];
    if (!sileoURL) {
        [self openURLString:repoURL fallback:nil failureMessage:S("没有找到可用的打开方式。请手动在 Sileo 里添加源：https://qq391160.github.io/repo/")];
        return;
    }
    __weak typeof(self) weakSelf = self;
    BOOL spawnedUIopen = [self ctSpawnUIopen:sileoURLString];
    double firstDelay = spawnedUIopen ? 0.9 : 0.05;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(firstDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
        [weakSelf ctOpenViaLaunchServices:sileoURL];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
            [[UIApplication sharedApplication] openURL:sileoURL options:[NSDictionary dictionary] completionHandler:nil];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
                [weakSelf openURLString:repoURL fallback:nil failureMessage:S("没有找到可用的打开方式。请手动在 Sileo 里添加源：https://qq391160.github.io/repo/")];
            });
        });
    });
}

#pragma mark - 重启用户空间

- (void)usreboot {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:S("重启用户空间")
        message:S("安装或升级时只会自动重启 thermalmonitord；此操作将重启 SpringBoard 和其他用户态服务。")
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("取消")
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:S("确定重启")
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) {
        pid_t pid = 0;
        NSString *toolPath = CTHermesToolPath();
        if (toolPath.length > 0 && [[NSFileManager defaultManager] isExecutableFileAtPath:toolPath]) {
            char *args[] = {(char *)"CTHermesTool", (char *)"userspace-reboot", NULL};
            if (posix_spawn(&pid, [toolPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
                waitpid(pid, NULL, 0);
                return;
            }
        }

        NSString *launchctlPath = CTHermesLaunchctlPath();
        if (launchctlPath.length == 0) return;
        char *args[] = {(char *)"launchctl", (char *)"reboot", (char *)"userspace", NULL};
        if (posix_spawn(&pid, [launchctlPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
            waitpid(pid, NULL, 0);
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 开源代码（保留旧入口文案）

- (void)openSourceCode {
    [self openURLString:S("https://github.com/be-huge/insulation") fallback:nil failureMessage:S("无法打开 GitHub，请手动访问 https://github.com/be-huge/insulation")];
}

#pragma mark - 署名行 → 打开 QQ

// ★ T7z23：多方案兜底（群名片 → 官方链接 → 只打开 QQ），全失败给出提示；带防抖避免重复触发
static CFAbsoluteTime sCTLastQQAt = 0;

- (void)ctQQLog:(NSString *)line {
    @try {
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:S(CTDiagLogDirC()) withIntermediateDirectories:YES attributes:nil error:NULL];
        NSString *path = S(CTDiagLogPathC());
        NSString *old = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL] ?: S("");
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = S("HH:mm:ss");
        NSString *stamp = [df stringFromDate:[NSDate date]];
        NSString *text = [old stringByAppendingFormat:S("[%@][QQ] %@\n"), stamp, line];
        [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    } @catch (__unused NSException *e) {}
}

- (void)tryOpenQQCandidates:(NSArray *)cands index:(NSUInteger)i options:(NSDictionary *)opts {
    if (i >= cands.count) {
        [self ctQQLog:@"全部方案失败（QQ 未安装或系统拦截）"];
        @try {   // ★ T7z23c：兜底 —— 把 QQ 号复制到剪贴板，打开 QQ 直接粘贴搜索
            [UIPasteboard generalPasteboard].string = S("12074475");
            [self ctQQLog:@"已把群号 12074475 复制到剪贴板"];
        } @catch (__unused NSException *e) {}
        [self showSimpleAlertWithTitle:S("打不开 QQ")
                               message:S("已把群号复制到剪贴板（12074475）。打开 QQ，粘贴到搜索框即可进群。")];
        return;
    }
    NSURL *u = [NSURL URLWithString:cands[i]];
    if (!u) { [self tryOpenQQCandidates:cands index:i + 1 options:opts]; return; }
    [[UIApplication sharedApplication] openURL:u options:opts completionHandler:^(BOOL success) {
        [self ctQQLog:[NSString stringWithFormat:S("方案%lu → %@"), (unsigned long)i, success ? S("成功") : S("失败")]];
        if (!success) [self tryOpenQQCandidates:cands index:i + 1 options:opts];
    }];
}

- (void)openAuthorQQ {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - sCTLastQQAt < 1.0) return;                      // 防抖：避免重复触发两次
    sCTLastQQAt = now;
    [self ctQQLog:@"点击「QQ 交流群」→ 尝试打开群"];
    NSArray *cands = [NSArray arrayWithObjects:
        S("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=12074475&card_type=group&source=qrcode"),   // ★ 1：QQ 群名片（装了 QQ 秒进群）
        S("https://qm.qq.com/q/wldSMcSoHC"),                                        // ★ 2：官方加群链接（网页兜底）
        S("mqqapi://card/show_pslcard?uin=12074475&card_type=group"),               // ★ 3：简版群名片
        S("mqq://"),                                                                 // 4：仅打开 QQ
        nil];
    [self tryOpenQQCandidates:cands index:0 options:[NSDictionary dictionary]];
}

#pragma mark - Specifier 加载与自定义渲染

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSArray *ctAuthCombined = [[self ctAuthSpecifiers] arrayByAddingObjectsFromArray:[self loadSpecifiersFromPlistName:S("Root") target:self]];
        _specifiers = [ctAuthCombined mutableCopy];
        [_specifiers addObjectsFromArray:CTConflictGroup()];   // ★ 0930 底部：环境自检（冲突检测）
        [self ctApplySpecifierHeights];
    }
    return _specifiers;
}

#pragma mark - ★ 0930：授权区（置顶）

// 根页自带行构造（面板基类的 ctGroupWithFooter/ctActionRow 在根控制器里不可见）
static PSSpecifier *ctAuthGroup(NSString *footer) {
    PSSpecifier *g = [PSSpecifier emptyGroupSpecifier];
    if (footer.length) [g setProperty:footer forKey:S("footerText")];
    return g;
}

static PSSpecifier *ctAuthRow(NSString *label, NSString *action, id target) {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:target set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
    [sp setProperty:label forKey:S("label")];   // ★ 修复：自绘行标题取自 "label" 属性（此前只设了 name → 标题显示不出来，只剩小字副标题）
    [sp setProperty:action forKey:S("action")];
    [sp setProperty:@"" forKey:S("default")];
    ctBindSpecifierActionTarget(sp, NSSelectorFromString(action), target);
    return sp;
}

- (NSArray *)ctAuthSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    NSDictionary *p = [self prefs];
    id devRaw = CTSettingsDeviceCode(p);
    id stRaw = p[kCTKeyAuthState];
    BOOL activated = [stRaw respondsToSelector:@selector(boolValue)] && [stRaw boolValue];
    NSString *dev = ([devRaw isKindOfClass:[NSString class]] && [(NSString *)devRaw length] > 0)
        ? (NSString *)devRaw : S("获取中（重开本页 / 重启用户空间）");
    [a addObject:ctAuthGroup(activated ? @"" : S("此插件需赞助授权后使用：将「设备码」私发给作者换取授权码（一码一机、永久有效；群里联系请认准群主/管理员）；授权后即可解锁全部功能（立即生效，无需注销）。未授权时，插件所有功能均不生效。"))];   // ★ 已授权后收起底部说明
    {
        BOOL flagged = NO;
        id tf = p[S("__integrityTampered")]; id af = p[S("__analysedFlag")];
        if ([tf respondsToSelector:@selector(boolValue)] && [tf boolValue]) flagged = YES;
        if ([af respondsToSelector:@selector(boolValue)] && [af boolValue]) flagged = YES;
        if (flagged) {
            PSSpecifier *sp = ctAuthRow(S("⚠️ 本版本已被修改"), S("ctAuthTapTampered"), self);
            [sp setProperty:S("exclamationmark.triangle") forKey:S("ctIcon")];
            [sp setProperty:S("orange") forKey:S("ctIconTint")];
            [sp setProperty:S("功能已停用 · 请使用官方版本") forKey:S("ctSub")];
            [a addObject:sp];
        }
    }
    {
        PSSpecifier *sp = ctAuthRow(S("授权状态"), S("ctAuthTapStatus"), self);
        [sp setProperty:(activated ? S("checkmark.seal.fill") : S("key")) forKey:S("ctIcon")];
        if (activated) [sp setProperty:S("green") forKey:S("ctIconTint")];
        [sp setProperty:(activated ? S("已授权 ✅ 全功能解锁") : S("未授权 · 加入 QQ 交流群获取授权")) forKey:S("ctSub")];
        [a addObject:sp];
    }
    if (!activated) {   // ★ 已授权后收起设备码行（点第 1 行可查看并复制）
        PSSpecifier *sp = ctAuthRow(S("设备码（点按复制）"), S("ctAuthTapDeviceCode"), self);
        [sp setProperty:S("doc.on.doc") forKey:S("ctIcon")];
        [sp setProperty:dev forKey:S("ctSub")];
        [a addObject:sp];
    }
    {   // ★ 0930-0191：输入行常显（已授权时 = 二次输入 / 换码 / 售后修复；一码一机，重粘即生效）
        PSSpecifier *sp = ctAuthRow(activated ? S("重新输入授权码") : S("输入授权码"), S("ctAuthTapInputCode"), self);
        [sp setProperty:S("checkmark.seal") forKey:S("ctIcon")];
        [sp setProperty:(activated ? S("换码 / 修复未生效（一码一机）") : S("粘贴授权码并启用")) forKey:S("ctSub")];
        [a addObject:sp];
    }
    {   // ★ 0930-0191：重置授权状态（清空本机已存码 → 回到「未授权」，售后一步到位）
        PSSpecifier *sp = ctAuthRow(S("重置授权状态"), S("ctAuthTapResetAuth"), self);
        [sp setProperty:S("arrow.counterclockwise") forKey:S("ctIcon")];
        [sp setProperty:(activated ? S("清空本机已存授权码（可随时重粘）") : S("本机当前没有已存授权码")) forKey:S("ctSub")];
        [a addObject:sp];
    }
    return a;
}

// ★ 注销一次：设置页（mobile 身份）没权限杀 SpringBoard → 写请求文件 + 发通知，由 root 守护进程代做（约 5 秒内生效）
static void ctAuthRequestRespring(void) {
    [[NSData data] writeToFile:S(CTDiagFileC("CTHermesRespring.req")) atomically:YES];
    notify_post(kCTHermesSettingsChangedNotifC);
}

// ★ 2.0.96：带「加入 QQ 交流群」按钮的授权弹窗
- (void)ctAuthShowJoinAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:S("加入 QQ 交流群") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        [self openAuthorQQ];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:ac animated:YES completion:nil];
}

- (void)ctAuthTapStatus {
    NSDictionary *p = [self prefs];
    BOOL activated = [p[kCTKeyAuthState] respondsToSelector:@selector(boolValue)] && [p[kCTKeyAuthState] boolValue];
    if (activated) {
        id devRaw = CTSettingsDeviceCode(p);
        NSString *dev = [devRaw isKindOfClass:[NSString class]] ? devRaw : S("（获取中）");
        BOOL copied = [dev hasPrefix:S("CT-")];            // ★ 授权后设备码行已收起：点本行查看并自动复制（售后/换机用）
        if (copied) [[UIPasteboard generalPasteboard] setString:dev];
        NSString *msg = [NSString stringWithFormat:S("全功能已解锁，感谢支持。\n\n设备码：%@%@"), dev, copied ? S("\n（已复制到剪贴板）") : S("")];
        UIAlertController *ac = [UIAlertController alertControllerWithTitle:S("已授权 ✅") message:msg preferredStyle:UIAlertControllerStyleAlert];
        [ac addAction:[UIAlertAction actionWithTitle:S("注销一次（重启桌面）") style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            ctAuthRequestRespring();
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self showSimpleAlertWithTitle:S("正在注销") message:S("已通知后台执行，约 5 秒内手机会自动重启桌面。")];
            });
        }]];
        [ac addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:ac animated:YES completion:nil];
        return;
    }
    id devRaw = CTSettingsDeviceCode(p);
    NSString *dev = [devRaw isKindOfClass:[NSString class]] ? devRaw : S("（获取中）");
    [self ctAuthShowJoinAlertWithTitle:S("未授权") message:[NSString stringWithFormat:S("未授权时插件所有功能均不生效。\n\n设备码：%@\n\n把设备码私发给作者换取授权码，然后在「输入授权码」里粘贴。\n（群里联系请认准群主/管理员，谨防冒充。）"), dev]];
}

- (void)ctAuthTapTampered {
    [self showSimpleAlertWithTitle:S("检测到本版本已被修改") message:S("此版本功能已停用。\n\n请卸载后从官方源重新下载安装；重装官方版本后功能会自动恢复。")];
}

- (void)ctAuthTapDeviceCode {
    NSDictionary *p = [self prefs];
    id devRaw = CTSettingsDeviceCode(p);
    NSString *dev = ([devRaw isKindOfClass:[NSString class]] && [(NSString *)devRaw length] > 0) ? devRaw : nil;
    if (dev.length == 0) {
        [self showSimpleAlertWithTitle:S("设备码获取中") message:S("插件刚加载或尚未运行；请重启用户空间后再来复制。")];
        return;
    }
    [UIPasteboard generalPasteboard].string = dev;
    CTSettingsDiagLine([NSString stringWithFormat:S("授权：复制设备码 %@"), dev]);
    [self ctAuthShowJoinAlertWithTitle:S("已复制设备码") message:[NSString stringWithFormat:S("%@\n\n私发给作者换取授权码（群里认准群主/管理员，谨防冒充）。"), dev]];
}

- (void)ctAuthTapInputCode {
    NSDictionary *p0 = [self prefs];
    id devRaw = CTSettingsDeviceCode(p0);
    NSString *dev = ([devRaw isKindOfClass:[NSString class]] && [(NSString *)devRaw length] > 0) ? devRaw : nil;
    if (dev.length == 0) {
        [self showSimpleAlertWithTitle:S("设备码获取中") message:S("请重启用户空间后重试。")];
        return;
    }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:S("输入授权码")
                                                                   message:[NSString stringWithFormat:S("设备码：%@"), dev]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = S("粘贴授权码");
        tf.autocorrectionType = UITextAutocorrectionTypeNo;
        tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
        tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:S("授权") style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *act) {
        NSString *code = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        BOOL ok = (code.length > 0) && CTAuthVerifyCode(dev, code);
        if (!ok) {
            CTSettingsDiagLine(S("授权：无效授权码被拒"));
            [self showSimpleAlertWithTitle:S("授权码无效") message:S("授权码须与上方设备码配套（一码一机），请核对后重试。")];
            return;
        }
        NSMutableDictionary *p = [self prefs];
        p[kCTKeyActivationCode] = code;
        p[kCTKeyAuthState] = @YES;
        CTHermesWritePrefs(p);
        // ★ 1.4.11：顺手写授权文件 = 「授权码」本身（可独立验签）→ 充电守护不必等主插件、立刻上岗；
        //   同时杜绝"往该文件写个 1 就能上岗"的旁路
        CTAuthWriteCodeAllPaths(code);   // ★ 0930-0207：授权码多路写（守护/核心都读得到）
        notify_post(kCTHermesSettingsChangedNotifC);
        CTSettingsDiagLine(S("授权：本地验签通过，已写入设置（含授权文件）"));
        _specifiers = nil;
        [self reloadSpecifiers];
        [self showSimpleAlertWithTitle:S("授权成功 ✅ 已生效") message:S("已解锁全部功能，立即生效。\n\n不需要注销，也不需要重启。")];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:S("取消") style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

// ★ 0930-0191：重置授权状态（售后修复入口）——清空本机已存码 + 授权文件，回到「未授权」，可立刻重粘
- (void)ctAuthTapResetAuth {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:S("重置授权状态")
                                                              message:S("将清空本机全部配置与已保存的授权码（你的码不会失效，随时可重新粘贴）。\n\n确定继续？")
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:S("重置") style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        NSMutableDictionary *p = [self prefs];
        NSString *__ctDevKeep = p[kCTKeyDevCode];   // 设备码保留（重新激活要用）
        [p removeAllObjects];                       // ★ 2.0.40：全部配置清零（一个键不留）
        if (__ctDevKeep) p[kCTKeyDevCode] = __ctDevKeep;
        p[kCTKeyAuthState] = @NO;
        CTHermesWritePrefs(p);
        CTAuthRemoveAllPaths();   // ★ 0930-0207：多路清除
        {   // ★ 2.0.40：连"跨权限票根"一起清（否则会 0.5 秒后"自己变回已授权"）
            NSFileManager *__ctFM = [NSFileManager defaultManager];
            for (NSString *__ctTP in CTAuthTicketPaths()) [__ctFM removeItemAtPath:__ctTP error:NULL];
        }
        notify_post(kCTHermesSettingsChangedNotifC);
        notify_post("com.qq391160.cpucore/authReset");   // ★ 2.0.40：请 root 引擎代清票根并立即全关
        CTSettingsDiagLine(S("授权：已重置（清空全部配置与授权文件），等待重新输入"));
        self->_specifiers = nil;
        [self reloadSpecifiers];
        [self showSimpleAlertWithTitle:S("已重置") message:S("本机授权与全部配置已清空。\n\n重新粘贴授权码后，按需要重新开启功能即可。")];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:S("取消") style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:ac animated:YES completion:nil];
}

// ★ 1.4.2：行高通过 specifier 的 height 属性下发（与委托方法双保险）
- (void)ctApplySpecifierHeights {
    for (PSSpecifier *sp in _specifiers) {
        @try {
            NSString *icon = [sp propertyForKey:S("ctIcon")];
            if ([icon isKindOfClass:[NSString class]] && icon.length) {
                [sp setProperty:[NSNumber numberWithDouble:66.0] forKey:S("height")];
                continue;
            }
            if ([sp propertyForKey:S("ctModeSelector")]) {
                [sp setProperty:[NSNumber numberWithDouble:68.0] forKey:S("height")];
                continue;
            }
            NSString *cellProp = [sp propertyForKey:S("cell")];
            NSString *groupLabel = [sp propertyForKey:S("label")];
            if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
                && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) {
                [sp setProperty:[NSNumber numberWithDouble:16.0] forKey:S("height")];
            }
        } @catch (__unused NSException *e) {}
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    @try {
        id sp = nil;
        @try { sp = [cell valueForKey:S("specifier")]; } @catch (__unused NSException *e) {}
        if (!sp) return cell;

        NSString *icon = [sp propertyForKey:S("ctIcon")];
        if ([icon isKindOfClass:[NSString class]] && icon.length) {
            CTSentryCell *row = [tableView dequeueReusableCellWithIdentifier:S("CTSentryCell")];
            if (!row) row = [[CTSentryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryCell")];
            [row configureWithSpecifier:sp];
            return row;
        }
        if ([sp propertyForKey:S("ctModeSelector")]) {
            CTSentryModeCell *mode = [tableView dequeueReusableCellWithIdentifier:S("CTSentryModeCell")];
            if (!mode) mode = [[CTSentryModeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryModeCell")];
            mode.ctSpecifier = sp;
            mode.specifier = sp;
            [mode ctConfigureTitles:@[S("智能"), S("低功耗"), S("性能模式")] subs:@[S("自动识别"), S("全局省电"), S("全局高性能")] values:@[S("smart"), S("lowPower"), S("fullPower")]];
            [mode setSelectedValue:[self readPreferenceValue:sp]];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            mode.onPick = ^(NSString *value) {
                [weakSelf setPreferenceValue:value specifier:weakSpec];
            };
            return mode;
        }
    } @catch (__unused NSException *e) {}
    return cell;
}

// 多 section / 单 section 两种结构下都能找到 indexPath 对应的 specifier
- (PSSpecifier *)ctSpecifierAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        NSInteger section = -1, row = 0;
        for (PSSpecifier *sp in _specifiers) {
            NSString *cellProp = [sp propertyForKey:S("cell")];
            BOOL isGroup = [cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")];
            if (isGroup) { section++; row = 0; continue; }
            if (section == (NSInteger)indexPath.section && row == (NSInteger)indexPath.row) return sp;
            row++;
        }
        if (indexPath.section == 0 && indexPath.row < (NSInteger)_specifiers.count) return _specifiers[indexPath.row];
    } @catch (__unused NSException *e) {}
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    PSSpecifier *sp = [self ctSpecifierAtIndexPath:indexPath];
    if (sp) {
        NSString *icon = [sp propertyForKey:S("ctIcon")];
        if ([icon isKindOfClass:[NSString class]] && icon.length) return 66.0;   // ★ 授权区四行：74 → 66（收紧间距）
        if ([sp propertyForKey:S("ctModeSelector")]) return 68.0;
        // ★ 空白分组行 = 卡片之间的黑缝 → 从 ~36pt 收到 18pt（用户要求减半）
        NSString *cellProp = [sp propertyForKey:S("cell")];
        NSString *groupLabel = [sp propertyForKey:S("label")];
        if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
            && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) return 18.0;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

// ★ 1.4.2 修订：不再自建 didSelect 分发 —— 全部交给系统原生机制：
//   · detail=类名 → 框架原生 push（与旧版 App 档位/自检同款机制）
//   · action=选择子 → 框架原生调度（与旧版署名行/重启同款机制）

@end
