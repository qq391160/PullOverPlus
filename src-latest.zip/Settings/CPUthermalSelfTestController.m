// ============================================================
// ★ T7z16：一键自检（设置页）
//   · 「开始 30 秒自检」→ 主插件后台采样 → 自动出报告 → 本页展示
//   · 报告 = 频率/深度/提速/温度 + 「压制是否生效」结论
//   · 禁止 @"" 常量（roothide 会崩），全部用 S()
// ============================================================

#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <CPUthermalPaths.h>

static NSString *CTStReq(void) { return S("/var/mobile/Library/Logs/CPUthermalSelfTest.req"); }
static NSString *CTStRes(void) { return S("/var/mobile/Library/Logs/CPUthermalSelfTest.txt"); }

// ---------- 报告查看页 ----------
@interface CPUthermalReportController : UIViewController
@property (nonatomic, copy) NSString *reportText;
@end

@implementation CPUthermalReportController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    UITextView *tv = [[UITextView alloc] initWithFrame:self.view.bounds];
    tv.editable = NO;
    tv.font = [UIFont monospacedSystemFontOfSize:12.5 weight:UIFontWeightRegular];
    tv.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    tv.textContainerInset = UIEdgeInsetsMake(14, 14, 14, 14);
    tv.text = self.reportText ?: S("");
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:tv];
}
@end

// ---------- 自检页 ----------
@interface CPUthermalSelfTestController : PSListController
@property (nonatomic, strong) NSTimer *pollTimer;
@property (nonatomic) CFAbsoluteTime startedAt;
@property (nonatomic) BOOL running;
@property (nonatomic, strong) PSSpecifier *statusGroup;
@end

@implementation CPUthermalSelfTestController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *arr = [NSMutableArray array];

        PSSpecifier *g1 = [PSSpecifier emptyGroupSpecifier];
        [g1 setProperty:S("自检说明") forKey:S("label")];
        [g1 setProperty:S("点下面的按钮跑 30 秒采样：自动统计 频率 / 深度 / 提速 / 温度，并判断「压制是否生效」。采样期间正常用手机，滑一滑更准。") forKey:S("footerText")];
        [arr addObject:g1];

        PSSpecifier *b1 = [PSSpecifier preferenceSpecifierNamed:S("开始 30 秒自检") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        b1->action = @selector(stStart:);
        [arr addObject:b1];

        self.statusGroup = [PSSpecifier emptyGroupSpecifier];
        [self.statusGroup setProperty:S("状态") forKey:S("label")];
        [self.statusGroup setProperty:S("（还没跑过）") forKey:S("footerText")];
        [arr addObject:self.statusGroup];

        PSSpecifier *b2 = [PSSpecifier preferenceSpecifierNamed:S("查看上次报告") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        b2->action = @selector(stShow:);
        [arr addObject:b2];

        _specifiers = arr;
    }
    return _specifiers;
}

- (void)setStatus:(NSString *)s {
    [self.statusGroup setProperty:s forKey:S("footerText")];
    [self reloadSpecifier:self.statusGroup];
}

- (void)stStart:(PSSpecifier *)spec {
    if (self.running) return;
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm removeItemAtPath:CTStRes() error:NULL];
    [fm removeItemAtPath:CTStReq() error:NULL];
    NSString *stamp = [NSString stringWithFormat:S("%.0f"), CFAbsoluteTimeGetCurrent()];
    if (![stamp writeToFile:CTStReq() atomically:YES encoding:NSUTF8StringEncoding error:NULL]) {
        [self setStatus:S("⚠ 写入请求失败——确认「CPU 智能温控」已安装并运行")];
        return;
    }
    self.running = YES;
    self.startedAt = CFAbsoluteTimeGetCurrent();
    [self setStatus:S("正在采样…约 30 秒（请正常用手机，滑一滑更准）")];
    [self.pollTimer invalidate];
    self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(stPoll) userInfo:nil repeats:YES];
}

- (void)stPoll {
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:CTStRes()]) {
        self.running = NO;
        [self.pollTimer invalidate]; self.pollTimer = nil;
        [self setStatus:S("✅ 完成（报告已生成）")];
        [self showReport];
        return;
    }
    double el = CFAbsoluteTimeGetCurrent() - self.startedAt;
    if (el > 45.0) {
        self.running = NO;
        [self.pollTimer invalidate]; self.pollTimer = nil;
        [self setStatus:S("⚠ 插件无响应——确认插件在运行；或重启用户空间后重试")];
        return;
    }
    [self setStatus:[NSString stringWithFormat:S("正在采样… 剩余约 %.0f 秒"), MAX(0.0, 32.0 - el)]];
}

- (void)stShow:(PSSpecifier *)spec { [self showReport]; }

- (void)showReport {
    NSString *rep = [NSString stringWithContentsOfFile:CTStRes() encoding:NSUTF8StringEncoding error:NULL];
    if (!rep.length) { [self setStatus:S("还没有报告——先点上面「开始 30 秒自检」")]; return; }
    CPUthermalReportController *r = [[CPUthermalReportController alloc] init];
    r.reportText = rep;
    r.title = S("自检报告");
    [self.navigationController pushViewController:r animated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.running && !self.pollTimer) {
        self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(stPoll) userInfo:nil repeats:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.pollTimer invalidate];
    self.pollTimer = nil;
    self.running = NO;
}

@end
