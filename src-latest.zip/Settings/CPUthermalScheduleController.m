// ============================================================
// ★ T7z16：定时切档（设置页主控制器）
//   · 总开关 + 两个时段入口（显示摘要）→ 编辑页（时段一/二）
//   · 保存即写入 com.qq391160.thermal，并通知主插件实时生效
//   · 到点自动切到目标档位、时段结束自动恢复；跨午夜自动处理
//   · 禁止 @"" 常量（roothide 会崩），全部用 S()
// ============================================================

#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <notify.h>
#import <CPUthermalPaths.h>

// ---------- 公共小工具（本文件内共用） ----------
static NSDictionary *CTPrefsRead(void) {
    return CPUthermalReadPrefs() ?: [NSDictionary dictionary];
}

static void CTPrefsSet(NSString *key, id value) {
    NSMutableDictionary *d = CPUthermalReadMutablePrefs();
    if (!d) d = [NSMutableDictionary dictionary];
    d[key] = value;
    CPUthermalWritePrefs(d);
    notify_post(kCPUthermalSettingsChangedNotifC);
}

static NSString *CTTimeStr(int minutes) {
    return [NSString stringWithFormat:S("%02d:%02d"), minutes / 60, minutes % 60];
}

static NSString *CTDaysStr(int days) {
    if (days == 0x7F) return S("每天");
    if (days == 0x1F) return S("工作日");
    if (days == 0x60) return S("周末");
    NSString *cs = S("一二三四五六日");
    NSMutableString *m = [NSMutableString string];
    for (int i = 0; i < 7; i++) {
        if ((days >> i) & 1) [m appendString:[cs substringWithRange:NSMakeRange(i, 1)]];
    }
    if (m.length == 0) return S("未选");
    return [NSString stringWithFormat:S("周%@"), m];
}

// ---------- 时段编辑页（自定义 VC，push 进入） ----------
@interface CPUthermalSegEditorController : UIViewController
@property (nonatomic) int segIndex;
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) UISwitch *onSwitch;
@property (nonatomic, strong) NSMutableArray *dayButtons;
@property (nonatomic, strong) UIDatePicker *startPicker;
@property (nonatomic, strong) UIDatePicker *endPicker;
@property (nonatomic, strong) UISegmentedControl *modeSegment;
@end

// ---------- 主控制器 ----------
@interface CPUthermalScheduleController : PSListController
@end

@implementation CPUthermalScheduleController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *arr = [NSMutableArray array];

        PSSpecifier *g1 = [PSSpecifier emptyGroupSpecifier];
        [g1 setProperty:S("定时切换") forKey:S("label")];
        [g1 setProperty:S("到设定时段自动切到目标档位；时段结束自动恢复你选的模式。支持两段、可跨午夜；两段同时命中时以「时段一」优先。定时生效期间会覆盖手动切换。") forKey:S("footerText")];
        [arr addObject:g1];

        PSSpecifier *en = [PSSpecifier preferenceSpecifierNamed:S("启用定时切换")
                                                         target:self
                                                            set:@selector(setPreferenceValue:forSpecifier:)
                                                            get:@selector(readPreferenceValue:)
                                                         detail:nil
                                                           cell:PSSwitchCell
                                                           edit:nil];
        [en setProperty:S("scheduleEnabled") forKey:S("key")];
        [en setProperty:@NO forKey:S("default")];
        [en setProperty:S("com.qq391160.thermal") forKey:S("defaults")];
        [arr addObject:en];

        PSSpecifier *g2 = [PSSpecifier emptyGroupSpecifier];
        [g2 setProperty:S("时段") forKey:S("label")];
        [g2 setProperty:S("点条目进入编辑：重复（勾周几）＋开始/结束时间（转轮自选）＋目标档位。") forKey:S("footerText")];
        [arr addObject:g2];

        for (int i = 0; i < 2; i++) {
            NSString *title = (i == 0) ? S("时段一") : S("时段二");
            PSSpecifier *b = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:S("%@　%@"), title, [self summaryForSeg:i]]
                                                            target:self
                                                               set:nil
                                                               get:nil
                                                            detail:nil
                                                              cell:PSButtonCell
                                                              edit:nil];
            b->action = (i == 0) ? @selector(editSeg1:) : @selector(editSeg2:);
            [arr addObject:b];
        }

        _specifiers = arr;
    }
    return _specifiers;
}

- (NSString *)summaryForSeg:(int)i {
    NSDictionary *d = CTPrefsRead();
    NSString *base = (i == 0) ? S("seg1") : S("seg2");
    BOOL on = [d[[base stringByAppendingString:S("On")]] ?: @NO boolValue];
    if (!on) return S("未启用，点此设置");
    int days = 0;
    for (int b2 = 0; b2 < 7; b2++) {
        NSString *k = [base stringByAppendingFormat:S("Day%d"), b2];
        if ([d[k] ?: @NO boolValue]) days |= (1 << b2);
    }
    int s = [d[[base stringByAppendingString:S("Start")]] ?: @0 intValue];
    int e = [d[[base stringByAppendingString:S("End")]] ?: @0 intValue];
    NSString *mstr = d[[base stringByAppendingString:S("Mode")]];
    NSString *mt = S("低功耗");
    if ([mstr isEqualToString:S("fullPower")]) mt = S("性能模式");
    else if ([mstr isEqualToString:S("smart")]) mt = S("智能");
    return [NSString stringWithFormat:S("%@ %@ → %@ · %@"), CTDaysStr(days), CTTimeStr(s), CTTimeStr(e), mt];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _specifiers = nil;              // 从编辑页返回时刷新摘要
    [self reloadSpecifiers];
}

- (void)editSeg1:(PSSpecifier *)spec { [self openEditor:0]; }
- (void)editSeg2:(PSSpecifier *)spec { [self openEditor:1]; }

- (void)openEditor:(int)i {
    CPUthermalSegEditorController *e = [[CPUthermalSegEditorController alloc] init];
    e.segIndex = i;
    e.title = (i == 0) ? S("时段一") : S("时段二");
    [self.navigationController pushViewController:e animated:YES];
}

- (id)readPreferenceValue:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    NSDictionary *d = CTPrefsRead();
    id v = d[key];
    return v ?: [spec propertyForKey:S("default")];
}

- (void)setPreferenceValue:(id)value forSpecifier:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    CTPrefsSet(key, value);
}

@end

// ============================================================
// 时段编辑页实现（自定义 VC；打开时若缺省则补出厂默认：工作日 9:00-18:00 低功耗）
// ============================================================
@interface CPUthermalSegEditorController ()
@property (nonatomic, strong) UILabel *onLabel;
@property (nonatomic, strong) UILabel *daysLabel;
@property (nonatomic, strong) UILabel *startLabel;
@property (nonatomic, strong) UILabel *endLabel;
@property (nonatomic, strong) UILabel *modeLabel;
@end

@implementation CPUthermalSegEditorController

- (NSString *)keyFor:(NSString *)suffix {
    NSString *base = (self.segIndex == 0) ? S("seg1") : S("seg2");
    return [base stringByAppendingString:suffix];
}

- (UILabel *)makeLabel:(NSString *)text {
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectZero];
    l.text = text;
    l.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    return l;
}

- (UIDatePicker *)makeTimePicker {
    UIDatePicker *p = [[UIDatePicker alloc] init];
    p.datePickerMode = UIDatePickerModeTime;
    p.preferredDatePickerStyle = UIDatePickerStyleWheels;
    p.minuteInterval = 5;
    return p;
}

- (NSDate *)dateFromMinutes:(int)m {
    NSDate *now = [NSDate date];
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *c = [cal components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:now];
    c.hour = m / 60;
    c.minute = m % 60;
    return [cal dateFromComponents:c] ?: now;
}

- (int)minutesFromPicker:(UIDatePicker *)p {
    NSDateComponents *c = [[NSCalendar currentCalendar] components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:p.date];
    return (int)c.hour * 60 + (int)c.minute;
}

- (void)styleDayButton:(UIButton *)b on:(BOOL)on {
    b.selected = on;
    b.backgroundColor = on ? [UIColor systemBlueColor] : [UIColor tertiarySystemFillColor];
    [b setTitleColor:(on ? [UIColor whiteColor] : [UIColor labelColor]) forState:UIControlStateNormal];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    self.scroll = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scroll.alwaysBounceVertical = YES;
    [self.view addSubview:self.scroll];

    NSString *base = (self.segIndex == 0) ? S("seg1") : S("seg2");
    NSDictionary *d = CTPrefsRead();

    // 首次进入：补齐出厂默认（工作日 9:00 → 18:00 · 低功耗；不自动启用）
    if (d[[base stringByAppendingString:S("Start")]] == nil) {
        CTPrefsSet([self keyFor:S("Start")], @(9 * 60));
        CTPrefsSet([self keyFor:S("End")], @(18 * 60));
        CTPrefsSet([self keyFor:S("Mode")], S("lowPower"));
        for (int i = 0; i < 5; i++) CTPrefsSet([self keyFor:[NSString stringWithFormat:S("Day%d"), i]], @YES);
        d = CTPrefsRead();
    }

    self.onLabel = [self makeLabel:S("启用本段")];
    [self.scroll addSubview:self.onLabel];
    self.onSwitch = [[UISwitch alloc] init];
    self.onSwitch.on = [d[[self keyFor:S("On")]] ?: @NO boolValue];
    [self.onSwitch addTarget:self action:@selector(onChanged) forControlEvents:UIControlEventValueChanged];
    [self.scroll addSubview:self.onSwitch];

    self.daysLabel = [self makeLabel:S("重复（点选星期）")];
    [self.scroll addSubview:self.daysLabel];
    self.dayButtons = [NSMutableArray array];
    NSArray *names = @[ S("一"), S("二"), S("三"), S("四"), S("五"), S("六"), S("日") ];
    for (int i = 0; i < 7; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        [b setTitle:names[i] forState:UIControlStateNormal];
        b.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
        b.tag = i;
        b.layer.cornerRadius = 9.0;
        NSString *dk = [self keyFor:[NSString stringWithFormat:S("Day%d"), i]];
        [self styleDayButton:b on:[d[dk] ?: @NO boolValue]];
        [b addTarget:self action:@selector(dayTapped:) forControlEvents:UIControlEventTouchUpInside];
        [self.dayButtons addObject:b];
        [self.scroll addSubview:b];
    }

    self.startLabel = [self makeLabel:S("开始时间（转轮自选）")];
    [self.scroll addSubview:self.startLabel];
    self.startPicker = [self makeTimePicker];
    self.startPicker.date = [self dateFromMinutes:[d[[self keyFor:S("Start")]] ?: @(9 * 60) intValue]];
    [self.startPicker addTarget:self action:@selector(startChanged) forControlEvents:UIControlEventValueChanged];
    [self.scroll addSubview:self.startPicker];

    self.endLabel = [self makeLabel:S("结束时间（转轮自选）")];
    [self.scroll addSubview:self.endLabel];
    self.endPicker = [self makeTimePicker];
    self.endPicker.date = [self dateFromMinutes:[d[[self keyFor:S("End")]] ?: @(18 * 60) intValue]];
    [self.endPicker addTarget:self action:@selector(endChanged) forControlEvents:UIControlEventValueChanged];
    [self.scroll addSubview:self.endPicker];

    self.modeLabel = [self makeLabel:S("目标档位")];
    [self.scroll addSubview:self.modeLabel];
    self.modeSegment = [[UISegmentedControl alloc] initWithItems:@[ S("低功耗"), S("性能模式"), S("智能") ]];
    NSString *mstr = d[[self keyFor:S("Mode")]];
    if ([mstr isEqualToString:S("fullPower")]) self.modeSegment.selectedSegmentIndex = 1;
    else if ([mstr isEqualToString:S("smart")]) self.modeSegment.selectedSegmentIndex = 2;
    else self.modeSegment.selectedSegmentIndex = 0;
    [self.modeSegment addTarget:self action:@selector(modeChanged) forControlEvents:UIControlEventValueChanged];
    [self.scroll addSubview:self.modeSegment];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat W = self.scroll.bounds.size.width;
    CGFloat y = 18.0;

    self.onLabel.frame = CGRectMake(20, y + 4, W - 120, 22);
    self.onSwitch.frame = CGRectMake(W - 20 - self.onSwitch.bounds.size.width, y, self.onSwitch.bounds.size.width, self.onSwitch.bounds.size.height);
    y += 54.0;

    self.daysLabel.frame = CGRectMake(20, y, W - 40, 22);
    y += 30.0;
    if (self.dayButtons.count == 7) {
        CGFloat gap = 6.0;
        CGFloat bw = floor((W - 40.0 - gap * 6.0) / 7.0);
        for (int i = 0; i < 7; i++) {
            UIButton *b = self.dayButtons[i];
            b.frame = CGRectMake(20 + i * (bw + gap), y, bw, 40.0);
        }
        y += 40.0 + 20.0;
    }

    self.startLabel.frame = CGRectMake(20, y, W - 40, 22);
    y += 30.0;
    self.startPicker.frame = CGRectMake(0, y, W, 216.0);
    y += 216.0 + 12.0;

    self.endLabel.frame = CGRectMake(20, y, W - 40, 22);
    y += 30.0;
    self.endPicker.frame = CGRectMake(0, y, W, 216.0);
    y += 216.0 + 12.0;

    self.modeLabel.frame = CGRectMake(20, y, W - 40, 22);
    y += 30.0;
    self.modeSegment.frame = CGRectMake(20, y, W - 40, 34.0);
    y += 34.0 + 48.0;

    self.scroll.contentSize = CGSizeMake(W, y);
}

// ---------- 改动即保存 ----------
- (void)onChanged {
    CTPrefsSet([self keyFor:S("On")], self.onSwitch.on ? @YES : @NO);
}

- (void)dayTapped:(UIButton *)b {
    BOOL on = !b.selected;
    [self styleDayButton:b on:on];
    CTPrefsSet([self keyFor:[NSString stringWithFormat:S("Day%d"), (int)b.tag]], on ? @YES : @NO);
}

- (void)startChanged {
    CTPrefsSet([self keyFor:S("Start")], @([self minutesFromPicker:self.startPicker]));
}

- (void)endChanged {
    CTPrefsSet([self keyFor:S("End")], @([self minutesFromPicker:self.endPicker]));
}

- (void)modeChanged {
    int idx = (int)self.modeSegment.selectedSegmentIndex;
    NSString *m = S("lowPower");
    if (idx == 1) m = S("fullPower");
    else if (idx == 2) m = S("smart");
    CTPrefsSet([self keyFor:S("Mode")], m);
}

@end
