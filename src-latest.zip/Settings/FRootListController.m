#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <spawn.h>
#import <sys/wait.h>
#import <notify.h>
#import <dlfcn.h>
#import <CPUthermalPaths.h>
#import <CTObf.h>
#import <CTFingerprint.h>
#import <CTCrashLog.h>

#include <time.h>
#include <stdio.h>

// ★ 1.4.6b：设置页诊断行（追加到 CPUthermalDiag.log）—— 用于核对“点选”等交互是否真正触发
static void CTSettingsDiagLine(NSString *msg) {
    @try {
        char tbuf[32]; time_t t = time(NULL); struct tm tmv; localtime_r(&t, &tmv);
        strftime(tbuf, sizeof(tbuf), "%H:%M:%S", &tmv);
        NSString *line = [NSString stringWithFormat:S("[%s] [设置] %@\n"), tbuf, msg];
        FILE *f = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
        if (f) { fputs(line.UTF8String, f); fclose(f); }
    } @catch (__unused NSException *e) {}
}

// ============================================================
// 注意: 禁止使用 @"" ObjC 字符串常量
// roothide 重映射会破坏 __cfstring 内部指针，导致 SIGBUS
// 所有字符串通过 C 字符串 + stringWithUTF8String: 动态创建
// ============================================================

// ============================================================
// ★ 1.4.2：设置页「重新排版」——
//   · 根页面：分类导航（英雄区 / 常驻模式三卡 / 主要功能 / 高级功能 / 支持与关于）
//   · 子页面：原有开关分组原样搬入（键值、默认值、行为一律未动）
//   · 所有偏好写入路径统一走 CTSentryBaseController：键值处理、整数夹取、
//     notify 通知与旧版逐字一致，只是界面换了组织方式。
// ============================================================

// 本机 stub 头未声明 UITableView 协议方法，这里补声明以便调用父类实现
@interface PSListController (CTSentryTableInternal)
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
@end

#pragma mark - 通用写入逻辑（根页面与子页面共用，行为=旧版 FRootListController）

@interface CTSentryBaseController : PSListController
@end

@implementation CTSentryBaseController
+ (void)load { CTCrashLogInstall("Settings"); }   // ★ 1.4.6：装上崩溃捕手（异常原文+调用栈 → CPUthermalDiag.log）

- (NSString *)prefPath {
    return CPUthermalCurrentPrefPath();
}

- (NSMutableDictionary *)prefs {
    NSMutableDictionary *d = CPUthermalReadMutablePrefs();
    if (!d) d = [NSMutableDictionary dictionary];
    return d;
}

- (void)runThermalToolCommand:(const char *)command value:(BOOL)value hasValue:(BOOL)hasValue {
    NSString *toolPath = CPUthermalToolPath();
    if (!toolPath.length || !command) return;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        pid_t pid = 0;
        char valueBuffer[2] = { value ? '1' : '0', '\0' };
        char *argsWithValue[] = {(char *)"CPUthermalTool", (char *)command, valueBuffer, NULL};
        char *argsNoValue[] = {(char *)"CPUthermalTool", (char *)command, NULL};
        char **arguments = hasValue ? argsWithValue : argsNoValue;
        if (posix_spawn(&pid, toolPath.fileSystemRepresentation, NULL, NULL, arguments, NULL) == 0) waitpid(pid, NULL, 0);
    });
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return;

    NSMutableDictionary *prefs = [self prefs];

    // 功率模式统一规范为字符串，防止框架传入 NSNumber 索引
    if ([key isEqualToString:S("powerMode")]) {
        if ([value isKindOfClass:[NSNumber class]]) {
            NSInteger ctModeIdx = [value integerValue];
            value = (ctModeIdx == 0) ? S("lowPower") : ((ctModeIdx == 1) ? S("fullPower") : S("smart"));
        } else if (![value isKindOfClass:[NSString class]]) {
            value = S("fullPower");
        }
    }

    prefs[key] = value;
    if ([key isEqualToString:S("floatWindowFontSize")]) {
        // ★ T7z18c：浮窗字号 —— 取整并夹在 6~20（滑块连续拖动也只存整数）
        double fs = [value doubleValue];
        if (fs < 6.0) fs = 6.0;
        if (fs > 20.0) fs = 20.0;
        prefs[key] = [NSNumber numberWithInt:(int)(fs + 0.5)];
    }
    if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        [prefs removeObjectForKey:S("sunlightAutomatic")];
        [prefs removeObjectForKey:S("sunlightOverride")];
    }
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        [prefs removeObjectForKey:S("hipProtectionEnabled")];
        [prefs removeObjectForKey:S("simulateHIP")];
        [prefs removeObjectForKey:S("hipLockedMode")];
    }
    CPUthermalWritePrefs(prefs);
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        // 设置页为亮屏：固定“仅锁屏”时立即恢复原生；锁屏后由 thermalmonitord 自动启用。
        [self runThermalToolCommand:"hip-lock" value:NO hasValue:YES];
    } else if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        if ([value boolValue]) [self runThermalToolCommand:"sunlight-override" value:YES hasValue:YES];
        else [self runThermalToolCommand:"sunlight-auto" value:NO hasValue:NO];
    }

    // 功率模式只发专用通知，避免 settingsChanged + powerModeChanged 重复应用。
    if ([key isEqualToString:S("powerMode")]) {
        notify_post(kCPUthermalPowerModeChangedNotifC);
        _specifiers = nil;
        [self reloadSpecifiers];
    } else {
        notify_post(kCPUthermalSettingsChangedNotifC);
    }
}

- (id)readPreferenceValue:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return nil;

    // 功率模式为字符串值，默认满血(性能模式)
    if ([key isEqualToString:S("powerMode")]) {
        id mode = [self prefs][key];
        if (mode && [mode isKindOfClass:[NSString class]]) return mode;
        return S("fullPower");
    }

    id val = [self prefs][key];
    if (val) return val;

    // ★ T7z18：浮窗字号默认 12（滑块初始位置）
    if ([key isEqualToString:S("floatWindowFontSize")]) return [NSNumber numberWithInt:12];
    if ([key isEqualToString:S("gameForceFullEnabled")]) return [NSNumber numberWithBool:YES];   // ★ T7z26：默认开

    // ★ 1.4.6b：带自定义默认档的行（滑块/档位）先取默认档，避免读成 0 造成显示错位
    id ctDef = [spec propertyForKey:S("ctDefault")];
    if (ctDef) return ctDef;

    // 其余功能开关默认关闭，仅用户主动开启后生效。
    return [NSNumber numberWithBool:NO];
}

@end

#pragma mark - 自定义外观元件

@interface CTSentryCell : UITableViewCell
@property(nonatomic, strong) PSSpecifier *ctSpecifier;
@property(nonatomic, strong) PSSpecifier *specifier;
@property(nonatomic, strong) UIImageView *ctIconView;
@property(nonatomic, strong) UILabel *ctTitleLabel;
@property(nonatomic, strong) UILabel *ctSubLabel;
@property(nonatomic, strong) UIImageView *ctChevron;
@end

@implementation CTSentryCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.contentView.backgroundColor = [UIColor clearColor];

    _ctIconView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _ctIconView.contentMode = UIViewContentModeCenter;
    _ctTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctTitleLabel.font = [UIFont systemFontOfSize:16.5];
    _ctTitleLabel.textColor = [UIColor labelColor];
    _ctSubLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctSubLabel.font = [UIFont systemFontOfSize:12.0];
    _ctSubLabel.textColor = [UIColor secondaryLabelColor];
    _ctChevron = [[UIImageView alloc] initWithFrame:CGRectZero];
    _ctChevron.contentMode = UIViewContentModeCenter;

    [self.contentView addSubview:_ctIconView];
    [self.contentView addSubview:_ctTitleLabel];
    [self.contentView addSubview:_ctSubLabel];
    [self.contentView addSubview:_ctChevron];
    return self;
}

- (void)configureWithSpecifier:(PSSpecifier *)sp {
    self.ctSpecifier = sp;
    self.specifier = sp;
    NSString *icon = [sp propertyForKey:S("ctIcon")];
    UIImage *img = nil;
    if ([icon isKindOfClass:[NSString class]] && icon.length) {
        img = [UIImage systemImageNamed:icon];
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:19.0 weight:UIImageSymbolWeightRegular];
        if (img && cfg) img = [img imageWithConfiguration:cfg];
        if (img) img = [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    }
    self.ctIconView.image = img;
    self.ctIconView.tintColor = [UIColor systemBlueColor];
    self.ctIconView.hidden = (img == nil);

    id label = [sp propertyForKey:S("label")];
    self.ctTitleLabel.text = [label isKindOfClass:[NSString class]] ? label : S("");
    id sub = [sp propertyForKey:S("ctSub")];
    self.ctSubLabel.text = [sub isKindOfClass:[NSString class]] ? sub : S("");
    self.ctSubLabel.hidden = (self.ctSubLabel.text.length == 0);

    UIImage *chev = [UIImage systemImageNamed:S("chevron.right")];
    UIImageSymbolConfiguration *ccfg = [UIImageSymbolConfiguration configurationWithPointSize:13.5 weight:UIImageSymbolWeightSemibold];
    if (chev && ccfg) chev = [chev imageWithConfiguration:ccfg];
    if (chev) chev = [chev imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    self.ctChevron.image = chev;
    // 和字体同色：深色模式=白 / 浅色模式=黑（自动跟随系统）
    self.ctChevron.tintColor = [UIColor labelColor];
    [self setNeedsLayout];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat iconSize = 26.0;
    CGFloat x = 16.0;
    self.ctIconView.frame = CGRectMake(x, (b.size.height - iconSize) / 2.0, iconSize, iconSize);
    CGFloat textX = x + iconSize + 12.0;
    CGFloat chevW = 14.0;
    CGFloat chevX = b.size.width - 16.0 - chevW;
    self.ctChevron.frame = CGRectMake(chevX, (b.size.height - 16.0) / 2.0, chevW, 16.0);
    CGFloat textW = chevX - textX - 8.0;
    if (!self.ctSubLabel.hidden) {
        self.ctTitleLabel.frame = CGRectMake(textX, b.size.height / 2.0 - 20.0, textW, 20.0);
        self.ctSubLabel.frame = CGRectMake(textX, b.size.height / 2.0 + 1.0, textW, 16.0);
    } else {
        self.ctTitleLabel.frame = CGRectMake(textX, 0, textW, b.size.height);
    }
}
@end

@interface CTSentryModeCell : UITableViewCell
@property(nonatomic, strong) PSSpecifier *ctSpecifier;
@property(nonatomic, strong) PSSpecifier *specifier;
@property(nonatomic, strong) UIView *ctTrack;
@property(nonatomic, copy) void (^onPick)(NSString *value);
@property(nonatomic, strong) NSMutableArray *chips;
@property(nonatomic, strong) NSMutableArray *chipNames;
@property(nonatomic, strong) NSMutableArray *chipSubs;
@property(nonatomic, strong) NSArray *values;
@property(nonatomic) double ctLastPickStamp;   // ★ 1.4.6b：点选去抖时间戳
- (void)ctConfigureTitles:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values;
- (void)setSelectedValue:(NSString *)value;
- (void)ctHandlePickIndex:(NSUInteger)idx;
- (void)ctWholeCellTapped:(UITapGestureRecognizer *)g;
@end

@implementation CTSentryModeCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _chips = [NSMutableArray array];
    _chipNames = [NSMutableArray array];
    _chipSubs = [NSMutableArray array];
    _ctTrack = [[UIView alloc] initWithFrame:CGRectZero];
    _ctTrack.backgroundColor = [UIColor clearColor];   // ★ 1.4.2：不加第二层背景（直接坐在卡片上）
    _ctTrack.layer.cornerRadius = 13.0;
    _ctTrack.layer.masksToBounds = YES;
    [self.contentView addSubview:_ctTrack];
    NSArray *titles = @[S("智能"), S("低功耗"), S("性能模式")];
    NSArray *subs   = @[S("自动识别"), S("全局省电"), S("全局高性能")];
    _values = @[S("smart"), S("lowPower"), S("fullPower")];
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:14.0];
        nm.textAlignment = NSTextAlignmentCenter;
        UILabel *sb = [[UILabel alloc] initWithFrame:CGRectZero];
        sb.text = subs[i];
        sb.font = [UIFont systemFontOfSize:10.0];
        sb.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        [chip addSubview:sb];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [_chips addObject:chip];
        [_chipNames addObject:nm];
        [_chipSubs addObject:sb];
    }
    UITapGestureRecognizer *ctWhole = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctWholeCellTapped:)];
    ctWhole.cancelsTouchesInView = NO;
    [self.contentView addGestureRecognizer:ctWhole];   // ★ 1.4.6b：整卡兜底点选（子块手势万一没吃到，这里也能选中）
    return self;
}

- (void)ctConfigureTitles:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)vals {
    if (![titles isKindOfClass:[NSArray class]] || titles.count == 0) return;
    NSArray *useSubs = [subs isKindOfClass:[NSArray class]] ? subs : @[];
    NSArray *useVals = [vals isKindOfClass:[NSArray class]] ? vals : @[];
    if (self.chips.count == titles.count && [self.values isEqualToArray:useVals]) return;   // 同构复用 → 跳过重建
    for (UIView *c in self.chips) [c removeFromSuperview];
    [self.chips removeAllObjects];
    [self.chipNames removeAllObjects];
    [self.chipSubs removeAllObjects];
    self.values = useVals;
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:14.0];
        nm.textAlignment = NSTextAlignmentCenter;
        UILabel *sb = [[UILabel alloc] initWithFrame:CGRectZero];
        sb.text = (i < useSubs.count) ? useSubs[i] : @"";
        sb.font = [UIFont systemFontOfSize:10.0];
        sb.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        [chip addSubview:sb];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [self.chips addObject:chip];
        [self.chipNames addObject:nm];
        [self.chipSubs addObject:sb];
    }
    [self setNeedsLayout];
}

- (void)ctChipTapped:(UITapGestureRecognizer *)g {
    [self ctHandlePickIndex:(NSUInteger)g.view.tag];
}

- (void)ctHandlePickIndex:(NSUInteger)idx {
    if (idx >= self.values.count) return;
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (now - self.ctLastPickStamp < 0.15) return;   // ★ 1.4.6b 去抖：两个手势同时命中只算一次
    self.ctLastPickStamp = now;
    if (self.onPick) self.onPick(self.values[idx]);
}

- (void)ctWholeCellTapped:(UITapGestureRecognizer *)g {
    CGPoint p = [g locationInView:self.contentView];
    for (UIView *chip in self.chips) {
        if (CGRectContainsPoint(chip.frame, p)) { [self ctHandlePickIndex:(NSUInteger)chip.tag]; return; }
    }
}

- (void)setSelectedValue:(NSString *)value {
    for (NSUInteger i = 0; i < self.chips.count; i++) {
        BOOL on = (i < self.values.count) && [self.values[i] isEqualToString:value];
        UIView *chip = self.chips[i];
        UILabel *nm = self.chipNames[i];
        UILabel *sb = self.chipSubs[i];
        if (on) {
            chip.backgroundColor = [UIColor systemBlueColor];
            nm.textColor = [UIColor whiteColor];
            sb.textColor = [UIColor colorWithWhite:1.0 alpha:0.8];
        } else {
            chip.backgroundColor = [UIColor clearColor];
            nm.textColor = [UIColor labelColor];
            sb.textColor = [UIColor secondaryLabelColor];
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 12.0, top = 2.0, inset = 2.0;
    CGFloat trackH = b.size.height - top - 2.0;
    CGFloat trackW = b.size.width - pad * 2.0;
    self.ctTrack.frame = CGRectMake(pad, top, trackW, trackH);
    if (self.chips.count == 0) return;
    CGFloat segW = (trackW - inset * 2.0) / (CGFloat)self.chips.count;
    CGFloat segH = trackH - inset * 2.0;
    for (NSUInteger i = 0; i < self.chips.count; i++) {
        UIView *chip = self.chips[i];
        chip.frame = CGRectMake(pad + inset + i * segW, top + inset, segW, segH);
        UILabel *nm = self.chipNames[i];
        UILabel *sb = self.chipSubs[i];
        if (sb.text.length == 0) {
            nm.frame = CGRectMake(0, segH / 2.0 - 10.0, segW, 20.0);   // 无副标题 → 主标题居中
        } else {
            nm.frame = CGRectMake(0, segH / 2.0 - 17.0, segW, 18.0);
            sb.frame = CGRectMake(0, segH / 2.0 + 3.0, segW, 14.0);
        }
    }
}
@end

// ============================================================
// ★ 0928-2：「显示内容」多选芯片行（样式与模式卡一致；点选/取消，可多选）
// ============================================================
@interface CTSentryMultiChipCell : UITableViewCell
@property(nonatomic, strong) NSMutableArray *ctmChips;
@property(nonatomic, strong) NSMutableArray *ctmNames;
@property(nonatomic, strong) NSMutableArray *ctmKeys;
@property(nonatomic, strong) NSMutableArray *ctmStates;
@property(nonatomic, assign) NSTimeInterval ctmLastStamp;
@property(nonatomic, copy) void (^onToggle)(NSString *key, BOOL on);
@end
@implementation CTSentryMultiChipCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _ctmChips = [NSMutableArray array];
    _ctmNames = [NSMutableArray array];
    _ctmKeys = [NSMutableArray array];
    _ctmStates = [NSMutableArray array];
    return self;
}
- (void)ctmConfigureTitles:(NSArray *)titles keys:(NSArray *)keys selected:(NSArray *)sel {
    if (![titles isKindOfClass:[NSArray class]] || titles.count == 0) return;
    if (self.ctmChips.count == titles.count && [self.ctmKeys isEqualToArray:(keys ?: @[])]) {
        [self ctmApplyStates:sel];
        [self setNeedsLayout];
        return;
    }
    for (UIView *c in self.ctmChips) [c removeFromSuperview];
    [self.ctmChips removeAllObjects];
    [self.ctmNames removeAllObjects];
    [self.ctmKeys removeAllObjects];
    [self.ctmStates removeAllObjects];
    [self.ctmKeys addObjectsFromArray:(keys ?: @[])];
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIView *chip = [[UIView alloc] initWithFrame:CGRectZero];
        chip.layer.cornerRadius = 9.5;
        chip.tag = (NSInteger)i;
        UILabel *nm = [[UILabel alloc] initWithFrame:CGRectZero];
        nm.text = titles[i];
        nm.font = [UIFont systemFontOfSize:13.0];
        nm.textAlignment = NSTextAlignmentCenter;
        [chip addSubview:nm];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctmChipTapped:)];
        [chip addGestureRecognizer:tap];
        [self.contentView addSubview:chip];
        [self.ctmChips addObject:chip];
        [self.ctmNames addObject:nm];
    }
    UITapGestureRecognizer *whole = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ctmWholeTapped:)];
    whole.cancelsTouchesInView = NO;
    [self.contentView addGestureRecognizer:whole];   // 整卡兜底点选
    [self ctmApplyStates:sel];
    [self setNeedsLayout];
}
- (void)ctmApplyStates:(NSArray *)sel {
    [self.ctmStates removeAllObjects];
    for (NSUInteger i = 0; i < self.ctmChips.count; i++) {
        BOOL on = (i < sel.count) && [sel[i] boolValue];
        [self.ctmStates addObject:[NSNumber numberWithBool:on]];
        UIView *chip = self.ctmChips[i];
        UILabel *nm = self.ctmNames[i];
        chip.backgroundColor = on ? [UIColor systemBlueColor] : [UIColor clearColor];
        nm.textColor = on ? [UIColor whiteColor] : [UIColor labelColor];
    }
}
- (void)ctmSetChip:(NSUInteger)idx on:(BOOL)on {
    if (idx >= self.ctmChips.count) return;
    self.ctmStates[idx] = [NSNumber numberWithBool:on];
    UIView *chip = self.ctmChips[idx];
    UILabel *nm = self.ctmNames[idx];
    chip.backgroundColor = on ? [UIColor systemBlueColor] : [UIColor clearColor];
    nm.textColor = on ? [UIColor whiteColor] : [UIColor labelColor];
}
- (void)ctmToggleIndex:(NSUInteger)idx {
    if (idx >= self.ctmChips.count || idx >= self.ctmKeys.count) return;
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (now - self.ctmLastStamp < 0.15) return;   // 去抖：两个手势同时命中只算一次
    self.ctmLastStamp = now;
    BOOL newOn = ![self.ctmStates[idx] boolValue];
    [self ctmSetChip:idx on:newOn];
    if (self.onToggle) self.onToggle(self.ctmKeys[idx], newOn);
}
- (void)ctmChipTapped:(UITapGestureRecognizer *)g { [self ctmToggleIndex:(NSUInteger)g.view.tag]; }
- (void)ctmWholeTapped:(UITapGestureRecognizer *)g {
    CGPoint p = [g locationInView:self.contentView];
    for (UIView *chip in self.ctmChips) {
        if (CGRectContainsPoint(chip.frame, p)) { [self ctmToggleIndex:(NSUInteger)chip.tag]; return; }
    }
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 12.0, top = 2.0, inset = 2.0;
    CGFloat trackH = b.size.height - top - 2.0;
    CGFloat trackW = b.size.width - pad * 2.0;
    if (self.ctmChips.count == 0) return;
    CGFloat segW = (trackW - inset * 2.0) / (CGFloat)self.ctmChips.count;
    CGFloat segH = trackH - inset * 2.0;
    for (NSUInteger i = 0; i < self.ctmChips.count; i++) {
        UIView *chip = self.ctmChips[i];
        chip.frame = CGRectMake(pad + inset + i * segW, top + inset, segW, segH);
        UILabel *nm = self.ctmNames[i];
        nm.frame = CGRectMake(0, segH / 2.0 - 10.0, segW, 20.0);
    }
}
@end

// ============================================================
// ★ 1.4.6b：自绘滑块行（替代框架 PSSliderCell）——
//   拖动中即时更新数值显示；松手才写盘+通知（一次交互一次写入，且不依赖框架刷新）。
// ============================================================
@interface CTSentrySliderCell : UITableViewCell
@property(nonatomic, strong) UISlider *ctSlider;
@property(nonatomic, strong) UILabel *ctValueLabel;
@property(nonatomic, copy) NSString *ctFmt;
@property(nonatomic, copy) void (^onValue)(double value, BOOL committed);
@end

@implementation CTSentrySliderCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _ctFmt = S("%.1f");
    _ctSlider = [[UISlider alloc] initWithFrame:CGRectZero];
    _ctSlider.continuous = YES;
    [_ctSlider addTarget:self action:@selector(ctSliderChanged:) forControlEvents:UIControlEventValueChanged];
    [_ctSlider addTarget:self action:@selector(ctSliderDone:) forControlEvents:(UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel)];
    [self.contentView addSubview:_ctSlider];
    _ctValueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _ctValueLabel.font = [UIFont systemFontOfSize:14.0];
    _ctValueLabel.textColor = [UIColor secondaryLabelColor];
    _ctValueLabel.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:_ctValueLabel];
    return self;
}

- (void)ctConfigureMin:(double)mn max:(double)mx value:(double)v fmt:(NSString *)fmt {
    self.ctSlider.minimumValue = (float)mn;
    self.ctSlider.maximumValue = (float)mx;
    if (v < mn) v = mn;
    if (v > mx) v = mx;
    self.ctSlider.value = (float)v;
    if (fmt.length) self.ctFmt = fmt;
    [self ctRefreshLabel:v];
}

- (void)ctRefreshLabel:(double)v {
    self.ctValueLabel.text = [NSString stringWithFormat:self.ctFmt, v];
}

- (void)ctSliderChanged:(UISlider *)s {
    [self ctRefreshLabel:s.value];
    if (self.onValue) self.onValue((double)s.value, NO);
}

- (void)ctSliderDone:(UISlider *)s {
    if (self.onValue) self.onValue((double)s.value, YES);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.contentView.bounds;
    CGFloat pad = 16.0, labelW = 48.0;
    self.ctSlider.frame = CGRectMake(pad, 2.0, b.size.width - pad * 2.0 - labelW - 6.0, b.size.height - 4.0);
    self.ctValueLabel.frame = CGRectMake(b.size.width - pad - labelW, b.size.height / 2.0 - 12.0, labelW, 24.0);
}
@end

@interface CTSentryHeaderView : UIView
@end

@implementation CTSentryHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectZero];
    UIImage *img = [UIImage imageNamed:S("icon") inBundle:[NSBundle bundleForClass:[self class]] compatibleWithTraitCollection:nil];
    icon.image = img;
    icon.contentMode = UIViewContentModeScaleAspectFit;
    icon.tag = 101;
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectZero];
    name.text = S("CPU 智能温控");
    name.font = [UIFont systemFontOfSize:17.0];
    name.textColor = [UIColor labelColor];
    name.textAlignment = NSTextAlignmentCenter;
    name.tag = 102;
    UILabel *tag = [[UILabel alloc] initWithFrame:CGRectZero];
    tag.text = S("智能温控 · 省电与性能自由切换");
    tag.font = [UIFont systemFontOfSize:12.5];
    tag.textColor = [UIColor secondaryLabelColor];
    tag.textAlignment = NSTextAlignmentCenter;
    tag.tag = 103;
    [self addSubview:icon];
    [self addSubview:name];
    [self addSubview:tag];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    UIImageView *icon = (UIImageView *)[self viewWithTag:101];
    UILabel *name = (UILabel *)[self viewWithTag:102];
    UILabel *tag = (UILabel *)[self viewWithTag:103];
    CGFloat iconSize = 56.0;
    icon.frame = CGRectMake((b.size.width - iconSize) / 2.0, 14.0, iconSize, iconSize);
    name.frame = CGRectMake(16.0, 78.0, b.size.width - 32.0, 22.0);
    tag.frame = CGRectMake(16.0, 100.0, b.size.width - 32.0, 17.0);
}
@end

#pragma mark - 子页面（6 个类，specifier 全部「代码生成」；写入行为随基类）

// ★ 1.4.2 修订：子页不再从 pane_*.plist 动态加载（该路径在本机框架上不生效），
//   改为代码生成 specifier —— 与 App 档位 / 定时切换 / 一键自检 同款机制。
@interface CTSentryPaneBase : CTSentryBaseController
- (NSMutableArray *)ctBuildSpecifiers;
- (NSString *)ctPaneTitleText;
- (PSSpecifier *)ctGroupWithFooter:(NSString *)footer;
- (PSSpecifier *)ctSwitch:(NSString *)label key:(NSString *)key default:(BOOL)def;
- (PSSpecifier *)ctSlider:(NSString *)label key:(NSString *)key def:(double)def min:(double)mn max:(double)mx fmt:(NSString *)fmt;
- (PSSpecifier *)ctActionRow:(NSString *)label action:(NSString *)action;
- (PSSpecifier *)ctSegmentRow:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values key:(NSString *)key default:(NSString *)def;
- (PSSpecifier *)ctMultiChipRow:(NSArray *)titles keys:(NSArray *)keys;
- (id)ctGetPref:(PSSpecifier *)spec;
- (void)ctSetPref:(id)value specifier:(PSSpecifier *)spec;
@end

// ★ 1.4.6：运行时绑定 specifier 的 action/target。
//   各环境头文件声明不一致（有的把 target 声明为 property、有的声明为 ivar）→ 用运行时写，两边兼容。
static void ctBindSpecifierActionTarget(PSSpecifier *sp, SEL sel, id target) {
    @try {
        Ivar ivA = class_getInstanceVariable([PSSpecifier class], "action");
        if (ivA) *(SEL *)((uint8_t *)(__bridge void *)sp + ivar_getOffset(ivA)) = sel;
        Ivar ivT = class_getInstanceVariable([PSSpecifier class], "target");
        if (ivT) object_setIvar(sp, ivT, target);
    } @catch (__unused NSException *e) {}
}

@implementation CTSentryPaneBase
- (NSString *)ctPaneTitleText { return S(""); }

- (NSMutableArray *)ctBuildSpecifiers { return [NSMutableArray array]; }

- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self ctBuildSpecifiers];
    return _specifiers;
}

- (PSSpecifier *)ctGroupWithFooter:(NSString *)footer {
    PSSpecifier *g = [PSSpecifier emptyGroupSpecifier];
    if (footer.length) [g setProperty:footer forKey:S("footerText")];
    return g;
}

- (PSSpecifier *)ctSwitch:(NSString *)label key:(NSString *)key default:(BOOL)def {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:@selector(ctSetPref:specifier:) get:@selector(ctGetPref:) detail:nil cell:PSSwitchCell edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:[NSNumber numberWithBool:def] forKey:S("ctDefault")];
    return sp;
}

- (PSSpecifier *)ctSlider:(NSString *)label key:(NSString *)key def:(double)def min:(double)mn max:(double)mx fmt:(NSString *)fmt {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:@selector(ctSetPref:specifier:) get:@selector(ctGetPref:) detail:nil cell:(PSCellType)5 /* PSSliderCell 的枚举真值 */ edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:[NSNumber numberWithDouble:def] forKey:S("ctDefault")];
    [sp setProperty:[NSNumber numberWithDouble:def] forKey:S("default")];
    [sp setProperty:[NSNumber numberWithDouble:mn] forKey:S("min")];
    [sp setProperty:[NSNumber numberWithDouble:mx] forKey:S("max")];
    [sp setProperty:[NSNumber numberWithBool:YES] forKey:S("isContinuous")];
    [sp setProperty:[NSNumber numberWithBool:YES] forKey:S("showValue")];
    [sp setProperty:@YES forKey:S("ctSliderRow")];   // ★ 1.4.6b：自绘滑块行标记
    [sp setProperty:fmt forKey:S("ctSliderFmt")];
    return sp;
}

- (PSSpecifier *)ctActionRow:(NSString *)label action:(NSString *)action {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:label target:self set:nil get:nil detail:nil cell:(PSCellType)4 /* PSTitleValueSpecifier 枚举真值 */ edit:nil];
    [sp setProperty:action forKey:S("action")];
    [sp setProperty:@"" forKey:S("default")];
    ctBindSpecifierActionTarget(sp, NSSelectorFromString(action), self);   // ★ 关键：代码生成的行动作要直接绑定（运行时写，兼容各环境头文件差异；只 setProperty → 点了没反应）
    return sp;
}

- (PSSpecifier *)ctSegmentRow:(NSArray *)titles subs:(NSArray *)subs values:(NSArray *)values key:(NSString *)key default:(NSString *)def {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:S("") target:self set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
    [sp setProperty:key forKey:S("key")];
    [sp setProperty:def forKey:S("ctDefault")];
    [sp setProperty:@YES forKey:S("ctSegment")];
    [sp setProperty:titles forKey:S("ctSegTitles")];
    if (subs) [sp setProperty:subs forKey:S("ctSegSubs")];
    [sp setProperty:values forKey:S("ctSegValues")];
    return sp;
}

- (PSSpecifier *)ctMultiChipRow:(NSArray *)titles keys:(NSArray *)keys {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:S("") target:self set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
    [sp setProperty:@YES forKey:S("ctMultiChip")];
    [sp setProperty:titles forKey:S("ctmTitles")];
    [sp setProperty:keys forKey:S("ctmKeys")];
    return sp;
}

- (PSSpecifier *)ctPaneSpecifierAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        NSInteger section = -1, row = 0;
        for (PSSpecifier *sp in _specifiers) {
            NSString *cellProp = [sp propertyForKey:S("cell")];
            BOOL isGroup = [cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")];
            if (isGroup) { section++; row = 0; continue; }
            if (section == (NSInteger)indexPath.section && row == (NSInteger)indexPath.row) return sp;
            row++;
        }
        if (indexPath.section == 0 && indexPath.row < (NSInteger)_specifiers.count) return _specifiers[indexPath.row];
    } @catch (__unused NSException *e) {}
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    @try {
        id sp = nil;
        @try { sp = [cell valueForKey:S("specifier")]; } @catch (__unused NSException *e) {}
        if (!sp) return cell;
        if ([sp propertyForKey:S("ctSegment")]) {
            CTSentryModeCell *seg = [tableView dequeueReusableCellWithIdentifier:S("CTSentryModeCell")];
            if (!seg) seg = [[CTSentryModeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryModeCell")];
            NSArray *titles = [sp propertyForKey:S("ctSegTitles")] ?: @[];
            NSArray *subs = [sp propertyForKey:S("ctSegSubs")] ?: @[];
            NSArray *vals = [sp propertyForKey:S("ctSegValues")] ?: @[];
            [seg ctConfigureTitles:titles subs:subs values:vals];
            id cur = [self ctGetPref:sp];   // ★ 1.4.6b：按 key 读（含默认档）—— 修“打开时无选中高亮”
            if (cur && ![cur isKindOfClass:[NSString class]]) cur = [cur stringValue];
            [seg setSelectedValue:cur];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            __weak CTSentryModeCell *weakSeg = seg;
            seg.onPick = ^(NSString *value) {
                [weakSelf setPreferenceValue:value specifier:weakSpec];
                [weakSeg setSelectedValue:value];   // ★ 1.4.6b：点选立即高亮（即时反馈）
                CTSettingsDiagLine([NSString stringWithFormat:S("充电管家：选择 %@"), value]);   // ★ 诊断
            };
            return seg;
        }
        if ([sp propertyForKey:S("ctMultiChip")]) {
            CTSentryMultiChipCell *mc = [tableView dequeueReusableCellWithIdentifier:S("CTSentryMultiChipCell")];
            if (!mc) mc = [[CTSentryMultiChipCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryMultiChipCell")];
            NSArray *titles = [sp propertyForKey:S("ctmTitles")] ?: @[];
            NSArray *keys = [sp propertyForKey:S("ctmKeys")] ?: @[];
            NSDictionary *prefs = [self prefs];
            NSMutableArray *states = [NSMutableArray array];
            for (NSString *k in keys) [states addObject:[NSNumber numberWithBool:[(prefs[k] ?: @YES) boolValue]]];
            [mc ctmConfigureTitles:titles keys:keys selected:states];
            __weak typeof(self) weakSelf = self;
            mc.onToggle = ^(NSString *key, BOOL on) {
                @try {
                    PSSpecifier *ps = [PSSpecifier preferenceSpecifierNamed:S("") target:nil set:nil get:nil detail:nil cell:(PSCellType)4 edit:nil];
                    [ps setProperty:key forKey:S("key")];
                    [weakSelf setPreferenceValue:[NSNumber numberWithBool:on] specifier:ps];
                    CTSettingsDiagLine([NSString stringWithFormat:S("显示内容：%@ = %@"), key, on ? S("开") : S("关")]);
                } @catch (__unused NSException *e) {}
            };
            return mc;
        }
        if ([sp propertyForKey:S("ctSliderRow")]) {
            CTSentrySliderCell *sl = [tableView dequeueReusableCellWithIdentifier:S("CTSentrySliderCell")];
            if (!sl) sl = [[CTSentrySliderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentrySliderCell")];
            id cur = [self ctGetPref:sp];
            double v = cur ? [cur doubleValue] : 0.0;
            double mn = [[sp propertyForKey:S("min")] doubleValue];
            double mx = [[sp propertyForKey:S("max")] doubleValue];
            NSString *fmt = [sp propertyForKey:S("ctSliderFmt")];
            [sl ctConfigureMin:mn max:mx value:v fmt:fmt];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            sl.onValue = ^(double value, BOOL committed) {
                if (!committed) return;   // ★ 拖动中只更新显示；松手才写盘
                [weakSelf setPreferenceValue:[NSNumber numberWithDouble:value] specifier:weakSpec];
                CTSettingsDiagLine([NSString stringWithFormat:S("滑块 %@ = %.2f"), [weakSpec propertyForKey:S("key")], value]);   // ★ 诊断
            };
            return sl;
        }
    } @catch (__unused NSException *e) {}
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    PSSpecifier *sp = [self ctPaneSpecifierAtIndexPath:indexPath];
    if (sp) {
        if ([sp propertyForKey:S("ctSegment")]) return 68.0;
        if ([sp propertyForKey:S("ctMultiChip")]) return 68.0;
        if ([sp propertyForKey:S("ctSliderRow")]) return 60.0;
        // 空白分组行 = 卡片间黑缝（与根页面一致）
        NSString *cellProp = [sp propertyForKey:S("cell")];
        NSString *groupLabel = [sp propertyForKey:S("label")];
        if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
            && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) return 16.0;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

- (id)ctGetPref:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    id v = key.length ? [self prefs][key] : nil;
    if (v) return v;
    id d = [spec propertyForKey:S("ctDefault")];
    return d ?: [NSNumber numberWithBool:NO];
}

- (void)ctSetPref:(id)value specifier:(PSSpecifier *)spec {
    [self setPreferenceValue:value specifier:spec];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *t = [self ctPaneTitleText];
    if (t.length) {
        self.title = t;
        self.navigationItem.title = t;
    }
}
@end

@interface CTSentryPaneSmartController : CTSentryPaneBase @end
@implementation CTSentryPaneSmartController
- (NSString *)ctPaneTitleText { return S("深度省电"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("无操作深度省电：界面停手 2 秒后进入深度压制（更省更凉），一碰屏幕立刻恢复；只作用于低频率时段，游戏/性能模式不受影响。\n视频场景优化：检测到视频/直播播放时，自动豁免深度降频、暂停滑动提速（防卡顿、更省电）。\n视频中也深度省电：开启后视频/直播播放时也允许进入深度档（更省电；个别软解直播可能卡，默认关）。")]];
    [a addObject:[self ctSwitch:S("无操作深度省电") key:S("idleSinkEnabled") default:YES]];
    [a addObject:[self ctSwitch:S("视频场景优化") key:S("videoProfileEnabled") default:YES]];
    [a addObject:[self ctSwitch:S("视频中也深度省电") key:S("videoDeepEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneGameController : CTSentryPaneBase @end
@implementation CTSentryPaneGameController
- (NSString *)ctPaneTitleText { return S("游戏加速"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("识别为「游戏」的应用（靠 App Store 分类元数据判定）运行时一律按高性能执行，无视当前模式。自签/侧载等识别不到的游戏，请到「App 档位」里把它钉成「高性能」。\n（1.4.4 起：游戏运行期间不会被系统发热降频打断，极端发热也保持高性能。）")]];
    [a addObject:[self ctSwitch:S("游戏强制高性能") key:S("gameForceFullEnabled") default:YES]];
    return a;
}
@end

@interface CTSentryPaneScrollController : CTSentryPaneBase @end
@implementation CTSentryPaneScrollController
- (NSString *)ctPaneTitleText { return S("滑动提速"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("作用：在 App 里滑动（滚动）时，低频率的应用会临时提速（约 1 秒后自动回落）——滑动更跟手，停手立刻回落省电。默认关闭，打开后生效。")]];
    [a addObject:[self ctSwitch:S("滑动时自动提速") key:S("scrollBoostEnabled") default:NO]];
    return a;
}
@end

@interface CTSentryPaneFloatController : CTSentryPaneBase @end
@implementation CTSentryPaneFloatController
- (NSString *)ctPaneTitleText { return S("状态浮窗"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("悬浮窗：屏幕最上层实时显示「频率 · 模式 · 深度/提速状态」的小胶囊；可拖动、位置自动记住、锁屏自动隐藏；内容过长自动缩字号保证完整显示。长按胶囊 = 锁定位置（再长按解锁）。「浮窗字号」可调 6~20；「隐藏悬浮窗背景」打开后只留纯白文字与状态点。默认关闭。")]];
    [a addObject:[self ctSwitch:S("悬浮窗（实时状态）") key:S("floatWindowEnabled") default:NO]];
    [a addObject:[self ctSlider:S("浮窗字号") key:S("floatWindowFontSize") def:12.0 min:6.0 max:20.0 fmt:S("%.0f")]];
    [a addObject:[self ctSwitch:S("隐藏悬浮窗背景") key:S("floatWindowHideBg") default:NO]];
    [a addObject:[self ctGroupWithFooter:S("显示内容：点一下选中（蓝色）、再点取消——选中的模块才会显示在浮窗里。「充电」与「充电管家 → 充电实时数据」是同一个开关；全部取消时保留一个状态点兜底。默认全选。")]];
    [a addObject:[self ctMultiChipRow:@[S("状态点"), S("频率"), S("模式"), S("标记"), S("充电")] keys:@[S("floatShowDot"), S("floatShowFreq"), S("floatShowMode"), S("floatShowFlags"), S("chargeDisplayEnabled")]]];
    return a;
}
@end

@interface CTSentryPaneProtectController : CTSentryPaneBase @end
@implementation CTSentryPaneProtectController
- (NSString *)ctPaneTitleText { return S("温控保护"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("· 防温控暗屏：所有模式均保护显示亮度，动态读取本机亮度上限并拦截系统热亮度限制；\n· 屏蔽高温温度计警告：阻止全屏「iPhone 需要冷却」警告及其高温强制锁屏行为；\n· 锁屏模拟口袋过热：仅在锁屏/熄屏时锁定 HIP 与 simulateHip，亮屏自动恢复系统原生判断；\n· 锁定阳光暴晒：将 sunlightOverride 持久锁定为 true，关闭后恢复系统自动检测；\n· 设备朝下自动锁屏：SpringBoard 检测到屏幕朝下时模拟按下锁屏键（仅注入 SpringBoard）；\n· 过热自动保护：热压升高或电池达 44°C 时临时切低功耗帮降温，温度恢复约 5 秒后自动切回你的模式。默认全部关闭。")]];
    [a addObject:[self ctSwitch:S("防温控暗屏") key:S("thermalPreventDimmingEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("屏蔽高温温度计警告") key:S("thermalBlockNotifPopup") default:NO]];
    [a addObject:[self ctSwitch:S("锁屏模拟口袋过热") key:S("hipLockedEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("锁定阳光暴晒模式") key:S("sunlightLockedEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("设备朝下自动锁屏") key:S("lockWhenFaceDown") default:NO]];
    [a addObject:[self ctSwitch:S("过热自动保护") key:S("thermalPressureAutoProtectionEnabled") default:NO]];
    [a addObject:[self ctSwitch:S("温度正常后自动恢复") key:S("thermalNominalAutoRecoveryEnabled") default:YES]];
    return a;
}
@end

@interface CTSentryPaneLowPowerController : CTSentryPaneBase @end
@implementation CTSentryPaneLowPowerController
- (NSString *)ctPaneTitleText { return S("低功耗增强"); }
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[self ctGroupWithFooter:S("常驻「低功耗」时用到的设置。\n只影响「低功耗」时段；「性能模式」不受影响。\n「桌面原生频率」：开 = 回桌面交还系统（原生）；关 = 桌面也保持低功耗（默认）。")]];
    [a addObject:[self ctSwitch:S("桌面原生频率") key:S("lowPowerDesktopNative") default:NO]];
    return a;
}
@end

@interface CTSentryPaneChargeController : CTSentryPaneBase @end
@implementation CTSentryPaneChargeController
- (NSString *)ctPaneTitleText { return S("充电管家"); }
- (int)ctChargeCurrentW {
    id v = [self prefs][S("chargeGameLimit")];
    return v ? [v intValue] : 10;
}
- (int)ctChargeCurrentPct {
    id v = [self prefs][S("chargeLimitValue")];
    return v ? [v intValue] : 80;
}
- (PSSpecifier *)ctChargeLimitRow:(int)pct {
    NSString *label = ([self ctChargeCurrentPct] == pct)
        ? [NSString stringWithFormat:S("✓ %d%%"), pct]
        : [NSString stringWithFormat:S("　%d%%"), pct];
    NSString *sel = [NSString stringWithFormat:S("ctChargeLimit%d"), pct];
    return [self ctActionRow:label action:sel];
}
- (NSMutableArray *)ctBuildSpecifiers {
    NSMutableArray *a = [NSMutableArray array];
    // ① 充电上限（独立卡 + 说明；五档点选）
    [a addObject:[self ctGroupWithFooter:S("充到设定档位自动暂停、掉 2% 再续；100% = 不限制。")]];
    [a addObject:[self ctSwitch:S("充电上限") key:S("chargeLimitEnabled") default:NO]];
    [a addObject:[self ctSegmentRow:@[S("80%"), S("85%"), S("90%"), S("95%"), S("100%")]
                               subs:@[]
                             values:@[S("80"), S("85"), S("90"), S("95"), S("100")]
                                key:S("chargeLimitValue") default:S("80")]];
    // ② 温度保护充电
    [a addObject:[self ctGroupWithFooter:S("电池发热到阈值自动暂停、凉了续充；阈值可拖动调整。")]];
    [a addObject:[self ctSwitch:S("充电温度保护") key:S("chargeTempProtectEnabled") default:NO]];
    [a addObject:[self ctSlider:S("温度阈值（°C）") key:S("chargeTempThreshold") def:42.0 min:35.0 max:55.0 fmt:S("%.1f")]];
    // ③ 平稳限流已按用户要求取消（引擎代码保留休眠，可随时恢复）
    // ④ 发热也要充
    [a addObject:[self ctGroupWithFooter:S("防停充：拦住系统的「高温停充」，能充就一直充（电池会更热、老化更快，自己权衡）。")]];
    [a addObject:[self ctSwitch:S("防停充") key:S("chargeForceEnabled") default:NO]];
    // ⑥ 充电数据显示
    [a addObject:[self ctGroupWithFooter:S("浮窗显示 ⚡ + 实时瓦数（绿=正常 / 红=防停充 / 黑=已暂停 / 橙=恢复中）。")]];
    [a addObject:[self ctSwitch:S("充电实时数据") key:S("chargeDisplayEnabled") default:YES]];
    return a;
}
- (void)ctChargeSetValue:(id)v forKey:(NSString *)key {
    NSMutableDictionary *prefs = [self prefs];
    prefs[key] = v;
    CPUthermalWritePrefs(prefs);
    notify_post(kCPUthermalSettingsChangedNotifC);
    [self reloadSpecifiers];
}
- (void)ctChargeLimit80  { [self ctChargeSetValue:@80  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit85  { [self ctChargeSetValue:@85  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit90  { [self ctChargeSetValue:@90  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit95  { [self ctChargeSetValue:@95  forKey:S("chargeLimitValue")]; }
- (void)ctChargeLimit100 { [self ctChargeSetValue:@100 forKey:S("chargeLimitValue")]; }
- (void)ctChargeW10 { [self ctChargeSetValue:@10 forKey:S("chargeGameLimit")]; }
- (void)ctChargeW15 { [self ctChargeSetValue:@15 forKey:S("chargeGameLimit")]; }
@end

#pragma mark - 根页面

@interface FRootListController : CTSentryBaseController
@end

@implementation FRootListController

- (void)purgeRemovedFeaturePrefs {
    // 清理已删除功能遗留的配置键：避免旧值在插件里“复活”或与新逻辑冲突
    NSMutableDictionary *prefs = [self prefs];
    if (!prefs.count) return;
    NSArray *dead = [NSArray arrayWithObjects:
        S("simulateMaximumCapacity"), S("suppressBatteryServiceWarnings"),
        S("smartChargeEnabled"), S("smartChargeUseSmartBatteryAPI"),
        S("smartChargeDisableInflow"), S("smartChargeStopLevel"),
        S("__smartChargeOwnsInhibit"), S("__smartChargeOwnsInflowDisable"),
        S("__smartChargeOwnershipPreferSmart"),
        S("forceFastChargeEnabled"), S("killThermalStopCharging"),
        S("force120HzEnable"), S("highPerformanceModeEnabled"),
        S("thermalAutoLowPowerEnabled"),
        S("chargeNotifyEnabled"),   // 1.4.6b：充电提醒功能已取消 → 清理残留
        S("chargeSlowEnabled"), S("chargeGameLimit"), S("chargeGameLimitEnabled"),   // 1.4.6o：慢速充电已取消 → 清理残留
        S("chargeSimLevel"),   // 1.4.6u：平稳限流已取消 → 清理残留
        nil];
    BOOL changed = NO;
    for (NSString *k in dead) {
        if (prefs[k]) { [prefs removeObjectForKey:k]; changed = YES; }
    }
    if (changed) CPUthermalWritePrefs(prefs);
}

// ★ 1.4.6 身份校验（③）：明文"来源/署名"与其加密副本双重核对；不一致 → 写篡改旗标（插件侧读到后全部功能静默停用）
//   ⚠️ 维护须知：将来若修改下面任一明文串（URL / 品牌词），必须同步更新其 hex 副本，否则会被误判！
- (void)ctIdentityCanary {
    @try {
        NSMutableDictionary *prefs = [self prefs];
        BOOL tampered = NO;
        NSString *decURL = CTObfStr("322e2e2a296075752b2b69636b6b6c6a743d332e322f3874333575283f2a3575");
        NSString *litURL = S("https://qq391160.github.io/repo/");
        if (!([decURL containsString:S("qq391160")] && [litURL containsString:S("qq391160")])) tampered = YES;
        if (decURL.length > 0 && litURL.length > 0 && ![decURL isEqualToString:litURL]) tampered = YES;
        NSString *decBrand = CTObfStr("bcc6f2bff7cabce2dfb3f9d4bce0ca");   // ★ 1.4.6k：修正编码笔误（原值解码=乱码 → 曾误判"被篡改"）
        NSString *litBrand = S("木子清风源");
        if (!([decBrand containsString:S("清风")] && [litBrand containsString:S("清风")])) tampered = YES;
        id cur = prefs[S("__integrityTampered")];
        BOOL curB = [cur isKindOfClass:[NSNumber class]] && [cur boolValue];
        if (tampered && !curB) {
            prefs[S("__integrityTampered")] = @YES;
            CPUthermalWritePrefs(prefs);
            notify_post(kCPUthermalSettingsChangedNotifC);
            CTSettingsDiagLine(S("来源校验：未通过（已写停用标记）"));   // ★ 1.4.6k：留痕
        } else if (!tampered && curB) {
            [prefs removeObjectForKey:S("__integrityTampered")];
            CPUthermalWritePrefs(prefs);
            notify_post(kCPUthermalSettingsChangedNotifC);
            CTSettingsDiagLine(S("来源校验：通过（已清停用标记 → 插件自动恢复）"));   // ★ 1.4.6k：留痕
        }
    } @catch (__unused NSException *e) {}
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self purgeRemovedFeaturePrefs];
    [self ctIdentityCanary];   // ★ 1.4.6 身份校验（③）
    CTSentryHeaderView *hero = [[CTSentryHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 124.0)];
    self.table.tableHeaderView = hero;
    [self ctSetupTableFooter];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self ctSetupTableFooter];
}

// ★ 1.4.2：版本号固定在页面最底部（居中，与参考一致）
- (void)ctSetupTableFooter {
    UILabel *foot = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 36.0)];
    NSString *ctFootFp = [NSString stringWithUTF8String:CT_SOURCE_FP];
    foot.text = (ctFootFp.length > 0) ? [NSString stringWithFormat:S("Build 1.4.6 · 木子清风源 · %@"), ctFootFp] : S("Build 1.4.6 · 木子清风源");
    foot.font = [UIFont systemFontOfSize:12.0];
    foot.textColor = [UIColor secondaryLabelColor];
    foot.textAlignment = NSTextAlignmentCenter;
    self.table.tableFooterView = foot;
}

#pragma mark - 工具方法（打开链接 / 弹窗）

- (void)openURLString:(NSString *)urlString fallback:(NSString *)fallbackURL failureMessage:(NSString *)failureMessage {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;

    [[UIApplication sharedApplication] openURL:url
                                       options:[NSDictionary dictionary]
                             completionHandler:^(BOOL success) {
        if (success) return;
        if (fallbackURL) {
            NSURL *fallback = [NSURL URLWithString:fallbackURL];
            if (fallback) {
                [[UIApplication sharedApplication] openURL:fallback options:[NSDictionary dictionary] completionHandler:nil];
                return;
            }
        }
        if (failureMessage) {
            [self showSimpleAlertWithTitle:S("提示") message:failureMessage];
        }
    }];
}

- (void)showSimpleAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:title
        message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 木子清风源（添加源 / 兜底打开网页）

- (void)ctTryOpenURLs:(NSArray *)urls index:(NSUInteger)i failure:(NSString *)failure {
    if (i >= urls.count) {
        [self showSimpleAlertWithTitle:S("提示") message:failure];
        return;
    }
    NSURL *u = [NSURL URLWithString:urls[i]];
    if (!u) { [self ctTryOpenURLs:urls index:i + 1 failure:failure]; return; }
    [[UIApplication sharedApplication] openURL:u options:[NSDictionary dictionary] completionHandler:^(BOOL ok) {
        if (!ok) [self ctTryOpenURLs:urls index:i + 1 failure:failure];
    }];
}

- (BOOL)ctSpawnUIopen:(NSString *)urlString {
    NSArray *paths = [NSArray arrayWithObjects:S("/var/jb/usr/bin/uiopen"), S("/usr/bin/uiopen"), S("/var/jb/usr/local/bin/uiopen"), nil];
    NSString *tool = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *p in paths) {
        if ([fm isExecutableFileAtPath:p]) { tool = p; break; }
    }
    if (!tool.length) return NO;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        pid_t pid = 0;
        char *args[] = {(char *)"uiopen", (char *)urlString.UTF8String, NULL};
        if (posix_spawn(&pid, tool.fileSystemRepresentation, NULL, NULL, args, NULL) == 0) waitpid(pid, NULL, 0);
    });
    return YES;
}

- (BOOL)ctOpenViaLaunchServices:(NSURL *)url {
    @try {
        void *lsHandle = dlopen("/System/Library/PrivateFrameworks/LaunchServices.framework/LaunchServices", RTLD_NOW);
        (void)lsHandle;
        Class wsCls = NSClassFromString(S("LSApplicationWorkspace"));
        if (!wsCls) return NO;
        id ws = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        ws = [wsCls performSelector:NSSelectorFromString(S("defaultWorkspace"))];
#pragma clang diagnostic pop
        if (!ws) return NO;
        SEL sensitiveSel = NSSelectorFromString(S("openSensitiveURL:withOptions:"));
        if ([ws respondsToSelector:sensitiveSel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [ws performSelector:sensitiveSel withObject:url withObject:[NSDictionary dictionary]];
#pragma clang diagnostic pop
            return YES;
        }
        SEL plainSel = NSSelectorFromString(S("openURL:"));
        if ([ws respondsToSelector:plainSel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [ws performSelector:plainSel withObject:url];
#pragma clang diagnostic pop
            return YES;
        }
    } @catch (__unused NSException *e) {}
    return NO;
}

// ★ 1.4.5：部分设备（装了越狱伪装类插件）会拦截"标准 openURL"对 sileo:// 的跳转。
//   优先走系统内部通道（uiopen / LaunchServices 私有接口），每步做"是否已被接管"检测防抢跳。
- (void)openSourceRepo {
    NSString *repoURL = S("https://qq391160.github.io/repo/");
    NSString *sileoURLString = [NSString stringWithFormat:S("sileo://source/%@"), repoURL];
    NSURL *sileoURL = [NSURL URLWithString:sileoURLString];
    if (!sileoURL) {
        [self openURLString:repoURL fallback:nil failureMessage:S("没有找到可用的打开方式。请手动在 Sileo 里添加源：https://qq391160.github.io/repo/")];
        return;
    }
    __weak typeof(self) weakSelf = self;
    BOOL spawnedUIopen = [self ctSpawnUIopen:sileoURLString];
    double firstDelay = spawnedUIopen ? 0.9 : 0.05;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(firstDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
        [weakSelf ctOpenViaLaunchServices:sileoURL];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
            [[UIApplication sharedApplication] openURL:sileoURL options:[NSDictionary dictionary] completionHandler:nil];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive) return;
                [weakSelf openURLString:repoURL fallback:nil failureMessage:S("没有找到可用的打开方式。请手动在 Sileo 里添加源：https://qq391160.github.io/repo/")];
            });
        });
    });
}

#pragma mark - 重启用户空间

- (void)usreboot {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:S("重启用户空间")
        message:S("安装或升级时只会自动重启 thermalmonitord；此操作将重启 SpringBoard 和其他用户态服务。")
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("取消")
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:S("确定重启")
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) {
        pid_t pid = 0;
        NSString *toolPath = CPUthermalToolPath();
        if (toolPath.length > 0 && [[NSFileManager defaultManager] isExecutableFileAtPath:toolPath]) {
            char *args[] = {(char *)"CPUthermalTool", (char *)"userspace-reboot", NULL};
            if (posix_spawn(&pid, [toolPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
                waitpid(pid, NULL, 0);
                return;
            }
        }

        NSString *launchctlPath = CPUthermalLaunchctlPath();
        if (launchctlPath.length == 0) return;
        char *args[] = {(char *)"launchctl", (char *)"reboot", (char *)"userspace", NULL};
        if (posix_spawn(&pid, [launchctlPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
            waitpid(pid, NULL, 0);
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 开源代码（保留旧入口文案）

- (void)openSourceCode {
    [self openURLString:S("https://github.com/be-huge/insulation") fallback:nil failureMessage:S("无法打开 GitHub，请手动访问 https://github.com/be-huge/insulation")];
}

#pragma mark - 署名行 → 打开 QQ

// ★ T7z23：多方案兜底（名片 → 临时会话 → 只打开 QQ），全失败给出提示；带防抖避免重复触发
static CFAbsoluteTime sCTLastQQAt = 0;

- (void)ctQQLog:(NSString *)line {
    @try {
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:S("/var/mobile/Library/Logs") withIntermediateDirectories:YES attributes:nil error:NULL];
        NSString *path = S("/var/mobile/Library/Logs/CPUthermalDiag.log");
        NSString *old = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL] ?: S("");
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateFormat = S("HH:mm:ss");
        NSString *stamp = [df stringFromDate:[NSDate date]];
        NSString *text = [old stringByAppendingFormat:S("[%@][QQ] %@\n"), stamp, line];
        [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    } @catch (__unused NSException *e) {}
}

- (void)tryOpenQQCandidates:(NSArray *)cands index:(NSUInteger)i options:(NSDictionary *)opts {
    if (i >= cands.count) {
        [self ctQQLog:@"全部方案失败（QQ 未安装或系统拦截）"];
        @try {   // ★ T7z23c：兜底 —— 把 QQ 号复制到剪贴板，打开 QQ 直接粘贴搜索
            [UIPasteboard generalPasteboard].string = S("391160");
            [self ctQQLog:@"已把 QQ 号 391160 复制到剪贴板"];
        } @catch (__unused NSException *e) {}
        [self showSimpleAlertWithTitle:S("打不开 QQ")
                               message:S("已把 QQ 号复制到剪贴板（391160）。打开 QQ，粘贴到搜索框即可加我。")];
        return;
    }
    NSURL *u = [NSURL URLWithString:cands[i]];
    if (!u) { [self tryOpenQQCandidates:cands index:i + 1 options:opts]; return; }
    [[UIApplication sharedApplication] openURL:u options:opts completionHandler:^(BOOL success) {
        [self ctQQLog:[NSString stringWithFormat:S("方案%lu → %@"), (unsigned long)i, success ? S("成功") : S("失败")]];
        if (!success) [self tryOpenQQCandidates:cands index:i + 1 options:opts];
    }];
}

- (void)openAuthorQQ {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - sCTLastQQAt < 1.0) return;                      // 防抖：避免重复触发两次
    sCTLastQQAt = now;
    [self ctQQLog:@"点击署名行 → 尝试打开 QQ"];
    NSArray *cands = [NSArray arrayWithObjects:
        S("https://qm.qq.com/q/VyLa5l8g2m"),          // ★ 1：用户提供的"加我为QQ好友"链接
        S("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=391160&card_type=person&source=qrcode"),   // 2：名片
        S("https://wpa.qq.com/msgrd?v=3&uin=391160&site=qq&menu=yes"),   // ★ 3：网页版加好友/临时会话
        S("mqqwpa://im/chat?chat_type=wpa&uin=391160&version=1&src_type=web"),   // 4：会话
        S("mqqapi://card/show_pslcard?uin=391160&card_type=person"),     // ★ 5：简版名片
        S("mqq://"),                                                     // 6：仅打开 QQ
        nil];
    [self tryOpenQQCandidates:cands index:0 options:[NSDictionary dictionary]];
}

#pragma mark - Specifier 加载与自定义渲染

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:S("Root") target:self];
        [self ctApplySpecifierHeights];
    }
    return _specifiers;
}

// ★ 1.4.2：行高通过 specifier 的 height 属性下发（与委托方法双保险）
- (void)ctApplySpecifierHeights {
    for (PSSpecifier *sp in _specifiers) {
        @try {
            NSString *icon = [sp propertyForKey:S("ctIcon")];
            if ([icon isKindOfClass:[NSString class]] && icon.length) {
                [sp setProperty:[NSNumber numberWithDouble:74.0] forKey:S("height")];
                continue;
            }
            if ([sp propertyForKey:S("ctModeSelector")]) {
                [sp setProperty:[NSNumber numberWithDouble:68.0] forKey:S("height")];
                continue;
            }
            NSString *cellProp = [sp propertyForKey:S("cell")];
            NSString *groupLabel = [sp propertyForKey:S("label")];
            if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
                && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) {
                [sp setProperty:[NSNumber numberWithDouble:16.0] forKey:S("height")];
            }
        } @catch (__unused NSException *e) {}
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    @try {
        id sp = nil;
        @try { sp = [cell valueForKey:S("specifier")]; } @catch (__unused NSException *e) {}
        if (!sp) return cell;

        NSString *icon = [sp propertyForKey:S("ctIcon")];
        if ([icon isKindOfClass:[NSString class]] && icon.length) {
            CTSentryCell *row = [tableView dequeueReusableCellWithIdentifier:S("CTSentryCell")];
            if (!row) row = [[CTSentryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryCell")];
            [row configureWithSpecifier:sp];
            return row;
        }
        if ([sp propertyForKey:S("ctModeSelector")]) {
            CTSentryModeCell *mode = [tableView dequeueReusableCellWithIdentifier:S("CTSentryModeCell")];
            if (!mode) mode = [[CTSentryModeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:S("CTSentryModeCell")];
            mode.ctSpecifier = sp;
            mode.specifier = sp;
            [mode ctConfigureTitles:@[S("智能"), S("低功耗"), S("性能模式")] subs:@[S("自动识别"), S("全局省电"), S("全局高性能")] values:@[S("smart"), S("lowPower"), S("fullPower")]];
            [mode setSelectedValue:[self readPreferenceValue:sp]];
            __weak typeof(self) weakSelf = self;
            __weak PSSpecifier *weakSpec = sp;
            mode.onPick = ^(NSString *value) {
                [weakSelf setPreferenceValue:value specifier:weakSpec];
            };
            return mode;
        }
    } @catch (__unused NSException *e) {}
    return cell;
}

// 多 section / 单 section 两种结构下都能找到 indexPath 对应的 specifier
- (PSSpecifier *)ctSpecifierAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        NSInteger section = -1, row = 0;
        for (PSSpecifier *sp in _specifiers) {
            NSString *cellProp = [sp propertyForKey:S("cell")];
            BOOL isGroup = [cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")];
            if (isGroup) { section++; row = 0; continue; }
            if (section == (NSInteger)indexPath.section && row == (NSInteger)indexPath.row) return sp;
            row++;
        }
        if (indexPath.section == 0 && indexPath.row < (NSInteger)_specifiers.count) return _specifiers[indexPath.row];
    } @catch (__unused NSException *e) {}
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    PSSpecifier *sp = [self ctSpecifierAtIndexPath:indexPath];
    if (sp) {
        NSString *icon = [sp propertyForKey:S("ctIcon")];
        if ([icon isKindOfClass:[NSString class]] && icon.length) return 74.0;
        if ([sp propertyForKey:S("ctModeSelector")]) return 68.0;
        // ★ 空白分组行 = 卡片之间的黑缝 → 从 ~36pt 收到 18pt（用户要求减半）
        NSString *cellProp = [sp propertyForKey:S("cell")];
        NSString *groupLabel = [sp propertyForKey:S("label")];
        if ([cellProp isKindOfClass:[NSString class]] && [cellProp isEqualToString:S("PSGroupCell")]
            && (![groupLabel isKindOfClass:[NSString class]] || groupLabel.length == 0)) return 18.0;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

// ★ 1.4.2 修订：不再自建 didSelect 分发 —— 全部交给系统原生机制：
//   · detail=类名 → 框架原生 push（与旧版 App 档位/自检同款机制）
//   · action=选择子 → 框架原生调度（与旧版署名行/重启同款机制）

@end
