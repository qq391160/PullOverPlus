#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <notify.h>
#import <CPUthermalPaths.h>
#include <sys/stat.h>

// ============================================================
// ★ T7w：App 档位管理（合并旧「两张名单」）
//   · 点按应用 → 弹出「满频 / 低频率 / 原生 / 自动」四选一（带 ✓ 标记）
//   · 选完只就地更新那一行（不整表重排，避免"跳上跳下"）
//   存储：偏好键 appTiers = { bundleID: "full" | "low" | "native" }（无 = 自动）
//   首次打开自动从旧名单迁移（fullPowerApps → full；lowPowerApps → low）。
//   注意：禁止 @"" 常量（roothide 重映射会崩），全部用 S() 创建。
// ============================================================

@interface CPUthermalAppTierController : PSListController <UISearchResultsUpdating>
@property(nonatomic,strong) NSArray<NSDictionary *> *allApps;
@property(nonatomic,copy) NSString *searchTerm;
@property(nonatomic,strong) UISearchController *searchController;
@property(nonatomic,strong) PSSpecifier *footerGroup;
- (void)applyTier:(NSString *)tier forBundleID:(NSString *)bundleID;
@end

@interface CPUthermalTierChoiceController : PSListController
@property(nonatomic,copy) NSString *ctAppBundleID;
@property(nonatomic,copy) NSString *appName;
@property(nonatomic,strong) void (^onTierChosen)(NSString *tier);   // nil = 自动
@end

// 只保留"桌面上看得见"的 App（与旧名单页同规则）
static BOOL CPUthermalTierIsVisibleApp(NSString *bundleID) {
    if (bundleID.length == 0) return NO;
    if (![bundleID hasPrefix:S("com.apple.")]) return YES;
    static NSArray *systemApps = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        systemApps = @[
            S("com.apple.Preferences"), S("com.apple.mobileslideshow"), S("com.apple.camera"),
            S("com.apple.DocumentsApp"), S("com.apple.mobilesafari"), S("com.apple.AppStore"),
            S("com.apple.MobileSMS"), S("com.apple.mobilephone"), S("com.apple.facetime"),
            S("com.apple.mobilemail"), S("com.apple.mobilecal"), S("com.apple.MobileAddressBook"),
            S("com.apple.reminders"), S("com.apple.mobilenotes"), S("com.apple.mobiletimer"),
            S("com.apple.calculator"), S("com.apple.weather"), S("com.apple.Maps"),
            S("com.apple.Music"), S("com.apple.podcasts"), S("com.apple.iBooks"),
            S("com.apple.news"), S("com.apple.stocks"), S("com.apple.Home"),
            S("com.apple.Health"), S("com.apple.Passbook"), S("com.apple.shortcuts"),
            S("com.apple.Translate"), S("com.apple.measure"), S("com.apple.compass"),
            S("com.apple.VoiceMemos"), S("com.apple.findmy"), S("com.apple.Fitness"),
            S("com.apple.Bridge"), S("com.apple.tv"), S("com.apple.tips"),
            S("com.apple.Magnifier"), S("com.apple.Passwords"), S("com.apple.MobileStore"),
            S("com.apple.TestFlight"), S("com.apple.Pages"), S("com.apple.Numbers"),
            S("com.apple.Keynote"), S("com.apple.iMovie"), S("com.apple.GarageBand"),
        ];
    });
    return [systemApps containsObject:bundleID];
}

// 搜索规范化：转小写 + 去掉空格/全角空格/零宽等隐藏字符（"微 信"、"微信\u200b" 这类坑）
static NSString *CPUthermalSearchNormalize(NSString *s) {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return S("");
    NSString *lower = [s lowercaseString];
    NSMutableString *out = [NSMutableString string];
    for (NSUInteger i = 0; i < lower.length; i++) {
        unichar c = [lower characterAtIndex:i];
        if (c == ' ' || c == 0x3000 || c == 0x200B || c == 0x200E || c == 0x00AD || c == 0xFEFF || c == 0xA0 || c == '\n' || c == '\t' || c == '\r') continue;
        [out appendFormat:@"%C", c];
    }
    return out;
}

// ★ T7w：常用 App 的搜索别名（保底：不管系统名叫啥，这些关键字都能搜到它）
static NSString *CPUthermalExtraSearchAliases(NSString *bundleID) {
    if (![bundleID isKindOfClass:[NSString class]]) return S("");
    if ([bundleID isEqualToString:S("com.tencent.xin")]) return S("微信|weixin|wechat");
    if ([bundleID isEqualToString:S("com.tencent.wetype")]) return S("微信输入法|weixin");
    if ([bundleID isEqualToString:S("com.tencent.mqq")]) return S("QQ|qq");
    if ([bundleID isEqualToString:S("com.tencent.tim")]) return S("TIM|tim");
    if ([bundleID isEqualToString:S("com.tencent.lolm")]) return S("英雄联盟|英雄联盟手游|lolm|lol");
    if ([bundleID isEqualToString:S("com.ss.iphone.ugc.Aweme")]) return S("抖音|douyin|tiktok");
    if ([bundleID isEqualToString:S("com.taobao.taobao4iphone")]) return S("淘宝|taobao");
    if ([bundleID isEqualToString:S("com.tencent.wework")]) return S("企业微信|wework");
    if ([bundleID isEqualToString:S("com.tencent.qqmail")]) return S("QQ邮箱|qqmail");
    if ([bundleID isEqualToString:S("com.tencent.news")]) return S("腾讯新闻");
    return S("");
}

static NSString *CPUthermalTierDisplayName(NSString *tier) {
    if ([tier isEqualToString:S("full")]) return S("满频");
    if ([tier isEqualToString:S("low")]) return S("低频率");
    if ([tier isEqualToString:S("native")]) return S("原生");
    return S("自动");
}

static NSInteger CPUthermalTierRank(NSString *tier) {
    if ([tier isEqualToString:S("full")]) return 0;
    if ([tier isEqualToString:S("low")]) return 1;
    if ([tier isEqualToString:S("native")]) return 2;
    return 3;
}

@implementation CPUthermalAppTierController

#pragma mark - 偏好读写

- (NSMutableDictionary *)tiers {
    id value = CPUthermalReadPrefs()[S("appTiers")];
    return [value isKindOfClass:[NSDictionary class]] ? [value mutableCopy] : [NSMutableDictionary dictionary];
}

- (void)saveTiers:(NSDictionary *)tiers postNotify:(BOOL)postNotify {
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs() ?: [NSMutableDictionary dictionary];
    prefs[S("appTiers")] = tiers ?: [NSDictionary dictionary];
    prefs[S("appTiersMigrated")] = @YES;
    CPUthermalWritePrefs(prefs);
    if (postNotify) notify_post(kCPUthermalSettingsChangedNotifC);
}

// 旧名单迁移：fullPowerApps → 满频；lowPowerApps → 低频率（只做一次）
- (void)migrateLegacyListsIfNeeded {
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs() ?: [NSMutableDictionary dictionary];
    if ([prefs[S("appTiersMigrated")] boolValue]) return;
    NSMutableDictionary *tiers = [prefs[S("appTiers")] isKindOfClass:[NSDictionary class]] ? [prefs[S("appTiers")] mutableCopy] : [NSMutableDictionary dictionary];
    BOOL changed = NO;
    id fullList = prefs[S("fullPowerApps")];
    if ([fullList isKindOfClass:[NSArray class]]) {
        for (id bid in fullList) {
            if ([bid isKindOfClass:[NSString class]] && bid && tiers[bid] == nil) { tiers[bid] = S("full"); changed = YES; }
        }
    }
    id lowList = prefs[S("lowPowerApps")];
    if ([lowList isKindOfClass:[NSArray class]]) {
        for (id bid in lowList) {
            if ([bid isKindOfClass:[NSString class]] && bid && tiers[bid] == nil) { tiers[bid] = S("low"); changed = YES; }
        }
    }
    prefs[S("appTiers")] = tiers;
    prefs[S("appTiersMigrated")] = @YES;
    CPUthermalWritePrefs(prefs);
    if (changed) notify_post(kCPUthermalSettingsChangedNotifC);
}

#pragma mark - App 枚举

- (NSString *)stringFromObject:(id)object selectors:(NSArray<NSString *> *)selectors {
    for (NSString *name in selectors) {
        SEL selector = NSSelectorFromString(name);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

- (id)applicationProxyForBundleID:(NSString *)bundleID {
    @try {
        Class proxyClass = NSClassFromString(S("LSApplicationProxy"));
        SEL proxySel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
        if (proxyClass && [proxyClass respondsToSelector:proxySel] && bundleID.length) return ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, proxySel, bundleID);
    } @catch (__unused NSException *exception) {}
    return nil;
}

- (void)addApplicationAtPath:(NSString *)appPath toMap:(NSMutableDictionary *)map {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:S("Info.plist")]];
    NSString *bundleID = info[S("CFBundleIdentifier")];
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return;
    if (!CPUthermalTierIsVisibleApp(bundleID)) return;
    NSString *name = [self stringFromObject:[self applicationProxyForBundleID:bundleID] selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleDisplayName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = bundleID;
    map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):appPath ?: S(""), S("search"):[NSString stringWithFormat:@"%@|%@", CPUthermalSearchNormalize([NSString stringWithFormat:@"%@|%@|%@", name, bundleID, appPath.lastPathComponent ?: S("")]), CPUthermalExtraSearchAliases(bundleID)]};
}

- (NSArray<NSDictionary *> *)enumerateApplications {
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    @try {
        Class workspaceClass = NSClassFromString(S("LSApplicationWorkspace"));
        id workspace = [workspaceClass respondsToSelector:NSSelectorFromString(S("defaultWorkspace"))] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, NSSelectorFromString(S("defaultWorkspace"))) : nil;
        id applications = [workspace respondsToSelector:NSSelectorFromString(S("allApplications"))] ? ((id (*)(id, SEL))objc_msgSend)(workspace, NSSelectorFromString(S("allApplications"))) : nil;
        if ([applications isKindOfClass:[NSArray class]]) for (id proxy in applications) {
            NSString *bundleID = [self stringFromObject:proxy selectors:@[S("applicationIdentifier"),S("bundleIdentifier")]];
            if (bundleID.length == 0) continue;
            if (!CPUthermalTierIsVisibleApp(bundleID)) continue;
            NSString *name = [self stringFromObject:proxy selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]] ?: bundleID;
            NSString *bundlePath = S("");
            SEL urlSel = NSSelectorFromString(S("bundleURL"));
            if ([proxy respondsToSelector:urlSel]) {
                id url = ((id (*)(id, SEL))objc_msgSend)(proxy, urlSel);
                if ([url isKindOfClass:[NSURL class]]) bundlePath = ((NSURL *)url).path ?: S("");
            }
            map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):bundlePath, S("search"):[NSString stringWithFormat:@"%@|%@", CPUthermalSearchNormalize([NSString stringWithFormat:@"%@|%@|%@", name, bundleID, bundlePath.lastPathComponent ?: S("")]), CPUthermalExtraSearchAliases(bundleID)]};
        }
    } @catch (__unused NSException *exception) {}
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *root in @[S("/var/mobile/Containers/Bundle/Application"), S("/var/containers/Bundle/Application"), S("/Applications"), S("/System/Applications")]) {
        for (NSString *child in [fm contentsOfDirectoryAtPath:root error:nil] ?: @[]) {
            NSString *full = [root stringByAppendingPathComponent:child];
            if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) {
                [self addApplicationAtPath:full toMap:map];
                continue;
            }
            for (NSString *entry in [fm contentsOfDirectoryAtPath:full error:nil] ?: @[]) if ([[entry pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) [self addApplicationAtPath:[full stringByAppendingPathComponent:entry] toMap:map];
        }
    }
    return [map allValues];
}

- (NSArray<NSDictionary *> *)visibleApplications {
    if (!self.allApps) self.allApps = [self enumerateApplications];
    NSString *term = CPUthermalSearchNormalize(self.searchTerm ?: S(""));
    NSMutableArray *visible = [NSMutableArray array];
    for (NSDictionary *app in self.allApps) {
        NSString *blob = app[S("search")];
        if (![blob isKindOfClass:[NSString class]]) blob = [NSString stringWithFormat:@"%@|%@", CPUthermalSearchNormalize([NSString stringWithFormat:@"%@|%@", app[S("name")] ?: S(""), app[S("id")] ?: S("")]), CPUthermalExtraSearchAliases(app[S("id")])];
        if (term.length == 0 || [blob containsString:term]) [visible addObject:app];
    }
    NSDictionary *tiers = [self tiers];
    [visible sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSInteger ra = CPUthermalTierRank(tiers[a[S("id")]]), rb = CPUthermalTierRank(tiers[b[S("id")]]);
        if (ra != rb) return ra < rb ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult r = [a[S("name")] localizedCaseInsensitiveCompare:b[S("name")]];
        return r == NSOrderedSame ? [a[S("id")] compare:b[S("id")]] : r;
    }];
    return visible;
}

#pragma mark - 页脚

- (NSString *)footerTextForCount:(NSUInteger)count searching:(BOOL)searching {
    if (searching) return [NSString stringWithFormat:S("找到 %lu 个应用 · 点按进入选择档位。"), (unsigned long)count];
    return [NSString stringWithFormat:S("点按应用进入选择档位：满频 / 低频率 / 原生 / 自动。\n· 满频：进入后满频运行（游戏 / 微信 / 相机这类）\n· 低频率：进入后压频省电（刷视频这类）\n· 原生：不干预，交给系统\n· 自动：跟随智能识别（游戏→满频 / 普通应用→低频率 / 认不出→原生）\n对三种常驻模式都生效。已设置 %lu 个（其余均为自动）。"), (unsigned long)count];
}

- (void)refreshFooter {
    if (!self.footerGroup) return;
    // ★ T7x：搜索中显示"命中数"，否则显示"已设置数"（此前搜索时误用设置数 → 搜到也显示"找到 0 个"）
    NSUInteger ctFooterCount = self.searchTerm.length ? [self visibleApplications].count : [self tiers].count;
    [self.footerGroup setProperty:[self footerTextForCount:ctFooterCount searching:(self.searchTerm.length > 0)] forKey:S("footerText")];
}

#pragma mark - Specifiers

- (void)rebuildSpecifiers {
    if (!_specifiers) _specifiers = [[NSMutableArray alloc] init];
    [_specifiers removeAllObjects];
    @try {
        NSArray *apps = [self visibleApplications];
        NSDictionary *tiers = [self tiers];
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        NSUInteger ctFooterCount = self.searchTerm.length ? apps.count : tiers.count;   // ★ T7x：搜索时用"命中数"
        NSString *footer = self.allApps.count ? [self footerTextForCount:ctFooterCount searching:(self.searchTerm.length > 0)] : S("没有枚举到可用的应用。");
        [group setProperty:footer forKey:S("footerText")];
        self.footerGroup = group;
        [_specifiers addObject:group];
        if (!self.searchTerm.length && tiers.count > 0) {
            PSSpecifier *reset = [PSSpecifier preferenceSpecifierNamed:S("全部重置为「自动」") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
            reset->action = @selector(resetAllTiers:);
            [_specifiers addObject:reset];
        }
        [_specifiers addObject:[PSSpecifier emptyGroupSpecifier]];
        for (NSDictionary *app in apps) {
            NSString *bundleID = app[S("id")];
            NSString *tier = tiers[bundleID];
            NSString *appName = app[S("name")];
            NSString *rowName = (tier == nil) ? appName : [NSString stringWithFormat:S("%@　—　%@"), appName, CPUthermalTierDisplayName(tier)];
            PSSpecifier *specifier = [PSSpecifier preferenceSpecifierNamed:rowName target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
            specifier->action = @selector(openTierChooserForSpecifier:);
            specifier.identifier = bundleID;
            [specifier setProperty:bundleID forKey:S("id")];
            [specifier setProperty:bundleID forKey:S("ctBundleID")];
            [specifier setProperty:appName forKey:S("ctAppName")];
            [specifier setProperty:app[S("path")] ?: S("") forKey:S("ctBundlePath")];
            [_specifiers addObject:specifier];
        }
    } @catch (__unused NSException *exception) {
        [_specifiers removeAllObjects];
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        [group setProperty:S("应用列表加载异常。") forKey:S("footerText")];
        self.footerGroup = group;
        [_specifiers addObject:group];
    }
}

- (NSArray *)specifiers { if (!_specifiers) [self rebuildSpecifiers]; return _specifiers; }

#pragma mark - 选择与就地更新

- (void)openTierChooserForSpecifier:(PSSpecifier *)specifier {
    NSString *bundleID = specifier.identifier ?: [specifier propertyForKey:S("ctBundleID")];
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return;
    NSString *appName = [specifier propertyForKey:S("ctAppName")] ?: bundleID;
    CPUthermalTierChoiceController *choice = [[CPUthermalTierChoiceController alloc] init];
    choice.ctAppBundleID = bundleID;
    choice.appName = appName;
    __weak typeof(self) weakSelf = self;
    choice.onTierChosen = ^(NSString *tier) {
        [weakSelf applyTier:tier forBundleID:bundleID];
    };
    [self.navigationController pushViewController:choice animated:YES];
}

// 就地更新一行（不整表重排 → 不"跳上跳下"）
- (void)applyTier:(NSString *)tier forBundleID:(NSString *)bundleID {
    if (bundleID.length == 0) return;
    NSMutableDictionary *tiers = [self tiers];
    if (tier == nil) [tiers removeObjectForKey:bundleID];
    else tiers[bundleID] = tier;
    [self saveTiers:tiers postNotify:YES];
    dispatch_async(dispatch_get_main_queue(), ^{
        for (PSSpecifier *sp in self->_specifiers) {
            if (![[sp propertyForKey:S("ctBundleID")] isEqualToString:bundleID]) continue;
            NSString *appName = [sp propertyForKey:S("ctAppName")] ?: bundleID;
            [sp setName:(tier == nil) ? appName : [NSString stringWithFormat:S("%@　—　%@"), appName, CPUthermalTierDisplayName(tier)]];
            break;
        }
        [self refreshFooter];
        [self.table reloadData];
    });
}

- (void)resetAllTiers:(PSSpecifier *)specifier {
    (void)specifier;
    [self saveTiers:[NSDictionary dictionary] postNotify:YES];
    dispatch_async(dispatch_get_main_queue(), ^{ [self rebuildSpecifiers]; [self.table reloadData]; });
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    self.searchTerm = searchController.searchBar.text ?: S("");
    [self rebuildSpecifiers];
    [self.table reloadData];
    // ★ T7w 诊断：搜索实况写日志（看微信在本机的真实名字与字符串）
    @try {
        NSString *ctWxName = S("(无本条目)"), *ctWxBlob = S("");
        for (NSDictionary *ctApp in self.allApps) {
            if ([ctApp[S("id")] isEqualToString:S("com.tencent.xin")]) { ctWxName = ctApp[S("name")] ?: S("?"); ctWxBlob = ctApp[S("search")] ?: S(""); break; }
        }
        NSString *ctLine = [NSString stringWithFormat:@"[搜索] term=%@ hits=%lu 微信名=%@ blob=%@\n",
                            self.searchTerm, (unsigned long)[self visibleApplications].count, ctWxName, ctWxBlob];
        mkdir("/var/mobile/Library/Logs", 0755);
        FILE *ctFp = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
        if (ctFp) { fputs(ctLine.UTF8String, ctFp); fclose(ctFp); }
    } @catch (__unused NSException *exception) {}
}

#pragma mark - 生命周期

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = S("App 档位");
    [self migrateLegacyListsIfNeeded];
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchResultsUpdater = self;
    self.searchController.obscuresBackgroundDuringPresentation = NO;
    self.searchController.searchBar.placeholder = S("名称或 Bundle ID");
    self.navigationItem.searchController = self.searchController;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    self.definesPresentationContext = YES;
}

@end

#pragma mark - 四选一（满频 / 低频率 / 原生 / 自动）

@implementation CPUthermalTierChoiceController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];
        NSString *current = CPUthermalReadPrefs()[S("appTiers")][self.ctAppBundleID];
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        [group setProperty:[NSString stringWithFormat:S("为「%@」选择档位。对三种常驻模式都生效。"), self.appName ?: self.ctAppBundleID] forKey:S("footerText")];
        [specs addObject:group];
        NSArray *options = @[
            @[S("满频"), S("full"), S("进入后满频运行")],
            @[S("低频率"), S("low"), S("进入后压频省电")],
            @[S("原生"), S("native"), S("不干预，交给系统")],
            @[S("自动"), S("auto"), S("跟随智能识别")],
        ];
        for (NSArray *opt in options) {
            NSString *value = opt[1];
            BOOL isCurrent = (current == nil && [value isEqualToString:S("auto")]) || (current != nil && [current isEqualToString:value]);
            NSString *rowName = isCurrent ? [NSString stringWithFormat:S("✓ %@　—　%@"), opt[0], opt[2]] : [NSString stringWithFormat:S("%@　—　%@"), opt[0], opt[2]];
            PSSpecifier *spec = [PSSpecifier preferenceSpecifierNamed:rowName target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
            spec->action = @selector(chooseTierForSpecifier:);
            [spec setProperty:value forKey:S("ctTier")];
            if (isCurrent) [spec setProperty:@YES forKey:S("ctCurrent")];
            [specs addObject:spec];
        }
        _specifiers = specs;
    }
    return _specifiers;
}

- (void)chooseTierForSpecifier:(PSSpecifier *)specifier {
    NSString *value = [specifier propertyForKey:S("ctTier")];
    NSString *tier = [value isEqualToString:S("auto")] ? nil : value;
    if (self.onTierChosen) self.onTierChosen(tier);
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = self.appName.length ? self.appName : S("选择档位");
}

@end
