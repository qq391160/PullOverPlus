#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <notify.h>
#import <CPUthermalPaths.h>

@interface CPUthermalAppListController : PSListController <UISearchResultsUpdating>
@property(nonatomic,strong) NSArray<NSDictionary *> *allApps;
@property(nonatomic,copy) NSString *searchTerm;
@property(nonatomic,strong) UISearchController *searchController;
- (NSString *)ctPrefsKey;
- (void)writeEnabledBundleIDs:(NSSet *)enabled;
@end

static UIImage *CPUthermalIconForApp(NSString *bundleID, NSString *bundlePath);

// 只保留"桌面上看得见"的 App：
//  · 非 com.apple.* 的（第三方 App、越狱工具）全部保留
//  · com.apple.* 的只有白名单里的（相册/相机/设置这些真 App）才收，内部组件一律剔除
static BOOL CPUthermalIsVisibleApp(NSString *bundleID) {
    if (bundleID.length == 0) return NO;
    if (![bundleID hasPrefix:S("com.apple.")]) return YES;
    static NSArray *systemApps = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        systemApps = @[
            S("com.apple.Preferences"), S("com.apple.mobileslideshow"), S("com.apple.camera"),
            S("com.apple.DocumentsApp"), S("com.apple.mobilesafari"), S("com.apple.AppStore"),
            S("com.apple.MobileSMS"), S("com.apple.mobilephone"), S("com.apple.facetime"),
            S("com.apple.mobilemail"), S("com.apple.mobilecal"), S("com.apple.MobileAddressBook"),
            S("com.apple.reminders"), S("com.apple.mobilenotes"), S("com.apple.mobiletimer"),
            S("com.apple.calculator"), S("com.apple.weather"), S("com.apple.Maps"),
            S("com.apple.Music"), S("com.apple.podcasts"), S("com.apple.iBooks"),
            S("com.apple.news"), S("com.apple.stocks"), S("com.apple.Home"),
            S("com.apple.Health"), S("com.apple.Passbook"), S("com.apple.shortcuts"),
            S("com.apple.Translate"), S("com.apple.measure"), S("com.apple.compass"),
            S("com.apple.VoiceMemos"), S("com.apple.findmy"), S("com.apple.Fitness"),
            S("com.apple.Bridge"), S("com.apple.tv"), S("com.apple.tips"),
            S("com.apple.Magnifier"), S("com.apple.Passwords"), S("com.apple.MobileStore"),
            S("com.apple.TestFlight"), S("com.apple.Pages"), S("com.apple.Numbers"),
            S("com.apple.Keynote"), S("com.apple.iMovie"), S("com.apple.GarageBand"),
        ];
    });
    return [systemApps containsObject:bundleID];
}



@implementation CPUthermalAppListController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = [[self ctPrefsKey] isEqualToString:S("fullPowerApps")] ? S("指定 App 高性能率") : S("指定 App 低频率");
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchResultsUpdater = self;
    self.searchController.obscuresBackgroundDuringPresentation = NO;
    self.searchController.searchBar.placeholder = S("名称或 Bundle ID");
    self.navigationItem.searchController = self.searchController;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    self.definesPresentationContext = YES;
}

- (NSString *)stringFromObject:(id)object selectors:(NSArray<NSString *> *)selectors {
    for (NSString *name in selectors) {
        SEL selector = NSSelectorFromString(name);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

- (id)applicationProxyForBundleID:(NSString *)bundleID {
    @try {
        Class proxyClass = NSClassFromString(S("LSApplicationProxy"));
        SEL proxySel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
        if (proxyClass && [proxyClass respondsToSelector:proxySel] && bundleID.length) return ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, proxySel, bundleID);
    } @catch (__unused NSException *exception) {}
    return nil;
}

- (void)addApplicationAtPath:(NSString *)appPath toMap:(NSMutableDictionary *)map {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:S("Info.plist")]];
    NSString *bundleID = info[S("CFBundleIdentifier")];
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return;
    if (!CPUthermalIsVisibleApp(bundleID)) return;
    NSString *name = [self stringFromObject:[self applicationProxyForBundleID:bundleID] selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleDisplayName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = bundleID;
    map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):appPath ?: S("")};
}

- (NSArray<NSDictionary *> *)enumerateApplications {
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    @try {
        Class workspaceClass = NSClassFromString(S("LSApplicationWorkspace"));
        id workspace = [workspaceClass respondsToSelector:NSSelectorFromString(S("defaultWorkspace"))] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, NSSelectorFromString(S("defaultWorkspace"))) : nil;
        id applications = [workspace respondsToSelector:NSSelectorFromString(S("allApplications"))] ? ((id (*)(id, SEL))objc_msgSend)(workspace, NSSelectorFromString(S("allApplications"))) : nil;
        if ([applications isKindOfClass:[NSArray class]]) for (id proxy in applications) {
            NSString *bundleID = [self stringFromObject:proxy selectors:@[S("applicationIdentifier"),S("bundleIdentifier")]];
            if (bundleID.length == 0) continue;
            if (!CPUthermalIsVisibleApp(bundleID)) continue;
            NSString *name = [self stringFromObject:proxy selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]] ?: bundleID;
            NSString *bundlePath = S("");
            SEL urlSel = NSSelectorFromString(S("bundleURL"));
            if ([proxy respondsToSelector:urlSel]) {
                id url = ((id (*)(id, SEL))objc_msgSend)(proxy, urlSel);
                if ([url isKindOfClass:[NSURL class]]) bundlePath = ((NSURL *)url).path ?: S("");
            }
            map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):bundlePath};
        }
    } @catch (__unused NSException *exception) {}
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *root in @[S("/var/mobile/Containers/Bundle/Application"), S("/var/containers/Bundle/Application"), S("/Applications"), S("/System/Applications")]) {
        for (NSString *child in [fm contentsOfDirectoryAtPath:root error:nil] ?: @[]) {
            NSString *full = [root stringByAppendingPathComponent:child];
            if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) {
                [self addApplicationAtPath:full toMap:map];
                continue;
            }
            for (NSString *entry in [fm contentsOfDirectoryAtPath:full error:nil] ?: @[]) if ([[entry pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) [self addApplicationAtPath:[full stringByAppendingPathComponent:entry] toMap:map];
        }
    }
    return [map allValues];
}

// 两份独立名单：基类 = 性能模式的「低功耗名单」；子类 = 低功耗模式的「高性能名单」
- (NSString *)ctPrefsKey { return S("lowPowerApps"); }

- (void)writeEnabledBundleIDs:(NSSet *)enabled {
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs() ?: [NSMutableDictionary dictionary];
    prefs[[self ctPrefsKey]] = [[enabled allObjects] sortedArrayUsingSelector:@selector(compare:)];
    CPUthermalWritePrefs(prefs);
    notify_post(kCPUthermalSettingsChangedNotifC);
}

- (NSMutableSet<NSString *> *)enabledBundleIDs {
    id value = CPUthermalReadPrefs()[[self ctPrefsKey]];
    return [NSMutableSet setWithArray:[value isKindOfClass:[NSArray class]] ? value : @[]];
}

- (NSArray<NSDictionary *> *)visibleApplications {
    if (!self.allApps) self.allApps = [self enumerateApplications];
    NSString *term = [[self.searchTerm ?: S("") stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] lowercaseString];
    NSMutableArray *visible = [NSMutableArray array];
    for (NSDictionary *app in self.allApps) {
        NSString *name = app[S("name")], *bundleID = app[S("id")];
        if (term.length == 0 || [[name lowercaseString] containsString:term] || [[bundleID lowercaseString] containsString:term]) [visible addObject:app];
    }
    NSSet *enabled = [self enabledBundleIDs];
    [visible sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        BOOL ae = [enabled containsObject:a[S("id")]], be = [enabled containsObject:b[S("id")]];
        if (ae != be) return ae ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult r = [a[S("name")] localizedCaseInsensitiveCompare:b[S("name")]];
        return r == NSOrderedSame ? [a[S("id")] compare:b[S("id")]] : r;
    }];
    return visible;
}

- (void)rebuildSpecifiers {
    if (!_specifiers) _specifiers = [[NSMutableArray alloc] init];
    [_specifiers removeAllObjects];
    @try {
        NSArray *apps = [self visibleApplications];
        NSUInteger enabledCount = [self enabledBundleIDs].count;
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        NSString *footer = self.searchTerm.length ? [NSString stringWithFormat:S("找到 %lu 个应用 · 已勾选的排在最前。\n「全选 / 全不选」只作用于当前列表。"), (unsigned long)apps.count] : [NSString stringWithFormat:S("已勾选 %lu 个应用。"), (unsigned long)enabledCount];
        if (!self.allApps.count) footer = S("没有枚举到可用的应用。");
        // 描述跟着当前常驻模式走（低功耗 → 高性能；性能模式 → 低功耗）
        {
            BOOL isFullList = [[self ctPrefsKey] isEqualToString:S("fullPowerApps")];
            id modeValue = CPUthermalReadPrefs()[S("powerMode")];
            BOOL residentLowPower = [modeValue isKindOfClass:[NSString class]] && [modeValue isEqualToString:S("lowPower")];
            if (!self.searchTerm.length) {
                footer = isFullList
                    ? (residentLowPower
                       ? [NSString stringWithFormat:S("▼ 本名单生效中（常驻「低功耗」）。\n已勾选 %lu 个应用：进入它们时高性能运行（不卡），其余应用保持低功耗；熄屏时一律低功耗。"), (unsigned long)enabledCount]
                       : [NSString stringWithFormat:S("当前常驻「性能模式」，本名单暂不生效。\n仅用于常驻「低功耗」时指定高性能应用。已勾选 %lu 个。"), (unsigned long)enabledCount])
                    : (residentLowPower
                       ? [NSString stringWithFormat:S("当前常驻「低功耗」，本名单暂不生效。\n仅用于常驻「性能模式」时指定低功耗应用。已勾选 %lu 个。"), (unsigned long)enabledCount]
                       : [NSString stringWithFormat:S("▼ 本名单生效中（常驻「性能模式」）。\n已勾选 %lu 个应用：进入它们时切换低功耗（省电），其余应用高性能。"), (unsigned long)enabledCount]);
            }
        }
        [group setProperty:footer forKey:S("footerText")];
        [_specifiers addObject:group];
        PSSpecifier *selectAllSpecifier = [PSSpecifier preferenceSpecifierNamed:S("全选") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        selectAllSpecifier->action = @selector(selectAllApps:);
        [_specifiers addObject:selectAllSpecifier];
        PSSpecifier *selectNoneSpecifier = [PSSpecifier preferenceSpecifierNamed:S("全不选") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        selectNoneSpecifier->action = @selector(clearAllApps:);
        [_specifiers addObject:selectNoneSpecifier];
        [_specifiers addObject:[PSSpecifier emptyGroupSpecifier]];
        for (NSDictionary *app in apps) {
            PSSpecifier *specifier = [PSSpecifier preferenceSpecifierNamed:app[S("name")] target:self set:@selector(setAppEnabled:specifier:) get:@selector(appEnabled:) detail:nil cell:PSSwitchCell edit:nil];
            specifier.identifier = app[S("id")];
            [specifier setProperty:app[S("id")] forKey:S("id")];
            [specifier setProperty:app[S("id")] forKey:S("ctBundleID")];
            [specifier setProperty:app[S("path")] ?: S("") forKey:S("ctBundlePath")];
            [_specifiers addObject:specifier];
        }
    } @catch (__unused NSException *exception) {
        [_specifiers removeAllObjects];
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        [group setProperty:S("应用列表加载异常。") forKey:S("footerText")];
        [_specifiers addObject:group];
    }
}

- (NSArray *)specifiers { if (!_specifiers) [self rebuildSpecifiers]; return _specifiers; }
- (id)appEnabled:(PSSpecifier *)specifier { return @([[self enabledBundleIDs] containsObject:specifier.identifier ?: [specifier propertyForKey:S("id")]]); }
- (void)setAppEnabled:(id)value specifier:(PSSpecifier *)specifier {
    NSString *bundleID = specifier.identifier ?: [specifier propertyForKey:S("id")];
    if (bundleID.length == 0) return;
    NSMutableSet *enabled = [self enabledBundleIDs];
    [value boolValue] ? [enabled addObject:bundleID] : [enabled removeObject:bundleID];
    [self writeEnabledBundleIDs:enabled];
    dispatch_async(dispatch_get_main_queue(), ^{ [self rebuildSpecifiers]; [self.table reloadData]; });
}
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController { self.searchTerm = searchController.searchBar.text ?: S(""); [self rebuildSpecifiers]; [self.table reloadData]; }

#pragma mark - 全选 / 全不选

- (void)selectAllApps:(PSSpecifier *)specifier {
    (void)specifier;
    NSMutableSet *enabled = [self enabledBundleIDs];
    for (NSDictionary *app in [self visibleApplications]) {
        id bundleID = app[S("id")];
        if ([bundleID isKindOfClass:[NSString class]]) [enabled addObject:bundleID];
    }
    [self writeEnabledBundleIDs:enabled];
    dispatch_async(dispatch_get_main_queue(), ^{ [self rebuildSpecifiers]; [self.table reloadData]; });
}

- (void)clearAllApps:(PSSpecifier *)specifier {
    (void)specifier;
    NSMutableSet *enabled = [self enabledBundleIDs];
    for (NSDictionary *app in [self visibleApplications]) {
        id bundleID = app[S("id")];
        if (bundleID) [enabled removeObject:bundleID];
    }
    [self writeEnabledBundleIDs:enabled];
    dispatch_async(dispatch_get_main_queue(), ^{ [self rebuildSpecifiers]; [self.table reloadData]; });
}
@end

#pragma mark - 低功耗模式下的「高性能名单」（独立于性能模式的低功耗名单）

@interface CPUthermalFullPowerAppListController : CPUthermalAppListController
@end

@implementation CPUthermalFullPowerAppListController
- (NSString *)ctPrefsKey { return S("fullPowerApps"); }
@end



#pragma mark - 应用图标

// 从 App 包目录里直接找 png 图标（读 Info.plist 的 CFBundleIconFiles）
static UIImage *CPUthermalIconFromBundle(NSString *bundlePath) {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[bundlePath stringByAppendingPathComponent:S("Info.plist")]];
    NSMutableArray *bases = [NSMutableArray array];
    id icons = info[S("CFBundleIcons")];
    if ([icons isKindOfClass:[NSDictionary class]]) {
        id primary = icons[S("CFBundlePrimaryIcon")];
        if ([primary isKindOfClass:[NSDictionary class]]) {
            id files = primary[S("CFBundleIconFiles")];
            if ([files isKindOfClass:[NSArray class]]) [bases addObjectsFromArray:files];
        }
    }
    id legacy = info[S("CFBundleIconFiles")];
    if ([legacy isKindOfClass:[NSArray class]]) [bases addObjectsFromArray:legacy];
    [bases addObjectsFromArray:@[S("AppIcon60x60"), S("AppIcon"), S("Icon")]];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (id base in bases) {
        if (![base isKindOfClass:[NSString class]] || [base length] == 0) continue;
        for (NSString *suffix in @[S("@3x.png"), S("@2x.png"), S(".png")]) {
            NSString *file = [[bundlePath stringByAppendingPathComponent:base] stringByAppendingString:suffix];
            if ([fm fileExistsAtPath:file]) {
                UIImage *image = [UIImage imageWithContentsOfFile:file];
                if (image) return image;
            }
        }
    }
    return nil;
}

// 多路取图标：① 私有 API ② LSApplicationProxy.iconData ③ 直接从包内读 png；结果带缓存
static UIImage *CPUthermalIconForApp(NSString *bundleID, NSString *bundlePath) {
    static NSMutableDictionary *cache = nil;
    static NSMutableSet *misses = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ cache = [NSMutableDictionary dictionary]; misses = [NSMutableSet set]; });
    if (bundleID.length == 0) return nil;
    if (cache[bundleID]) return cache[bundleID];
    if ([misses containsObject:bundleID]) return nil;
    UIImage *icon = nil;
    @try {
        CGFloat scale = [UIScreen mainScreen].scale ?: 2.0;
        SEL iconSel = NSSelectorFromString(S("_applicationIconImageForBundleIdentifier:format:scale:"));
        if ([UIImage respondsToSelector:iconSel]) icon = ((UIImage *(*)(id, SEL, NSString *, int, CGFloat))objc_msgSend)([UIImage class], iconSel, bundleID, 0, scale);
        if (!icon) {
            Class proxyClass = objc_getClass("LSApplicationProxy");
            SEL proxySel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
            if (proxyClass && [proxyClass respondsToSelector:proxySel]) {
                id proxy = ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, proxySel, bundleID);
                SEL dataSel = NSSelectorFromString(S("iconData"));
                if (proxy && [proxy respondsToSelector:dataSel]) {
                    NSData *data = ((NSData *(*)(id, SEL))objc_msgSend)(proxy, dataSel);
                    if ([data isKindOfClass:[NSData class]] && data.length) icon = [UIImage imageWithData:data];
                }
            }
        }
        if (!icon && bundlePath.length) icon = CPUthermalIconFromBundle(bundlePath);
    } @catch (__unused NSException *exception) {}
    if (icon) cache[bundleID] = icon; else [misses addObject:bundleID];
    return icon;
}

// 给 Preferences 里的表格行挂图标：运行时替换 PSTableCell 的刷新实现（不用自定义单元格类）
static void (*ct_orig_refresh)(id, SEL, PSSpecifier *) = NULL;

static void ct_refresh_cell(id self, SEL _cmd, PSSpecifier *specifier) {
    if (ct_orig_refresh) ct_orig_refresh(self, _cmd, specifier);
    // ★ T7w：当前档位选中行的 "✓" 显示为红色
    @try {
        UITableViewCell *ctCell = (UITableViewCell *)self;
        UILabel *ctLabel = ctCell.textLabel;
        BOOL ctWantRed = [[specifier propertyForKey:S("ctCurrent")] boolValue];
        if (ctWantRed && ctLabel.text.length) {
            NSString *ctText = ctLabel.text;
            NSMutableAttributedString *ctAttr = [[NSMutableAttributedString alloc] initWithString:ctText];
            if (ctLabel.font) [ctAttr addAttribute:NSFontAttributeName value:ctLabel.font range:NSMakeRange(0, ctText.length)];
            if (ctText.length > 1) [ctAttr addAttribute:NSForegroundColorAttributeName value:(ctLabel.textColor ?: [UIColor labelColor]) range:NSMakeRange(1, ctText.length - 1)];
            [ctAttr addAttribute:NSForegroundColorAttributeName value:[UIColor systemRedColor] range:NSMakeRange(0, 1)];
            ctLabel.attributedText = ctAttr;
        } else if (ctLabel.attributedText.length) {
            ctLabel.text = ctLabel.text;   // 清掉复用细胞上残留的红色属性
        }
    } @catch (__unused NSException *exception) {}
    @try {
        NSString *bundleID = [specifier propertyForKey:S("ctBundleID")];
        if (bundleID.length == 0) return;
        UIImage *icon = CPUthermalIconForApp(bundleID, [specifier propertyForKey:S("ctBundlePath")]);
        if (!icon) return;
        UITableViewCell *cell = (UITableViewCell *)self;
        cell.imageView.image = icon;
        cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
    } @catch (__unused NSException *exception) {}
}

__attribute__((constructor)) static void ct_install_cell_icon_hook(void) {
    Class cellClass = NSClassFromString(S("PSTableCell"));
    SEL sel = NSSelectorFromString(S("refreshCellContentsWithSpecifier:"));
    if (!cellClass) return;
    Method method = class_getInstanceMethod(cellClass, sel);
    if (!method) return;
    ct_orig_refresh = (void (*)(id, SEL, PSSpecifier *))method_getImplementation(method);
    method_setImplementation(method, (IMP)ct_refresh_cell);
}
