// ============================================================
// ★ T7z16：一键自检（设置页）
//   · 「开始 30 秒自检」→ 主插件后台采样 → 自动出报告 → 本页展示
//   · 报告 = 频率/深度/提速/温度 + 「压制是否生效」结论
//   · 禁止 @"" 常量（roothide 会崩），全部用 S()
// ============================================================

#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <CTHermesPaths.h>
#import <CTHardening.h>
#import <CTNotifyState.h>   // ★ 0930-0207：通知数据通道
#include <stdarg.h>
#include <sys/time.h>   // ★ 0930-0196：核心 ↔ 界面双通道（CTSharedReadNewest 等）

static NSString *CTStReq(void) { return S(CTDiagFileC("CTHermesSelfTest.req")); }
static void CTStLog(NSString *fmt, ...) {   // ★ 0930-0207：自检过程写进主日志（诊断）
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; localtime_r(&tv.tv_sec, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    FILE *f = fopen(CTDiagLogPathC(), "a");
    if (f) { fprintf(f, "[%s][自检] %s\n", ts, msg.UTF8String); fclose(f); }
}
static int sSampF[600]; static int sSampT[600]; static int sSampM[600]; static int sSampN = 0;   // ★ 0930-0207：通知采样桶
static void CTSampReset(void) { sSampN = 0; }
static void CTSampPush(void) {
    if (sSampN >= 600) return;
    if (gCTNSFreq < 0 && gCTNSTemp < 0) return;
    sSampF[sSampN] = gCTNSFreq; sSampT[sSampN] = gCTNSTemp; sSampM[sSampN] = gCTNSMode; sSampN++;
}
static NSString *CTSummaryReport(void) {   // ★ 0930-0207：用"通知通道"收到的核心数据拼摘要报告
    if (sSampN < 3) return nil;
    int fmin = 99999, fmax = -1; long fsum = 0; int fcnt = 0;
    int tmin = 999, tmax = -1; int mset = 0;
    for (int i = 0; i < sSampN; i++) {
        if (sSampF[i] >= 0) { int v = sSampF[i] * 100; if (v < fmin) fmin = v; if (v > fmax) fmax = v; fsum += v; fcnt++; }
        if (sSampT[i] >= 0) { int t = sSampT[i]; if (t < tmin) tmin = t; if (t > tmax) tmax = t; }
        if (sSampM[i] >= 0) mset |= (1 << sSampM[i]);
    }
    NSArray *mn = @[@"原生", @"智能低功耗", @"高性能"];
    NSMutableArray *ms = [NSMutableArray array];
    for (int i = 0; i < 3; i++) if (mset & (1 << i)) [ms addObject:mn[i]];
    NSArray *vs = @[@"压制生效 ✓", @"压力偏大 ⚠", @"未生效 ✗", @"采样中断"];
    NSString *vt = nil;
    if (gCTNSVerdict >= 0 && gCTNSVerdict < 4) {
        vt = vs[gCTNSVerdict];
    } else if (fmax > 0) {   // ★ 0930-0207：没有核心结论 → 用采样数据自己给结论
        if (fmax <= 2200) vt = [NSString stringWithFormat:@"✅ 所测频率正常：峰值 %dMHz ≤ 2200，未发现漏压", fmax];
        else              vt = [NSString stringWithFormat:@"⚠ 发现 %dMHz 样本（>2200）——可能没压住，建议复测", fmax];
    } else {
        vt = @"（本次样本不足，建议复测）";
    }
    NSMutableString *r = [NSMutableString string];
    [r appendString:@"【一键自检 · 摘要报告】\n（数据为本机实时读取）\n------------------------------\n"];
    [r appendFormat:@"采样: %d 个点（约 30 秒）\n", sSampN];
    if (fcnt > 0) [r appendFormat:@"频率: 最低 %d / 平均 %d / 最高 %d MHz\n", fmin, (int)(fsum / fcnt), fmax];
    if (tmax >= 0) [r appendFormat:@"温度: %d ~ %d ℃\n", tmin, tmax];
    if (ms.count) [r appendFormat:@"模式: %@\n", [ms componentsJoinedByString:@" / "]];
    [r appendFormat:@"------------------------------\n结论: %@\n", vt];
    return r;
}
static NSString *CTSummaryFromPrefs(void) {   // ★ 0930-0207：没收到通知采样时，用"守护桥"写进配置的核心数据
    NSString *st = CTPrefsStr(@"ctStatus");
    int f = 0, t = -1;
    NSRange r1 = [st rangeOfString:@"freq="];
    if (r1.location != NSNotFound) f = (int)[[st substringFromIndex:r1.location + 5] intValue];
    NSRange r2 = [st rangeOfString:@"temp="];
    if (r2.location != NSNotFound) t = (int)[[st substringFromIndex:r2.location + 5] doubleValue];
    NSArray *vs = @[@"压制生效 ✓", @"压力偏大 ⚠", @"未生效 ✗", @"采样中断"];
    int vb = (int)CTPrefsNum(@"ctVerdict");
    NSString *vt = (CTPrefsNum(@"ctVerdictAt") > 0 && vb >= 0 && vb < 4) ? vs[vb] : @"（核心结论暂未到）";
    return [NSString stringWithFormat:@"【一键自检 · 桥接摘要】\n（数据经「root 守护桥」取自温控核心）\n------------------------------\n频率：实测 %d MHz\n温度：%d ℃\n------------------------------\n结论：%@\n", f, t, vt];
}
static double sCTReqAt = 0;   // ★ 0930-0207：本次自检请求时间戳
// ★ 1.4.117：报告文件必须"比本次请求新"才算完成——防"清不掉的旧副本"冒充本次结果
//   （旧副本可能是 root 写的、设置进程删不掉：粘滞目录只允许文件属主删除）
static BOOL CTStFreshResultFile(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *dir in CTStateWriteDirs()) {
        NSString *p = [dir stringByAppendingPathComponent:@"CTHermesSelfTest.txt"];
        NSDictionary *at = [fm attributesOfItemAtPath:p error:NULL];
        if (!at) continue;
        NSDate *mt = at[NSFileModificationDate];
        if (mt && [mt timeIntervalSinceReferenceDate] > sCTReqAt - 0.2) return YES;
    }
    return NO;
}
static NSString *CTStRes(void) { return S(CTDiagFileC("CTHermesSelfTest.txt")); }

// ---------- 报告查看页 ----------
@interface CTHermesReportController : UIViewController
@property (nonatomic, copy) NSString *reportText;
@end

@implementation CTHermesReportController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    UITextView *tv = [[UITextView alloc] initWithFrame:self.view.bounds];
    tv.editable = NO;
    tv.font = [UIFont monospacedSystemFontOfSize:12.5 weight:UIFontWeightRegular];
    tv.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    tv.textContainerInset = UIEdgeInsetsMake(14, 14, 14, 14);
    tv.text = self.reportText ?: S("");
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:tv];
}
@end

// ---------- 自检页 ----------
@interface CTHermesSelfTestController : PSListController
@property (nonatomic, strong) NSTimer *pollTimer;
@property (nonatomic) CFAbsoluteTime startedAt;
@property (nonatomic) BOOL running;
@property (nonatomic, strong) PSSpecifier *statusGroup;
@end

@implementation CTHermesSelfTestController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *arr = [NSMutableArray array];

        PSSpecifier *g1 = [PSSpecifier emptyGroupSpecifier];
        [g1 setProperty:S("自检说明") forKey:S("label")];
        [g1 setProperty:S("点下面的按钮跑 30 秒采样：自动统计 频率 / 深度 / 提速 / 温度，并判断「压制是否生效」。采样期间正常用手机，滑一滑更准。") forKey:S("footerText")];
        [arr addObject:g1];

        PSSpecifier *b1 = [PSSpecifier preferenceSpecifierNamed:S("开始 30 秒自检") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        b1->action = @selector(stStart:);
        [arr addObject:b1];

        self.statusGroup = [PSSpecifier emptyGroupSpecifier];
        [self.statusGroup setProperty:S("状态") forKey:S("label")];
        [self.statusGroup setProperty:S("（还没跑过）") forKey:S("footerText")];
        [arr addObject:self.statusGroup];

        PSSpecifier *b2 = [PSSpecifier preferenceSpecifierNamed:S("查看上次报告") target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        b2->action = @selector(stShow:);
        [arr addObject:b2];

        _specifiers = arr;
    }
    return _specifiers;
}

- (void)setStatus:(NSString *)s {
    [self.statusGroup setProperty:s forKey:S("footerText")];
    [self reloadSpecifier:self.statusGroup];
}

- (void)stStart:(PSSpecifier *)spec {
    // ★ 1.4.120：连点 = 重新开始（以最后一次点击为准）——
    //   旧版"正在跑就忽略点击"会让结果在连点过程中突然出现（看着像"刚点就秒出"）；
    //   现在每次点击都重置计时+重发请求：你停下后 ≥25 秒才会出结果，且必然是"最后点击之后"跑出来的
    NSFileManager *fm = [NSFileManager defaultManager];
    CTStateRemove(@"CTHermesSelfTest.txt");   // ★ 0930-0207：多路清理
    [fm removeItemAtPath:CTStReq() error:NULL];
    NSString *stamp = [NSString stringWithFormat:S("%.0f"), CFAbsoluteTimeGetCurrent()];
    CTNotifyStateStart();
    CTSampReset();
    sCTReqAt = CFAbsoluteTimeGetCurrent();
    CTStLog(@"请求已发出（prefs+文件+通知）reqAt=%.0f", sCTReqAt);
    CTPrefsSet(@{@"ctSelfTestReqAt": @(sCTReqAt)});   // ★ 0930-0207：prefs 通道（最可靠的一条）
    CTStateWrite(@"CTHermesSelfTest.req", stamp);   // ★ 0930-0207：多路写（每个能写的目录都写一份）
    notify_post("com.qq391160.cpucore/selfTest");    // ★ 0930-0207：通知直接叫醒核心（文件通道不通也能开工）
    BOOL ctWrotePrimary = [stamp writeToFile:CTStReq() atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    if (!ctWrotePrimary) {   // ★ 0930-0207：主路径失败也别急——只要多路写成功一处，就算发得出去
        [self setStatus:S("⚠ 写入请求失败——确认「CPU 智能温控」已安装并运行")];
        if (!CTStateExists(@"CTHermesSelfTest.req")) return;
    }
    self.running = YES;
    self.startedAt = CFAbsoluteTimeGetCurrent();
    [self setStatus:S("正在采样…约 30 秒（请正常用手机，滑一滑更准）")];
    [self.pollTimer invalidate];
    self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(stPoll) userInfo:nil repeats:YES];
}

- (void)stPoll {
    NSFileManager *fm = [NSFileManager defaultManager];
    // ★ 1.4.118/119：真实的 30 秒检测不可能在 25 秒内完成——
    //   点击后 25 秒内出现的任何"完成信号"必然是"上一轮/别的来源"，一律不认（连点也不可能秒出）
    double elNow = CFAbsoluteTimeGetCurrent() - self.startedAt;
    if (elNow >= 25.0 && (CTPrefsNum(@"ctSelfTestReportAt") > sCTReqAt || CTStFreshResultFile())) {   // ★ 1.4.117/119
        self.running = NO;
        [self.pollTimer invalidate]; self.pollTimer = nil;
        [self setStatus:S("✅ 完成（报告已生成）")];
        [self showReport];
        return;
    }
    // ★ 1.4.116：删除"抢跑"捷径 —— 旧版这里用「上次的结论(gCTNSVerdict) + 任意新通知(gCTNSAt)」
    //   当"完成信号"，而 gCTNSAt 是"收到任意状态通知的时间"（核心每 1-2 秒都在发），
    //   所以点一下 1 秒就会拿"上次的结论"冒充"本次结果"（本次采样其实还在跑）✗
    //   ⇒ 完成只认"新鲜的"：①核心写完报告（文件/prefs，带本次时间戳）②桥接结论时间戳
    //   ③满 30 秒后由本次采样出摘要（下方逻辑）。
    CTSampPush();   // ★ 0930-0207：把"核心经通知发来的"数据记进采样
    // ★ 1.4.118：删除"桥接结论"捷径 —— 它的新鲜度时间戳(ctVerdictAt)由中转站按"结论变化"刷新，
    //   并非"本次自检的完成时刻"，存在"恰好赶上别的跑完"被冒充的窗口。真实完成一律由：
    //   ①核心报告（文件/prefs，必须比本次请求新）②满 30 秒后的本次采样摘要（下方）负责。
    if (CFAbsoluteTimeGetCurrent() - self.startedAt > 62.0) {   // ★ 1.4.120：62 秒兜底（考虑"前面还有一轮在跑"的排队）
        NSString *sum = CTSummaryReport();   // ★ 0930-0207：采样满 30 秒——报告没到就用通知数据出摘要
        if (!sum.length) sum = CTSummaryFromPrefs();   // ★ 0930-0207：连通知采样都没有 → 用守护桥的配置数据
        if (sum.length) {
            self.running = NO;
            [self.pollTimer invalidate]; self.pollTimer = nil;
            CTStLog(@"出摘要报告：采样 %d 点 结论=%d", sSampN, gCTNSVerdict);
            CTStateWrite(@"CTHermesSelfTest.txt", sum);
            CTPrefsSet(@{@"ctSelfTestReport": sum, @"ctSelfTestReportAt": @(CFAbsoluteTimeGetCurrent())});
            CTHermesReportController *rc = [[CTHermesReportController alloc] init];
            rc.reportText = sum;
            rc.title = S("自检报告（摘要）");
            [self.navigationController pushViewController:rc animated:YES];
            [self setStatus:S("✅ 完成（摘要报告已生成）")];
            return;
        }
    }
    if (elNow > 90.0) {   // ★ 1.4.120：90 秒超时（排队最坏 ~60 秒 + 余量）
        CTStLog(@"超时：45 秒没等到报告（prefs/文件/结论 三条都没到）");
        self.running = NO;
        [self.pollTimer invalidate]; self.pollTimer = nil;
        [self setStatus:S("⚠ 插件无响应——确认插件在运行；或重启用户空间后重试")];
        return;
    }
    {
        double leftS = 32.0 - elNow;
        if (leftS > 1.0)
            [self setStatus:[NSString stringWithFormat:S("正在采样… 剩余约 %.0f 秒（连点过则以最后一次为准）"), leftS]];
        else
            [self setStatus:S("正在采样… 即将出结果（连点过则以最后一次为准）")];
    }
}

- (void)stShow:(PSSpecifier *)spec { [self showReport]; }

- (void)showReport {
    NSString *rep = CTPrefsStr(@"ctSelfTestReport");   // ★ 0930-0207：优先 prefs
    if (!rep.length) rep = CTStateRead(@"CTHermesSelfTest.txt");
    if (!rep.length) { [self setStatus:S("还没有报告——先点上面「开始 30 秒自检」")]; return; }
    CTHermesReportController *r = [[CTHermesReportController alloc] init];
    r.reportText = rep;
    r.title = S("自检报告");
    [self.navigationController pushViewController:r animated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.running && !self.pollTimer) {
        self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(stPoll) userInfo:nil repeats:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.pollTimer invalidate];
    self.pollTimer = nil;
    self.running = NO;
}

@end
