#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <notify.h>
#import <CPUthermalPaths.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/time.h>

// ★ T7r 诊断：本组件里的"每秒前台轮询"是独立于前台插件的第二个上报源，
//   这里把每次上报的字符串/哈希/取值来源都写进日志（排查"前台指纹对不上"）。
static void CTFDLlog(const char *fmt, ...) {
    mkdir("/var/mobile/Library/Logs", 0755);
    FILE *fp = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][朝下] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

@interface SpringBoard : UIApplication
+ (instancetype)sharedApplication;
- (void)_simulateLockButtonPress;
@end

static BOOL gFaceDownLockEnabled = NO;
static CFAbsoluteTime gLastFaceDownLockTime = 0;
static int gFaceDownSettingsToken = 0;

static void ReloadFaceDownPreference(void) {
    gFaceDownLockEnabled = [CPUthermalReadPrefs()[S("lockWhenFaceDown")] boolValue];
}

%hook SBIdleTimerGlobalStateMonitor
- (void)pocketStateMonitor:(id)monitor pocketStateDidChangeFrom:(long long)oldState to:(long long)newState {
    %orig;
    if (!gFaceDownLockEnabled || newState != 3) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - gLastFaceDownLockTime < 1.5) return;
    gLastFaceDownLockTime = now;
    id springBoard = [%c(SpringBoard) sharedApplication];
    if ([springBoard respondsToSelector:@selector(_simulateLockButtonPress)])
        [springBoard _simulateLockButtonPress];
}
%end

// ★★ 在 SpringBoard 内每秒读一次"前台应用"—— 本插件本来就在 SpringBoard 里运行 ✓（不新增注入 ✗）
//    只用便宜接口（SBApplicationController / SBWorkspace 的缓存值 ✓），
//    不用无障碍树 ✗、不用 100 毫秒高频 ✗（上次翻车就是那两条 ✗）
static void CPUthermalStartFrontmostPoller(void) {
    static dispatch_source_t t = NULL;
    if (t) return;
    t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!t) return;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC),
                              1ull * NSEC_PER_SEC, 300ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(t, ^{
        id app = nil;
        Class ctrlCls = objc_getClass("SBApplicationController");
        SEL sharedSel = sel_registerName("sharedInstance");
        if ([ctrlCls respondsToSelector:sharedSel]) {
            id ctrl = ((id (*)(id, SEL))objc_msgSend)(ctrlCls, sharedSel);
            SEL frontSel = sel_registerName("frontmostApplication");
            if ([ctrl respondsToSelector:frontSel]) app = ((id (*)(id, SEL))objc_msgSend)(ctrl, frontSel);
        }
        if (!app) {
            Class wsCls = objc_getClass("SBWorkspace");
            SEL mainSel = sel_registerName("mainWorkspace");
            if ([wsCls respondsToSelector:mainSel]) {
                id ws = ((id (*)(id, SEL))objc_msgSend)(wsCls, mainSel);
                SEL frontSel = sel_registerName("frontmostApplication");
                if ([ws respondsToSelector:frontSel]) app = ((id (*)(id, SEL))objc_msgSend)(ws, frontSel);
            }
        }
        NSString *bid = nil;
        const char *usedSel = "-";
        const char *ids[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
        for (int i = 0; app && ids[i]; i++) {
            SEL s = sel_registerName(ids[i]);
            if ([app respondsToSelector:s]) {
                id v = ((id (*)(id, SEL))objc_msgSend)(app, s);
                if ([v isKindOfClass:[NSString class]] && [v length] > 0) { bid = v; usedSel = ids[i]; break; }
            }
        }
        static BOOL sCTFirstTick = YES;
        if (sCTFirstTick) { sCTFirstTick = NO; CTFDLlog("首轮读取: bid=%s app=%s", (bid.length ? bid.UTF8String : "(空)"), (app ? "有" : "无")); }
        static NSString *sLast = nil;
        if (bid.length && ![bid isEqualToString:sLast]) {
            sLast = bid;
            if (CPUthermalIsSystemComponentBundleID(bid)) {
                CTFDLlog("组件进程 %s → 跳过上报", bid.UTF8String);
            } else {
                CTFDLlog("上报=%s hash=%llu (sel=%s)", bid.UTF8String, (unsigned long long)CPUthermalBundleIDHash(bid), usedSel);
                CPUthermalPostForegroundBundleID(bid);
            }
        }
    });
    dispatch_resume(t);
}

%ctor {
    @autoreleasepool {
        ReloadFaceDownPreference();
        CTFDLlog("组件已加载，前台轮询启动");
        CPUthermalStartFrontmostPoller();
        notify_register_dispatch(kCPUthermalSettingsChangedNotifC, &gFaceDownSettingsToken,
                                 dispatch_get_main_queue(), ^(int token) {
            (void)token;
            ReloadFaceDownPreference();
        });
    }
}
