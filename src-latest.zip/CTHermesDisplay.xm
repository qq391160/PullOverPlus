// ============================================================================
// CTHermesDisplay —— 「亮度探针」（★ 2.0.95 新件；注入 brightnessd + backboardd + thermalmonitord + powerd + SpringBoard）
//   职责：**只看不动** —— 把"谁在写亮度相关键"记进独立小账本（CTHermesBright.log，自带轮转、耐主日志轮转）。
//   内容：①装入即报 ②IORegistry 写入记账（进程/键/值）③桌面侧周期读数（滑块值/锁态/开关）+ 跳变标记
//   硬门（缺一即休眠）：①已授权 ②防暗屏开关=开
//   护栏：全 @try；无新线程（仅一条定时器）；不拦任何写入（探针版零行为改变）；其它键/API 零干预。
// ============================================================================
#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <notify.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <CTHermesPaths.h>
#import <CTHardening.h>
#include <stdio.h>
#include <sys/time.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/stat.h>

// ---------- 主日志一行（装入即报等） ----------
static void CTDispMailLog(const char *fmt, ...) {
    FILE *fp = CTDiagLogOpenForAppend();
    if (!fp) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][亮度账] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

// ---------- 独立小账本（耐轮转：>96KB 转 .1） ----------
static NSString *CTDispLedgerPath(void) {
    static NSString *sPath = nil;
    if (sPath) return sPath;
    @try {
        NSString *main = @(CTDiagLogPathC());
        if (main.length) sPath = [[main stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"CTHermesBright.log"];
    } @catch (__unused NSException *e) {}
    return sPath;
}
static void CTDispLedger(const char *fmt, ...) {
    @try {
        NSString *p = CTDispLedgerPath();
        if (!p.length) return;
        NSFileManager *fm = [NSFileManager defaultManager];
        NSDictionary *attr = [fm attributesOfItemAtPath:p error:nil];
        unsigned long long sz = attr ? [attr[NSFileSize] unsignedLongLongValue] : 0;
        if (sz > 98304ULL) {   // 96KB 一轮转
            NSString *bak = [p stringByAppendingString:@".1"];
            [fm removeItemAtPath:bak error:nil];
            [fm moveItemAtPath:p toPath:bak error:nil];
        }
        FILE *fp = fopen(p.fileSystemRepresentation, "a");
        if (!fp) return;
        chmod(p.fileSystemRepresentation, 0666);
        struct timeval tv; gettimeofday(&tv, NULL);
        struct tm tmv; time_t tt = tv.tv_sec; localtime_r(&tt, &tmv);
        char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        fprintf(fp, "[%s][亮度账] ", ts);
        va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
        fputc('\n', fp); fclose(fp);
    } @catch (__unused NSException *e) {}
}

// ---------- 门控（5 秒缓存；仅授权+防暗屏） ----------
static BOOL CTDispActive(void) {
    static BOOL sOK = NO; static CFAbsoluteTime sAt = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (sAt > 0 && (now - sAt) < 5.0) return sOK;
    sAt = now; sOK = NO;
    @try {
        NSDictionary *p = CTHermesReadPrefs();
        if ([p[S("thermalPreventDimmingEnabled")] boolValue] && CTAuthFileAuthorized()) sOK = YES;
    } @catch (__unused NSException *e) { sOK = NO; }
    return sOK;
}

// ---------- 亮度相关键判定（探针版：宽名单、只记账） ----------
static BOOL CTDispKeyWatched(NSString *key) {
    if (!(key.length > 0)) return NO;
    NSString *lower = [key lowercaseString];
    if ([lower containsString:S("idle")] || [lower containsString:S("sleep")] ||
        [lower containsString:S("blank")] || [lower containsString:S("lock")] ||
        [lower containsString:S("power")] || [lower containsString:S("wake")] ||
        [lower containsString:S("proximity")] || [lower containsString:S("autolock")]) return NO;
    return [lower containsString:S("brightness")] || [lower containsString:S("nits")] ||
           [lower containsString:S("luminance")] || [lower containsString:S("backlight")] ||
           [lower containsString:S("iomfb")] || [lower containsString:S("blnits")] ||
           [lower containsString:S("panelmax")] || [lower containsString:S("maxbright")];
}
static void CTDispNoteWrite(const char *entry, NSString *key, CFTypeRef value) {
    static CFAbsoluteTime sLast = 0;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - sLast < 3.0) return;   // 进程内 3 秒节流
    sLast = now;
    const char *pn = [NSProcessInfo processInfo].processName.UTF8String ?: "?";
    const char *val = "?";
    char buf[48];
    if (value && CFGetTypeID(value) == CFNumberGetTypeID()) {
        snprintf(buf, sizeof(buf), "%.0f", [(__bridge id)value doubleValue]);
        val = buf;
    } else if (value && CFGetTypeID(value) == CFStringGetTypeID()) {
        val = [[(__bridge id)value description] UTF8String] ?: "?";
    }
    char kbuf[80]; snprintf(kbuf, sizeof(kbuf), "%s", key.UTF8String ?: "?");
    char vbuf[48]; snprintf(vbuf, sizeof(vbuf), "%s", val);
    CTDispLedger("写: 进程=%s 键=%.64s 值=%.40s（入口=%s）", pn, kbuf, vbuf, entry);
}

// ---------- 三条写入通道记账（只记，不拦） ----------
static kern_return_t (*orig_DispServiceSetProperty)(io_service_t, CFStringRef, CFTypeRef) = NULL;
static kern_return_t hooked_DispServiceSetProperty(io_service_t service, CFStringRef key, CFTypeRef value) {
    if (!orig_DispServiceSetProperty) return KERN_FAILURE;
    if (CTDispActive() && service != MACH_PORT_NULL && key) {
        @try { NSString *k = (__bridge NSString *)key; if (CTDispKeyWatched(k)) CTDispNoteWrite("SvcProperty", k, value); } @catch (__unused NSException *e) {}
    }
    return orig_DispServiceSetProperty(service, key, value);
}
%hookf(kern_return_t, IORegistryEntrySetCFProperty, io_registry_entry_t entry, CFStringRef key, CFTypeRef value) {
    if (CTDispActive() && entry != MACH_PORT_NULL && key) {
        @try { NSString *k = (__bridge NSString *)key; if (CTDispKeyWatched(k)) CTDispNoteWrite("RegSetCFProperty", k, value); } @catch (__unused NSException *e) {}
    }
    return %orig(entry, key, value);
}
%hookf(kern_return_t, IORegistryEntrySetCFProperties, io_registry_entry_t entry, CFTypeRef properties) {
    if (CTDispActive() && entry != MACH_PORT_NULL && properties) {
        @try {
            if (CFGetTypeID(properties) == CFDictionaryGetTypeID()) {
                NSDictionary *src = (__bridge NSDictionary *)properties;
                for (id rawKey in src) {
                    if (![rawKey isKindOfClass:[NSString class]]) continue;
                    NSString *k = (NSString *)rawKey;
                    if (CTDispKeyWatched(k)) { CTDispNoteWrite("RegSetCFProperties", k, (__bridge CFTypeRef)src[rawKey]); break; }
                }
            }
        } @catch (__unused NSException *e) {}
    }
    return %orig(entry, properties);
}

// ---------- 桌面侧周期读数 + 跳变标记（仅 SpringBoard 进程） ----------
static void CTDispLedgerTick(void) {
    if (!CTDispActive()) return;
    @try {
        double v = -1.0; BOOL got = NO;
        Class us = NSClassFromString(@"UIScreen");
        if (us) {
            SEL ms = sel_registerName("mainScreen");
            if ([us respondsToSelector:ms]) {
                id screen = ((id (*)(id, SEL))objc_msgSend)(us, ms);
                SEL bs = sel_registerName("brightness");
                if (screen && [screen respondsToSelector:bs]) { v = ((double (*)(id, SEL))objc_msgSend)(screen, bs); got = YES; }
            }
        }
        uint64_t lst = 99; int tok = 0;
        if (notify_register_check("com.apple.springboard.lockstate", &tok) == NOTIFY_STATUS_OK) {
            uint64_t st = 0;
            if (notify_get_state(tok, &st) == NOTIFY_STATUS_OK) lst = st;
            notify_cancel(tok);
        }
        NSDictionary *p = CTHermesReadPrefs();
        int gate = [p[S("thermalPreventDimmingEnabled")] boolValue] ? 1 : 0;
        static double sLast = -1.0; static CFAbsoluteTime sLastAt = 0; static int sN = 0;
        sN++;
        if (!got) { if (sN <= 3 || (sN % 10) == 0) CTDispLedger("读数: 滑块=读不到 锁=%d 开关=%d", (int)lst, gate); return; }
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (sLast >= 0 && fabs(v - sLast) > 0.12)
            CTDispLedger("★ 跳变: %.3f→%.3f（间隔≈%.0fs）锁=%d", sLast, v, (sLastAt > 0) ? (now - sLastAt) : 0.0, (int)lst);
        if (sN <= 3 || (sN % 4) == 0) CTDispLedger("读数: 滑块=%.3f 锁=%d 开关=%d", v, (int)lst, gate);
        sLast = v; sLastAt = now;
    } @catch (__unused NSException *e) {}
}

%ctor {
    @autoreleasepool {
        @try {
            NSString *pn = [NSProcessInfo processInfo].processName ?: @"?";
            {   void *ptr = dlsym(RTLD_DEFAULT, "IOServiceSetProperty");
                if (ptr && !orig_DispServiceSetProperty)
                    MSHookFunction(ptr, (void *)hooked_DispServiceSetProperty, (void **)&orig_DispServiceSetProperty);
            }
            CTDispMailLog("显示探针已装入（%s；在岗=%d；SvcProperty=%d）", pn.UTF8String ?: "?", CTDispActive() ? 1 : 0, orig_DispServiceSetProperty ? 1 : 0);
            if ([pn isEqualToString:@"SpringBoard"]) {
                dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
                if (t) {
                    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30ull * NSEC_PER_SEC)), (uint64_t)(30ull * NSEC_PER_SEC), (uint64_t)(5ull * NSEC_PER_SEC));
                    dispatch_source_set_event_handler(t, ^{ CTDispLedgerTick(); });
                    dispatch_resume(t);
                }
            }
        } @catch (__unused NSException *e) {}
    }
}
