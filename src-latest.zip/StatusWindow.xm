// ============================================================
// ★ T7z21：浅色模式适配（浅色→文字/状态点自动变黑，毛玻璃换浅色材质）
// ★ T7z20b：新增「隐藏悬浮窗背景」开关（只留纯白文字+状态点；无描边、无投影）
// ★ T7z18：浮窗 v2 增补 —— ①字号可自定义（设置→状态显示→浮窗字号，9~20，实时生效）
//   ②长按锁定位置（再长按解锁；锁定后拖动停用，状态随位置记忆一起保存）
//   ③空白处点击穿透（窗口永不挡桌面/App 操作；拖动只在胶囊上生效）
// ★ T7z17：状态浮窗 v2 —— 修复"浮窗已创建但屏幕上不显示"
//   根因（判断）：iOS 13 起 SpringBoard 是"场景化"应用，未挂 windowScene 的
//     自建 UIWindow 不会进入任何场景 → 不参与渲染（旧版只设了 hidden=NO）。
//   v2 三管齐下（一次构建尽量到位）：
//     ① 建窗时挂入前台场景（找不到就挂第一个场景）
//     ② 3 秒自检：窗口不在场景窗列 → 立即退化为"寄生"到系统现成顶层窗口
//     ③ 存活心跳日志（每 30 秒一行）：hidden/容器/场景内/位置，下次排查一眼定案
//   其余不变：开关实时生效、胶囊+毛玻璃+色点、宽度自适应+缩字号、拖动+位置记忆、锁屏隐藏
//   规矩：禁止 @"..." 常量（roothide 重映射会崩），全部用 S()
// ============================================================

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <AudioToolbox/AudioToolbox.h>
#import <notify.h>
#import <CPUthermalPaths.h>
#import <CTFingerprint.h>
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>

extern void CPUthermalStatusWindowTick(void);

// ---------- 日志 ----------
static void CTWinLog(const char *fmt, ...) {
    mkdir("/var/mobile/Library/Logs", 0755);
    FILE *fp = fopen("/var/mobile/Library/Logs/CPUthermalDiag.log", "a");
    if (!fp) return;
    time_t tt = time(NULL); struct tm tmv; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s][浮窗] ", ts);
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

// ---------- 状态 ----------
static UIWindow *gWin = nil;                 // 自建窗口（寄生模式下弃用但保留对象）
static UIView   *gHost = nil;                // 当前承载胶囊的容器（自建窗口根视图 / 系统窗口）
static UIView   *gWinCapsule = nil;
static UIView   *gWinDot = nil;
static UILabel  *gWinLabel = nil;
static id        gWinDrag = nil;
static UIPanGestureRecognizer *gWinPan = nil;
static BOOL      gWinEnabled = NO;
static BOOL      gWinBlanked = NO;
static BOOL      gHostIsSystem = NO;         // YES = 已寄生到系统窗口
static int       gWinSettingsToken = 0;
static int       gWinBlankToken = 0;
static CFAbsoluteTime gWinBornAt = 0;
static CFAbsoluteTime gWinLastAttempt = 0;
static CFAbsoluteTime gWinCheckAt = 0;
static CFAbsoluteTime gWinHeartbeatAt = 0;
static int       gWinCheckPhase = 0;         // 0=等 3 秒自检 1=等 15 秒复核 2=完成
static int       gWinRetryCount = 0;         // 寄生重试计数
static BOOL      gWinPlaced = NO;
static CGFloat   gWinBaseFont = 12.0;        // ★ T7z18：基础字号（设置可调 9~20）
static BOOL      gWinShowCharge = YES;       // ★ 1.4.6：浮窗显示充电段
static BOOL      gWinShowDot = YES;          // ★ 0928-2：「显示内容」状态点
static BOOL      gWinShowFreq = YES;         // ★ 0928-2：「显示内容」频率
static BOOL      gWinShowMode = YES;         // ★ 0928-2：「显示内容」模式
static BOOL      gWinShowFlags = YES;        // ★ 0928-2：「显示内容」标记（深/提/视）
static BOOL      gWinLocked = NO;            // ★ T7z18：位置锁定（长按切换）
static BOOL      gWinNeedFontReload = NO;    // ★ T7z18：设置变更后强制重排
static UILongPressGestureRecognizer *gWinLockPress = nil;
static UIVisualEffectView *gWinBlur = nil;   // ★ T7z20：背景（毛玻璃）可隐藏
static BOOL      gWinHideBg = NO;            // ★ T7z20：设置里「隐藏悬浮窗背景」
static BOOL      gWinLightMode = NO;         // ★ T7z21：浅色模式适配（浅色→黑字）
static NSString *gWinLastRaw = nil;
static CGFloat   gWinW = 132.0;
static CGFloat   gWinH = 27.0;
static CGFloat   gWinCX = 0.0;
static CGFloat   gWinCY = 0.0;

static void CTWinPlace(CGFloat cx, CGFloat cy);
static void CTWinSwitchToSystemHost(const char *why);

// ---------- 位置记忆 ----------
static NSString *CTWinPosPath(void) { return S("/var/mobile/Library/Logs/CPUthermalFloat.pos"); }

static BOOL CTWinLoadPos(CGFloat *x, CGFloat *y) {
    gWinLocked = NO;
    NSString *s = [NSString stringWithContentsOfFile:CTWinPosPath() encoding:NSUTF8StringEncoding error:NULL];
    if (s.length == 0) return NO;
    NSArray *arr = [s componentsSeparatedByString:S(",")];
    if (arr.count < 2) return NO;
    *x = [arr[0] doubleValue]; *y = [arr[1] doubleValue];
    if (arr.count >= 3) gWinLocked = [arr[2] boolValue];    // ★ T7z18：锁定状态随位置一起记
    return (*x > 1.0 && *y > 1.0);
}

static void CTWinSavePos(CGFloat x, CGFloat y) {
    NSString *s = [NSString stringWithFormat:S("%.1f,%.1f,%d"), x, y, gWinLocked ? 1 : 0];
    [s writeToFile:CTWinPosPath() atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

// ---------- 触感反馈（★ T7z19：改成"短震"—— 用轻触反馈，不再用系统长震动） ----------
//   双保险：系统轻触音(1520=pop / 1519=peek，都是短震) + 触感引擎轻击
static void CTWinHaptic(BOOL strong) {
    @try { AudioServicesPlaySystemSound(strong ? 1520 : 1519); } @catch (__unused NSException *e) {}
    @try {
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:(strong ? UIImpactFeedbackStyleMedium : UIImpactFeedbackStyleLight)];
        [gen prepare];
        [gen impactOccurred];
    } @catch (__unused NSException *e) {}
}

// ---------- 拖动 / 长按（手势挂在"胶囊"上：只有按到胶囊才响应） ----------
@interface CTWinDrag : NSObject
@end
@implementation CTWinDrag
- (void)pan:(UIPanGestureRecognizer *)g {
    if (gWinLocked) return;                 // ★ T7z18：已锁定 → 拖动停用
    if (!gWinCapsule) return;
    UIView *sv = gWinCapsule.superview;
    if (!sv) return;
    CGPoint t = [g translationInView:sv];
    [g setTranslation:CGPointZero inView:sv];
    BOOL hostMode = (gHostIsSystem || gWin == nil);
    CGPoint c = hostMode ? CGPointMake(gWinCapsule.center.x + t.x, gWinCapsule.center.y + t.y)
                         : CGPointMake(gWin.center.x + t.x, gWin.center.y + t.y);
    CTWinPlace(c.x, c.y);
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        CTWinSavePos(gWinCX, gWinCY);
        CTWinLog("位置已保存 (%.0f, %.0f)", gWinCX, gWinCY);
    }
}
// ★ T7z18：长按 → 锁定 / 解锁位置（锁定后拖动失效；状态随位置记忆）
- (void)lockPress:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    gWinLocked = !gWinLocked;
    CTWinSavePos(gWinCX, gWinCY);
    CTWinHaptic(gWinLocked);                // ★ T7z18b：锁定=短震(稍强)，解锁=短震(轻)
    CTWinLog(gWinLocked ? "长按：位置已锁定（拖动停用，已震动）" : "长按：位置已解锁（可拖动，已震动）");
    gWinLastRaw = nil;                      // 强制下一跳重绘（显示/去掉锁标记）
}
@end

// ---------- 自建微窗：窗口自身不做命中目标（双保险，配合"只占胶囊大小"的窗口） ----------
@interface CTWinWindow : UIWindow
@end
@implementation CTWinWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == self) ? nil : v;
}
@end

// ---------- 空白处穿透：只把"胶囊上的点"算作命中，其余交给下层（不挡桌面/App 操作） ----------
@interface CTWinHostView : UIView
@end
@implementation CTWinHostView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == self) ? nil : v;
}
@end

@interface CTWinHostVC : UIViewController
@end
@implementation CTWinHostVC
- (void)loadView {
    CTWinHostView *v = [[CTWinHostView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    v.backgroundColor = [UIColor clearColor];
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.view = v;
}
@end

// ---------- 场景 / 宿主窗口选择 ----------
static UIWindowScene *CTWinPickScene(void) {
    UIWindowScene *best = nil, *active = nil;
    CGFloat bestLv = -2.0;
    for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
        if (![sc isKindOfClass:[UIWindowScene class]]) continue;
        UIWindowScene *ws = (UIWindowScene *)sc;
        CGFloat lv = -1.0;
        NSArray<UIWindow *> *wins = [ws windows];
        for (UIWindow *ww in wins) if (ww.windowLevel > lv) lv = ww.windowLevel;
        if (wins.count == 0) lv = -1.5;                       // 空场景降级
        if (sc.activationState == UISceneActivationStateForegroundActive && !active) active = ws;
        if (lv > bestLv) { bestLv = lv; best = ws; }
    }
    return best ?: active;   // 优先"有窗口（越高层越像在显示）"的场景
}

static UIWindow *CTWinPickTopWindow(void) {
    CGRect sb = [UIScreen mainScreen].bounds;
    CGFloat needW = sb.size.width * 0.9, needH = sb.size.height * 0.9;
    UIWindow *bestFull = nil, *bestAny = nil;
    CGFloat lvFull = -1.0, lvAny = -1.0;
    for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
        if (![sc isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *ww in [(UIWindowScene *)sc windows]) {
            if (ww == gWin || ww.hidden || ww.alpha < 0.05) continue;
            CGRect b = ww.bounds;
            BOOL full = (b.size.width >= needW && b.size.height >= needH);
            if (full) { if (ww.windowLevel >= lvFull) { lvFull = ww.windowLevel; bestFull = ww; } }
            else      { if (ww.windowLevel >= lvAny)  { lvAny  = ww.windowLevel; bestAny  = ww; } }
        }
    }
    return bestFull ?: bestAny;   // 优先挑"满屏"的系统窗口
}

// ---------- 排版：胶囊定位（容器坐标系；超界自动夹回） ----------
static void CTWinPlace(CGFloat cx, CGFloat cy) {
    if (!gWinCapsule) return;
    BOOL hostMode = (gHostIsSystem || gWin == nil);
    CGRect bb = hostMode ? (gHost ? gHost.bounds : [UIScreen mainScreen].bounds) : [UIScreen mainScreen].bounds;
    if (bb.size.width < 1.0 || bb.size.height < 1.0) bb = [UIScreen mainScreen].bounds;
    CGFloat hw = gWinW * 0.5, hh = gWinH * 0.5;
    if (cx < hw) cx = hw;
    if (cx > bb.size.width - hw) cx = bb.size.width - hw;
    if (cy < hh) cy = hh;
    if (cy > bb.size.height - hh) cy = bb.size.height - hh;
    gWinCX = cx; gWinCY = cy;
    if (hostMode) {
        gWinCapsule.center = CGPointMake(cx, cy);
    } else {
        gWin.frame = CGRectMake(cx - hw, cy - hh, gWinW, gWinH);   // ★ 微窗只覆盖胶囊本身
        gWinCapsule.frame = CGRectMake(0, 0, gWinW, gWinH);
    }
}

// ---------- 渲染（智能自适应：宽度随内容伸缩 + 过长缩字号 + 状态色点） ----------
static void CTWinRender(NSString *raw) {
    if (!gWinLabel || !gWinCapsule) return;
    double freq = 0.0; BOOL haveFreq = NO, deep = NO, boost = NO, video = NO;
    int chg = 0, pw = 0, cap = 0; NSString *cr = nil;
    NSString *mode = nil;
    for (NSString *p in [raw componentsSeparatedByString:S(" ")]) {
        NSArray *kv = [p componentsSeparatedByString:S("=")];
        if (kv.count != 2) continue;
        NSString *k = kv[0], *v = kv[1];
        if ([k isEqualToString:S("freq")]) { freq = v.doubleValue; haveFreq = (freq > 0); }
        else if ([k isEqualToString:S("mode")]) { mode = v; }
        else if ([k isEqualToString:S("deep")]) { deep = v.boolValue; }
        else if ([k isEqualToString:S("boost")]) { boost = v.boolValue; }
        else if ([k isEqualToString:S("video")]) { video = v.boolValue; }
        else if ([k isEqualToString:S("chg")]) { chg = (int)v.integerValue; }
        else if ([k isEqualToString:S("pw")])  { pw = (int)v.integerValue; }
        else if ([k isEqualToString:S("cap")]) { cap = (int)v.integerValue; }
        else if ([k isEqualToString:S("cr")])  { cr = v; }
    }
    // ★ 0928-2：「显示内容」选择——按段拼装，分隔符只在相邻显示段之间出现
    NSMutableArray *ctmSegs = [NSMutableArray array];
    if (gWinShowFreq) { [ctmSegs addObject:(haveFreq ? [NSString stringWithFormat:S("%.0fM"), freq] : S("—M"))]; }
    if (gWinShowMode && mode.length) [ctmSegs addObject:mode];
    if (gWinShowFlags) {
        NSMutableString *ctmFlags = [[NSMutableString alloc] init];
        if (deep)  [ctmFlags appendString:S("深")];
        if (boost) [ctmFlags appendString:S("提")];
        if (video) [ctmFlags appendString:S("视")];
        if (ctmFlags.length) [ctmSegs addObject:ctmFlags];
    }
    // ★ 1.4.6 充电段：⚡ + 瓦数（chg：1绿/2黄/3红/4黑/5橙=恢复中）
    if (gWinShowCharge && chg >= 1) {
        if (chg == 5) [ctmSegs addObject:S("恢复中")];   // ★ 1.4.6x：已请求充上、等硬件放行
        else if (pw > 0) [ctmSegs addObject:[NSString stringWithFormat:S("\u26a1\ufe0e%dW"), pw]];
        else [ctmSegs addObject:S("\u26a1\ufe0e")];
    }
    NSString *text = [ctmSegs componentsJoinedByString:S(" · ")];
    BOOL winShowDot = gWinShowDot || (ctmSegs.count == 0);   // 全不选兜底：至少保留状态点

    CGRect sb = [UIScreen mainScreen].bounds;
    CGFloat maxW = sb.size.width * 0.72;
    CGFloat baseFs = gWinBaseFont;                                   // ★ T7z18：字号来自设置
    if (baseFs < 6.0) baseFs = 6.0;                                  // ★ T7z18c：下限放到 6
    if (baseFs > 20.0) baseFs = 20.0;
    CGFloat k = baseFs / 12.0;                                       // ★ T7z18：整窗随字号等比缩放
    if (k < 0.62) k = 0.62;                                          // ★ T7z18c：极小字号也等比缩
    if (k > 1.70) k = 1.70;
    CGFloat padX = 10.0 * k, dotW = 7.0 * k, gap = 6.0 * k, padY = 6.0 * k;
    CGFloat minFs = baseFs - 4.0; if (minFs < 6.0) minFs = 6.0;      // 过长仍需完整显示 → 允许缩
    CGFloat fs = baseFs;
    UIFont *f = nil;
    NSMutableAttributedString *as = nil;
    CGSize ts = CGSizeZero;
    NSRange lr = [text rangeOfString:S("\u26a1\ufe0e")];
    NSRange rr = [text rangeOfString:S("恢复中")];   // ★ 1.4.6x：恢复中（橙色）
    while (1) {
        f = [UIFont monospacedDigitSystemFontOfSize:fs weight:UIFontWeightSemibold];
        as = [[NSMutableAttributedString alloc] initWithString:text];
        [as addAttribute:NSFontAttributeName value:f range:NSMakeRange(0, as.length)];
        if (lr.location != NSNotFound) {   // ★ 1.4.6w：⚡ 略微加大（×1.35，随字号等比）
            UIFont *ctBoltFont = [UIFont monospacedDigitSystemFontOfSize:(fs * 1.35) weight:UIFontWeightSemibold];
            [as addAttribute:NSFontAttributeName value:ctBoltFont range:lr];
            // ★ 1.4.6y：⚡ 下移一点（随字号等比），与文字垂直居中对齐
            [as addAttribute:NSBaselineOffsetAttributeName value:@(-(fs * 0.1)) range:lr];
        }
        ts = [as boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
        CGFloat ctmNeedW = (padX * 2.0) + (winShowDot ? (dotW + ((text.length > 0) ? (gap + ts.width) : 0.0)) : ts.width);
        if (ctmNeedW <= maxW || fs <= minFs) break;
        fs -= 0.5;
    }
    CGFloat capW = ceil((padX * 2.0) + (winShowDot ? (dotW + ((text.length > 0) ? (gap + ts.width) : 0.0)) : ts.width));
    CGFloat capH = ceil(MAX(baseFs * 1.85, ts.height + padY * 2.0));   // ★ T7z18：高度也随字号走
    gWinW = capW; gWinH = capH;

    gWinLabel.font = f;
    gWinLabel.textColor = gWinLightMode ? [UIColor colorWithWhite:0.05 alpha:1.0]      // ★ T7z21：浅色→黑字
                                        : [UIColor colorWithWhite:1.0 alpha:1.0];
    {   // ★ 1.4.6：⚡ 单独上色（其余文字原色；四态自适应浅深模式；⚡ 字体已在上面加大）
        [as addAttribute:NSForegroundColorAttributeName value:gWinLabel.textColor range:NSMakeRange(0, as.length)];
        if (lr.location != NSNotFound) {
            UIColor *cc = nil;
            switch (chg) {
                case 1: cc = [UIColor systemGreenColor]; break;
                case 2: cc = [UIColor systemYellowColor]; break;
                case 3: cc = [UIColor systemRedColor]; break;
                default: cc = gWinLightMode ? [UIColor colorWithWhite:0.05 alpha:1.0]
                                            : [UIColor colorWithWhite:0.62 alpha:1.0]; break;
            }
            [as addAttribute:NSForegroundColorAttributeName value:cc range:lr];
        }
        else if (rr.location != NSNotFound) {
            // ★ 1.4.6x：恢复中单独上色（橙）；其余文字保持原色
            [as addAttribute:NSForegroundColorAttributeName value:[UIColor systemOrangeColor] range:rr];
        }
        gWinLabel.attributedText = as;
    }
    gWinCapsule.bounds = CGRectMake(0, 0, capW, capH);
    gWinCapsule.layer.cornerRadius = capH * 0.5;
    if (gWinBlur) {
        gWinBlur.hidden = gWinHideBg;                                                    // ★ T7z20：背景可隐藏
        if (!gWinHideBg) {                                                               // ★ T7z21：毛玻璃也分深浅色
            gWinBlur.effect = [UIBlurEffect effectWithStyle:(gWinLightMode ? UIBlurEffectStyleSystemUltraThinMaterialLight
                                                                           : UIBlurEffectStyleSystemUltraThinMaterialDark)];
        }
    }
    gWinCapsule.layer.borderWidth = gWinHideBg ? 0.0 : 0.5;
    gWinCapsule.layer.borderColor = (gWinLightMode ? [UIColor colorWithWhite:0.0 alpha:0.10]
                                                   : [UIColor colorWithWhite:1.0 alpha:0.14]).CGColor;
    gWinLabel.shadowColor = nil;                                                        // ★ T7z20b：不要投影/描边
    gWinLabel.shadowOffset = CGSizeMake(0.0, 0.0);
    gWinDot.layer.shadowOpacity = 0.0;
    gWinDot.hidden = !winShowDot;
    gWinDot.frame = CGRectMake(padX, (capH - dotW) * 0.5, dotW, dotW);
    gWinDot.layer.cornerRadius = dotW * 0.5;
    gWinLabel.frame = CGRectMake(padX + (winShowDot ? (dotW + gap) : 0.0), 0, ts.width + 4.0, capH);

    UIColor *dotColor = gWinLightMode ? [UIColor colorWithWhite:0.10 alpha:0.95]         // ★ T7z21：浅色→深色点
                                      : [UIColor colorWithWhite:0.92 alpha:0.9];
    if (boost) dotColor = [UIColor systemOrangeColor];
    else if (deep) dotColor = [UIColor systemGreenColor];
    else if (video) dotColor = [UIColor systemPurpleColor];
    gWinDot.backgroundColor = dotColor;

    if (gWinPlaced) CTWinPlace(gWinCX, gWinCY);
}

// ---------- 退化：寄生到系统现成窗口（自建窗口不进场景时的兜底） ----------
static void CTWinSwitchToSystemHost(const char *why) {
    UIWindow *host = CTWinPickTopWindow();
    if (!host) {
        gWinRetryCount++;
        if (gWinRetryCount <= 5) {
            CTWinLog("寄生失败：暂无可用系统窗口（%d/5，1 秒后重试）", gWinRetryCount);
            gWinCheckAt = CFAbsoluteTimeGetCurrent() - 2.0;   // 约 1 秒后再试
            gWinCheckPhase = 0;
        } else {
            CTWinLog("寄生放弃：连续 5 次未找到系统窗口");
        }
        return;
    }
    if (gWinPan) {
        UIView *old = gWinPan.view;
        if (old && old != gWinCapsule) [old removeGestureRecognizer:gWinPan];
    }
    [gWinCapsule removeFromSuperview];
    gHost = host;
    gHostIsSystem = YES;
    [host addSubview:gWinCapsule];
    [host bringSubviewToFront:gWinCapsule];
    if (gWinPan && !gWinPan.view) [gWinCapsule addGestureRecognizer:gWinPan];
    if (gWinLockPress && !gWinLockPress.view) [gWinCapsule addGestureRecognizer:gWinLockPress];
    if (gWin) gWin.hidden = YES;
    CTWinPlace(gWinCX, gWinCY);
    CTWinLog("已寄生到系统窗口（%s）cls=%s 层级=%.0f 容器=%.0fx%.0f",
             why ? why : "-", class_getName([host class]), host.windowLevel,
             host.bounds.size.width, host.bounds.size.height);
}

// ---------- 建胶囊（可独立重试；失败不影响其它功能） ----------
static BOOL CTWinBuildCapsule(void) {
    if (gWinCapsule) return YES;
    @try {
        @autoreleasepool {
            UIView *cap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, gWinW, gWinH)];
            cap.layer.cornerRadius = gWinH * 0.5;
            cap.layer.cornerCurve = kCACornerCurveContinuous;
            cap.layer.masksToBounds = YES;
            cap.layer.borderWidth = 0.5;
            cap.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.14].CGColor;
            UIVisualEffectView *blur = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark]];
            blur.frame = cap.bounds;
            blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [cap addSubview:blur];
            gWinBlur = blur;                     // ★ T7z20：留引用，便于整体隐藏
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(10, (gWinH - 7.0) * 0.5, 7.0, 7.0)];
            dot.layer.cornerRadius = 3.5;
            dot.backgroundColor = [UIColor colorWithWhite:0.92 alpha:0.9];
            [cap addSubview:dot];
            UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(23, 0, gWinW - 27, gWinH)];
            lab.font = [UIFont monospacedDigitSystemFontOfSize:13.0 weight:UIFontWeightSemibold];
            lab.textColor = [UIColor colorWithWhite:1.0 alpha:0.96];
            [cap addSubview:lab];
            gWinCapsule = cap; gWinDot = dot; gWinLabel = lab;
            gWinDrag = [[CTWinDrag alloc] init];
            gWinPan = [[UIPanGestureRecognizer alloc] initWithTarget:gWinDrag action:@selector(pan:)];
            gWinLockPress = [[UILongPressGestureRecognizer alloc] initWithTarget:gWinDrag action:@selector(lockPress:)];
            gWinLockPress.minimumPressDuration = 0.6;      // ★ T7z18：长按 0.6 秒 = 锁定/解锁
            [cap addGestureRecognizer:gWinPan];            // 手势挂在胶囊上：只有按到胶囊才响应
            [cap addGestureRecognizer:gWinLockPress];
            return YES;
        }
    } @catch (__unused NSException *e) {
        gWinCapsule = nil; gWinDot = nil; gWinLabel = nil; gWinPan = nil;
        return NO;
    }
}

// ---------- 建窗（延迟到启动 6 秒后 + 全程保护，失败自动重试；★ 关键：挂入场景） ----------
static void CTWinCreateIfReady(void) {
    if (gWin || gHostIsSystem) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - gWinBornAt < 6.0) return;
    if (now - gWinLastAttempt < 5.0) return;
    gWinLastAttempt = now;
    if (!CTWinBuildCapsule()) { CTWinLog("胶囊构建异常（5 秒后重试）"); return; }
    @try {
        @autoreleasepool {
            CGRect sb = [UIScreen mainScreen].bounds;
            CGFloat px, py;
            if (!CTWinLoadPos(&px, &py)) { px = sb.size.width - 76.0; py = 96.0; }
            gWinCX = px; gWinCY = py;
            CTWinHostVC *vc = [[CTWinHostVC alloc] init];                    // 空白处穿透
            UIWindow *w = [[CTWinWindow alloc] initWithFrame:CGRectMake(px - gWinW * 0.5, py - gWinH * 0.5, gWinW, gWinH)];   // ★ 微窗
            w.rootViewController = vc;
            w.windowLevel = 10000000.0;              // 高于一切系统窗口
            w.backgroundColor = [UIColor clearColor];
            w.opaque = NO;
            w.hidden = YES;
            w.windowScene = CTWinPickScene();        // ★ 关键修复：iOS 13+ 必须挂场景才会渲染
            [vc.view addSubview:gWinCapsule];
            gWin = w; gHost = vc.view;
            gWinPlaced = YES;
            CTWinPlace(px, py);
            int scN = 0, winN = 0; CGFloat topLv = -1.0;
            for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
                scN++;
                if (![sc isKindOfClass:[UIWindowScene class]]) continue;
                for (UIWindow *ww in [(UIWindowScene *)sc windows]) {
                    winN++;
                    if (ww.windowLevel > topLv) topLv = ww.windowLevel;
                }
            }
            CTWinLog("浮窗已创建（%.0f, %.0f）场景=%s 场景数=%d 系统窗数=%d 最高层=%.0f 字号=%.1f 锁定=%d",
                     px, py, w.windowScene ? "已挂" : "空", scN, winN, topLv, gWinBaseFont, gWinLocked ? 1 : 0);
            gWinCheckAt = now;
            gWinCheckPhase = 0;
        }
    } @catch (__unused NSException *e) {
        gWin = nil; gHost = nil;
        CTWinLog("建窗异常（5 秒后自动重试）");
    }
}

// ---------- 自检 / 复核 / 心跳 ----------
static void CTWinVerify(void) {
    if (!gWin || gHostIsSystem) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (gWinCheckAt <= 0.0) { gWinCheckAt = now; return; }
    double dt = now - gWinCheckAt;
    BOOL inScene = (gWin.windowScene != nil) && [[gWin.windowScene windows] containsObject:gWin];
    if (gWinCheckPhase == 0 && dt >= 3.0) {
        gWinCheckPhase = 1;
        CTWinLog("自检: hidden=%d 场景=%s 在场景窗列=%d 层级=%.0f",
                 gWin.hidden ? 1 : 0, gWin.windowScene ? "有" : "无", inScene ? 1 : 0, gWin.windowLevel);
        if (!inScene) CTWinSwitchToSystemHost("自建窗口未进入场景");
    } else if (gWinCheckPhase == 1 && dt >= 15.0) {
        gWinCheckPhase = 2;
        CTWinLog("复核: hidden=%d 场景=%s 在场景窗列=%d 容器=%s",
                 gWin.hidden ? 1 : 0, gWin.windowScene ? "有" : "无", inScene ? 1 : 0,
                 gHostIsSystem ? "系统窗" : "自建窗");
    }
}

static void CTWinHeartbeat(void) {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (gWinHeartbeatAt <= 0.0) { gWinHeartbeatAt = now; return; }
    if (now - gWinHeartbeatAt < 30.0) return;
    gWinHeartbeatAt = now;
    BOOL inScene = (gWin && gWin.windowScene != nil) && [[gWin.windowScene windows] containsObject:gWin];
    CTWinLog("存活 hidden=%d 容器=%s 场景内=%d 位置=%.0f,%.0f",
             (gWinCapsule && gWinCapsule.hidden) ? 1 : 0,
             gHostIsSystem ? "系统窗" : "自建窗", inScene ? 1 : 0, gWinCX, gWinCY);
}

// ---------- 每秒 tick（由 FaceDownLock 的轮询器调用） ----------
void CPUthermalStatusWindowTick(void) {
    @try {
        if (!gWinEnabled || gWinBlanked) {
            if (gWinCapsule && !gWinCapsule.hidden) gWinCapsule.hidden = YES;
            if (gWin && !gWin.hidden) gWin.hidden = YES;
            return;
        }
        if (!gWin && !gHostIsSystem) { CTWinCreateIfReady(); if (!gWin) return; }
        if (gWinNeedFontReload) { gWinNeedFontReload = NO; gWinLastRaw = nil; }   // ★ T7z18：字号变更 → 重排
        {   // ★ T7z21：系统深浅色变化 → 强制重绘（浅色→黑字）
            BOOL lightNow = NO;
            @try {
                UIUserInterfaceStyle st = UIUserInterfaceStyleUnspecified;
                if (gWin) st = gWin.traitCollection.userInterfaceStyle;
                if (st == UIUserInterfaceStyleUnspecified) st = [UIScreen mainScreen].traitCollection.userInterfaceStyle;
                lightNow = (st == UIUserInterfaceStyleLight);
            } @catch (__unused NSException *e) {}
            if (lightNow != gWinLightMode) { gWinLightMode = lightNow; gWinLastRaw = nil; }
        }
        NSString *raw = [NSString stringWithContentsOfFile:S("/var/mobile/Library/Logs/CPUthermalStatus.txt") encoding:NSUTF8StringEncoding error:NULL];
        raw = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (raw.length == 0) {
            // ★ 1.0.5：读到空/读失败 → 保持上一帧显示（不再闪占位符 —M）
            raw = gWinLastRaw ?: S("freq=0");   // 首次启动还没生成文件时才用占位符
        }
        if (gWinLastRaw == nil || ![raw isEqualToString:gWinLastRaw]) {
            gWinLastRaw = [raw copy];
            CTWinRender(raw);
        }
        if (gWinCapsule.hidden) gWinCapsule.hidden = NO;
        if (gWin && !gHostIsSystem && gWin.hidden) gWin.hidden = NO;
        CTWinVerify();
        CTWinHeartbeat();
    } @catch (__unused NSException *e) {
        CTWinLog("刷新异常（跳过本跳）");
    }
}

// ---------- 启动（构造期零 UIKit：只读开关 + 注册通知） ----------
%ctor {
    @autoreleasepool {
        gWinBornAt = CFAbsoluteTimeGetCurrent();
        @try {
            NSDictionary *d = CPUthermalReadPrefs();
            gWinEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];
            id fsObj = d[S("floatWindowFontSize")];                   // ★ T7z18：字号
            if (fsObj) {
                CGFloat fs = [fsObj doubleValue];
                if (fs >= 6.0 && fs <= 20.0) gWinBaseFont = fs;           // ★ T7z18c：6~20
            }
            gWinHideBg = [d[S("floatWindowHideBg")] ?: @NO boolValue];
            gWinShowCharge = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];
            gWinShowDot   = [d[S("floatShowDot")]   ?: @YES boolValue];
            gWinShowFreq  = [d[S("floatShowFreq")]  ?: @YES boolValue];
            gWinShowMode  = [d[S("floatShowMode")]  ?: @YES boolValue];
            gWinShowFlags = [d[S("floatShowFlags")] ?: @YES boolValue];
            @try {                                                         // ★ T7z21：初始深浅色
                UIUserInterfaceStyle st = [UIScreen mainScreen].traitCollection.userInterfaceStyle;
                gWinLightMode = (st == UIUserInterfaceStyleLight);
            } @catch (__unused NSException *e) {}
        } @catch (__unused NSException *e) {}
        notify_register_dispatch(kCPUthermalSettingsChangedNotifC, &gWinSettingsToken,
                                 dispatch_get_main_queue(), ^(int token) {
            (void)token;
            @try {
                NSDictionary *d = CPUthermalReadPrefs();
                gWinEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];
                id fsObj = d[S("floatWindowFontSize")];               // ★ T7z18：字号
                if (fsObj) {
                    CGFloat fs = [fsObj doubleValue];
                    if (fs >= 6.0 && fs <= 20.0) { gWinBaseFont = fs; }   // ★ T7z18c：6~20
                }
                gWinHideBg = [d[S("floatWindowHideBg")] ?: @NO boolValue];
            gWinShowCharge = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];
            gWinShowDot   = [d[S("floatShowDot")]   ?: @YES boolValue];
            gWinShowFreq  = [d[S("floatShowFreq")]  ?: @YES boolValue];
            gWinShowMode  = [d[S("floatShowMode")]  ?: @YES boolValue];
            gWinShowFlags = [d[S("floatShowFlags")] ?: @YES boolValue];
                gWinNeedFontReload = YES;                              // 强制重排（实时生效）
                CTWinLog("开关更新 = %s 字号=%.1f 背景=%s", gWinEnabled ? "开" : "关", gWinBaseFont, gWinHideBg ? "隐藏" : "显示");
            } @catch (__unused NSException *e) {}
        });
        int checkToken = 0;
        if (notify_register_check("com.apple.springboard.hasBlankedScreen", &checkToken) == NOTIFY_STATUS_OK) {
            uint64_t st = 0;
            notify_get_state(checkToken, &st);
            gWinBlanked = (st != 0);
            notify_cancel(checkToken);
        }
        notify_register_dispatch("com.apple.springboard.hasBlankedScreen", &gWinBlankToken,
                                 dispatch_get_main_queue(), ^(int token) {
            uint64_t st = 0;
            notify_get_state(token, &st);
            gWinBlanked = (st != 0);
        });
        CTWinLog("浮窗组件已加载（开关=%s 字号=%.1f 版本=v10/1.4.6）", gWinEnabled ? "开" : "关", gWinBaseFont);
        if (CT_SOURCE_FP[0]) CTWinLog("构建指纹 = %s", CT_SOURCE_FP);
    }
}
