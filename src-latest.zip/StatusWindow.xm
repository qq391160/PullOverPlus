#define CT_NO_IOKIT 1   // ★ 1.4.11：ObjC++ 组件不引入 IOKit（与前台组件同款，避免 module-import-in-extern-C 编译失败）
// ============================================================
// ★ T7z21：浅色模式适配（浅色→文字/状态点自动变黑，毛玻璃换浅色材质）
// ★ T7z20b：新增「隐藏悬浮窗背景」开关（只留纯白文字+状态点；无描边、无投影）
// ★ T7z18：浮窗 v2 增补 —— ①字号可自定义（设置→状态显示→浮窗字号，9~20，实时生效）
//   ②长按锁定位置（再长按解锁；锁定后拖动停用，状态随位置记忆一起保存）
//   ③空白处点击穿透（窗口永不挡桌面/App 操作；拖动只在胶囊上生效）
// ★ T7z17：状态浮窗 v2 —— 修复"浮窗已创建但屏幕上不显示"
//   根因（判断）：iOS 13 起 SpringBoard 是"场景化"应用，未挂 windowScene 的
//     自建 UIWindow 不会进入任何场景 → 不参与渲染（旧版只设了 hidden=NO）。
//   v2 三管齐下（一次构建尽量到位）：
//     ① 建窗时挂入前台场景（找不到就挂第一个场景）
//     ② 3 秒自检：窗口不在场景窗列 → 立即退化为"寄生"到系统现成顶层窗口
//     ③ 存活心跳日志（每 30 秒一行）：hidden/容器/场景内/位置，下次排查一眼定案
//   其余不变：开关实时生效、胶囊+毛玻璃+色点、宽度自适应+缩字号、拖动+位置记忆、锁屏隐藏
//   规矩：禁止 @"..." 常量（roothide 重映射会崩），全部用 S()
// ============================================================

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <AudioToolbox/AudioToolbox.h>
#import <notify.h>
#import <CTHermesPaths.h>
#import <CTFingerprint.h>
#import <CTHardening.h>
#import <CTNotifyState.h>   // ★ 0930-0207：通知数据通道
#include <stdio.h>
#include <time.h>
#include <sys/time.h>   // ★ 2.0.79：毫秒时间戳（gettimeofday）
#include <sys/stat.h>
#include <dlfcn.h>          // ★ 2.0.68：实时帧率符号动态解析（dlsym——零链接依赖，绝不拖累组件加载）
#include <unistd.h>         // ★ 2.0.72：空帧重试用 usleep
#include <string.h>

extern void CTHermesStatusWindowTick(void);

// ---------- 日志 ----------
static void CTWinLog(const char *fmt, ...) {
    mkdir(CTDiagLogDirC(), 0755);
    FILE *fp = fopen(CTDiagLogPathC(), "a");
    if (!fp) {   // ★ 0930-0207：主日志写不进 → 兜底日志（前台组件会搬回主日志）
        for (NSString *d in CTStateWriteDirs()) {
            NSString *lp = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
            mkdir([d UTF8String], 0755);
            fp = fopen([lp UTF8String], "a");
            if (fp) break;
        }
    }
    if (!fp) return;
    struct timeval ctv; gettimeofday(&ctv, NULL);   // ★ 2.0.79：毫秒留痕（对延迟用）
    time_t tt = ctv.tv_sec; struct tm tmv; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s.%03d][浮窗] ", ts, (int)(ctv.tv_usec / 1000));
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}

// ---------- 状态 ----------
static UIWindow *gWin = nil;                 // 自建窗口（寄生模式下弃用但保留对象）
static UIView   *gHost = nil;                // 当前承载胶囊的容器（自建窗口根视图 / 系统窗口）
static UIView   *gWinCapsule = nil;
static UIView   *gWinDot = nil;
static BOOL      gWinEmpty = NO;             // ★ 2.0.41：全关态（无点无内容）→ 整窗不显示
static UILabel  *gWinLabel = nil;
static id        gWinDrag = nil;
static UIPanGestureRecognizer *gWinPan = nil;
static BOOL      gWinEnabled = NO;
static BOOL      gWinUninstalled = NO;   // ★ 1.4.94：卸载后禁止浮窗回弹（内存态，不落盘）
static BOOL      gWinBlanked = NO;
static BOOL      gHostIsSystem = NO;         // YES = 已寄生到系统窗口
static int       gWinSettingsToken = 0;
static int       gWinBlankToken = 0;
static BOOL      gWinDeviceLocked = NO;      // ★ 2.0.92：锁屏中（亮屏锁屏也算；≠上方位置锁 gWinLocked）
static int       gWinDeviceLockToken = 0;
static BOOL      gWinHideOnLock = NO;        // ★ 2.0.92：设置「锁屏时隐藏」
static CFAbsoluteTime gWinBornAt = 0;
static CFAbsoluteTime gWinLastAttempt = 0;
static CFAbsoluteTime gWinCheckAt = 0;
static CFAbsoluteTime gWinHeartbeatAt = 0;
static int       gWinCheckPhase = 0;         // 0=等 3 秒自检 1=等 15 秒复核 2=完成
static int       gWinRetryCount = 0;         // 寄生重试计数
static BOOL      gWinPlaced = NO;
static CGFloat   gWinBaseFont = 12.0;        // ★ T7z18：基础字号（设置可调 9~20）
static BOOL      gWinShowCharge = YES;       // ★ 1.4.6：浮窗显示充电段
static BOOL      gWinShowDot = YES;          // ★ 0928-2：「显示内容」状态点
static BOOL      gWinShowFreq = YES;         // ★ 0928-2：「显示内容」频率
static BOOL      gWinShowMode = YES;         // ★ 0928-2：「显示内容」模式
static BOOL      gWinShowFlags = YES;        // ★ 0928-2：「显示内容」标记（深/提/视）
static BOOL      gWinShowCurrent = YES;      // ★ 0929：「显示内容」电流
static BOOL      gWinShowNet = YES;          // ★ 0929：「显示内容」网速
static BOOL      gWinShowTemp = YES;         // ★ 0929：「显示内容」温度
static BOOL      gWinShowBattery = YES;      // ★ 1.4.115：「显示内容」电量（剩余百分比）
static int       gWinBatteryPct = -1;        // ★ 1.4.115：当前电量（-1=未知）
static int       gWinNetBps = 0;             // ★ 0929：网速（读守护工具写的文件）
static int       gWinLastNet = -1;
static BOOL      gWinLocked = NO;            // ★ T7z18：位置锁定（长按切换）
static BOOL      gWinNeedFontReload = NO;    // ★ T7z18：设置变更后强制重排
static UILongPressGestureRecognizer *gWinLockPress = nil;
static UIVisualEffectView *gWinBlur = nil;   // ★ T7z20：背景（毛玻璃）可隐藏
static BOOL      gWinHideBg = NO;            // ★ T7z20：设置里「隐藏悬浮窗背景」
static BOOL      gWinInvert = NO;           // ★ 2.0.69：颜色自适应 = 实时反色效果
static BOOL      gWinFollowTime = NO;        // ★ 2.0.69：跟随状态栏时间颜色
static BOOL      gWinShowFPS = NO;        // ★ 2.0.68：「实时帧率」开关
static double    gWinFPSShown = -1.0;        // 上次渲染的 FPS（数字变才重绘）
static CFIndex   sCTFPSPrev = 0;             // 上一拍脏帧计数
static BOOL      sCTFPSReset = YES;          // 基线未建立
static double    sCTFPSValue = 0.0;          // 最近一次测得 FPS
static double    sCTFPSRing[3] = {0,0,0};    // ★ 2.0.69：近 3 秒样本（显示取峰值，滑动时更快冲到满帧）
static int       sCTFPSRingN = 0;            // 样本计数
static int       sCTFPSStatN = 0;            // ★ 2.0.69：30 秒统计窗口
static double    sCTFPSStatPeak = 0.0, sCTFPSStatSum = 0.0;
static BOOL      gWinLightMode = NO;         // ★ T7z21：浅色模式适配（浅色→黑字）
static NSString *gWinLastRaw = nil;
static CGFloat   gWinW = 132.0;
static CGFloat   gWinH = 27.0;
static CGFloat   gWinCX = 0.0;
static CGFloat   gWinCY = 0.0;
static CGFloat   gWinRotAngle = 0.0;   // ★ 1.4.106：当前旋转角（0=竖屏；±90°=横屏）
// ★ 1.4.111：竖屏/横屏"各自独立"位置记忆——竖屏=你放的位置（永远回到它）；横屏=从竖屏位自动推导贴边（可手挪，挪了以你为准）
static CGFloat   gWinPX = -1.0;      // 竖屏位置（主文件加载）
static CGFloat   gWinPY = -1.0;
static CGFloat   gWinLX = -1.0;      // 横屏位置（用户手挪过才有）
static CGFloat   gWinLY = -1.0;
static BOOL      gWinLUserSet = NO;  // 横屏位是否"用户手设过"（否则每次按竖屏位自动推导）
static BOOL      gWinLSeedDone = NO; // 本次横屏是否已完成"自动贴边"
static CFAbsoluteTime gWinLSeedAt = 0.0;
static CFAbsoluteTime gWinResyncAt = 0.0;   // 切 App 后延迟归位（跨 App 收敛）
static BOOL      gWinOrientFast = NO;   // ★ 1.4.112：系统方向事件（免"两拍"直通）
static CFAbsoluteTime gWinFastUntil = 0.0;   // ★ 2.0.5：切 App 后的"快切窗口"截止时间（此窗口内方向变化免去抖，要"马上切过去"）

static void CTWinPlace(CGFloat cx, CGFloat cy);
static void CTWinSwitchToSystemHost(const char *why);
static void CTWinSavePositions(void);
static void CTWinReloadPositions(void);
static void CTWinResyncPosition(void);
static BOOL CTWinPlaceVisual(CGFloat vx, CGFloat vy);
static void CTWinSeedLandscape(void);
static void CTWinSaveLand(void);
static void CTWinLoadLand(void);
static BOOL CTWinRestoreUserLandPos(const char *why);   // ★ 2.0.38：读回"你设过的横屏位"（含可见性校验，防飞出）
static BOOL CTWinVisualCenter(CGPoint *out);
static CGSize CTWinVisSize(void);

// ---------- 位置记忆 ----------
static NSString *CTWinPosPath(void) { return S(CTDiagFileC("CTHermesFloat.pos")); }

// ---------- ★ 2.0.48：位置环线（通知通道）——客户机 16 上"窗口写不出文件"的兜底 ----------
static BOOL gWinUserMovedBus = NO;   // 竖屏：本会话用户动过 → 以用户为准
static BOOL gWinUserMovedLand = NO;  // ★ 2.0.49 横屏：本会话用户动过
static BOOL gWinBusApplied = NO;     // 竖屏已应用回传
static BOOL gWinBusAppliedL = NO;    // ★ 2.0.49 横屏已应用回传
static int  gWinBusReqLeft = 3;      // "请核心回传"剩余次数（错峰 3 次）

static void CTWinPosBusReq(void) {
    if (gWinBusReqLeft <= 0) return;
    if ((gWinUserMovedBus || gWinBusApplied) && (gWinUserMovedLand || gWinBusAppliedL)) return;   // 两个方向都定了 → 不再要
    gWinBusReqLeft--;
    CTPosBusSend(CT_POSBUS_CH_REQ, 1ULL);
}
static void CTWinPosBusApplyFromNotify(uint64_t st) {
    if (!st || gWinUserMovedBus || gWinBusApplied) return;
    double x = 0, y = 0; int lk = 0;
    CTPosBusUnpack(st, &x, &y, &lk);
    if (x < 1.0 || y < 1.0) return;
    gWinBusApplied = YES;
    gWinLocked = (lk != 0);   // ★ 2.0.49：锁定标志与位置同源回放（与文件路径行为对齐）
    if (gWinCapsule && gWinPX > 1.0 && gWinPY > 1.0 && fabs(gWinPX - x) < 0.6 && fabs(gWinPY - y) < 0.6) return;   // 已在该位 → 静默
    gWinPX = x; gWinPY = y;
    if (gWinCapsule) CTWinPlace(x, y);
    CTWinLog("位置环线：通知回传落位 (%.0f,%.0f)", x, y);
    CTPosBusSend(CT_POSBUS_CH_ACT, (CT_POSBUS_ACT_LOADBUS << 56) | (CTPosBusPack(x, y, lk) & 0x00FFFFFFFFFFFFFFULL));
}
static void CTWinPosBusApplyLandFromNotify(uint64_t st) {
    if (!st || gWinUserMovedLand || gWinBusAppliedL) return;
    double x = 0, y = 0; int us = 0;
    CTPosBusUnpack(st, &x, &y, &us);
    if (x < 1.0 || y < 1.0) return;
    gWinBusAppliedL = YES;
    gWinLX = x; gWinLY = y; gWinLUserSet = (us != 0);
    BOOL inLand = (gWinRotAngle > 0.01 || gWinRotAngle < -0.01);
    if (inLand && gWinCapsule) CTWinPlace(x, y);
    CTWinLog("位置环线：横屏位回传%s (%.0f,%.0f)", inLand ? "并落位" : "已收（转屏生效）", x, y);
    CTPosBusSend(CT_POSBUS_CH_ACT, (CT_POSBUS_ACT_LOADBUS_L << 56) | (CTPosBusPack(x, y, us) & 0x00FFFFFFFFFFFFFFULL));
}
static void CTWinPosBusInit(void) {
    static BOOL sBusDone = NO;
    if (sBusDone) return;
    sBusDone = YES;
    @try {
        static int sBusBcTok = -1;
        notify_register_dispatch(CT_POSBUS_CH_BCAST, &sBusBcTok, dispatch_get_main_queue(), ^(int t) {
            uint64_t st = 0;
            if (notify_get_state(t, &st) != NOTIFY_STATUS_OK || st == 0) return;
            CTWinPosBusApplyFromNotify(st);
        });
        static int sBusBcTokL = -1;
        notify_register_dispatch(CT_POSBUS_CH_BCAST_L, &sBusBcTokL, dispatch_get_main_queue(), ^(int t) {
            uint64_t st = 0;
            if (notify_get_state(t, &st) != NOTIFY_STATUS_OK || st == 0) return;
            CTWinPosBusApplyLandFromNotify(st);
        });
        CTWinPosBusReq();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTWinPosBusReq(); });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(9.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTWinPosBusReq(); });
    } @catch (__unused NSException *e) {}
}

static BOOL CTWinLoadPos(CGFloat *x, CGFloat *y) {
    gWinLocked = NO;
    NSString *s = CTFloatReadNewest(S("CTHermesFloat.pos"), NULL);   // ★ 2.0.46：多路读（全候选取最新）
    if (s.length == 0) {   // ★ 2.0.48：文件读不到 → 位置环线兜底（核心回传的最后已知位置）
        uint64_t bst = CTPosBusGet(CT_POSBUS_CH_BCAST);
        if (bst) {
            double bx = 0, by = 0; int bl = 0;
            CTPosBusUnpack(bst, &bx, &by, &bl);
            if (bx > 1.0 && by > 1.0) { *x = bx; *y = by; gWinLocked = (bl != 0); return YES; }
        }
        return NO;
    }
    NSArray *arr = [s componentsSeparatedByString:S(",")];
    if (arr.count < 2) return NO;
    *x = [arr[0] doubleValue]; *y = [arr[1] doubleValue];
    if (arr.count >= 3) gWinLocked = [arr[2] boolValue];    // ★ T7z18：锁定状态随位置一起记
    return (*x > 1.0 && *y > 1.0);
}

static void CTWinSavePos(CGFloat x, CGFloat y) {
    NSString *s = [NSString stringWithFormat:S("%.1f,%.1f,%d"), x, y, gWinLocked ? 1 : 0];
    BOOL ok = CTFloatWriteAll(S("CTHermesFloat.pos"), s);
    if (!ok) CTWinLog("位置写入失败（竖屏：全部路径不可写）");   // ★ 2.0.46：多路写（双目录+原子/非原子）
    // ★ 2.0.48：文件成败都喊一声（客户机 16 上窗口写不出文件 → 由 root 核心代写；写得出则双保险）
    uint64_t pk = CTPosBusPack(x, y, gWinLocked ? 1 : 0);
    CTPosBusSend(CT_POSBUS_CH_SAVE, pk);
    CTPosBusSend(CT_POSBUS_CH_ACT, ((ok ? CT_POSBUS_ACT_SAVED : CT_POSBUS_ACT_SAVEFAIL) << 56) | (pk & 0x00FFFFFFFFFFFFFFULL));
}

// ---------- 触感反馈（★ T7z19：改成"短震"—— 用轻触反馈，不再用系统长震动） ----------
//   双保险：系统轻触音(1520=pop / 1519=peek，都是短震) + 触感引擎轻击
static void CTWinHaptic(BOOL strong) {
    @try { AudioServicesPlaySystemSound(strong ? 1520 : 1519); } @catch (__unused NSException *e) {}
    @try {
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:(strong ? UIImpactFeedbackStyleMedium : UIImpactFeedbackStyleLight)];
        [gen prepare];
        [gen impactOccurred];
    } @catch (__unused NSException *e) {}
}

// ---------- 拖动 / 长按（手势挂在"胶囊"上：只有按到胶囊才响应） ----------
@interface CTWinDrag : NSObject
@end
@implementation CTWinDrag
- (void)pan:(UIPanGestureRecognizer *)g {
    if (gWinLocked) return;                 // ★ T7z18：已锁定 → 拖动停用
    if (!gWinCapsule) return;
    UIView *sv = gWinCapsule.superview;
    if (!sv) return;
    CGPoint t = [g translationInView:sv];
    [g setTranslation:CGPointZero inView:sv];
    BOOL hostMode = (gHostIsSystem || gWin == nil);
    CGPoint c = hostMode ? CGPointMake(gWinCapsule.center.x + t.x, gWinCapsule.center.y + t.y)
                         : CGPointMake(gWin.center.x + t.x, gWin.center.y + t.y);
    CTWinPlace(c.x, c.y);
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        if (fabs(gWinRotAngle) > 0.01) gWinUserMovedLand = YES; else gWinUserMovedBus = YES;   // ★ 2.0.48/49：用户已手拖（按方向记）→ 忽略回传落位
        CTWinSavePositions();   // ★ 1.4.111：按方向分别记忆（横屏=横屏位；竖屏=竖屏位）
    }
}
// ★ T7z18：长按 → 锁定 / 解锁位置（锁定后拖动失效；状态随位置记忆）
- (void)lockPress:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    gWinLocked = !gWinLocked;
    CTWinSavePositions();   // ★ 1.4.111
    CTWinHaptic(gWinLocked);                // ★ T7z18b：锁定=短震(稍强)，解锁=短震(轻)
    CTWinLog(gWinLocked ? "长按：位置已锁定（拖动停用，已震动）" : "长按：位置已解锁（可拖动，已震动）");
    gWinLastRaw = nil;                      // 强制下一跳重绘（显示/去掉锁标记）
}
@end

// ---------- 自建微窗：窗口自身不做命中目标（双保险，配合"只占胶囊大小"的窗口） ----------
@interface CTWinWindow : UIWindow
@end
@implementation CTWinWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    if (v == self) {
        // ★ 1.4.111：胶囊外圈"隐形抓取余量"命中（小字号也好抓；锁定时不抓，避免白挡）
        if (gWinCapsule && !gWinCapsule.hidden && !gWinLocked && gWinCapsule.window == self) {
            CGRect slop = CGRectInset([gWinCapsule convertRect:gWinCapsule.bounds toView:self], -10.0, -12.0);
            if (CGRectContainsPoint(slop, point)) return gWinCapsule;
        }
        return nil;
    }
    return v;
}
@end

// ---------- 空白处穿透：只把"胶囊上的点"算作命中，其余交给下层（不挡桌面/App 操作） ----------
@interface CTWinHostView : UIView
@end
@implementation CTWinHostView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    if (v == self) {
        // ★ 1.4.111：胶囊外圈"隐形抓取余量"命中（小字号也好抓；锁定时不抓，避免白挡）
        if (gWinCapsule && !gWinCapsule.hidden && !gWinLocked && gWinCapsule.superview == self) {
            CGRect slop = CGRectInset([gWinCapsule convertRect:gWinCapsule.bounds toView:self], -10.0, -12.0);
            if (CGRectContainsPoint(slop, point)) return gWinCapsule;
        }
        return nil;
    }
    return v;
}
@end

@interface CTWinHostVC : UIViewController
@end
@implementation CTWinHostVC
// ★ 1.4.10 修复：浮窗宿主控制器必须声明"支持全部方向"。
//   否则系统会按本窗口(VS 用户设的方向)去限制整个场景 → 别的插件/横屏 App 的浮层会被强行竖屏渲染 ✗
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }
- (BOOL)shouldAutorotate { return YES; }
- (BOOL)prefersStatusBarHidden { return NO; }
- (void)loadView {
    CTWinHostView *v = [[CTWinHostView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    v.backgroundColor = [UIColor clearColor];
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.view = v;
}
@end

// ---------- 场景 / 宿主窗口选择 ----------
static UIWindowScene *CTWinPickScene(void) {
    UIWindowScene *best = nil, *active = nil;
    CGFloat bestLv = -2.0;
    for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
        if (![sc isKindOfClass:[UIWindowScene class]]) continue;
        UIWindowScene *ws = (UIWindowScene *)sc;
        CGFloat lv = -1.0;
        NSArray<UIWindow *> *wins = [ws windows];
        for (UIWindow *ww in wins) if (ww.windowLevel > lv) lv = ww.windowLevel;
        if (wins.count == 0) lv = -1.5;                       // 空场景降级
        if (sc.activationState == UISceneActivationStateForegroundActive && !active) active = ws;
        if (lv > bestLv) { bestLv = lv; best = ws; }
    }
    return best ?: active;   // 优先"有窗口（越高层越像在显示）"的场景
}

static UIWindow *CTWinPickTopWindow(void) {
    CGRect sb = [UIScreen mainScreen].bounds;
    CGFloat needW = sb.size.width * 0.9, needH = sb.size.height * 0.9;
    UIWindow *bestFull = nil, *bestAny = nil;
    CGFloat lvFull = -1.0, lvAny = -1.0;
    for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
        if (![sc isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *ww in [(UIWindowScene *)sc windows]) {
            if (ww == gWin || ww.hidden || ww.alpha < 0.05) continue;
            CGRect b = ww.bounds;
            BOOL full = (b.size.width >= needW && b.size.height >= needH);
            if (full) { if (ww.windowLevel >= lvFull) { lvFull = ww.windowLevel; bestFull = ww; } }
            else      { if (ww.windowLevel >= lvAny)  { lvAny  = ww.windowLevel; bestAny  = ww; } }
        }
    }
    return bestFull ?: bestAny;   // 优先挑"满屏"的系统窗口
}

// ---------- ★ 1.4.106：方向跟随（跟"屏幕方向"走；横屏原地转 ±90°；与锁屏方向无关） ----------
#import <math.h>
#import <objc/message.h>
#import <objc/runtime.h>
static long long gWinLastOrientV = 0;   // ★ 1.4.109：最近选中的方向值（诊断用）
static CGFloat CTWinAngleForOrient(UIInterfaceOrientation o) {
    if (o == UIInterfaceOrientationLandscapeLeft)  return -M_PI_2;   // ★ 1.4.109：对调（108 实测该向转出 180° 翻转）
    if (o == UIInterfaceOrientationLandscapeRight) return  M_PI_2;
    return 0.0;
}
static long long CTWinFBSOrient(void) {
    // ★ 1.4.108：系统级方向源（FrontBoard，跨进程有效；游戏强横屏也会变）
    static id sObs = nil; static BOOL sTried = NO;
    @try {
        if (!sTried) {
            sTried = YES;
            Class c = objc_getClass("FBSOrientationObserver");
            if (c) sObs = [[c alloc] init];
            if (sObs && [sObs respondsToSelector:NSSelectorFromString(@"setHandler:")]) {
                void (^h)(long long) = ^(long long o) { (void)o; };
                ((void (*)(id, SEL, void (^)(long long)))objc_msgSend)(sObs, NSSelectorFromString(@"setHandler:"), h);
            }
        }
        if (sObs && [sObs respondsToSelector:NSSelectorFromString(@"activeInterfaceOrientation")]) {
            return ((long long (*)(id, SEL))objc_msgSend)(sObs, NSSelectorFromString(@"activeInterfaceOrientation"));
        }
    } @catch (__unused NSException *e) {}
    return -1;
}
static UIInterfaceOrientation CTWinReadOrient(void) {
    // ★ 1.4.108：五路取源 + 探针（每次值变化都记一行，远程诊断用）
    long long fbs = CTWinFBSOrient();
    NSInteger fma = -1;
    @try {
        UIApplication *app0 = [UIApplication sharedApplication];
        if ([app0 respondsToSelector:NSSelectorFromString(@"_frontMostAppOrientation")]) {
            fma = (NSInteger)((long long (*)(id, SEL))objc_msgSend)(app0, NSSelectorFromString(@"_frontMostAppOrientation"));
        }
    } @catch (__unused NSException *e) {}
    NSInteger sb = -1, sc = -1, dv = -1;
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        if ([app respondsToSelector:@selector(statusBarOrientation)]) sb = (NSInteger)[app statusBarOrientation];
    } @catch (__unused NSException *e) {}
    @try {
        UIWindowScene *ws = nil;
        if (gWin) ws = gWin.windowScene;
        if (!ws) { UIWindow *hw = gHost.window; if (hw) ws = hw.windowScene; }
        if (ws) sc = (NSInteger)ws.interfaceOrientation;
    } @catch (__unused NSException *e) {}
    UIDeviceOrientation d = [UIDevice currentDevice].orientation;
    if (d == UIDeviceOrientationLandscapeLeft)  dv = (NSInteger)UIInterfaceOrientationLandscapeLeft;
    else if (d == UIDeviceOrientationLandscapeRight) dv = (NSInteger)UIInterfaceOrientationLandscapeRight;
    else if (d == UIDeviceOrientationPortrait) dv = (NSInteger)UIInterfaceOrientationPortrait;
    static long long sL[5] = {-9, -9, -9, -9, -9};
    long long vals[5] = { fbs, (long long)fma, (long long)sb, (long long)sc, (long long)dv };
    BOOL changed = NO;
    for (int i = 0; i < 5; i++) { if (vals[i] != sL[i]) { changed = YES; sL[i] = vals[i]; } }
    if (changed) CTWinLog("方向探针：fbs=%d fma=%d sb=%d sc=%d dev=%d", (int)fbs, (int)fma, (int)sb, (int)sc, (int)dv);
    // ★ 1.4.113 修订：按"权威度"优先（fbs > fma > sb > sc > dev）——
    //   防切换瞬间"杂音源"把方向带偏（曾表现为切 App 时"横竖横竖来回跳"）
    for (int i = 0; i < 5; i++) {
        long long v = vals[i];
        if (v == 1 || v == 2 || v == 3 || v == 4) { gWinLastOrientV = v; return (UIInterfaceOrientation)v; }
    }
    gWinLastOrientV = -1;
    return UIInterfaceOrientationPortrait;
}
// ---------- ★ 1.4.111：竖屏/横屏"各自独立"位置 + 横屏自动贴边 ----------
static CGSize CTWinVisSize(void) {
    @try {
        CGRect b = [UIScreen mainScreen].coordinateSpace.bounds;
        if (b.size.width > 1.0 && b.size.height > 1.0) return b.size;
    } @catch (__unused NSException *e) {}
    CGSize s2 = [UIScreen mainScreen].bounds.size;
    if (s2.width < 1.0 || s2.height < 1.0) s2 = CGSizeMake(375.0, 812.0);
    return s2;
}
static BOOL CTWinVisualCenter(CGPoint *out) {
    @try {
        if (!gWinCapsule) return NO;
        CGRect r = [gWinCapsule convertRect:gWinCapsule.bounds toCoordinateSpace:[UIScreen mainScreen].coordinateSpace];
        if (r.size.width < 1.0 || r.size.height < 1.0) return NO;
        if (r.origin.x != r.origin.x || r.origin.y != r.origin.y) return NO;   // NaN 保护
        *out = CGPointMake(CGRectGetMidX(r), CGRectGetMidY(r));
        return YES;
    } @catch (__unused NSException *e) { return NO; }
}
static NSString *CTWinLandPath(void) { return S(CTDiagFileC("CTHermesFloat.land")); }
static void CTWinSaveLand(void) {
    NSString *s2 = [NSString stringWithFormat:S("%.1f,%.1f,%d"), gWinLX, gWinLY, gWinLUserSet ? 1 : 0];
    BOOL ok = CTFloatWriteAll(S("CTHermesFloat.land"), s2);
    if (!ok) CTWinLog("位置写入失败（横屏：全部路径不可写）");   // ★ 2.0.46：多路写（双目录+原子/非原子）
    // ★ 2.0.49：横屏位也喊一声（客户机 16 上窗口写不出文件 → 由 root 核心代写）
    if (gWinLX > 1.0 && gWinLY > 1.0) {
        uint64_t pk = CTPosBusPack(gWinLX, gWinLY, gWinLUserSet ? 1 : 0);
        CTPosBusSend(CT_POSBUS_CH_SAVE_L, pk);
        CTPosBusSend(CT_POSBUS_CH_ACT, ((ok ? CT_POSBUS_ACT_SAVED_L : CT_POSBUS_ACT_SAVEFAIL_L) << 56) | (pk & 0x00FFFFFFFFFFFFFFULL));
    }
}
static void CTWinLoadLand(void) {
    // ★ 2.0.38：读失败不再清零（与竖屏 CTWinLoadPos 对称）——只有读到有效内容才更新；读不到沿用内存里的
    //   "上次已知好值"，防"文件暂不可用/被清"时把用户横屏位抹掉（"锁不住"的另一半根因）。
    NSString *s2 = CTFloatReadNewest(S("CTHermesFloat.land"), NULL);   // ★ 2.0.46：多路读（全候选取最新）
    if (s2.length == 0) {   // ★ 2.0.49：文件读不到 → 横屏位环线兜底（核心回传的最后已知横屏位）
        uint64_t bst = CTPosBusGet(CT_POSBUS_CH_BCAST_L);
        if (bst) {
            double bx = 0, by = 0; int bu = 0;
            CTPosBusUnpack(bst, &bx, &by, &bu);
            if (bx > 1.0 && by > 1.0) { gWinLX = bx; gWinLY = by; gWinLUserSet = (bu != 0); }
        }
        return;
    }
    NSArray *arr = [s2 componentsSeparatedByString:S(",")];
    if (arr.count < 3) return;
    CGFloat lx = [arr[0] doubleValue], ly = [arr[1] doubleValue];
    if (lx > 1.0 && ly > 1.0) { gWinLX = lx; gWinLY = ly; gWinLUserSet = [arr[2] boolValue]; }
}
// ★ 1.4.111：把两个位置文件重新读一遍（跨 App / 跨层收敛到最新）
static void CTWinReloadPositions(void) {
    CGFloat px2 = 0.0, py2 = 0.0;
    if (CTWinLoadPos(&px2, &py2) && px2 > 0.5 && py2 > 0.5) { gWinPX = px2; gWinPY = py2; }
    CTWinLoadLand();
}
// ★ 1.4.111：切 App 后"自动归位"——当前方向的标准位（竖屏=P_p；横屏=手设位或自动贴边）
static void CTWinResyncPosition(void) {
    if (!gWinCapsule || gWinUninstalled) return;
    CTWinReloadPositions();
    if (fabs(gWinRotAngle) > 0.01) {
        if (CTWinRestoreUserLandPos("切App归位")) {
            /* ★ 2.0.38：已回到你设过的横屏位（含可见性校验） */
        } else if (gWinLUserSet && gWinLX > 0.5) {
            /* ★ 2.0.38：读回校验未过 → 已退回原位（保护现状，不贴边） */
        } else {
            CGSize sc = CTWinVisSize();
            if (sc.width > sc.height && !gWinLSeedDone) { gWinLSeedDone = YES; CTWinSeedLandscape(); }   // ★ 2.0.5：每次进横屏只补一次，防重复测量
        }
    } else {
        if (gWinPX > 0.5 && gWinPY > 0.5) {
            CTWinPlace(gWinPX, gWinPY);
            CTWinLog("切App归位：竖屏 ← 你上次的竖屏位(%.0f,%.0f)", gWinCX, gWinCY);
        }
    }
}
// ★ 1.4.111：按当前方向分别记忆——横屏存"横屏位"（挪过就以你为准）；竖屏存"竖屏位"（永不被横屏影响）
static void CTWinSavePositions(void) {
    if (fabs(gWinRotAngle) > 0.01) {
        gWinLX = gWinCX; gWinLY = gWinCY; gWinLUserSet = YES;
    } else {
        gWinPX = gWinCX; gWinPY = gWinCY;
        CTWinSavePos(gWinCX, gWinCY);
    }
    CTWinSaveLand();
    CTWinLog("位置已保存 (%.0f, %.0f)%s", gWinCX, gWinCY, (fabs(gWinRotAngle) > 0.01) ? "（横屏位）" : "（竖屏位）");
}
// 把"视觉目标点"换算成放置坐标并落位（黑箱校准：两轴微探量 J，解 J·p = d；复测超差再修一次）
static BOOL CTWinPlaceVisual(CGFloat vx, CGFloat vy) {
    CGPoint vA;
    if (!CTWinVisualCenter(&vA)) return NO;
    CGFloat bx = gWinCX, by = gWinCY;
    CGFloat jx1 = 0, jy1 = 0, jx2 = 0, jy2 = 0;
    BOOL okX = NO, okY = NO;
    const CGFloat dxy[4][2] = { {30, 0}, {-30, 0}, {0, 30}, {0, -30} };
    for (int i = 0; i < 4 && !(okX && okY); i++) {
        BOOL isX = (dxy[i][0] != 0);
        if (isX && okX) continue;
        if (!isX && okY) continue;
        CTWinPlace(bx + dxy[i][0], by + dxy[i][1]);
        CGPoint vB;
        if (!CTWinVisualCenter(&vB)) continue;
        CGFloat ex = vB.x - vA.x, ey = vB.y - vA.y;
        if (fabs(ex) < 2.0 && fabs(ey) < 2.0) continue;   // 没动=被夹回 → 换方向再试
        if (isX) { jx1 = ex / 30.0; jy1 = ey / 30.0; okX = YES; }
        else     { jx2 = ex / 30.0; jy2 = ey / 30.0; okY = YES; }
    }
    if (!(okX && okY)) { CTWinPlace(bx, by); return NO; }
    CGFloat det = jx1 * jy2 - jy1 * jx2;
    if (fabs(det) < 0.05) { CTWinPlace(bx, by); return NO; }
    CGFloat ddx = vx - vA.x, ddy = vy - vA.y;
    CGFloat ppx = ( jy2 * ddx - jy1 * ddy) / det;
    CGFloat ppy = (-jx2 * ddx + jx1 * ddy) / det;
    CTWinPlace(bx + ppx, by + ppy);
    CGPoint vC;
    if (CTWinVisualCenter(&vC)) {
        CGFloat ex = vx - vC.x, ey = vy - vC.y;
        if (sqrt(ex * ex + ey * ey) > 25.0) {
            CGFloat qx = ( jy2 * ex - jy1 * ey) / det;
            CGFloat qy = (-jx2 * ex + jx1 * ey) / det;
            CTWinPlace(gWinCX + qx, gWinCY + qy);
        }
    }
    return YES;
}
// 进横屏：从"竖屏位"推导等价的"贴边"目标（贴边→边距再收紧一点；中间→按比例），并落位
static void CTWinSeedLandscape(void) {
    if (!gWinCapsule || gWinPX < 1.0 || gWinPY < 1.0) return;
    CGSize cur = CTWinVisSize();
    CGFloat Wl = MAX(cur.width, cur.height), Hl = MIN(cur.width, cur.height);
    if (Wl < 1.0 || Hl < 1.0) return;
    CGFloat Wp = Hl, Hp = Wl;                        // 竖屏参考尺寸 = 横屏空间的小/大边互换
    CGFloat pw = gWinW, ph = gWinH;
    // ★ 2.0.5：源位置先夹进"竖屏参考尺寸"的可放范围——防历史遗留的半离屏坐标把推导算歪（旧版重置写进的 (宽-40,90) 就会）
    CGFloat srcPX = gWinPX, srcPY = gWinPY;
    if (srcPX < pw * 0.5 + 2.0) srcPX = pw * 0.5 + 2.0;
    if (srcPX > Wp - pw * 0.5 - 2.0) srcPX = (Wp - pw * 0.5 - 2.0 > pw * 0.5 + 2.0) ? (Wp - pw * 0.5 - 2.0) : (Wp * 0.5);
    if (srcPY < ph * 0.5 + 2.0) srcPY = ph * 0.5 + 2.0;
    if (srcPY > Hp - ph * 0.5 - 2.0) srcPY = (Hp - ph * 0.5 - 2.0 > ph * 0.5 + 2.0) ? (Hp - ph * 0.5 - 2.0) : (Hp * 0.5);
    CGFloat mL = srcPX - pw * 0.5,  mR = Wp - (srcPX + pw * 0.5);
    CGFloat mT = srcPY - ph * 0.5,  mB = Hp - (srcPY + ph * 0.5);
    CGFloat edgeThr = 0.15 * MIN(Wp, Hp);
    BOOL rightSide = (mR <= mL);
    BOOL xDock = ((rightSide ? mR : mL) <= edgeThr);
    CGFloat mx = rightSide ? mR : mL;
    if (xDock && mx > 12.0) mx = 12.0;               // ★ 1.4.111：横向更"贴边一点点"
    CGFloat v1x = xDock ? (rightSide ? (Wl - mx - pw * 0.5) : (mx + pw * 0.5))
                        : (srcPX / Wp * Wl);
    BOOL bottomSide = (mB <= mT);
    BOOL yDock = ((bottomSide ? mB : mT) <= edgeThr);
    CGFloat my = bottomSide ? mB : mT;
    if (yDock && my > 24.0) my = 24.0;               // ★ 1.4.111：纵向稍收（不进游戏顶栏）
    CGFloat v1y = yDock ? (bottomSide ? (Hl - my - ph * 0.5) : (my + ph * 0.5))
                        : (srcPY / Hp * Hl);
    CGFloat keepX = gWinCX, keepY = gWinCY;          // ★ 1.4.113：先记住"落位前的位置"（此刻它是可见的）
    BOOL measured = CTWinPlaceVisual(v1x, v1y);
    // ★ 1.4.113：落位"可见性校验"——测量异常（乱值/不可用/出界）→ 退回原位，绝不"飞出屏幕"
    BOOL bad = NO;
    if (!measured) bad = YES;
    else {
        CGFloat cMax = MAX(Wl, Hl) + 250.0;   // ★ r3：解算结果"离谱"直接判失败（实测曾出现 1928,-1220 等乱值）
        if (gWinCX < -cMax || gWinCX > cMax || gWinCY < -cMax || gWinCY > cMax) bad = YES;
        else {
            CGPoint vNow;
            if (!CTWinVisualCenter(&vNow)) bad = YES;
            else {
                CGSize vs = CTWinVisSize();
                if (vNow.x < -40.0 || vNow.x > vs.width + 40.0 || vNow.y < -40.0 || vNow.y > vs.height + 40.0) bad = YES;
            }
        }
    }
    if (bad) {
        CTWinPlace(keepX, keepY);
        CTWinLog("方向跟随：贴边落位校验未过 → 退回原位(%.0f,%.0f)（防飞出屏幕）", gWinCX, gWinCY);
    } else {
        CTWinLog("方向跟随：横屏自动贴边（源=竖屏 %.0f,%.0f 边距 R%.0f T%.0f → 视觉 %.0f,%.0f 落位 %.0f,%.0f）",
                 gWinPX, gWinPY, mR, mT, v1x, v1y, gWinCX, gWinCY);
    }
    gWinLX = gWinCX; gWinLY = gWinCY;                // 记下最终结果（gWinLUserSet 仍为 NO：下次仍按最新竖屏位推导）
    CTWinSaveLand();
}
// ★ 2.0.38：读回"你设过的横屏位"——带可见性校验（防读出屏外坐标；不合格 → 退回原位并出声，绝不飞出屏幕）
static BOOL CTWinRestoreUserLandPos(const char *why) {
    if (!(gWinLUserSet && gWinLX > 0.5)) return NO;
    CGFloat keepX = gWinCX, keepY = gWinCY;
    CTWinPlace(gWinLX, gWinLY);
    BOOL bad = NO;
    @try {
        CGFloat cMax = 2600.0;
        if (gWinCX < -cMax || gWinCX > cMax || gWinCY < -cMax || gWinCY > cMax) bad = YES;
        else {
            CGPoint vNow;
            if (CTWinVisualCenter(&vNow)) {
                CGSize vs = CTWinVisSize();
                if (vNow.x < -40.0 || vNow.x > vs.width + 40.0 || vNow.y < -40.0 || vNow.y > vs.height + 40.0) bad = YES;
            }
        }
    } @catch (__unused NSException *e) {}
    if (bad) {
        CTWinPlace(keepX, keepY);
        CTWinLog("%s：横屏位校验未过 → 退回原位(%.0f,%.0f)（防飞出屏幕）", why ? why : "读回", gWinCX, gWinCY);
        return NO;
    }
    CTWinLog("%s：横屏 ← 你设过的横屏位(%.0f,%.0f)", why ? why : "读回", gWinCX, gWinCY);
    return YES;
}
static void CTWinSyncOrientation(void) {
    if (!gWinCapsule || gWinUninstalled) return;
    // ★ 1.4.111：横屏"自动贴边"补做（等空间切到横屏后再落位，保证测量在同一空间里）
    if (!gWinLUserSet && !gWinLSeedDone && (gWinRotAngle > 0.01 || gWinRotAngle < -0.01)) {
        CGSize sc0 = CTWinVisSize();
        if (sc0.width > sc0.height) {
            gWinLSeedDone = YES;
            CTWinSeedLandscape();
        } else if (gWinLSeedAt > 0.0 && CFAbsoluteTimeGetCurrent() - gWinLSeedAt > 6.0) {
            gWinLSeedDone = YES;   // 空间迟迟不切 → 用现有尺寸硬推一次（兜底）
            CTWinSeedLandscape();
        }
    }
    CFAbsoluteTime nowC = CFAbsoluteTimeGetCurrent();
    BOOL fastCome = gWinOrientFast; gWinOrientFast = NO;             // ★ 1.4.112：系统方向事件 → 免等待直通
    // ★ 2.0.5：切 App 后的 1.2 秒"快切窗口"——这段时间方向最可能变，免两拍去抖（要"马上切过去"）
    if (!fastCome && gWinFastUntil > 0.0 && nowC < gWinFastUntil) fastCome = YES;
    CGFloat a = CTWinAngleForOrient(CTWinReadOrient());
    static CGFloat sPendA = 0; static int sPendN = 0; static CFAbsoluteTime sPendT0 = 0;
    if (fabs(a - gWinRotAngle) < 0.01) {                             // 已是目标角
        sPendN = 0;
        // ★ 2.0.5：自愈——角度没变也查一次"旋转是否真的应用着"（防快切/重建窗口后偶发丢旋转 → 横屏里躺着）
        @try {
            if (gWinCapsule && gWinPlaced) {
                CGAffineTransform t = gWinCapsule.transform;
                BOOL want0 = (fabs(gWinRotAngle) < 0.01);
                BOOL is0  = (fabs(t.a - 1.0) < 0.02 && fabs(t.b) < 0.02 && fabs(t.c) < 0.02 && fabs(t.d - 1.0) < 0.02);
                BOOL is90 = (fabs(t.a) < 0.02 && fabs(t.d) < 0.02 && fabs(fabs(t.b) - 1.0) < 0.02 && fabs(fabs(t.c) - 1.0) < 0.02);
                if (!(want0 ? is0 : is90)) {
                    CTWinPlace(gWinCX, gWinCY);
                    CTWinLog("方向自愈：补应用旋转（%.0f°）", gWinRotAngle * 180.0 / M_PI);
                }
            }
        } @catch (__unused NSException *e) {}
        return;
    }
    if (fabs(a - sPendA) < 0.01) sPendN++; else { sPendA = a; sPendN = 1; sPendT0 = nowC; }
    // ★ 2.0.5：防冻修正——旧版"20 秒内超 6 次变化 → 暂停 8 秒"会让快切 App 时 8 秒不跟随（就是"点了重置后偶尔横着/竖着"的元凶之一）。
    //   现在改为"尾沿收敛"：噪声仍两拍去抖；但任何新方向最多等 0.66 秒必定执行——永远收敛到最新，绝不冻住。
    BOOL waited = (sPendT0 > 0.0 && (nowC - sPendT0) >= 0.66);
    if (sPendN < 2 && !fastCome && !waited) return;                  // ★ 1.4.107 防抖；★ 1.4.112/2.0.5 直通
    CGFloat old = gWinRotAngle;
    gWinRotAngle = a;
    sPendN = 0;
    CTWinPlace(gWinCX, gWinCY);
    CTWinLog("方向跟随：%.0f° → %.0f°（切方向） 值=%d 位=%.0f,%.0f 尺=%.0fx%.0f", old * 180.0 / M_PI, a * 180.0 / M_PI, (int)gWinLastOrientV, gWinCX, gWinCY, gWinW, gWinH);
    // ★ 1.4.111：分方向落位——进横屏：挪过→用你的横屏位；没挪过→自动贴边（从竖屏位推导）
    CTWinReloadPositions();   // ★ 收敛到最新（跨 App 切换后不拿旧值）
    if (fabs(a) > 0.01) {
        gWinLSeedDone = NO;
        gWinLSeedAt = nowC;
        if (CTWinRestoreUserLandPos("方向跟随")) {
            /* ★ 2.0.38：已回到你设过的横屏位（含可见性校验） */
        } else if (gWinLUserSet && gWinLX > 0.5) {
            /* ★ 2.0.38：读回校验未过 → 已退回原位（保护现状） */
        } else {
            CGSize sc = CTWinVisSize();
            if (sc.width > sc.height) { gWinLSeedDone = YES; CTWinSeedLandscape(); }
            else CTWinLog("方向跟随：进横屏，等空间翻转后自动贴边");
        }
    } else {
        // ★ 1.4.111：回竖屏 → 永远回到"你上一次的竖屏位置"
        gWinLSeedDone = NO;
        if (gWinPX > 0.5 && gWinPY > 0.5) {
            CTWinPlace(gWinPX, gWinPY);
            CTWinLog("方向跟随：竖屏 ← 你上次的竖屏位(%.0f,%.0f)", gWinCX, gWinCY);
        } else {
            CTWinLog("方向跟随：回竖屏（暂无竖屏记忆位）");
        }
    }
}

// ---------- 排版：胶囊定位（容器坐标系；超界自动夹回；★ 1.4.106 支持原地旋转） ----------
static void CTWinPlace(CGFloat cx, CGFloat cy) {
    if (!gWinCapsule) return;
    BOOL hostMode = (gHostIsSystem || gWin == nil);
    CGRect bb = hostMode ? (gHost ? gHost.bounds : [UIScreen mainScreen].bounds) : [UIScreen mainScreen].bounds;
    if (bb.size.width < 1.0 || bb.size.height < 1.0) bb = [UIScreen mainScreen].bounds;
    CGFloat hw = gWinW * 0.5, hh = gWinH * 0.5;
    BOOL rotL = (fabs(gWinRotAngle) > 0.01);
    if (rotL) { hw = gWinH * 0.5; hh = gWinW * 0.5; }   // ★ 1.4.106：横屏按旋转后包围盒夹回
    CGFloat dx = cx, dy = cy;   // ★ 1.4.109：夹回只影响"显示"，不改写用户位置（治"切方向丢位置"）
    // ★ 1.4.112：横屏时把"可到达范围"放宽到长边 —— 横屏里可能拿到"竖屏形"坐标空间，
    //           窄边夹回会像一堵墙（右边拉不过去）；放宽后横屏全屏可拉（尺寸全按运行时实际值，机型无关）
    CGFloat clw = bb.size.width, clh = bb.size.height;
    if (rotL) { CGFloat cMax = MAX(clw, clh); if (clw < clh) clw = cMax; else clh = cMax; }
    if (dx < hw) dx = hw;
    if (dx > clw - hw) dx = clw - hw;
    if (dy < hh) dy = hh;
    if (dy > clh - hh) dy = clh - hh;
    gWinCX = cx; gWinCY = cy;
    CGFloat ang = gWinRotAngle;
    if (hostMode) {
        gWinCapsule.center = CGPointMake(dx, dy);
        gWinCapsule.transform = (fabs(ang) < 0.01) ? CGAffineTransformIdentity : CGAffineTransformMakeRotation(ang);
    } else {
        BOOL land = (fabs(ang) > 0.01);
        CGFloat bw = land ? gWinH : gWinW;    // 旋转后的包围盒（原地转：中心不变）
        CGFloat bh = land ? gWinW : gWinH;
        // ★ 1.4.111：窗口比胶囊多留一圈"隐形抓取余量"（小字号也好抓；外观不变）
        gWin.frame = CGRectMake(dx - bw * 0.5 - 10.0, dy - bh * 0.5 - 12.0, bw + 20.0, bh + 24.0);
        gWinCapsule.transform = CGAffineTransformIdentity;
        gWinCapsule.bounds = CGRectMake(0, 0, gWinW, gWinH);
        gWinCapsule.center = CGPointMake(bw * 0.5 + 10.0, bh * 0.5 + 12.0);
        if (land) gWinCapsule.transform = CGAffineTransformMakeRotation(ang);
    }
}

// ★ 1.4.115：读取当前电量百分比（UIDevice 主路 + powersources 通知兜底；拿不到返回 -1）
static int CTWinBatteryPercent(void) {
    @try {
        UIDevice *dv = [UIDevice currentDevice];
        if (!dv.batteryMonitoringEnabled) dv.batteryMonitoringEnabled = YES;
        float bl = dv.batteryLevel;
        if (bl >= 0.0f) return (int)lroundf(bl * 100.0f);
    } @catch (__unused NSException *e) {}
    @try {
        int tok = 0;
        if (notify_register_check("com.apple.system.powersources.percent", &tok) == NOTIFY_STATUS_OK) {
            uint64_t st = 0;
            notify_get_state(tok, &st);
            notify_cancel(tok);
            if (st <= 100) return (int)st;
        }
    } @catch (__unused NSException *e) {}
    return -1;
}

// ---------- 渲染（智能自适应：宽度随内容伸缩 + 过长缩字号 + 状态色点） ----------

// ============================================================================
// ★ 2.0.68：「颜色自适应」——文字自动适配背后画面（反色高对比处理；自有实现）：
//   文字区域实时显示背后画面的 模糊→去色→高对比→反色 版本 → 任何深浅背景上都醒目，
//   专治"某些 App 里黑字 / 白字看不清"。关掉 = 原样（随系统深 / 浅色的黑 / 白文字，自定义色照旧）。
//   · 零新线程；构造 / 渲染失败自动退回原样式（绝不崩、绝不卡）。
// ============================================================================
@interface CTWinInvertBackdropView : UIView @end
@implementation CTWinInvertBackdropView
+ (Class)layerClass {
    Class c = NSClassFromString(S("CABackdropLayer"));
    return c ? c : [CALayer class];
}
@end

static id CTWinMkFilter(Class caf, NSString *name, NSDictionary *kv) {
    id f = nil;
    @try {
        if (!caf || ![caf respondsToSelector:NSSelectorFromString(S("filterWithName:"))]) return nil;
        f = [caf performSelector:NSSelectorFromString(S("filterWithName:")) withObject:name];
        if (!f) return nil;
        for (NSString *k in kv) {
            @try { [f performSelector:NSSelectorFromString(S("setValue:forKey:")) withObject:kv[k] withObject:k]; } @catch (__unused NSException *e) {}
        }
    } @catch (__unused NSException *e) { f = nil; }
    return f;
}

@interface CTWinInvertLabel : UILabel
@property (nonatomic, copy) NSAttributedString *ctMaskSource;   // 原始富文本（掩膜用；颜色无关）
- (void)ctSetInvertEnabled:(BOOL)enabled;
- (void)ctResyncInvert;
@end

@implementation CTWinInvertLabel {
    BOOL _ctInvert;
    CTWinInvertBackdropView *_ctBackdrop;
    CALayer *_ctMask;
    UIImage *_ctMaskImg;
    CGSize _ctMaskSize;
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _ctMaskSize = CGSizeZero; }
    return self;
}
- (void)ctSetInvertEnabled:(BOOL)enabled {
    if (_ctInvert == enabled) return;
    _ctInvert = enabled;
    [self ctApply];
}
- (void)ctApply {
    @try {
        if (_ctInvert) {
            if (!_ctBackdrop) {
                Class caf = NSClassFromString(S("CAFilter"));
                if (!caf) return;   // 环境无滤镜 → 保持原文字（安全退回）
                NSMutableArray *fs = [NSMutableArray array];
                id f1 = CTWinMkFilter(caf, S("gaussianBlur"),    @{S("inputRadius"):@(50.0), S("inputNormalizeEdges"):@YES});
                id f2 = CTWinMkFilter(caf, S("colorBrightness"), @{S("inputAmount"):@(-0.285)});
                id f3 = CTWinMkFilter(caf, S("colorContrast"),   @{S("inputAmount"):@(1000.0)});
                id f4 = CTWinMkFilter(caf, S("colorSaturate"),   @{S("inputAmount"):@(0.0)});
                id f5 = CTWinMkFilter(caf, S("colorInvert"),     @{});
                if (f1) [fs addObject:f1]; if (f2) [fs addObject:f2]; if (f3) [fs addObject:f3];
                if (f4) [fs addObject:f4]; if (f5) [fs addObject:f5];
                CTWinInvertBackdropView *bv = [[CTWinInvertBackdropView alloc] initWithFrame:self.bounds];
                bv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                bv.userInteractionEnabled = NO;
                if (fs.count) bv.layer.filters = fs;
                _ctMask = [CALayer layer];
                _ctMask.frame = self.bounds;
                _ctMask.contentsScale = [UIScreen mainScreen].scale;
                _ctMask.actions = @{S("bounds"):[NSNull null], S("contents"):[NSNull null], S("position"):[NSNull null]};
                bv.layer.mask = _ctMask;
                [self addSubview:bv];
                _ctBackdrop = bv;
            }
            _ctBackdrop.hidden = NO;
            if (self.attributedText.length) [self setAttributedText:(self.ctMaskSource ?: self.attributedText)];
        } else {
            if (_ctBackdrop) {
                NSAttributedString *orig = self.ctMaskSource;
                [_ctBackdrop removeFromSuperview];
                _ctBackdrop = nil; _ctMask = nil; _ctMaskImg = nil; _ctMaskSize = CGSizeZero;
                if (orig.length) [super setAttributedText:orig];   // 立即还原（下一秒渲染也会覆盖刷新）
            }
        }
    } @catch (__unused NSException *e) {}
}
- (void)ctSyncMask {
    if (!_ctMask) return;
    @try {
        CGSize sz = self.bounds.size;
        if (sz.width < 2.0 || sz.height < 2.0) return;
        NSAttributedString *src = self.ctMaskSource;
        if (!src.length) { _ctMask.contents = nil; return; }
        // 掩膜 = 文字画成"不透明像素"（与标签同款居中；⚡ 放大/位移一并保留）
        NSMutableAttributedString *m = [src mutableCopy];
        [m addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, m.length)];
        UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:sz];
        UIImage *img = [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
            // ★ 2.0.69：单行整宽测量 + 按实际文本宽度绘制 → 永不换行、绝无"尾部黑块"残影
            CGSize ts = [m boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX)
                                        options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
            [m drawWithRect:CGRectMake(0, (sz.height - ts.height) * 0.5, ts.width, ts.height)
                    options:NSStringDrawingUsesLineFragmentOrigin context:nil];
        }];
        _ctMaskImg = img;   // 保活（contents 是 CGImage）
        _ctMask.contents = (__bridge id)img.CGImage;
        _ctMask.frame = self.bounds;
        _ctMaskSize = sz;
    } @catch (__unused NSException *e) {}
}
- (void)setAttributedText:(NSAttributedString *)attributedText {
    self.ctMaskSource = attributedText;
    if (_ctInvert) {
        NSMutableAttributedString *clearStr = [attributedText mutableCopy];
        if (clearStr.length) [clearStr addAttribute:NSForegroundColorAttributeName value:[UIColor clearColor] range:NSMakeRange(0, clearStr.length)];
        [super setAttributedText:clearStr];
        if (_ctBackdrop) [self ctSyncMask];
    } else {
        [super setAttributedText:attributedText];
    }
}
- (void)layoutSublayersOfLayer:(CALayer *)layer {
    [super layoutSublayersOfLayer:layer];
    if (layer == self.layer && _ctMask && !CGSizeEqualToSize(_ctMaskSize, self.layer.bounds.size)) [self ctSyncMask];
}
- (void)ctResyncInvert {   // ★ 2.0.69：渲染完成（frame 定稿）后再对齐一次掩膜
    if (_ctInvert && _ctMask) [self ctSyncMask];
}
@end

// ★ 2.0.69：「颜色自适应」——读"状态栏时间"的实际颜色（与状态栏时间完全一致；找不到=退回深浅色逻辑）
static __weak UILabel *sTimeLabel = nil;   // ★ 2.0.73：文件级——切 App 可强制立即重找
static CFAbsoluteTime sFindAt = 0;
// ★ 2.0.79：跟色增强——刷新来源 / 切换窗 / 钩子“当场直通” / 最近显示色
static const char *sFollowSrc = "拍";
static const char *sRenderSrc = "拍";
static CFAbsoluteTime sSwitchAt = 0;
static CFAbsoluteTime sHookAt = 0;
static __weak UILabel *sHookLab = nil;
static UIColor *sHookCol = nil;
static int sHookChan = 0;   /* 0=textColor 1=富文本 */
static CGFloat sFollowR = -1.0, sFollowG = -1.0, sFollowB = -1.0;

static double CTWinEffAlpha(UIView *v) {   // ★ 2.0.79：等效可见度（沿父链连乘；遇 hidden 归零）
    CGFloat a = 1.0; int d = 0;
    @try {
        while (v && d++ < 24) {
            if (v.hidden) return 0.0;
            a *= v.alpha;
            if (a < 0.01) return 0.0;
            v = v.superview;
        }
    } @catch (__unused NSException *e) {}
    return (double)a;
}
static double CTWinCandScore(UILabel *l) {   // ★ 2.0.79：候选打分（切换瞬间"谁在台前"）
    double sc = 0.0;
    @try {
        NSString *cn = NSStringFromClass([l class]);
        if ([cn rangeOfString:S("StatusBar")].location != NSNotFound) sc += 4000.0;
        sc += CTWinEffAlpha(l) * 2500.0;
        UIWindow *w = l.window;
        if (w) {
            if (w.isKeyWindow) sc += 1200.0;
            @try {
                if (w.windowScene) {
                    long st2 = (long)w.windowScene.activationState;
                    if (st2 == 0) sc += 1500.0;
                    else if (st2 == 1) sc += 600.0;
                    else sc -= 500.0;
                }
            } @catch (__unused NSException *e) {}
            double lv = w.windowLevel; if (lv > 1e8) lv = 1e8; if (lv < 0) lv = 0;
            sc += lv / 100000.0;
        }
    } @catch (__unused NSException *e) {}
    return sc;
}
static UIColor *CTWinReadLabColor(UILabel *l) {   // ★ 2.0.79：取色（最近通道优先；跨通道兜底）
    UIColor *c = nil;
    if (!l) return nil;
    if (sHookChan == 1) {
        @try { NSAttributedString *at = l.attributedText; if (at.length > 0) c = [at attribute:NSForegroundColorAttributeName atIndex:0 effectiveRange:NULL]; } @catch (__unused NSException *e) { c = nil; }
    }
    if (!c) { @try { c = l.textColor; } @catch (__unused NSException *e) { c = nil; } }
    if (!c) { @try { NSAttributedString *at = l.attributedText; if (at.length > 0) c = [at attribute:NSForegroundColorAttributeName atIndex:0 effectiveRange:NULL]; } @catch (__unused NSException *e) { c = nil; } }
    return c;
}

// ★ 2.0.92：锁屏色源——锁屏时改读「大时钟」的颜色（CSProminent 族，多通道兜底 + 探针留痕；2 秒缓存）
static UIColor *CTWinLockClockColor(NSString **channelOut) {
    static CFAbsoluteTime sLockPickAt = 0;
    static UIColor *sLockCached = nil;
    static NSString *sLockCachedChan = nil;
    CFAbsoluteTime nowL = CFAbsoluteTimeGetCurrent();
    if (sLockCached && (nowL - sLockPickAt) < 2.0) { if (channelOut) *channelOut = sLockCachedChan; return sLockCached; }
    sLockPickAt = nowL; sLockCached = nil; sLockCachedChan = nil;
    UIColor *found = nil; NSString *chan = @"-"; UIView *clock = nil;
    NSMutableArray *nameSample = [NSMutableArray array];
    @try {
        NSMutableArray *stack = [NSMutableArray array];
        @try {
            for (UIWindow *w in [UIApplication sharedApplication].windows) { if (w) [stack addObject:w]; }
            for (UIScene *sc2 in [UIApplication sharedApplication].connectedScenes) {
                if ([sc2 isKindOfClass:[UIWindowScene class]]) {
                    for (UIWindow *w2 in [(UIWindowScene *)sc2 windows]) { if (w2) [stack addObject:w2]; }
                }
            }
        } @catch (__unused NSException *e) {}
        int guard = 0;
        while (stack.count > 0 && guard++ < 12000) {
            UIView *v = [stack lastObject]; [stack removeLastObject];
            NSString *cn = NSStringFromClass([v class]);
            if (cn.length && [cn containsString:S("Prominent")]) {
                if (nameSample.count < 4 && ![nameSample containsObject:cn]) [nameSample addObject:cn];
                if (!clock && [cn containsString:S("Time")]) clock = v;
                if (!clock) clock = v;
            }
            for (UIView *sub in v.subviews) { if (sub) [stack addObject:sub]; }
        }
        if (clock) {
            @try { id tc = [clock valueForKey:@"textColor"]; if ([tc isKindOfClass:[UIColor class]]) { found = tc; chan = @"clock.KVC"; } } @catch (__unused NSException *e) {}
            if (!found && [clock isKindOfClass:[UILabel class]]) { @try { if (((UILabel *)clock).textColor) { found = ((UILabel *)clock).textColor; chan = @"clock.UILabel"; } } @catch (__unused NSException *e) {} }
            if (!found) {
                NSMutableArray *st2 = [NSMutableArray arrayWithArray:clock.subviews];
                int g2 = 0;
                while (st2.count > 0 && g2++ < 5000) {
                    UIView *v2 = [st2 lastObject]; [st2 removeLastObject];
                    if ([v2 isKindOfClass:[UILabel class]]) { @try { UIColor *c2 = ((UILabel *)v2).textColor; if (c2) { found = c2; chan = @"sub.UILabel"; break; } } @catch (__unused NSException *e) {} }
                    @try { id tc2 = [v2 valueForKey:@"textColor"]; if ([tc2 isKindOfClass:[UIColor class]]) { found = tc2; chan = @"sub.KVC"; break; } } @catch (__unused NSException *e) {}
                    for (UIView *s2 in v2.subviews) { if (s2) [st2 addObject:s2]; }
                }
            }
            if (!found) { @try { if (clock.tintColor) { found = clock.tintColor; chan = @"tint"; } } @catch (__unused NSException *e) {} }
        }
        static CFAbsoluteTime sLockLogAt = 0;
        if (nowL - sLockLogAt > 20.0) {
            sLockLogAt = nowL;
            CTWinLog("[浮窗] 锁屏色源=%s（通道=%s 类=%s 样例=%s）",
                     found ? "已取到 ✓" : "未找到", chan.UTF8String,
                     clock ? NSStringFromClass([clock class]).UTF8String : "-",
                     nameSample.count ? [nameSample componentsJoinedByString:@","].UTF8String : "-");
        }
    } @catch (__unused NSException *e) {}
    sLockCached = found; sLockCachedChan = chan;
    if (channelOut) *channelOut = chan;
    return found;
}

static UIColor *CTWinStatusBarTimeColor(void) {
    if (gWinDeviceLocked) {   // ★ 2.0.92：锁屏 → 改读"大时钟"色源（读不到则继续走原兜底链）
        UIColor *lc = CTWinLockClockColor(NULL);
        if (lc) return lc;
    }
    CFAbsoluteTime nowT = CFAbsoluteTimeGetCurrent();
    if (sHookCol && sHookLab && (nowT - sHookAt) < 0.45) {   // ★ 2.0.79：当场直通（系统刚设过色 → 毫秒对齐）
        sTimeLabel = sHookLab;
        return sHookCol;
    }
    @try {
        if (!sTimeLabel || (nowT - sFindAt) > 0.2) {
            sFindAt = nowT;
            NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:S("^[0-9]{1,2}:[0-9]{2}$") options:0 error:nil];
            if (!re) return nil;
            NSMutableArray *stack = [NSMutableArray array];
            for (UIWindow *w in [UIApplication sharedApplication].windows) { if (w) [stack addObject:w]; }
            @try {
                for (UIScene *sc2 in [UIApplication sharedApplication].connectedScenes) {
                    if ([sc2 isKindOfClass:[UIWindowScene class]]) {
                        for (UIWindow *w2 in [(UIWindowScene *)sc2 windows]) { if (w2) [stack addObject:w2]; }
                    }
                }
            } @catch (__unused NSException *e) {}
            int guard = 0;
            NSMutableArray *cands = [NSMutableArray array];   // ★ 2.0.79：全部候选（打分选最优）
            while (stack.count > 0 && guard++ < 8000) {
                UIView *v = [stack lastObject]; [stack removeLastObject];
                for (UIView *sub in v.subviews) { if (sub) [stack addObject:sub]; }
                if (![v isKindOfClass:[UILabel class]]) continue;
                UILabel *l = (UILabel *)v;
                NSString *t = l.text; if (!t.length || t.length > 6) continue;
                if (![re firstMatchInString:t options:0 range:NSMakeRange(0, t.length)]) continue;
                if (l.hidden || l.alpha < 0.05 || !l.window) continue;
                if (cands.count < 12) [cands addObject:l];
            }
            UILabel *best = nil; double bestSc = -1e18;
            UILabel *bestDiff = nil; double bestDiffSc = -1e18;
            for (NSUInteger ci = 0; ci < cands.count; ci++) {
                UILabel *l2 = [cands objectAtIndex:ci];
                double sc = CTWinCandScore(l2);
                if (sc > bestSc) { bestSc = sc; best = l2; }
                if (sFollowR >= 0.0 && (nowT - sSwitchAt) < 2.5) {   // ★ 2.0.79：翻色向导
                    UIColor *cc2 = CTWinReadLabColor(l2);
                    CGFloat r2 = 0, g2 = 0, b2 = 0, a2 = 0;
                    if (cc2 && [cc2 getRed:&r2 green:&g2 blue:&b2 alpha:&a2]) {
                        if (fabs(r2 - sFollowR) > 0.5 || fabs(g2 - sFollowG) > 0.5 || fabs(b2 - sFollowB) > 0.5) {
                            if (sc > bestDiffSc) { bestDiffSc = sc; bestDiff = l2; }
                        }
                    }
                }
            }
            if (bestDiff && bestDiffSc >= bestSc - 900.0) {
                best = bestDiff;   // 切换窗内：有"另一种颜色"的像样候补 → 直接翻过去
            } else if (sTimeLabel && best && best != sTimeLabel) {   // 滞回：防来回跳
                BOOL oldFound = NO;
                for (NSUInteger ci = 0; ci < cands.count; ci++) { if ([cands objectAtIndex:ci] == sTimeLabel) { oldFound = YES; break; } }
                if (oldFound) {
                    double oldSc = CTWinCandScore(sTimeLabel);
                    if (bestSc < oldSc + 400.0) best = sTimeLabel;
                }
            }
            if (cands.count > 1) {   // ★ 2.0.79：多候补留痕（排查"切换慢"用；最多 3 个，1 秒节流）
                static CFAbsoluteTime sCandLogAt = 0;
                if (nowT - sCandLogAt > 6.0) {   // ★ 2.0.92：降噪（原 1 秒，未变不刷）
                    sCandLogAt = nowT;
                    NSMutableString *ms2 = [NSMutableString string];
                    for (NSUInteger ci = 0; ci < cands.count && ci < 3; ci++) {
                        UILabel *l2 = [cands objectAtIndex:ci];
                        UIColor *cc2 = CTWinReadLabColor(l2);
                        CGFloat r2 = -1, g2 = -1, b2 = -1, a2 = 0;
                        BOOL ok2 = (cc2 && [cc2 getRed:&r2 green:&g2 blue:&b2 alpha:&a2]);
                        long st2 = -8;
                        @try { st2 = l2.window.windowScene ? (long)l2.window.windowScene.activationState : -8; } @catch (__unused NSException *e) { st2 = -7; }
                        [ms2 appendFormat:S("%s%c色=%s 亮=%.2f 键=%d 层=%.0f 场=%ld"),
                            ci ? " | " : "", (l2 == best) ? '*' : ' ',
                            ok2 ? [[NSString stringWithFormat:S("%.1f/%.1f/%.1f"), r2, g2, b2] UTF8String] : "?",
                            CTWinEffAlpha(l2), l2.window.isKeyWindow ? 1 : 0, l2.window.windowLevel, st2];
                    }
                    CTWinLog("[浮窗] 跟色候补: %s", ms2.UTF8String);
                }
            }
            sTimeLabel = best;
        }
    } @catch (__unused NSException *e) {}
    {   // ★ 2.0.79：取色来源留痕（实例变化时一行）
        static const void *sLastLogLabP = NULL;
        if (sLastLogLabP != (__bridge const void *)sTimeLabel) {
            sLastLogLabP = (__bridge const void *)sTimeLabel;
            CTWinLog("[浮窗] 颜色自适应：时间色源=%s（%s）", sTimeLabel ? "已取到 ✓" : "未找到（退回深浅色）", sTimeLabel ? NSStringFromClass([sTimeLabel class]).UTF8String : "-");
        }
    }
    UIColor *c = CTWinReadLabColor(sTimeLabel);
    if (!c) {
        @try {
            UIStatusBarStyle st = [[UIApplication sharedApplication] statusBarStyle];
            if (st == UIStatusBarStyleLightContent) c = [UIColor whiteColor];
            else if (st == UIStatusBarStyleDarkContent) c = [UIColor blackColor];
        } @catch (__unused NSException *e) {}
    }
    return c;
}


// ============================================================================
// ★ 2.0.70：「颜色自适应」= 整窗取样——读浮窗背后那块的真实亮度：亮(≥0.6)→黑字、暗(≤0.4)→白字，
//   0.4~0.6 之间保持上次判定（防边界闪烁）。取样走渲染服务器截屏（dlsym 动态解析，零链接依赖）；
//   任何一步失败 → 自动退回"系统深浅色"逻辑，绝不拖累加载、绝不报错。
// ============================================================================
typedef void *CTIOSurfRef;
static void *sCTIOSFw = NULL;
static CTIOSurfRef (*sCTSurfCreate)(CFDictionaryRef) = NULL;
static int   (*sCTSurfLock)(CTIOSurfRef, uint32_t, void *) = NULL;
static int   (*sCTSurfUnlock)(CTIOSurfRef, uint32_t, void *) = NULL;
static void *(*sCTSurfBase)(CTIOSurfRef) = NULL;
static size_t (*sCTSurfBPR)(CTIOSurfRef) = NULL;
static void  (*sCTRenderDisplay)(int, CFStringRef, CTIOSurfRef) = NULL;
static unsigned int (*sCTGetServerPort)(void *) = NULL;
static CTIOSurfRef sCTSurf = NULL;
static CFAbsoluteTime sCTAdaptAt = 0;
static int sCTAdaptDec = -1;                 // 0=白字（暗背景） 1=黑字（亮背景）
static UIColor *sCTAdaptColor = nil;

static void CTWinAdaptiveColorTick(void) {
    if (!gWinInvert || gWinFollowTime || !gWinEnabled || gWinBlanked) return;
    if (gWinW < 4.0 || gWinH < 4.0) return;
    CFAbsoluteTime nowA = CFAbsoluteTimeGetCurrent();
    if (sCTAdaptAt > 0.0 && (nowA - sCTAdaptAt) < 1.2) return;   // ★ 2.0.73：1.2 秒取样一拍（颜色秒换）
    sCTAdaptAt = nowA;
    @try {
        if (!sCTRenderDisplay) {   // 符号解析（只做一次；失败=退回深浅色并留痕）
            if (!sCTIOSFw) sCTIOSFw = dlopen("/System/Library/Frameworks/IOSurface.framework/IOSurface", RTLD_LAZY);
            void *fw = sCTIOSFw;
            sCTSurfCreate = (CTIOSurfRef (*)(CFDictionaryRef))(fw ? dlsym(fw, "IOSurfaceCreate") : dlsym(RTLD_DEFAULT, "IOSurfaceCreate"));
            sCTSurfLock   = (int (*)(CTIOSurfRef, uint32_t, void *))(fw ? dlsym(fw, "IOSurfaceLock") : dlsym(RTLD_DEFAULT, "IOSurfaceLock"));
            sCTSurfUnlock = (int (*)(CTIOSurfRef, uint32_t, void *))(fw ? dlsym(fw, "IOSurfaceUnlock") : dlsym(RTLD_DEFAULT, "IOSurfaceUnlock"));
            sCTSurfBase   = (void *(*)(CTIOSurfRef))(fw ? dlsym(fw, "IOSurfaceGetBaseAddress") : dlsym(RTLD_DEFAULT, "IOSurfaceGetBaseAddress"));
            sCTSurfBPR    = (size_t (*)(CTIOSurfRef))(fw ? dlsym(fw, "IOSurfaceGetBytesPerRow") : dlsym(RTLD_DEFAULT, "IOSurfaceGetBytesPerRow"));
            sCTRenderDisplay = (void (*)(int, CFStringRef, CTIOSurfRef))dlsym(RTLD_DEFAULT, "CARenderServerRenderDisplay");
            sCTGetServerPort = (unsigned int (*)(void *))dlsym(RTLD_DEFAULT, "CARenderServerGetServerPort");
            if (!sCTRenderDisplay || !sCTSurfCreate) { CTWinLog("[浮窗] 颜色自适应：取样符号缺失（退回深浅色）"); return; }
            unsigned int ctProbe = sCTGetServerPort ? sCTGetServerPort(NULL) : 0;
            CTWinLog("[浮窗] 颜色自适应：取样通道就绪（端口=0x%x）", ctProbe);
        }
        CGFloat sc = [UIScreen mainScreen].scale; if (sc < 1.0) sc = 3.0;
        size_t pw = (size_t)([UIScreen mainScreen].bounds.size.width * sc);
        size_t ph = (size_t)([UIScreen mainScreen].bounds.size.height * sc);
        if (!sCTSurf) {
            CFMutableDictionaryRef props = CFDictionaryCreateMutable(NULL, 4, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
            int w = (int)pw, h = (int)ph, bpe = 4, pf = 0x42475241;   // 'BGRA'
            CFNumberRef n1 = CFNumberCreate(NULL, kCFNumberIntType, &w);
            CFNumberRef n2 = CFNumberCreate(NULL, kCFNumberIntType, &h);
            CFNumberRef n3 = CFNumberCreate(NULL, kCFNumberIntType, &bpe);
            CFNumberRef n4 = CFNumberCreate(NULL, kCFNumberIntType, &pf);
            if (props && n1 && n2 && n3 && n4) {
                CFDictionarySetValue(props, CFSTR("IOSurfaceWidth"), n1);
                CFDictionarySetValue(props, CFSTR("IOSurfaceHeight"), n2);
                CFDictionarySetValue(props, CFSTR("IOSurfaceBytesPerElement"), n3);
                CFDictionarySetValue(props, CFSTR("IOSurfacePixelFormat"), n4);
                sCTSurf = sCTSurfCreate(props);
            }
            if (n1) CFRelease(n1); if (n2) CFRelease(n2); if (n3) CFRelease(n3); if (n4) CFRelease(n4);
            if (props) CFRelease(props);
        }
        if (!sCTSurf) return;
        unsigned int ctPort = 0;
        if (sCTGetServerPort) ctPort = sCTGetServerPort(NULL);
        sCTRenderDisplay((int)ctPort, CFSTR("LCD"), sCTSurf);
        uint32_t seed = 0;
        if (sCTSurfLock && sCTSurfLock(sCTSurf, 0x00000001, &seed) != 0) return;
        unsigned char *base = (unsigned char *)sCTSurfBase(sCTSurf);
        size_t bpr = sCTSurfBPR(sCTSurf);
        CGFloat wx = gWinCX - gWinW * 0.5, wy = gWinCY - gWinH * 0.5;
        size_t x0 = (size_t)(MAX(0.0, wx) * sc), y0 = (size_t)(MAX(0.0, wy) * sc);
        size_t x1 = (size_t)(MIN((CGFloat)pw, (wx + gWinW) * sc)), y1 = (size_t)(MIN((CGFloat)ph, (wy + gWinH) * sc));
        long lightCnt = 0, total = 0, nzCnt = 0;
        if (base && bpr > 0 && x1 > x0 && y1 > y0) {
            for (size_t yy = y0; yy < y1; yy += 3) {
                unsigned char *row = base + yy * bpr;
                for (size_t xx = x0; xx < x1; xx += 3) {
                    unsigned char *px = row + xx * 4;
                    double lum01 = (0.114 * px[0] + 0.587 * px[1] + 0.299 * px[2]) / 255.0;
                    if (lum01 >= 0.5) lightCnt++;
                    if (px[0] || px[1] || px[2]) nzCnt++;
                    total++;
                }
            }
        }
        if (sCTSurfUnlock) sCTSurfUnlock(sCTSurf, 0x00000001, &seed);
        if (total > 0 && nzCnt == 0) {   // ★ 2.0.72：空帧重试一次（等 3ms 让合成落地，再渲染+读取）
            usleep(3000);
            sCTRenderDisplay((int)ctPort, CFSTR("LCD"), sCTSurf);
            if (sCTSurfLock && sCTSurfLock(sCTSurf, 0x00000001, &seed) == 0) {
                base = (unsigned char *)sCTSurfBase(sCTSurf);
                bpr = sCTSurfBPR(sCTSurf);
                lightCnt = 0; total = 0; nzCnt = 0;
                if (base && bpr > 0 && x1 > x0 && y1 > y0) {
                    for (size_t yy = y0; yy < y1; yy += 3) {
                        unsigned char *row = base + yy * bpr;
                        for (size_t xx = x0; xx < x1; xx += 3) {
                            unsigned char *px = row + xx * 4;
                            double lum01 = (0.114 * px[0] + 0.587 * px[1] + 0.299 * px[2]) / 255.0;
                            if (lum01 >= 0.5) lightCnt++;
                            if (px[0] || px[1] || px[2]) nzCnt++;
                            total++;
                        }
                    }
                }
                if (sCTSurfUnlock) sCTSurfUnlock(sCTSurf, 0x00000001, &seed);
            }
        }
        if (total <= 0) return;
        static int sCTAdaptLogN = 0; sCTAdaptLogN++;
        if (nzCnt == 0) {   // ★ 2.0.71：空帧防护——截屏没取到内容时，绝不据此改判定
            if (sCTAdaptLogN <= 3 || (sCTAdaptLogN % 60) == 0)
                CTWinLog("[浮窗] 颜色自适应：取样为空（区=%.0f,%.0f %.0fx%.0f）→ 忽略本拍", wx, wy, gWinW, gWinH);
            return;
        }
        double lightShare = (double)lightCnt / (double)total;   // ★ 2.0.70：按"大多数"投票——整窗只用一个颜色
        int dec;
        if (lightShare >= 0.60) dec = 1;        // 大部分亮 → 整窗黑字
        else if (lightShare <= 0.40) dec = 0;   // 大部分暗 → 整窗白字
        else dec = (sCTAdaptDec >= 0) ? sCTAdaptDec : ((lightShare >= 0.5) ? 1 : 0);
        int ctChanged = (dec != sCTAdaptDec);
        sCTAdaptDec = dec;
        sCTAdaptColor = (dec == 1) ? [UIColor colorWithWhite:0.05 alpha:1.0] : [UIColor colorWithWhite:1.0 alpha:1.0];
        if (ctChanged || sCTAdaptLogN <= 3 || (sCTAdaptLogN % 60) == 0)
            CTWinLog("[浮窗] 颜色自适应：画面亮占比=%.0f%%（区=%.0f,%.0f %.0fx%.0f）→ 整窗%s", lightShare * 100.0, wx, wy, gWinW, gWinH, (dec == 1) ? "黑字" : "白字");
        if (ctChanged) gWinLastRaw = nil;   // ★ 2.0.73：判定一变 → 同拍立即重绘
    } @catch (__unused NSException *e) {}
}

static void CTWinRender(NSString *raw) {
    if (!gWinLabel || !gWinCapsule) return;
    double freq = 0.0; BOOL haveFreq = NO, deep = NO, boost = NO, video = NO;
    int chg = 0, pw = 0, cap = 0; int cur = 0; double tempC = 0; NSString *cr = nil;
    NSString *mode = nil;
    for (NSString *p in [raw componentsSeparatedByString:S(" ")]) {
        NSArray *kv = [p componentsSeparatedByString:S("=")];
        if (kv.count != 2) continue;
        NSString *k = kv[0], *v = kv[1];
        if ([k isEqualToString:S("freq")]) { freq = v.doubleValue; haveFreq = (freq > 0); }
        else if ([k isEqualToString:S("mode")]) { mode = v; }
        else if ([k isEqualToString:S("deep")]) { deep = v.boolValue; }
        else if ([k isEqualToString:S("boost")]) { boost = v.boolValue; }
        else if ([k isEqualToString:S("video")]) { video = v.boolValue; }
        else if ([k isEqualToString:S("chg")]) { chg = (int)v.integerValue; }
        else if ([k isEqualToString:S("pw")])  { pw = (int)v.integerValue; }
        else if ([k isEqualToString:S("cap")]) { cap = (int)v.integerValue; }
        else if ([k isEqualToString:S("cr")])  { cr = v; }
        else if ([k isEqualToString:S("cur")]) { cur = (int)v.integerValue; }
        else if ([k isEqualToString:S("temp")]) { tempC = v.doubleValue; }
    }
    // ★ 0928-2：「显示内容」选择——按段拼装，分隔符只在相邻显示段之间出现
    NSMutableArray *ctmSegs = [NSMutableArray array];
    if (gWinShowFreq) { [ctmSegs addObject:(haveFreq ? [NSString stringWithFormat:S("%.0fM"), freq] : S("—M"))]; }
    if (gWinShowMode && mode.length) [ctmSegs addObject:mode];
    if (gWinShowFlags) {
        NSMutableString *ctmFlags = [[NSMutableString alloc] init];
        if (deep)  [ctmFlags appendString:S("深")];
        if (boost) [ctmFlags appendString:S("提")];
        if (video) [ctmFlags appendString:S("视")];
        if (ctmFlags.length) [ctmSegs addObject:ctmFlags];
    }
    // ★ 1.4.6 充电段：⚡ + 瓦数（chg：1绿/2黄/3红/4黑/5橙=恢复中）
    if (gWinShowCharge && chg >= 1) {
        if (chg == 5) [ctmSegs addObject:S("恢复中")];   // ★ 1.4.6x：已请求充上、等硬件放行
        else if (pw > 0) [ctmSegs addObject:[NSString stringWithFormat:S("\u26a1\ufe0e%dW"), pw]];
        else [ctmSegs addObject:S("\u26a1\ufe0e")];
    }
    // ★ 1.4.115：电量段（剩余百分比，如 90%）
    if (gWinShowBattery && gWinBatteryPct >= 0) {
        [ctmSegs addObject:[NSString stringWithFormat:S("%d%%"), gWinBatteryPct]];
    }
    // ★ 0929：电流段 / 网速段（主插件每秒写入状态文件）
    if (gWinShowCurrent) {
        [ctmSegs addObject:[NSString stringWithFormat:S("%dmA"), cur]];
    }
    if (gWinShowNet) {
        int nb = gWinNetBps;
        if (nb >= 1048576)      [ctmSegs addObject:[NSString stringWithFormat:S("%.1fM/s"), nb / 1048576.0]];
        else if (nb >= 1024)    [ctmSegs addObject:[NSString stringWithFormat:S("%dK/s"), nb / 1024]];
        else                    [ctmSegs addObject:S("0K/s")];
    }
    if (gWinShowTemp && tempC > 0.5) {
        [ctmSegs addObject:[NSString stringWithFormat:S("%.1f°C"), tempC]];
    }
    if (gWinShowFPS) {   // ★ 2.0.68：实时帧率段（浮窗尾部，如 118FPS）
        double ctShow = sCTFPSValue;   // ★ 2.0.69：取近 3 秒样本峰值（滑动时数字更快冲到 ~120）
        if (sCTFPSRing[0] > ctShow) ctShow = sCTFPSRing[0];
        if (sCTFPSRing[1] > ctShow) ctShow = sCTFPSRing[1];
        if (sCTFPSRing[2] > ctShow) ctShow = sCTFPSRing[2];
        [ctmSegs addObject:[NSString stringWithFormat:S("%.0fFPS"), ctShow]];
    }
    NSString *text = [ctmSegs componentsJoinedByString:S(" · ")];
    BOOL winShowDot = gWinShowDot;   // ★ 2.0.41：严格按开关（全关=连点都不显示）

    CGRect sb = [UIScreen mainScreen].bounds;
    CGFloat maxW = MIN(sb.size.width, sb.size.height) * 0.72;   // ★ 1.4.109：按"较窄边"算 → 横竖屏字号一致（治"切方向时字体忽大忽小"）
    CGFloat baseFs = gWinBaseFont;                                   // ★ T7z18：字号来自设置
    if (baseFs < 6.0) baseFs = 6.0;                                  // ★ T7z18c：下限放到 6
    if (baseFs > 20.0) baseFs = 20.0;
    CGFloat k = baseFs / 12.0;                                       // ★ T7z18：整窗随字号等比缩放
    if (k < 0.62) k = 0.62;                                          // ★ T7z18c：极小字号也等比缩
    if (k > 1.70) k = 1.70;
    CGFloat padX = 10.0 * k, dotW = 7.0 * k, gap = 6.0 * k, padY = 6.0 * k;
    CGFloat minFs = baseFs - 4.0; if (minFs < 6.0) minFs = 6.0;      // 过长仍需完整显示 → 允许缩
    CGFloat fs = baseFs;
    UIFont *f = nil;
    NSMutableAttributedString *as = nil;
    CGSize ts = CGSizeZero;
    NSRange lr = [text rangeOfString:S("\u26a1\ufe0e")];
    NSRange rr = [text rangeOfString:S("恢复中")];   // ★ 1.4.6x：恢复中（橙色）
    while (1) {
        f = [UIFont monospacedDigitSystemFontOfSize:fs weight:UIFontWeightSemibold];
        as = [[NSMutableAttributedString alloc] initWithString:text];
        [as addAttribute:NSFontAttributeName value:f range:NSMakeRange(0, as.length)];
        if (lr.location != NSNotFound) {   // ★ 1.4.6w：⚡ 略微加大（×1.35，随字号等比）
            UIFont *ctBoltFont = [UIFont monospacedDigitSystemFontOfSize:(fs * 1.35) weight:UIFontWeightSemibold];
            [as addAttribute:NSFontAttributeName value:ctBoltFont range:lr];
            // ★ 1.4.6y：⚡ 下移一点（随字号等比），与文字垂直居中对齐
            [as addAttribute:NSBaselineOffsetAttributeName value:@(-(fs * 0.1)) range:lr];
        }
        ts = [as boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
        CGFloat ctmNeedW = (padX * 2.0) + (winShowDot ? (dotW + ((text.length > 0) ? (gap + ts.width) : 0.0)) : ts.width);
        if (ctmNeedW <= maxW || fs <= minFs) break;
        fs -= 0.5;
    }
    CGFloat capW = ceil((padX * 2.0) + (winShowDot ? (dotW + ((text.length > 0) ? (gap + ts.width) : 0.0)) : ts.width));
    CGFloat capH = ceil(MAX(baseFs * 1.85, ts.height + padY * 2.0));   // ★ T7z18：高度也随字号走
    gWinW = capW; gWinH = capH;

    gWinLabel.font = f;
    // ★ 1.4.68：自定义颜色优先（开关打开且颜色有效 ⇒ 用它 ✓；否则走原来的自动逻辑 ✓）
    UIColor *ctCustom = nil;
    {
        @try {
            NSDictionary *pd = CTHermesReadPrefs();
            if ([pd[S("floatTextColorOn")] boolValue]) {
                NSString *hx = pd[S("floatTextColorHex")];
                if ([hx isKindOfClass:[NSString class]] && hx.length == 7) {
                    unsigned int rr=0,gg=0,bb=0;
                    NSScanner *sc=[NSScanner scannerWithString:hx];
                    [sc scanString:S("#") intoString:NULL];
                    if ([sc scanHexInt:&rr] && rr<=0xFFFFFF) { gg=(rr>>8)&0xFF; bb=rr&0xFF; rr=(rr>>16)&0xFF;
                        ctCustom=[UIColor colorWithRed:rr/255.0 green:gg/255.0 blue:bb/255.0 alpha:1.0]; }
                }
            }
        } @catch (__unused NSException *e) {}
    }
    UIColor *ctFinalColor = ctCustom ?: (gWinLightMode ? [UIColor colorWithWhite:0.05 alpha:1.0]
                                                   : [UIColor colorWithWhite:1.0 alpha:1.0]);
    if (gWinFollowTime) {   // ★ 2.0.69：「跟随状态栏」= 窗口文字颜色跟状态栏时间完全一致（读不到退回深浅色）
        UIColor *ctTime = CTWinStatusBarTimeColor();
        if (ctTime) {
            ctFinalColor = ctTime;
            CGFloat rr3 = 0, gg3 = 0, bb3 = 0, aa3 = 0;
            if ([ctTime getRed:&rr3 green:&gg3 blue:&bb3 alpha:&aa3]) {
                BOOL chg3 = (sFollowR < 0 || fabs(rr3 - sFollowR) > 0.02 || fabs(gg3 - sFollowG) > 0.02 || fabs(bb3 - sFollowB) > 0.02);
                sFollowR = rr3; sFollowG = gg3; sFollowB = bb3;
                if (chg3) {
                    CTWinLog("[浮窗] 跟色已应用=%.2f,%.2f,%.2f（源=%s）", rr3, gg3, bb3, sRenderSrc);
                } else if (strcmp(sRenderSrc, "拍") != 0) {
                    static CFAbsoluteTime sChkLogAt = 0;   // ★ 2.0.79：切换中"读到啥"也留痕（1.5 秒节流）
                    CFAbsoluteTime nowChk = CFAbsoluteTimeGetCurrent();
                    if (nowChk - sChkLogAt > 30.0) { sChkLogAt = nowChk; CTWinLog("[浮窗] 跟色刷新：读到 %.2f,%.2f,%.2f（未变·源=%s）", rr3, gg3, bb3, sRenderSrc); }   // ★ 2.0.92：降噪（原 1.5 秒）
                }
            }
        }
    } else if (gWinInvert) {   // ★ 2.0.70：颜色自适应=整窗取样（亮→黑字/暗→白字；未取样前退回深浅色）
        if (sCTAdaptColor) ctFinalColor = sCTAdaptColor;
    }
    gWinLabel.textColor = ctFinalColor;
    {   // ★ 1.4.6：⚡ 单独上色（其余文字原色；四态自适应浅深模式；⚡ 字体已在上面加大）
        [as addAttribute:NSForegroundColorAttributeName value:gWinLabel.textColor range:NSMakeRange(0, as.length)];
        if (lr.location != NSNotFound) {
            UIColor *cc = nil;
            switch (chg) {
                case 1: cc = [UIColor systemGreenColor]; break;
                case 2: cc = [UIColor systemYellowColor]; break;
                case 3: cc = [UIColor systemRedColor]; break;
                default: cc = gWinLightMode ? [UIColor colorWithWhite:0.05 alpha:1.0]
                                            : [UIColor colorWithWhite:0.62 alpha:1.0]; break;
            }
            [as addAttribute:NSForegroundColorAttributeName value:cc range:lr];
        }
        else if (rr.location != NSNotFound) {
            // ★ 1.4.6x：恢复中单独上色（橙）；其余文字保持原色
            [as addAttribute:NSForegroundColorAttributeName value:[UIColor systemOrangeColor] range:rr];
        }
        gWinLabel.attributedText = as;
    }
    gWinCapsule.bounds = CGRectMake(0, 0, capW, capH);
    gWinCapsule.layer.cornerRadius = capH * 0.5;
    BOOL ctBgGone = (gWinHideBg || (gWinInvert && !gWinFollowTime));   // ★ 2.0.69：反色模式自动隐藏背景；跟随状态栏不动背景
    if (gWinBlur) {
        gWinBlur.hidden = ctBgGone;                                                      // ★ T7z20：背景可隐藏
        if (!ctBgGone) {                                                                 // ★ T7z21：毛玻璃也分深浅色
            gWinBlur.effect = [UIBlurEffect effectWithStyle:(gWinLightMode ? UIBlurEffectStyleSystemUltraThinMaterialLight
                                                                           : UIBlurEffectStyleSystemUltraThinMaterialDark)];
        }
    }
    gWinCapsule.layer.borderWidth = ctBgGone ? 0.0 : 0.5;
    gWinCapsule.layer.borderColor = (gWinLightMode ? [UIColor colorWithWhite:0.0 alpha:0.10]
                                                   : [UIColor colorWithWhite:1.0 alpha:0.14]).CGColor;
    gWinLabel.shadowColor = nil;                                                        // ★ T7z20b：不要投影/描边
    gWinLabel.shadowOffset = CGSizeMake(0.0, 0.0);
    gWinDot.layer.shadowOpacity = 0.0;
    gWinDot.hidden = !winShowDot;
    gWinEmpty = (ctmSegs.count == 0 && !winShowDot);   // ★ 2.0.41：全关 → 整窗不显示（连白点都不留）
    gWinCapsule.hidden = gWinEmpty;
    gWinDot.frame = CGRectMake(padX, (capH - dotW) * 0.5, dotW, dotW);
    gWinDot.layer.cornerRadius = dotW * 0.5;
    gWinLabel.frame = CGRectMake(padX + (winShowDot ? (dotW + gap) : 0.0), 0, ts.width + 4.0, capH);
    if ([gWinLabel isKindOfClass:[CTWinInvertLabel class]]) [(CTWinInvertLabel *)gWinLabel ctResyncInvert];   // ★ 2.0.69：布局定稿后再对齐"反色掩膜"

    BOOL ctTextLight = !gWinLightMode;   // ★ 2.0.73：状态点跟随"最终文字色"（白字→白点 / 黑字→深点）
    @try {
        CGFloat rr2=0, gg2=0, bb2=0, aa2=0;
        if ([ctFinalColor getRed:&rr2 green:&gg2 blue:&bb2 alpha:&aa2]) {
            ctTextLight = ((0.299*rr2 + 0.587*gg2 + 0.114*bb2) >= 0.5);
        }
    } @catch (__unused NSException *e) {}
    UIColor *dotColor = ctTextLight ? [UIColor colorWithWhite:0.92 alpha:0.9]
                                    : [UIColor colorWithWhite:0.10 alpha:0.95];
    if (boost) dotColor = [UIColor systemOrangeColor];
    else if (deep) dotColor = [UIColor systemGreenColor];
    else if (video) dotColor = [UIColor systemPurpleColor];
    gWinDot.backgroundColor = dotColor;

    if (gWinPlaced) CTWinPlace(gWinCX, gWinCY);
}

// ---------- 退化：寄生到系统现成窗口（自建窗口不进场景时的兜底） ----------
static void CTWinSwitchToSystemHost(const char *why) {
    UIWindow *host = CTWinPickTopWindow();
    if (!host) {
        gWinRetryCount++;
        if (gWinRetryCount <= 5) {
            CTWinLog("寄生失败：暂无可用系统窗口（%d/5，1 秒后重试）", gWinRetryCount);
            gWinCheckAt = CFAbsoluteTimeGetCurrent() - 2.0;   // 约 1 秒后再试
            gWinCheckPhase = 0;
        } else {
            CTWinLog("寄生放弃：连续 5 次未找到系统窗口");
        }
        return;
    }
    if (gWinPan) {
        UIView *old = gWinPan.view;
        if (old && old != gWinCapsule) [old removeGestureRecognizer:gWinPan];
    }
    [gWinCapsule removeFromSuperview];
    gHost = host;
    gHostIsSystem = YES;
    [host addSubview:gWinCapsule];
    [host bringSubviewToFront:gWinCapsule];
    if (gWinPan && !gWinPan.view) [gWinCapsule addGestureRecognizer:gWinPan];
    if (gWinLockPress && !gWinLockPress.view) [gWinCapsule addGestureRecognizer:gWinLockPress];
    if (gWin) gWin.hidden = YES;
    CTWinPlace(gWinCX, gWinCY);
    CTWinLog("已寄生到系统窗口（%s）cls=%s 层级=%.0f 容器=%.0fx%.0f",
             why ? why : "-", class_getName([host class]), host.windowLevel,
             host.bounds.size.width, host.bounds.size.height);
}

// ---------- 建胶囊（可独立重试；失败不影响其它功能） ----------
static BOOL CTWinBuildCapsule(void) {
    if (gWinCapsule) return YES;
    @try {
        @autoreleasepool {
            UIView *cap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, gWinW, gWinH)];
            cap.layer.cornerRadius = gWinH * 0.5;
            cap.layer.cornerCurve = kCACornerCurveContinuous;
            cap.layer.masksToBounds = YES;
            cap.layer.borderWidth = 0.5;
            cap.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.14].CGColor;
            UIVisualEffectView *blur = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark]];
            blur.frame = cap.bounds;
            blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [cap addSubview:blur];
            gWinBlur = blur;                     // ★ T7z20：留引用，便于整体隐藏
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(10, (gWinH - 7.0) * 0.5, 7.0, 7.0)];
            dot.layer.cornerRadius = 3.5;
            dot.backgroundColor = [UIColor colorWithWhite:0.92 alpha:0.9];
            [cap addSubview:dot];
            UILabel *lab = [[CTWinInvertLabel alloc] initWithFrame:CGRectMake(23, 0, gWinW - 27, gWinH)];
            lab.font = [UIFont monospacedDigitSystemFontOfSize:13.0 weight:UIFontWeightSemibold];
            lab.textColor = [UIColor colorWithWhite:1.0 alpha:0.96];
            [cap addSubview:lab];
            gWinCapsule = cap; gWinDot = dot; gWinLabel = lab;
            gWinDrag = [[CTWinDrag alloc] init];
            gWinPan = [[UIPanGestureRecognizer alloc] initWithTarget:gWinDrag action:@selector(pan:)];
            gWinLockPress = [[UILongPressGestureRecognizer alloc] initWithTarget:gWinDrag action:@selector(lockPress:)];
            gWinLockPress.minimumPressDuration = 0.6;      // ★ T7z18：长按 0.6 秒 = 锁定/解锁
            [cap addGestureRecognizer:gWinPan];            // 手势挂在胶囊上：只有按到胶囊才响应
            [cap addGestureRecognizer:gWinLockPress];
            return YES;
        }
    } @catch (__unused NSException *e) {
        gWinCapsule = nil; gWinDot = nil; gWinLabel = nil; gWinPan = nil;
        return NO;
    }
}

// ---------- 建窗（延迟到启动 6 秒后 + 全程保护，失败自动重试；★ 关键：挂入场景） ----------
static void CTWinCreateIfReady(void) {
    if (gWin || gHostIsSystem) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - gWinBornAt < 6.0) return;
    if (now - gWinLastAttempt < 5.0) return;
    gWinLastAttempt = now;
    if (!CTWinBuildCapsule()) { CTWinLog("胶囊构建异常（5 秒后重试）"); return; }
    @try {
        @autoreleasepool {
            CGRect sb = [UIScreen mainScreen].bounds;
            CGFloat px, py;
            if (!CTWinLoadPos(&px, &py)) { px = sb.size.width - (gWinW > 10.0 ? gWinW : 266.0) * 0.5 - 12.0; py = 90.0; }   // ★ 2.0.5：默认位改用"右贴边留 12pt"的干净坐标（与重置一致）
            gWinPX = px; gWinPY = py;   // ★ 1.4.111：主文件 = 竖屏位
            CTWinLoadLand();            // ★ 1.4.111：读横屏位 / 手设标记
            gWinCX = px; gWinCY = py;
            CTWinHostVC *vc = [[CTWinHostVC alloc] init];                    // 空白处穿透
            UIWindow *w = [[CTWinWindow alloc] initWithFrame:CGRectMake(px - gWinW * 0.5, py - gWinH * 0.5, gWinW, gWinH)];   // ★ 微窗
            // ★ 1.4.10b：不设根控制器 —— 窗口不参与"场景支持方向"的判定（原来会限制整个场景，别的插件内容变竖屏）
            // w.rootViewController = vc;
            w.windowLevel = 10000000.0;              // 高于一切系统窗口
            w.backgroundColor = [UIColor clearColor];
            w.opaque = NO;
            w.hidden = YES;
            w.windowScene = CTWinPickScene();        // ★ 关键修复：iOS 13+ 必须挂场景才会渲染
            [w addSubview:gWinCapsule];   // ★ 1.4.10b：胶囊直接挂在窗口上（无根控制器 → 不影响场景方向）
            gWin = w; gHost = vc.view;
            gWinPlaced = YES;
            CTWinPlace(px, py);
            int scN = 0, winN = 0; CGFloat topLv = -1.0;
            for (UIScene *sc in [UIApplication sharedApplication].connectedScenes) {
                scN++;
                if (![sc isKindOfClass:[UIWindowScene class]]) continue;
                for (UIWindow *ww in [(UIWindowScene *)sc windows]) {
                    winN++;
                    if (ww.windowLevel > topLv) topLv = ww.windowLevel;
                }
            }
            CTWinLog("浮窗已创建（%.0f, %.0f）场景=%s 场景数=%d 系统窗数=%d 最高层=%.0f 字号=%.1f 锁定=%d",
                     px, py, w.windowScene ? "已挂" : "空", scN, winN, topLv, gWinBaseFont, gWinLocked ? 1 : 0);
            gWinCheckAt = now;
            gWinCheckPhase = 0;
        }
    } @catch (__unused NSException *e) {
        gWin = nil; gHost = nil;
        CTWinLog("建窗异常（5 秒后自动重试）");
    }
}

// ---------- 自检 / 复核 / 心跳 ----------
static void CTWinVerify(void) {
    if (gWinUninstalled) return;   // ★ 1.4.94：卸载后停止一切写入
    if (!gWin || gHostIsSystem) return;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (gWinCheckAt <= 0.0) { gWinCheckAt = now; return; }
    double dt = now - gWinCheckAt;
    BOOL inScene = (gWin.windowScene != nil) && [[gWin.windowScene windows] containsObject:gWin];
    if (gWinCheckPhase == 0 && dt >= 3.0) {
        gWinCheckPhase = 1;
        CTWinLog("自检: hidden=%d 场景=%s 在场景窗列=%d 层级=%.0f",
                 gWin.hidden ? 1 : 0, gWin.windowScene ? "有" : "无", inScene ? 1 : 0, gWin.windowLevel);
        if (!inScene) CTWinSwitchToSystemHost("自建窗口未进入场景");
    } else if (gWinCheckPhase == 1 && dt >= 15.0) {
        gWinCheckPhase = 2;
        CTWinLog("复核: hidden=%d 场景=%s 在场景窗列=%d 容器=%s",
                 gWin.hidden ? 1 : 0, gWin.windowScene ? "有" : "无", inScene ? 1 : 0,
                 gHostIsSystem ? "系统窗" : "自建窗");
    }
}

static void CTWinHeartbeat(void) {
    if (gWinUninstalled) return;   // ★ 1.4.94：卸载后停止一切写入
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (gWinHeartbeatAt <= 0.0) { gWinHeartbeatAt = now; return; }
    if (now - gWinHeartbeatAt < 30.0) return;
    gWinHeartbeatAt = now;
    BOOL inScene = (gWin && gWin.windowScene != nil) && [[gWin.windowScene windows] containsObject:gWin];
    CTWinLog("存活 hidden=%d 容器=%s 场景内=%d 位置=%.0f,%.0f",
             (gWinCapsule && gWinCapsule.hidden) ? 1 : 0,
             gHostIsSystem ? "系统窗" : "自建窗", inScene ? 1 : 0, gWinCX, gWinCY);
    notify_post("com.qq391160.cpucore/winbeat");   // ★ 2.0.39：浮窗心跳（跨沙盒取证：主插件收到会记日志）
}

// ---------- 每秒 tick（由 FaceDownLock 的轮询器调用） ----------

// ★ 2.0.68：「实时帧率」——每秒读渲染服务器"脏帧计数"做差分，得出实时帧率（验证 120 高刷用）。
//   符号用 dlsym 动态解析：零链接依赖，符号缺失也绝不拖累组件加载（开关关/浮窗关/熄屏 → 基线复位、零采样）。
static CFIndex (*sCTFPSFn)(void *) = NULL;
static BOOL sCTFPSProbed = NO;
static void CTWinFPSTick(void) {
    if (!gWinShowFPS || !gWinEnabled || gWinBlanked || (gWinDeviceLocked && gWinHideOnLock)) { sCTFPSReset = YES; return; }
    @try {
        if (!sCTFPSProbed) {
            sCTFPSProbed = YES;
            sCTFPSFn = (CFIndex (*)(void *))dlsym(RTLD_DEFAULT, "CARenderServerGetDirtyFrameCount");
            if (!sCTFPSFn) {
                void *h = dlopen("/System/Library/Frameworks/QuartzCore.framework/QuartzCore", RTLD_LAZY);
                if (h) sCTFPSFn = (CFIndex (*)(void *))dlsym(h, "CARenderServerGetDirtyFrameCount");
            }
            if (!sCTFPSFn) CTWinLog("[浮窗] 实时帧率：暂不可用（跳过）");
        }
        if (!sCTFPSFn) return;
        static CFAbsoluteTime sCTFPSTime = 0.0;
        CFAbsoluteTime nowF = CFAbsoluteTimeGetCurrent();
        CFIndex cur = sCTFPSFn(NULL);
        if (sCTFPSReset || sCTFPSTime <= 0.0) { sCTFPSPrev = cur; sCTFPSTime = nowF; sCTFPSReset = NO; sCTFPSValue = 0.0; return; }
        double ctDt = nowF - sCTFPSTime;
        CFIndex diff = cur - sCTFPSPrev; sCTFPSPrev = cur;
        if (diff < 0) diff = 0;
        if (ctDt < 0.25) return;              // ★ 2.0.75：间隔过短不更新（防切换瞬间数字闪降）
        sCTFPSTime = nowF;
        double fps = (double)diff / ctDt;     // ★ 2.0.75：按实际间隔折算
        double maxFPS = (double)[UIScreen mainScreen].maximumFramesPerSecond;
        if (maxFPS < 1.0) maxFPS = 120.0;
        if (fps > maxFPS) fps = maxFPS;
        sCTFPSValue = fps;
        sCTFPSRing[sCTFPSRingN % 3] = fps; sCTFPSRingN++;
        {   // ★ 2.0.69：近 30 秒统计（峰值/均值）→ 日志，下轮对照真假 120
            sCTFPSStatN++; sCTFPSStatSum += fps;
            if (fps > sCTFPSStatPeak) sCTFPSStatPeak = fps;
            if (sCTFPSStatN >= 30) {
                CTWinLog("[帧率] 近 30 秒：峰值=%.0f 均值=%.0f", sCTFPSStatPeak, sCTFPSStatSum / (double)sCTFPSStatN);
                sCTFPSStatN = 0; sCTFPSStatSum = 0.0; sCTFPSStatPeak = 0.0;
            }
        }
    } @catch (__unused NSException *e) {}
}

// ★ 2.0.93：锁屏态——只用"通知通道"读取（notify_get_state），零系统类访问。
//   2.0.92 教训：启动期访问 [SBLockScreenManager sharedInstance] 会触发其内部断言 →
//   libdispatch 块内异常 → terminate 崩溃（不可 @try 捕获）→ SpringBoard 启动即崩、进安全模式。已彻底移除该类访问。
static void CTWinDeviceLockRefresh(void) {
    @try {
        static BOOL sCTLockEverRead = NO;
        int tok = 0;
        if (notify_register_check("com.apple.springboard.lockstate", &tok) != NOTIFY_STATUS_OK) return;
        uint64_t st = UINT64_MAX;
        int rc = notify_get_state(tok, &st);
        notify_cancel(tok);
        if (rc != NOTIFY_STATUS_OK || st == UINT64_MAX) return;   // 读不到=保持原值
        BOOL nowL = (st != 0);   // 1=锁屏中；0=已解锁
        if (sCTLockEverRead && nowL == gWinDeviceLocked) return;
        sCTLockEverRead = YES;
        gWinDeviceLocked = nowL;
        CTWinLog("[浮窗] 锁屏状态=%s（锁屏隐藏=%s）", nowL ? "锁屏" : "解锁", gWinHideOnLock ? "开" : "关");
    } @catch (__unused NSException *e) {}
}

void CTHermesStatusWindowTick(void) {
    @try {
        sRenderSrc = sFollowSrc; sFollowSrc = "拍";   // ★ 2.0.79：本拍来源（钩子/信号/补拍/拍）
        CTWinFPSTick();   // ★ 2.0.68：实时帧率采样（开关关=内部直接返回）
        CTWinAdaptiveColorTick();   // ★ 2.0.70：颜色自适应取样（开关关=内部直接返回）
        if (!gWinEnabled || gWinBlanked || (gWinDeviceLocked && gWinHideOnLock)) {
            if (gWinCapsule && !gWinCapsule.hidden) gWinCapsule.hidden = YES;
            if (gWin && !gWin.hidden) gWin.hidden = YES;
            return;
        }
        if (!gWin && !gHostIsSystem) { CTWinCreateIfReady(); if (!gWin) return; }
        if (gWinNeedFontReload) { gWinNeedFontReload = NO; gWinLastRaw = nil; }   // ★ T7z18：字号变更 → 重排
        {   // ★ T7z21：系统深浅色变化 → 强制重绘（浅色→黑字）
            BOOL lightNow = NO;
            @try {
                // ★ 0930-0207：先问【系统真值】（AppleInterfaceStyle ✓ 最可靠），再退回窗口/屏幕
                UIUserInterfaceStyle st = UIUserInterfaceStyleUnspecified;
                // ★ 0930-0207：第 0 层——直接读【系统窗口】外观（其他插件同款做法，100% 可靠）
                @try {
                    for (UIWindow *w2 in [UIApplication sharedApplication].windows.reverseObjectEnumerator) {
                        UIUserInterfaceStyle s2 = w2.traitCollection.userInterfaceStyle;
                        if (s2 != UIUserInterfaceStyleUnspecified) { st = s2; break; }
                    }
                } @catch (__unused NSException *e) {}
                CFPropertyListRef sv = CFPreferencesCopyAppValue(CFSTR("AppleInterfaceStyle"), kCFPreferencesAnyApplication);
                if (sv && CFGetTypeID(sv) == CFStringGetTypeID()) {
                    st = (CFStringCompare((CFStringRef)sv, CFSTR("Dark"), 0) == kCFCompareEqualTo)
                       ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
                }
                if (sv) CFRelease(sv);
                if (gWin && st == UIUserInterfaceStyleUnspecified) st = gWin.traitCollection.userInterfaceStyle;
                if (st == UIUserInterfaceStyleUnspecified) st = [UIScreen mainScreen].traitCollection.userInterfaceStyle;
                if (st == UIUserInterfaceStyleUnspecified) {   // ★ 0930-0207：最后兜底——读前台代传的系统外观
                    NSString *ap = CTStateRead(@"CTHermesAppearance.txt");
                    if (ap.length) st = [ap hasPrefix:@"dark"] ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
                }
                if (st == UIUserInterfaceStyleUnspecified) {   // ★ 0930-0207：都拿不到 ⇒ 问系统真实深浅色（读 AppleInterfaceStyle）
                    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("AppleInterfaceStyle"), kCFPreferencesAnyApplication);
                    BOOL sysDark = (v && CFGetTypeID(v) == CFStringGetTypeID() &&
                                    CFStringCompare((CFStringRef)v, CFSTR("Dark"), 0) == kCFCompareEqualTo);
                    if (v) CFRelease(v);
                    st = sysDark ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
                }
                lightNow = (st == UIUserInterfaceStyleLight);
            } @catch (__unused NSException *e) {}
            if (lightNow != gWinLightMode) { gWinLightMode = lightNow; gWinLastRaw = nil;
                CTWinLog("外观判定: %s → %s字", lightNow ? "light" : "dark", lightNow ? "黑" : "白");   // ★ 0930-0207
            }
        }
        // ★ 2.0.39：三级"保鲜链"——①新鲜文件 ②新鲜 prefs ③新鲜通知；全旧才退回"旧文件/上一帧"（治 16 上"读到旧文件=锁死"）
        double ctNow = CFAbsoluteTimeGetCurrent();
        double ctFAt = 0.0;
        NSString *raw = CTStateReadTimed(@"CTHermesStatus.txt", &ctFAt);
        NSString *ctPS = CTPrefsStr(@"ctStatus");
        double ctPAt = CTPrefsNum(@"ctStatusAt");
        NSString *ctNS = CTNotifyStateStatusLine();
        double ctNAt = CTNotifyStateLastAt();
        if (raw.length && (ctNow - ctFAt) <= 8.0) {
            /* ①：文件新鲜（正常通道） */
        } else if (ctPS.length && (ctNow - ctPAt) <= 120.0) {
            raw = ctPS;   // ②：prefs 新鲜
        } else if (ctNS.length && (ctNow - ctNAt) <= 60.0) {
            raw = ctNS;   // ③：通知通道新鲜（粗粒度兜底）
        }
        if (raw.length == 0) raw = CTStateRead(@"CTHermesDirect.txt");   // ★ 0930-0207：核心没有 → 用守护的"直读"专属文件
        if (raw.length == 0) raw = CTPrefsStr(@"ctDirect");               // ★ 直读专属配置
        if (raw.length == 0) raw = ctNS;                                 // ★ 2.0.39：最后走"通知"通道
        if (raw.length == 0) CTNotifyStateEnsure();   // ★ 0930-0207：一直没数据 → 重试订阅
        raw = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        raw = [raw stringByReplacingOccurrencesOfString:@"mode=LP" withString:@"mode=低功耗"];
        raw = [raw stringByReplacingOccurrencesOfString:@"mode=SMART" withString:@"mode=智能"];
        raw = [raw stringByReplacingOccurrencesOfString:@"mode=HP" withString:@"mode=高性能"];   // ★ 0930-0207：代号翻中文（浮窗自己的中文字节是好的 ✓）
        if (raw.length == 0) {
            // ★ 1.0.5：读到空/读失败 → 保持上一帧显示（不再闪占位符 —M）
            raw = gWinLastRaw ?: S("freq=0");   // 首次启动还没生成文件时才用占位符
        }
        {   // ★ 0929：网速（由充电守护工具每秒写入独立文件）
            NSString *netStr = CTStateRead(@"CTHermesNet.txt");   // ★ 0930-0207：多路读  // ★ 0930-0207：双通道
            if (netStr.length == 0) netStr = CTPrefsStr(@"ctNet");   // ★ 0930-0207：prefs 兜底
            int nb = netStr ? netStr.intValue : 0;
            if (nb < 0) nb = 0;
            gWinNetBps = nb;
        }
        {   // ★ 1.4.115：电量（每秒刷新；数值变化 → 强制重绘）
            int bp = CTWinBatteryPercent();
            if (bp != gWinBatteryPct) { gWinBatteryPct = bp; gWinLastRaw = nil; }
        }
        if (gWinLastRaw == nil || ![raw isEqualToString:gWinLastRaw] || gWinLastNet != gWinNetBps ||
            (gWinShowFPS && fabs(gWinFPSShown - sCTFPSValue) >= 1.0) ||
            gWinInvert || gWinFollowTime) {   // ★ 2.0.73：颜色功能开着 → 每秒重绘（秒换）
            gWinLastRaw = [raw copy];
            gWinLastNet = gWinNetBps;
            gWinFPSShown = sCTFPSValue;
            CTWinRender(raw);
        }
        if (gWinCapsule.hidden && !gWinEmpty) gWinCapsule.hidden = NO;   // ★ 2.0.41：全关态保持不显示
        if (gWin && !gHostIsSystem && gWin.hidden) gWin.hidden = NO;
        // ★ 1.4.111：横屏自动贴边"补做"（冗余保险；正常由方向定时器完成）
        if (!gWinLUserSet && !gWinLSeedDone && (gWinRotAngle > 0.01 || gWinRotAngle < -0.01)) {
            CGSize sc0 = CTWinVisSize();
            if (sc0.width > sc0.height) { gWinLSeedDone = YES; CTWinSeedLandscape(); }
        }
        // ★ 1.4.111：切 App 后"自动归位"（延迟 1.5 秒执行；拖动中延后）
        if (gWinResyncAt > 0.0 && CFAbsoluteTimeGetCurrent() >= gWinResyncAt) {
            if (gWinPan && (gWinPan.state == UIGestureRecognizerStateBegan || gWinPan.state == UIGestureRecognizerStateChanged)) {
                gWinResyncAt = CFAbsoluteTimeGetCurrent() + 0.5;
            } else {
                gWinResyncAt = 0.0;
                CTWinResyncPosition();
            }
        }
        CTWinVerify();
        CTWinHeartbeat();
    } @catch (__unused NSException *e) {
        CTWinLog("刷新异常（跳过本跳）");
    }
}

// ---------- ★ 2.0.76：颜色快速通道（切 App / 回桌面信号 → 立即整帧刷新；+0.7 秒补拍） ----------
static void CTWinFastColorRefresh(void) {
    sCTAdaptAt = 0;      // 立即重取样（颜色自适应）
    sFindAt = 0;         // 立即重找色源（跟随状态栏）
    gWinLastRaw = nil;   // 强制重绘
    sSwitchAt = CFAbsoluteTimeGetCurrent();   // ★ 2.0.79：开"切换窗"（翻色向导用）
    sFollowSrc = "信号";
    dispatch_async(dispatch_get_main_queue(), ^{ @try { CTHermesStatusWindowTick(); } @catch (__unused NSException *e) {} });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { sCTAdaptAt = 0; sFindAt = 0; gWinLastRaw = nil; sFollowSrc = "补拍"; CTHermesStatusWindowTick(); } @catch (__unused NSException *e) {}
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { sCTAdaptAt = 0; sFindAt = 0; gWinLastRaw = nil; sFollowSrc = "补拍"; CTHermesStatusWindowTick(); } @catch (__unused NSException *e) {}
    });
}

// ---------- ★ 授权门：未激活时浮窗不出现（激活并注销后自动出现） ----------
static BOOL CTAuthActivatedForWindow(NSDictionary *d) {
    id st = [d objectForKey:@"ctAuthState"];          // 主插件发布的授权状态（1=已激活）
    if (st) return [st boolValue];
    NSString *s = [NSString stringWithContentsOfFile:S(CTDiagFileC("CTHermesAuth.txt"))
                                             encoding:NSUTF8StringEncoding error:NULL];
    if (s.length == 0) s = [NSString stringWithContentsOfFile:@"/var/mobile/Library/Logs/CTHermesAuth.txt"
                                                     encoding:NSUTF8StringEncoding error:NULL];
    // ★ 1.4.11：授权文件内容 = 授权码本身 → 独立验签才算数（不再认裸 "1"）
    if (s.length == 0) return NO;
    return CTAuthFileAuthorized();
}

// ★ 2.0.38：卸载拆除"双保险" —— 通知可能因环境差异送不到，所以加"墓碑自检"：
//   卸载脚本一落墓碑(.ctHermesUninstalling)，浮窗在 1 拍（≈1 秒）内自拆，绝不依赖通知送达。
static void CTWinTearDownUninstall(void) {
    if (gWinUninstalled) return;
    gWinUninstalled = YES;
    gWinEnabled = NO;
    CTHermesWipeLeftovers();   // ★ 1.4.102：本层残留自清
    @try {
        if (gWinCapsule) { [gWinCapsule removeFromSuperview]; gWinCapsule.hidden = YES; }
        if (gWin) { [gWin removeFromSuperview]; gWin.hidden = YES; }
    } @catch (__unused NSException *e) {}
    CTWinLog("卸载通知/卸载墓碑已确认 → 浮窗已拆除（窗口移除+防弹回）");
}

// ★ 2.0.38：宿主"心跳"监听——收到 tm/powerd 经通知通道发来的"活着"信号 → 记进日志（无需文件权限的取证通道）
static void CTWinBeatLog(const char *fmt, ...) {
    mkdir(CTDiagLogDirC(), 0755);
    FILE *fp = fopen(CTDiagLogPathC(), "a");
    if (!fp) {
        for (NSString *d in CTStateWriteDirs()) {
            NSString *lp = [d stringByAppendingPathComponent:@"CTHermesFallback.log"];
            mkdir([d UTF8String], 0755);
            fp = fopen([lp UTF8String], "a");
            if (fp) break;
        }
    }
    if (!fp) return;
    struct timeval btv; gettimeofday(&btv, NULL);   // ★ 2.0.79：毫秒留痕
    time_t tt = btv.tv_sec; struct tm tmv; localtime_r(&tt, &tmv);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
    fprintf(fp, "[%s.%03d][心跳] ", ts, (int)(btv.tv_usec / 1000));
    va_list ap; va_start(ap, fmt); vfprintf(fp, fmt, ap); va_end(ap);
    fputc('\n', fp); fclose(fp);
}
static void CTWinHostAliveWatch(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        CTWinBeatLog("监听已启动（等 tm/powerd 心跳）");
        NSArray *names = @[@"com.qq391160.cpucore/alive.thermalmonitord", @"com.qq391160.cpucore/alive.powerd", @"com.qq391160.cpucore/alive.powerdatad"];
        static uint64_t lastSt[3] = {0, 0, 0};
        static CFAbsoluteTime lastAt[3] = {0, 0, 0};
        static int toks[3] = {0, 0, 0};
        for (NSUInteger i = 0; i < names.count && i < 3; i++) {
            NSUInteger idx = i;
            notify_register_dispatch([names[i] UTF8String], &toks[i], dispatch_get_main_queue(), ^(int t) {
                if (gWinUninstalled) return;
                uint64_t st = 0; notify_get_state(t, &st);
                CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
                if (st != lastSt[idx] || (now - lastAt[idx]) > 600.0) {
                    lastSt[idx] = st; lastAt[idx] = now;
                    uint32_t pid = (uint32_t)(st >> 32);
                    uint32_t fl  = (uint32_t)(st & 0xFFFFFFFFu);
                    CTWinBeatLog("%s 活着 pid=%u 标志=0x%x（ctor=%u 挂载=%u 已挂类=%u 已到达=%u 开关(TM)=%u 补丁=%u）",
                                 idx == 0 ? "thermalmonitord" : (idx == 1 ? "powerd" : "powerdatad"), pid, fl,
                                 (fl & 1u), (fl >> 1) & 1u, (fl >> 2) & 0xFu, (fl >> 8) & 1u, (fl >> 16) & 1u, (fl >> 20) & 0xFFu);
                }
            });
        }
        // ★ 2.0.38：细节通道（签名 + 名字前 6 字节；0 = 无内容）
        NSArray *dnames = @[@"com.qq391160.cpucore/diag.thermalmonitord", @"com.qq391160.cpucore/diag.powerd", @"com.qq391160.cpucore/diag.powerdatad"];
        static uint64_t dLast[3] = {0, 0, 0};
        static int dtoks[3] = {0, 0, 0};
        for (NSUInteger di = 0; di < dnames.count && di < 3; di++) {
            NSUInteger didx = di;
            notify_register_dispatch([dnames[di] UTF8String], &dtoks[di], dispatch_get_main_queue(), ^(int t) {
                if (gWinUninstalled) return;
                uint64_t w = 0; notify_get_state(t, &w);
                if (w != dLast[didx]) {
                    dLast[didx] = w;
                    unsigned int dna = (unsigned int)((w >> 60) & 0xF);
                    unsigned int drc = (unsigned int)((w >> 56) & 0xF);
                    unsigned int da2 = (unsigned int)((w >> 52) & 0xF);
                    unsigned int da3 = (unsigned int)((w >> 48) & 0xF);
                    char dnb[7] = {0};
                    for (int bi = 0; bi < 6; bi++) { unsigned char bc2 = (unsigned char)((w >> (40 - bi * 8)) & 0xFF); dnb[bi] = (bc2 >= 32 && bc2 < 127) ? (char)bc2 : '.'; }
                    CTWinBeatLog("%s 细节：参数数=%u 返回码=%u 参2码=%u 参3码=%u 名字=%s",
                                 didx == 0 ? "thermalmonitord" : (didx == 1 ? "powerd" : "powerdatad"), dna, drc, da2, da3, dnb);
                }
            });
        }
        // ★ 2.0.38：细节扩展（2=类型字符+名字7-10；3=名字11-18；4=背光拦写计数）——只盯 tm
        {
            static uint64_t eLast[6] = {0, 0, 0, 0, 0, 0};
            static int etoks[6] = {0, 0, 0, 0, 0, 0};
            NSArray *enames = @[@"com.qq391160.cpucore/diag2.thermalmonitord", @"com.qq391160.cpucore/diag3.thermalmonitord", @"com.qq391160.cpucore/diag4.thermalmonitord", @"com.qq391160.cpucore/diag4.powerd", @"com.qq391160.cpucore/diag4.powerdatad", @"com.qq391160.cpucore/diag5.thermalmonitord"];
            for (NSUInteger ei = 0; ei < 6; ei++) {
                NSUInteger eidx = ei;
                notify_register_dispatch([enames[ei] UTF8String], &etoks[ei], dispatch_get_main_queue(), ^(int t) {
                    if (gWinUninstalled) return;
                    uint64_t w = 0; notify_get_state(t, &w);
                    if (w != eLast[eidx]) {
                        eLast[eidx] = w;
                        if (eidx == 0) {
                            uint32_t rwn = (uint32_t)((w >> 32) & 0xFFFFFFFF);
                            uint32_t rwv = (uint32_t)(w & 0xFFFFFFFF);
                            CTWinBeatLog("thermalmonitord 回写表：次数=%u 最后回写值=%.1f", (unsigned int)rwn, rwv / 10.0);
                        } else if (eidx == 1) {
                            CTWinBeatLog("thermalmonitord 钩子台账：命中=%u 挂位=0x%x", (unsigned int)(w & 0xFFFFFFFF), (unsigned int)((w >> 32) & 0xFFFFFFFF));
                        } else if (eidx == 5) {
                            char rts[9] = {0};
                            for (int bi = 0; bi < 8; bi++) { unsigned char rc5 = (unsigned char)((w >> (56 - bi * 8)) & 0xFF); rts[bi] = (rc5 >= 32 && rc5 < 127) ? (char)rc5 : '.'; }
                            CTWinBeatLog("thermalmonitord 弹窗拦截=%u", (unsigned int)(w & 0xFFFFFFFF));
                        } else {
                            CTWinBeatLog("%s 背光拦写：见过=%u 挡下=%u",
                                         eidx == 2 ? "thermalmonitord" : (eidx == 3 ? "powerd" : "powerdatad"),
                                         (unsigned int)(w & 0xFFFFFFFFu), (unsigned int)((w >> 32) & 0xFFFFFFFFu));
                        }
                    }
                });
            }
        }
    });
}


// ★ 2.0.76：状态栏"跟色"零延迟钩子——状态栏时间视图每次重设颜色，我们当场对齐
//   （实验性：不生效也不影响任何东西；全 @try、有节流、有留痕）
@interface STUIStatusBarStringView : UILabel
- (void)setTextColor:(UIColor *)color;
@end
// ★ 2.0.77：是不是"时钟样子"（HH:MM / H:MM）
static BOOL CTWinLooksLikeClock(NSString *t) {
    if (t.length < 3 || t.length > 6) return NO;
    NSRange r = [t rangeOfString:@":"];
    if (r.location == NSNotFound || r.location < 1 || r.location > 2 || r.location != t.length - 3) return NO;
    for (NSUInteger i = 0; i < t.length; i++) {
        if (i == r.location) continue;
        unichar ch = [t characterAtIndex:i];
        if (ch < '0' || ch > '9') return NO;
    }
    return YES;
}
// ★ 2.0.77/2.0.79：时间视图"认领"——setTextColor / setText / setAttributedText / 装窗 / 显影 / 取消隐藏 全算
//   （谁被系统动过，谁就是"当前时间视图"→ 当场直通、毫秒对齐；全 @try，失败不影响任何功能）
static void CTWinNoteTimeViewIfClock(id v, UIColor *direct) {
    if (!gWinFollowTime || !v) return;
    @try {
        NSString *t = nil;
        if ([v isKindOfClass:[UILabel class]]) t = [(UILabel *)v text];
        if (!CTWinLooksLikeClock(t)) return;
        UILabel *lab = (UILabel *)v;
        sTimeLabel = lab;   // 当场认领
        UIColor *c = direct;
        if (!c) { @try { c = lab.textColor; } @catch (__unused NSException *e) { c = nil; } }
        if (!c) { @try { NSAttributedString *at = lab.attributedText; if (at.length > 0) c = [at attribute:NSForegroundColorAttributeName atIndex:0 effectiveRange:NULL]; } @catch (__unused NSException *e) { c = nil; } }
        CFAbsoluteTime nowI = CFAbsoluteTimeGetCurrent();
        sHookLab = lab; sHookCol = c; sHookAt = nowI; sSwitchAt = nowI;   // 直通色 + 切换窗
        static CFAbsoluteTime sInstantAt = 0;
        static int sInstantN = 0;
        if (nowI - sInstantAt >= 0.05) {
            sInstantAt = nowI;
            sInstantN++;
            if (c) {
                CGFloat r0 = 0, g0 = 0, b0 = 0, a0 = 0;
                if ([c getRed:&r0 green:&g0 blue:&b0 alpha:&a0]) CTWinLog("[浮窗] 颜色追平：时间色即时更新（第 %d 次 · 读=%.2f,%.2f,%.2f）", sInstantN, r0, g0, b0);
                else CTWinLog("[浮窗] 颜色追平：时间色即时更新（第 %d 次 · 读=?）", sInstantN);
            } else {
                CTWinLog("[浮窗] 颜色追平：时间色即时更新（第 %d 次 · 读=失败）", sInstantN);
            }
            sFindAt = 0;
            gWinLastRaw = nil;
            sFollowSrc = "钩子";
            dispatch_async(dispatch_get_main_queue(), ^{ @try { CTHermesStatusWindowTick(); } @catch (__unused NSException *e) {} });
        }
    } @catch (__unused NSException *e) {}
}
%hook STUIStatusBarStringView
- (void)setTextColor:(UIColor *)color {
    %orig;
    sHookChan = 0;
    CTWinNoteTimeViewIfClock(self, color);
}
- (void)setText:(NSString *)text {
    %orig;
    sHookChan = 0;
    CTWinNoteTimeViewIfClock(self, nil);
}
- (void)setAttributedText:(NSAttributedString *)attributedText {
    %orig;
    sHookChan = 1;
    CTWinNoteTimeViewIfClock(self, nil);
}
- (void)didMoveToWindow {
    %orig;
    if (self.window) CTWinNoteTimeViewIfClock(self, nil);
}
- (void)setAlpha:(CGFloat)alpha {
    %orig;
    if (alpha >= 0.05) CTWinNoteTimeViewIfClock(self, nil);
}
- (void)setHidden:(BOOL)hidden {
    %orig;
    if (!hidden) CTWinNoteTimeViewIfClock(self, nil);
}
%end

// ---------- 启动（构造期零 UIKit：只读开关 + 注册通知） ----------
%ctor {
    CTNotifyStateStart();   // ★ 0930-0207：订阅核心的"通知"数据
    @try { CTWinHostAliveWatch(); } @catch (__unused NSException *e) {}   // 自测增强：宿主状态监听
    @try { [UIDevice currentDevice].batteryMonitoringEnabled = YES; } @catch (__unused NSException *e) {}   // ★ 1.4.115：电量监测
    @autoreleasepool {
        gWinBornAt = CFAbsoluteTimeGetCurrent();
        @try {
            NSDictionary *d = CTHermesReadPrefs();
            // ★ 0930-0207：跨权限心跳 —— 收主插件经"通知"通道发来的"已注入"心跳 → 记日志 + 写配置（界面可显示"核心在线"）
            {
                static int ctHbTok = 0;
                notify_register_dispatch("com.qq391160.cpucore/coreAlive", &ctHbTok, dispatch_get_main_queue(), ^(int t) {
                    if (gWinUninstalled) return;   // ★ 1.4.94：卸载后停止一切写入
                    static BOOL ctHbOnce = NO;
                    if (ctHbOnce) return;
                    ctHbOnce = YES;
                    CTWinLog("★ [核心] 心跳已收到（通知通道）→ 主插件在本机已注入 ✓");
                    NSMutableDictionary *hb = [(CTHermesReadPrefs() ?: @{}) mutableCopy];
                    hb[S("ctCoreAliveAt")] = @([[NSDate date] timeIntervalSince1970]);
                    CTHermesWritePrefs(hb);
                });
            }
            // ★ 1.4.94：收到「卸载中」通知 → 立即拆除浮窗（拆窗口 + 禁弹回；文件已删，重启即彻底清零）
            {
                static int ctByeTok = 0;
                notify_register_dispatch("com.qq391160.cpucore/uninstalling", &ctByeTok, dispatch_get_main_queue(), ^(int t) {
                    (void)t;
                    CTWinTearDownUninstall();   // ★ 2.0.38：与"墓碑自检"共用同一拆除函数
                });
            }
            // ★ 1.4.106/107：方向跟随——开设备方向通知 + 系统方向通知 + 每秒巡检（防抖）
            {
                static dispatch_source_t sOrientTimer = NULL;
                if (!sOrientTimer) {
                    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];   // ★ 1.4.107：让设备方向可读
                    [[NSNotificationCenter defaultCenter] addObserverForName:@"UIApplicationDidChangeStatusBarOrientationNotification" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *n) {
                        (void)n;
                        if (gWinUninstalled) return;
                        gWinOrientFast = YES;     // ★ 1.4.112：系统事件 → 免"两拍"等待，立即跟随
                        CTWinSyncOrientation();
                    }];
                    dispatch_queue_t oq = dispatch_get_main_queue();
                    sOrientTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, oq);
                    if (sOrientTimer) {
                        dispatch_source_set_timer(sOrientTimer,
                                                  dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.22 * NSEC_PER_SEC)),
                                                  (uint64_t)(0.22 * NSEC_PER_SEC),
                                                  (uint64_t)(0.1 * NSEC_PER_SEC));
                        dispatch_source_set_event_handler(sOrientTimer, ^{
                            if (gWinUninstalled) return;
                            // ★ 2.0.38：墓碑自检（双保险）——卸载一开始，1 拍内自拆，不等通知
                            static int sCTByeChk = 0;
                            if ((++sCTByeChk % 4) == 0 && CTHermesUninstalling()) { CTWinTearDownUninstall(); return; }
                            CTWinSyncOrientation();
                        });
                        dispatch_resume(sOrientTimer);
                    }
                }
            }
            gWinEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];
            if (gWinEnabled && !CTAuthActivatedForWindow(d)) gWinEnabled = NO;   // ★ 未激活 → 浮窗不出现
            id fsObj = d[S("floatWindowFontSize")];                   // ★ T7z18：字号
            if (fsObj) {
                CGFloat fs = [fsObj doubleValue];
                if (fs >= 6.0 && fs <= 20.0) gWinBaseFont = fs;           // ★ T7z18c：6~20
            }
            gWinHideBg = [d[S("floatWindowHideBg")] ?: @NO boolValue];
            gWinInvert = NO;   // ★ 2.0.79：自适应已下架（开关删除）——代码保留休眠：忽略旧键，永不启用
            gWinFollowTime = [d[S("floatWindowFollowTime")] ?: @NO boolValue];
            gWinHideOnLock = [d[S("floatHideOnLock")] ?: @NO boolValue];   // ★ 2.0.92：「锁屏时隐藏」（默认关）
            gWinShowFPS = [d[S("floatShowFPS")] ?: @YES boolValue];
            gWinShowCharge = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];
            gWinShowDot   = [d[S("floatShowDot")]   ?: @YES boolValue];
            gWinShowFreq  = [d[S("floatShowFreq")]  ?: @YES boolValue];
            gWinShowMode  = [d[S("floatShowMode")]  ?: @YES boolValue];
            gWinShowFlags = [d[S("floatShowFlags")] ?: @YES boolValue];
            gWinShowCurrent = [d[S("floatShowCurrent")] ?: @YES boolValue];
            gWinShowTemp   = [d[S("floatShowTemp")] ?: @YES boolValue];
            gWinShowNet     = [d[S("floatShowNetSpeed")] ?: @YES boolValue];
            gWinShowBattery = [d[S("floatShowBattery")] ?: @YES boolValue];   // ★ 1.4.115：电量
            @try {                                                         // ★ T7z21：初始深浅色
                UIUserInterfaceStyle st = [UIScreen mainScreen].traitCollection.userInterfaceStyle;
                gWinLightMode = (st == UIUserInterfaceStyleLight);
            } @catch (__unused NSException *e) {}
        } @catch (__unused NSException *e) {}
        notify_register_dispatch(kCTHermesSettingsChangedNotifC, &gWinSettingsToken,
                                 dispatch_get_main_queue(), ^(int token) {
            (void)token;
            @try {
                if (gWinUninstalled) { gWinEnabled = NO; return; }   // ★ 1.4.94：卸载后禁止回弹
                NSDictionary *d = CTHermesReadPrefs();
                gWinEnabled = [d[S("floatWindowEnabled")] ?: @NO boolValue];
                if (gWinEnabled && !CTAuthActivatedForWindow(d)) gWinEnabled = NO;   // ★ 未激活 → 浮窗不出现
                id fsObj = d[S("floatWindowFontSize")];               // ★ T7z18：字号
                if (fsObj) {
                    CGFloat fs = [fsObj doubleValue];
                    if (fs >= 6.0 && fs <= 20.0) { gWinBaseFont = fs; }   // ★ T7z18c：6~20
                }
                gWinHideBg = [d[S("floatWindowHideBg")] ?: @NO boolValue];
            gWinInvert = NO;   // ★ 2.0.79：自适应已下架（开关删除）——代码保留休眠：忽略旧键，永不启用
            gWinFollowTime = [d[S("floatWindowFollowTime")] ?: @NO boolValue];
            gWinHideOnLock = [d[S("floatHideOnLock")] ?: @NO boolValue];   // ★ 2.0.92：「锁屏时隐藏」（默认关）
            gWinShowFPS = [d[S("floatShowFPS")] ?: @YES boolValue];
            gWinShowCharge = [d[S("chargeDisplayEnabled")] ?: @YES boolValue];
            gWinShowDot   = [d[S("floatShowDot")]   ?: @YES boolValue];
            gWinShowFreq  = [d[S("floatShowFreq")]  ?: @YES boolValue];
            gWinShowMode  = [d[S("floatShowMode")]  ?: @YES boolValue];
            gWinShowFlags = [d[S("floatShowFlags")] ?: @YES boolValue];
            gWinShowCurrent = [d[S("floatShowCurrent")] ?: @YES boolValue];
            gWinShowTemp   = [d[S("floatShowTemp")] ?: @YES boolValue];
            gWinShowNet     = [d[S("floatShowNetSpeed")] ?: @YES boolValue];
            gWinShowBattery = [d[S("floatShowBattery")] ?: @YES boolValue];   // ★ 1.4.115：电量
                gWinNeedFontReload = YES;                              // 强制重排（实时生效）
                CTWinLog("开关更新 = %s 字号=%.1f 背景=%s 自适应=%s FPS=%s 跟随=%s", gWinEnabled ? "开" : "关", gWinBaseFont, gWinHideBg ? "隐藏" : "显示", gWinInvert ? "开" : "关", gWinShowFPS ? "开" : "关", gWinFollowTime ? "开" : "关");
            } @catch (__unused NSException *e) {}
        });
        // ★ 2.0.4 新增 / ★ 2.0.5 重写：重置浮窗位置（专用通知）——设置页按钮发出，一键救回"被拖到屏幕底部挪不动"。
        //   2.0.5 修正：① 默认位不再写"半离屏坐标"（旧 (宽-40,90) 会被当成"手设位"记下 → 之后每次进横屏自动贴边都算歪、校验失败 → 观感"重置后不对劲"）；
        //   ② 重置后"横屏位"清成"未手设"（下次进横屏重新自动贴边；手拖过才记为手设）；③ 浮窗未启用时只写默认坐标与清记忆，不误记坐标。
        {
            static int ctRstTok = 0;
            notify_register_dispatch("com.qq391160.cpucore/resetFloatPos", &ctRstTok, dispatch_get_main_queue(), ^(int t3) {
                (void)t3;
                if (gWinUninstalled) return;
                // 1) 清掉全部位置记忆（竖屏 + 横屏）
                gWinPX = -1; gWinPY = -1;
                gWinLX = -1; gWinLY = -1; gWinLUserSet = NO; gWinLSeedDone = NO;
                // 2) 默认位 = 右上、右贴边留 12pt（先按"实际能放到的"规则夹好 → 记录值 = 屏幕上看到的位置）
                CGRect bb = [UIScreen mainScreen].bounds;
                CGFloat pw = (gWinW > 10.0 ? gWinW : 266.0);
                CGFloat ph = (gWinH > 4.0 ? gWinH : 24.0);
                CGFloat defPX = bb.size.width - pw * 0.5 - 12.0;
                if (defPX < pw * 0.5) defPX = pw * 0.5;
                CGFloat defPY = 90.0;
                if (defPY < ph * 0.5) defPY = ph * 0.5;
                if (defPY > bb.size.height - ph * 0.5) defPY = bb.size.height - ph * 0.5;
                if (gWinCapsule) {
                    CTWinPlace(defPX, defPY);   // 显示层自带夹取 → 一定可见
                    CTWinLog("重置：浮窗已回默认位置(%.0f,%.0f)", gWinCX, gWinCY);
                } else {
                    CTWinLog("重置：浮窗未创建 → 仅清记忆/写默认位（启用后回到默认位）");
                }
                // 3) 竖屏位记成默认位（干净值）；横屏位保持"未手设"（下次进横屏自动贴边；拖过才记为手设）
                gWinPX = defPX; gWinPY = defPY;
                CTWinSavePos(defPX, defPY);
                CTWinSaveLand();
            });
        }
        // ★ 1.4.111/112/113：前台 App 变化 → 0.5 秒后"自动归位"（仅在"真的换 App"时；系统会周期性重报同一个值）
        {
            static int ctFgTok = 0;
            static int ctFgGen2 = 0;
            static uint64_t ctFgLastH = 0;
            notify_register_dispatch(kCTHermesForegroundAppNotifC, &ctFgTok, dispatch_get_main_queue(), ^(int t2) {
                if (gWinUninstalled) return;
                uint64_t h = 0;
                if (notify_get_state(t2, &h) != NOTIFY_STATUS_OK) h = 0;
                if (h == ctFgLastH) return;   // ★ r3：同值重报不干活（原来每 2 秒被误触发一次，日志刷了几百条）
                ctFgLastH = h;
                CTWinFastColorRefresh();   // ★ 2.0.75/76：信号一到 → 立即整帧刷新 + 0.7 秒补拍
                gWinFastUntil = CFAbsoluteTimeGetCurrent() + 1.2;   // ★ 2.0.5：切 App 后开 1.2 秒"快切窗口"（方向变化免去抖，立即跟）
                int myGen = ++ctFgGen2;
                gWinResyncAt = CFAbsoluteTimeGetCurrent() + 0.5;   // tick 兜底
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (myGen != ctFgGen2 || gWinUninstalled) return;   // 又切了 → 以最新一次为准
                    if (gWinResyncAt <= 0.0) return;                    // tick 已处理
                    if (gWinPan && (gWinPan.state == UIGestureRecognizerStateBegan || gWinPan.state == UIGestureRecognizerStateChanged)) return;   // 拖动中 → 交给 tick 兜底
                    gWinResyncAt = 0.0;
                    CTWinResyncPosition();
                });
            });
            {   // ★ 2.0.76：颜色快速通道——"先于确认窗"的补发信号（快速切换不掉队；不影响其它逻辑）
                static int ctColorTok = 0;
                static CFAbsoluteTime ctColorLast = 0;
                notify_register_dispatch(kCTHermesColorRefreshNotifC, &ctColorTok, dispatch_get_main_queue(), ^(int t3) {
                    (void)t3;
                    if (gWinUninstalled) return;
                    CFAbsoluteTime nowN = CFAbsoluteTimeGetCurrent();
                    if (nowN - ctColorLast < 0.25) return;   // 节流（快速切换最高 4 次/秒）
                    ctColorLast = nowN;
                    CTWinFastColorRefresh();
                });
            }
        }
        int checkToken = 0;
        if (notify_register_check("com.apple.springboard.hasBlankedScreen", &checkToken) == NOTIFY_STATUS_OK) {
            uint64_t st = 0;
            notify_get_state(checkToken, &st);
            gWinBlanked = (st != 0);
            notify_cancel(checkToken);
        }
        notify_register_dispatch("com.apple.springboard.hasBlankedScreen", &gWinBlankToken,
                                 dispatch_get_main_queue(), ^(int token) {
            uint64_t st = 0;
            notify_get_state(token, &st);
            gWinBlanked = (st != 0);
        });
        CTWinDeviceLockRefresh();   // ★ 2.0.93：启动读一次（纯通知通道、零系统类访问）
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ CTWinDeviceLockRefresh(); });   // 开机 5 秒后校准一次
        notify_register_dispatch("com.apple.springboard.lockstate", &gWinDeviceLockToken,
                                 dispatch_get_main_queue(), ^(int token2) {
            (void)token2;
            CTWinDeviceLockRefresh();
        });
        CTWinLog("浮窗组件已加载（开关=%s 字号=%.1f 版本=v10/2.0.96）", gWinEnabled ? "开" : "关", gWinBaseFont);
        notify_post("com.qq391160.cpucore/winbeat");   // ★ 2.0.39：加载即报"浮窗组件活着"
        CTWinPosBusInit();   // ★ 2.0.48：位置环线（通知通道；文件写不出时的兜底）
        if (CT_SOURCE_FP[0]) CTWinLog("构建指纹 = %s", CT_SOURCE_FP);
    }
}
