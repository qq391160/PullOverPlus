//
//  POApplicationHelper.m
//  PullOverPlus
//
//  Created by Will Smillie on 4/8/19.
//

#import "POApplicationHelper.h"
#import <objc/message.h>

@interface UIImage (POApplicationIcon)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)bundleID
                                               format:(int)format
                                                scale:(CGFloat)scale;
@end

static NSString * const POEnabledPendingRespringKey = @"enabled-respring-pending";
static NSDictionary *POCachedSettings;
static NSSet<NSString *> *POExternalURLRoutingWhitelist;
static BOOL PORuntimeEnabled;
static BOOL PORuntimeEnabledInitialized;

static UIImage *POIconServicesImageForIdentifier(NSString *identifier) {
    if (identifier.length == 0 ||
        ![UIImage respondsToSelector:@selector(_applicationIconImageForBundleIdentifier:format:scale:)]) {
        return nil;
    }

    @try {
        return [UIImage _applicationIconImageForBundleIdentifier:identifier
                                                          format:0
                                                           scale:UIScreen.mainScreen.scale];
    } @catch (__unused NSException *exception) {
        return nil;
    }
}

static id POValueForKeySafely(id object, NSString *key) {
    if (!object || key.length == 0) {
        return nil;
    }
    @try {
        return [object valueForKey:key];
    } @catch (NSException *exception) {
        return nil;
    }
}

static BOOL POApplicationHasHiddenTag(id application) {
    SEL infoSelector = NSSelectorFromString(@"info");
    if (!application || ![application respondsToSelector:infoSelector]) {
        return NO;
    }

    id info = ((id (*)(id, SEL))objc_msgSend)(application, infoSelector);
    SEL hiddenSelector = NSSelectorFromString(@"hasHiddenTag");
    return [info respondsToSelector:hiddenSelector]
        ? ((BOOL (*)(id, SEL))objc_msgSend)(info, hiddenSelector)
        : NO;
}

static NSDictionary *POInfoDictionaryForBundleIdentifier(NSString *bundleId) {
    if (bundleId.length == 0) {
        return nil;
    }
    Class proxyClass = NSClassFromString(@"LSApplicationProxy");
    SEL proxySelector = NSSelectorFromString(@"bundleProxyForIdentifier:");
    if (!proxyClass || ![proxyClass respondsToSelector:proxySelector]) {
        return nil;
    }
    id proxy = ((id (*)(id, SEL, id))objc_msgSend)(proxyClass, proxySelector, bundleId);
    NSURL *bundleURL = POValueForKeySafely(proxy, @"bundleURL");
    if (![bundleURL isKindOfClass:[NSURL class]]) {
        return nil;
    }
    return [NSBundle bundleWithURL:bundleURL].infoDictionary;
}

static UIInterfaceOrientationMask POOrientationMaskFromStrings(NSArray *orientations) {
    UIInterfaceOrientationMask mask = 0;
    for (id value in orientations) {
        if (![value isKindOfClass:[NSString class]]) {
            continue;
        }
        if ([value isEqualToString:@"UIInterfaceOrientationPortrait"]) {
            mask |= UIInterfaceOrientationMaskPortrait;
        } else if ([value isEqualToString:@"UIInterfaceOrientationPortraitUpsideDown"]) {
            mask |= UIInterfaceOrientationMaskPortraitUpsideDown;
        } else if ([value isEqualToString:@"UIInterfaceOrientationLandscapeLeft"]) {
            mask |= UIInterfaceOrientationMaskLandscapeLeft;
        } else if ([value isEqualToString:@"UIInterfaceOrientationLandscapeRight"]) {
            mask |= UIInterfaceOrientationMaskLandscapeRight;
        }
    }
    return mask;
}

static void POCollectRecentBundleIdentifiers(id object, NSMutableOrderedSet *bundleIds, NSInteger depth) {
    if (!object || depth > 4 || bundleIds.count >= 30) {
        return;
    }

    if ([object isKindOfClass:[NSString class]]) {
        if ([(NSString *)object containsString:@"."]) {
            [bundleIds addObject:object];
        }
        return;
    }
    if ([object isKindOfClass:[NSArray class]] || [object isKindOfClass:[NSSet class]] || [object isKindOfClass:[NSOrderedSet class]]) {
        for (id value in object) {
            POCollectRecentBundleIdentifiers(value, bundleIds, depth + 1);
        }
        return;
    }
    if ([object isKindOfClass:[NSDictionary class]]) {
        POCollectRecentBundleIdentifiers([(NSDictionary *)object allValues], bundleIds, depth + 1);
        return;
    }

    for (NSString *key in @[@"bundleIdentifier", @"displayIdentifier", @"applicationBundleIdentifier", @"applicationIdentifier", @"identifier", @"allItems", @"items", @"displayItems", @"application", @"app"]) {
        id value = POValueForKeySafely(object, key);
        if (value && value != object) {
            POCollectRecentBundleIdentifiers(value, bundleIds, depth + 1);
        }
    }
}

static id POSharedObjectForClass(Class cls) {
    for (NSString *selectorName in @[@"sharedInstance", @"sharedController", @"sharedModel", @"defaultInstance", @"defaultManager"]) {
        SEL selector = NSSelectorFromString(selectorName);
        if ([cls respondsToSelector:selector]) {
            return ((id (*)(id, SEL))objc_msgSend)(cls, selector);
        }
    }
    return nil;
}

@implementation POApplicationHelper

+ (void)updateExternalURLRoutingCacheWithSettings:(NSDictionary *)settings {
    id rawWhitelist = settings[@"externalURLRoutingWhitelist"];
    NSMutableSet<NSString *> *whitelist = [NSMutableSet set];
    if ([rawWhitelist isKindOfClass:[NSArray class]]) {
        for (id value in (NSArray *)rawWhitelist) {
            if ([value isKindOfClass:[NSString class]] && [(NSString *)value length] > 0) {
                [whitelist addObject:value];
            }
        }
    }
    POExternalURLRoutingWhitelist = [whitelist copy];
}

+(NSDictionary<NSString *, NSNumber *> *)snapshotModificationDates{
    NSMutableDictionary *dates = [NSMutableDictionary dictionary];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *base = @"/var/mobile/Library/SplashBoard/Snapshots";
    for (NSString *name in [fm contentsOfDirectoryAtPath:base error:NULL]) {
        if ([name rangeOfString:@"."].location == NSNotFound) { continue; }
        NSDictionary *attrs = [fm attributesOfItemAtPath:[base stringByAppendingPathComponent:name] error:NULL];
        NSDate *date = attrs[NSFileModificationDate];
        if (date) { dates[name] = @([date timeIntervalSince1970]); }
    }
    return dates;
}

+(void)notePluginOpenedBundleId:(NSString *)bundleId{
    if (bundleId.length == 0 || [bundleId isEqualToString:@"__PO_SEARCH__"]) { return; }
    NSUserDefaults *defaults = [self settingsDefaults];
    NSMutableDictionary *map = [[defaults dictionaryForKey:@"pluginRecentApps"] mutableCopy];
    if (!map) { map = [NSMutableDictionary dictionary]; }
    if (map.count > 40) { [map removeAllObjects]; }      // 别无限长
    map[bundleId] = @([[NSDate date] timeIntervalSince1970]);
    [defaults setObject:map forKey:@"pluginRecentApps"];
    [defaults synchronize];
    POLog(@"[最近使用] 记下插件里打开的 %@（插件历史共 %lu 个）", bundleId, (unsigned long)map.count);
}

+(void)noteSystemOpenedBundleId:(NSString *)bundleId{
    if (bundleId.length == 0 || [bundleId isEqualToString:@"__PO_SEARCH__"]) { return; }
    if (![self isUserFacingApplicationBundleId:bundleId]) { return; }
    NSUserDefaults *defaults = [self settingsDefaults];
    NSMutableDictionary *map = [[defaults dictionaryForKey:@"pluginRecentApps"] mutableCopy];
    if (!map) { map = [NSMutableDictionary dictionary]; }
    NSNumber *old = map[bundleId];
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (old && (now - [old doubleValue]) < 2.0) { return; }   // 2 秒内已经记过（插件那边记的）就不重复记
    if (map.count > 40) { [map removeAllObjects]; }           // 别无限长
    map[bundleId] = @(now);
    [defaults setObject:map forKey:@"pluginRecentApps"];
    [defaults synchronize];
    POLog(@"[最近使用] 系统里打开了 %@ → 置顶最近使用（历史共 %lu 个）", bundleId, (unsigned long)map.count);
}

// ---- 前台采样：谁被打开就把谁记一笔（桌面打开 / 应用切换器打开都算，不依赖任何钩子）----
static NSString *poFrontSampleLastBundleId = nil;
static NSString *poSplitShowingBundleId = nil;
static NSTimeInterval poSplitShowingTime = 0;

+(void)setSplitShowingBundleId:(NSString *)bundleId{
    poSplitShowingBundleId = [bundleId copy];
    poSplitShowingTime = [[NSDate date] timeIntervalSince1970];
}

+(void)sampleFrontMostAppIfChanged{
    if (![self isEnabled]) { return; }
    NSString *fm = [self frontMostBundleId];
    if (fm.length == 0) { return; }
    if (poFrontSampleLastBundleId == nil) {
        poFrontSampleLastBundleId = [fm copy];
        POLog(@"[最近使用] 前台采样启动，当前是 %@", fm);
        return;
    }
    if ([fm isEqualToString:poFrontSampleLastBundleId]) { return; }
    NSString *poPrev = poFrontSampleLastBundleId;
    poFrontSampleLastBundleId = [fm copy];
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (poSplitShowingBundleId != nil && [fm isEqualToString:poSplitShowingBundleId] &&
        (now - poSplitShowingTime) < 30.0) {
        POLog(@"[最近使用] 前台变成 %@，但它就是分屏里显示的那个 App → 跳过", fm);
        return;
    }
    [self noteSystemOpenedBundleId:fm];
    POLog(@"[最近使用] 前台从 %@ 变成 %@ → 记一笔（置顶最近使用）", poPrev, fm);
}

+(void)startFrontMostSampler{
    static dispatch_once_t poSamplerOnce;
    dispatch_once(&poSamplerOnce, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            NSTimer *poSamplerTimer = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                                       repeats:YES
                                                                         block:^(NSTimer *poTimer) {
                [POApplicationHelper sampleFrontMostAppIfChanged];
            }];
            (void)poSamplerTimer;
            POLog(@"[最近使用] 前台采样定时器已启动（每 5 秒看一眼前台 App，不碰界面）");
        });
    });
}

// 系统自己记的"最后一次使用时间"（SBApplication），取到就用它排序
+(double)systemLastUsedTimeForBundleId:(NSString *)bundleId{
    if (bundleId.length == 0) { return 0; }
    id controller = nil;
    @try { controller = [NSClassFromString(@"SBApplicationController") sharedInstance]; } @catch (NSException *e) { controller = nil; }
    if (controller == nil) { return 0; }
    id application = nil;
    @try { application = [controller applicationWithBundleIdentifier:bundleId]; } @catch (NSException *e) { application = nil; }
    if (application == nil) { return 0; }
    static NSString *poWorkingKey = nil;
    NSArray *poKeys = @[@"lastActivationDate", @"lastActiveDate", @"lastUsedDate", @"lastLaunchDate", @"_lastActivationDate"];
    for (NSString *poKey in poKeys) {
        id value = nil;
        @try { value = [application valueForKey:poKey]; } @catch (NSException *e) { value = nil; }
        if (value == nil) { continue; }
        double t = 0;
        if ([value isKindOfClass:[NSDate class]]) {
            t = [(NSDate *)value timeIntervalSince1970];
        } else if ([value isKindOfClass:[NSNumber class]]) {
            t = [value doubleValue];
        }
        if (t > 0) {
            if (poWorkingKey == nil) {
                poWorkingKey = [poKey copy];
                POLog(@"[最近使用] 系统时间戳可用（SBApplication.%@）", poKey);
            }
            return t;
        }
    }
    return 0;
}

// ---- 搜索框常用次数（只有"在搜索框里点选"才计次；桌面打开 / 图标栏点按都不计）----
#define PO_APP_PICK_COUNTS_KEY @"poAppPickCounts"

+(NSDictionary<NSString *, NSNumber *> *)appPickCountsDictionary{
    NSDictionary *stored = [[self settingsDefaults] dictionaryForKey:PO_APP_PICK_COUNTS_KEY];
    if ([stored isKindOfClass:[NSDictionary class]]) { return stored; }
    return @{};
}

+(NSInteger)appPickCountForBundleId:(NSString *)bundleId{
    if (bundleId.length == 0) { return 0; }
    return [[self appPickCountsDictionary][bundleId] integerValue];
}

+(void)noteAppPickCountForBundleId:(NSString *)bundleId{
    if (bundleId.length == 0) { return; }
    NSMutableDictionary *counts = [[self appPickCountsDictionary] mutableCopy];
    NSInteger value = [counts[bundleId] integerValue] + 1;
    counts[bundleId] = @(value);
    [[self settingsDefaults] setObject:counts forKey:PO_APP_PICK_COUNTS_KEY];
    [[self settingsDefaults] synchronize];
    POLog(@"[常用次数] 搜索框点了 %@ → %ld 次", bundleId, (long)value);
}

+(void)resetAppPickCountForBundleId:(NSString *)bundleId{
    if (bundleId.length == 0) { return; }
    NSMutableDictionary *counts = [[self appPickCountsDictionary] mutableCopy];
    [counts removeObjectForKey:bundleId];
    [[self settingsDefaults] setObject:counts forKey:PO_APP_PICK_COUNTS_KEY];
    [[self settingsDefaults] synchronize];
    POLog(@"[常用次数] 已清零 %@", bundleId);
}

+(void)resetAllAppPickCounts{
    [[self settingsDefaults] removeObjectForKey:PO_APP_PICK_COUNTS_KEY];
    [[self settingsDefaults] synchronize];
    POLog(@"[常用次数] 已全部重置");
}
+(NSArray<NSString *> *)pluginRecentBundleIdsWithLimit:(NSInteger)limit{
    NSDictionary *map = [[self settingsDefaults] dictionaryForKey:@"pluginRecentApps"];
    if (![map isKindOfClass:[NSDictionary class]] || map.count == 0) { return @[]; }
    NSArray *sorted = [map.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        double ta = [map[a] doubleValue];
        double tb = [map[b] doubleValue];
        if (ta > tb) { return NSOrderedAscending; }
        if (ta < tb) { return NSOrderedDescending; }
        return NSOrderedSame;
    }];
    NSMutableArray *out = [NSMutableArray array];
    for (NSString *b in sorted) {
        if (limit > 0 && (NSInteger)out.count >= limit) { break; }
        if ([b isEqualToString:@"__PO_SEARCH__"]) { continue; }
        [out addObject:b];
    }
    return out;
}

+(NSArray<NSString *> *)recentAppsWithCount:(int)count{
    if (count <= 0) {
        return @[];
    }

    NSMutableOrderedSet *bundleIds = [NSMutableOrderedSet orderedSet];
    NSArray *layoutKeys = @[@"recentAppLayouts", @"appLayouts", @"recentLayouts", @"layouts", @"displayItems", @"items"];
    NSArray *classNames = @[@"SBMainSwitcherViewController", @"SBMainSwitcherControllerCoordinator",
                            @"SBRecentDisplayManager", @"SBFluidSwitcherViewController",
                            @"SBAppSwitcherModel", @"SBRecentAppsController"];

    for (NSString *className in classNames) {
        id source = POSharedObjectForClass(NSClassFromString(className));
        if (!source) {
            continue;
        }

        NSUInteger before = bundleIds.count;
        for (NSString *key in layoutKeys) {
            POCollectRecentBundleIdentifiers(POValueForKeySafely(source, key), bundleIds, 0);
        }
        if (bundleIds.count == before) {
            POCollectRecentBundleIdentifiers(source, bundleIds, 0);
        }
        if (bundleIds.count >= (NSUInteger)count) {
            break;
        }
    }

    NSArray *pluginIds = [[self class] pluginRecentBundleIdsWithLimit:(count > 0 ? count : 0)];
    for (NSString *b in [pluginIds reverseObjectEnumerator]) {
        [bundleIds insertObject:b atIndex:0];      // 插件里打开过的排最前（系统不给记，只能自己记）
    }
    if (pluginIds.count > 0) {
        POLog(@"[最近使用] 插件自己记的 %lu 个已排到前面：%@", (unsigned long)pluginIds.count,
              [pluginIds componentsJoinedByString:@", "]);
    }
    NSUInteger fromClasses = bundleIds.count;
    NSArray *snapshotIds = [[self class] snapshotFolderRecentBundleIdsWithCount:0];
    for (NSString *b in snapshotIds) {
        [bundleIds addObject:b];      // NSMutableOrderedSet 会自动去重
    }
    POLog(@"[最近使用] 系统接口找到 %lu 个 / 快照目录 %lu 个（补了 %lu 个）",
          (unsigned long)fromClasses, (unsigned long)snapshotIds.count,
          (unsigned long)(bundleIds.count - fromClasses));

    // 统一按"最后一次使用时间"倒序：插件里打开过的用自己记的时间，
    // 系统里打开的用启动快照的修改时间；都没有就按系统给的顺序排在后面
    NSDictionary *pluginMap = [[self settingsDefaults] dictionaryForKey:@"pluginRecentApps"];
    NSDictionary *snapshotMap = [[self class] snapshotModificationDates];
    NSMutableArray<NSString *> *ordered = [NSMutableArray arrayWithArray:bundleIds.array];
    NSMutableDictionary<NSString *, NSNumber *> *scores = [NSMutableDictionary dictionary];
    // 没有时间戳的（系统列表里那些没留下启动快照的），按"系统给的顺序"当成刚用过 → 依次往后排
    // （否则它们全被排到最后，再被截断切掉，看着就是"刚用的 App 不在最近使用里"）
    double poMaxKnown = 0;
    for (NSString *bid in ordered) {
        double t = 0;
        if ([pluginMap[bid] isKindOfClass:[NSNumber class]]) { t = [pluginMap[bid] doubleValue]; }
        else if ([snapshotMap[bid] isKindOfClass:[NSNumber class]]) { t = [snapshotMap[bid] doubleValue]; }
        double poSysTime = [self systemLastUsedTimeForBundleId:bid];
        if (poSysTime > t) { t = poSysTime; }
        if (t > poMaxKnown) { poMaxKnown = t; }
    }
    if (poMaxKnown <= 0) { poMaxKnown = [[NSDate date] timeIntervalSince1970]; }
    // 没时间戳的（系统列表里没留下启动快照的，如文件管理器/浏览器/美团外卖）：
    // 排在"最新的那条记录"下面一点点，按系统给的顺序每项退 30 秒 → 不会被打到列表最末尾再截断掉
    __block NSInteger poUnknownCount = 0;
    [ordered enumerateObjectsUsingBlock:^(NSString *bid, NSUInteger idx, BOOL *stop) {
        double t = 0;
        if ([pluginMap[bid] isKindOfClass:[NSNumber class]]) {
            t = [pluginMap[bid] doubleValue];
        } else if ([snapshotMap[bid] isKindOfClass:[NSNumber class]]) {
            t = [snapshotMap[bid] doubleValue];
        } else {
            t = [self systemLastUsedTimeForBundleId:bid];
        }
        if (t <= 0) {
            poUnknownCount++;
            t = poMaxKnown - poUnknownCount * 30.0;
            POLog(@"[最近使用] %@ 没有时间戳 → 排在最新记录之下（第 %ld 个）", bid, (long)poUnknownCount);
        }
        scores[bid] = @(t - idx * 0.000001);
    }];
    POLog(@"[最近使用] 没时间戳的还有 %ld 个", (long)poUnknownCount);
    [ordered sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        double sa = [scores[a] doubleValue];
        double sb = [scores[b] doubleValue];
        if (sa > sb) { return NSOrderedAscending; }
        if (sa < sb) { return NSOrderedDescending; }
        return NSOrderedSame;
    }];

    NSArray *recent = [ordered copy];
    if (recent.count > (NSUInteger)count) {
        recent = [recent subarrayWithRange:NSMakeRange(0, count)];
    }
    POLog(@"[最近使用] 最终 %lu 个：%@", (unsigned long)recent.count,
          [recent componentsJoinedByString:@", "]);
    return recent;
}

// 兜底来源：SplashBoard 的启动快照目录，一个 App 一条，按修改时间倒序 = 最近打开的顺序
+(NSArray<NSString *> *)snapshotFolderRecentBundleIdsWithCount:(int)count{
    NSMutableArray *result = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *base = @"/var/mobile/Library/SplashBoard/Snapshots";
    NSArray *names = [fm contentsOfDirectoryAtPath:base error:NULL];
    if (names.count == 0) {
        POLog(@"[最近使用] 快照目录读不到：%@", base);
        return result;
    }
    NSMutableArray *entries = [NSMutableArray array];
    for (NSString *name in names) {
        if ([name hasPrefix:@"com.apple.SplashBoard"]) { continue; }
        if ([name rangeOfString:@"."].location == NSNotFound) { continue; }    // 只认像包名的目录
        NSString *full = [base stringByAppendingPathComponent:name];
        NSDictionary *attrs = [fm attributesOfItemAtPath:full error:NULL];
        NSDate *date = attrs[NSFileModificationDate];
        if (!date) { continue; }
        [entries addObject:@[date, name]];
    }
    [entries sortUsingComparator:^NSComparisonResult(NSArray *a, NSArray *b) {
        return [(NSDate *)b[0] compare:(NSDate *)a[0]];      // 新的在前
    }];
    for (NSArray *e in entries) {
        [result addObject:e[1]];
        if (count > 0 && (int)result.count >= count) { break; }
    }
    return result;
}

static NSInteger poRailModeOverride496 = 0;   // 496：1=只收藏 2=只最近
+(void)poSetRailModeOverride:(NSInteger)m { poRailModeOverride496 = m; }
// 496：直接把"收藏 / 最近"拆成两个独立列表（用户建议）
+(NSArray<NSString *> *)poFavoritesOnlyBundleIdentifiers {
    [self poSetRailModeOverride:1];
    NSArray *r = [self quickSwitchBundleIdentifiers];
    [self poSetRailModeOverride:0];
    return r;
}
+(NSArray<NSString *> *)poRecentsOnlyBundleIdentifiers {
    [self poSetRailModeOverride:2];
    NSArray *r = [self quickSwitchBundleIdentifiers];
    [self poSetRailModeOverride:0];
    return r;
}

+(NSArray<NSString *> *)quickSwitchBundleIdentifiers{
    [self sampleFrontMostAppIfChanged];
    NSDictionary *settings = [self settings];
    NSArray *favorites = [settings[@"favorites"] isKindOfClass:[NSArray class]] ? settings[@"favorites"] : @[];
    NSArray *sourceBundleIds = nil;
    BOOL favoritesOnly = [settings[@"style"] isEqualToString:@"Favorite Apps"];
    BOOL mergeMode = [settings[@"mergeFavoritesAndRecents"] boolValue];
    if (poRailModeOverride496 == 1) { favoritesOnly = YES; mergeMode = NO; }
    else if (poRailModeOverride496 == 2) { favoritesOnly = NO; mergeMode = NO; }
    POLog(@"[图标栏] 设置：模式=%@ 同时使用=%@ 格数=%@ 最近上限=%@ 收藏=%lu 个",
          settings[@"style"], mergeMode ? @"开" : @"关",
          settings[@"quickSwitchAppSlots"], settings[@"recentAppsCount"],
          (unsigned long)favorites.count);
    POLog(@"[图标栏] 收藏列表：%@", [favorites componentsJoinedByString:@", "]);
    NSInteger favLimit = [settings[@"quickSwitchAppSlots"] integerValue];   // 显示 N 个收藏应用
    if (favLimit <= 0) { favLimit = 5; }
    NSInteger recentLimit = [settings[@"recentAppsCount"] integerValue];    // 显示 N 个最近应用
    if (recentLimit <= 0) { recentLimit = 5; }

    if (!mergeMode && favoritesOnly) {
        sourceBundleIds = favorites;                                            // 开关关 + 收藏模式：只显示收藏（最多 favLimit 个）
    } else if (!mergeMode) {
        sourceBundleIds = [self recentAppsWithCount:(int)(recentLimit + 3)];     // 开关关 + 最近模式：只显示最近使用（最多 recentLimit 个）
    } else {
        // 开关开：前面收藏（最多 favLimit 个）+ 后面最近使用（最多 recentLimit 个）
        NSInteger favShown = (NSInteger)favorites.count < favLimit ? (NSInteger)favorites.count : favLimit;
        NSArray *favSlice = ((NSInteger)favorites.count > favShown)
            ? [favorites subarrayWithRange:NSMakeRange(0, (NSUInteger)favShown)]
            : favorites;
        NSMutableArray *merged = [NSMutableArray arrayWithArray:favSlice];
        // 已经收藏过的 App 不再进"最近使用"那一段 → 否则"显示 1 个收藏"却看到别的收藏冒出来
        for (NSString *b in [self recentAppsWithCount:(int)(recentLimit + 8)]) {
            if ([favorites containsObject:b]) {
                POLog(@"[最近使用] %@ 是你的收藏，只在收藏段显示，最近段跳过", b);
                continue;
            }
            [merged addObject:b];
        }
        sourceBundleIds = merged;
    }

    NSString *frontMostBundleId = [self frontMostBundleId];
    POLog(@"[图标栏] 当前前台 App = %@", frontMostBundleId ?: @"(空)");
    POLog(@"[图标栏] 候选（过滤前）= %@", [sourceBundleIds componentsJoinedByString:@", "]);
    NSMutableOrderedSet<NSString *> *bundleIds = [NSMutableOrderedSet orderedSet];
    for (id value in sourceBundleIds) {
        if (![value isKindOfClass:[NSString class]]) {
            continue;
        }
        NSString *bundleId = (NSString *)value;
        if ([self isUserFacingApplicationBundleId:bundleId]) {
            [bundleIds addObject:bundleId];      // 当前正在用的 App 也照样显示（不再抽走）
        } else {
            SBApplicationController *poCtrl = [NSClassFromString(@"SBApplicationController") sharedInstance];
            SBApplication *poApp = [poCtrl applicationWithBundleIdentifier:bundleId];
            POLog(@"[图标栏] 跳过 %@：%@", bundleId,
                  poApp ? @"它被隐藏了（隐藏插件标记为隐藏）" : @"系统里找不到这个 App（可能不是桌面 App）");
        }
    }
    {
        // 按设置截断：收藏最多 favLimit 个、最近使用最多 recentLimit 个
        NSUInteger favLead = 0;
        while (favLead < bundleIds.count && [favorites containsObject:[bundleIds objectAtIndex:favLead]]) { favLead++; }
        NSUInteger poMaxItems = mergeMode ? (favLead + (NSUInteger)recentLimit)
                                          : (favoritesOnly ? (NSUInteger)favLimit : (NSUInteger)recentLimit);
        while (bundleIds.count > poMaxItems) { [bundleIds removeObjectAtIndex:bundleIds.count - 1]; }
        POLog(@"[图标栏] 最终 %lu 个（收藏前段 %lu / 收藏上限 %ld / 最近上限 %ld）",
              (unsigned long)bundleIds.count, (unsigned long)favLead, (long)favLimit, (long)recentLimit);
    }
    NSArray<NSString *> *result = bundleIds.array;
    return result;
}

+(UIImage *)imageForBundleId:(NSString *)bundleId{
    return [self iconImageForIdentifier:bundleId];
}


// 这个 App 现在还在后台活着吗（从后台被划掉/被杀 → NO）
// 用 KVC 读私有属性，避免直接访问未声明的方法（那会编译失败）
+ (BOOL)isBundleRunning:(NSString *)bundleId {
    if (bundleId.length == 0) { return NO; }
    id poApp = nil;
    @try {
        SBApplicationController *poCtrl = [NSClassFromString(@"SBApplicationController") sharedInstance];
        poApp = [poCtrl applicationWithBundleIdentifier:bundleId];
    } @catch (NSException *e) { poApp = nil; }
    if (poApp == nil) { return NO; }
    @try {
        NSNumber *poPid = [poApp valueForKey:@"pid"];
        if ([poPid isKindOfClass:[NSNumber class]]) { return (poPid.intValue > 0); }
    } @catch (NSException *e) { }
    @try {
        id poRunning = [poApp valueForKey:@"running"];
        if ([poRunning isKindOfClass:[NSNumber class]]) { return [poRunning boolValue]; }
    } @catch (NSException *e) { }
    return YES;   // 拿不到信息就当"还在运行"，维持原来的行为
}

+(NSString *)frontMostBundleId{
    id app = ((SpringBoard *)[UIApplication sharedApplication])._accessibilityFrontMostApplication;
    if ([app respondsToSelector:@selector(bundleIdentifier)]) {
        return [app bundleIdentifier];
    }
    if ([app respondsToSelector:@selector(displayIdentifier)]) {
        return [app displayIdentifier];
    }
    return nil;
}

+ (BOOL)isUserFacingApplicationBundleId:(NSString *)bundleId {
    if (bundleId.length == 0) {
        return NO;
    }

    SBApplicationController *controller = [NSClassFromString(@"SBApplicationController") sharedInstance];
    SBApplication *application = [controller applicationWithBundleIdentifier:bundleId];
    if (!application) {
        return NO;
    }

    return !POApplicationHasHiddenTag(application);
}

+ (UIInterfaceOrientationMask)supportedInterfaceOrientationsForBundleId:(NSString *)bundleId {
    if (bundleId.length == 0) {
        return UIInterfaceOrientationMaskPortrait;
    }
    static NSCache<NSString *, NSNumber *> *cache;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cache = [[NSCache alloc] init];
        cache.countLimit = 64;
    });
    NSNumber *cached = [cache objectForKey:bundleId];
    if (cached) {
        return (UIInterfaceOrientationMask)cached.unsignedIntegerValue;
    }

    NSDictionary *info = POInfoDictionaryForBundleIdentifier(bundleId);
    if (!info) {
        return UIInterfaceOrientationMaskPortrait;
    }
    NSString *idiomKey = UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad
        ? @"UISupportedInterfaceOrientations~ipad"
        : @"UISupportedInterfaceOrientations~iphone";
    NSArray *orientations = [info[idiomKey] isKindOfClass:[NSArray class]] ? info[idiomKey] : nil;
    if (orientations.count == 0) {
        orientations = [info[@"UISupportedInterfaceOrientations"] isKindOfClass:[NSArray class]]
            ? info[@"UISupportedInterfaceOrientations"]
            : nil;
    }
    UIInterfaceOrientationMask mask = POOrientationMaskFromStrings(orientations);
    if (mask == 0) {
        mask = UIInterfaceOrientationMaskPortrait;
    }
    [cache setObject:@(mask) forKey:bundleId];
    return mask;
}

+ (UIInterfaceOrientation)preferredHostedInterfaceOrientationForBundleId:(NSString *)bundleId {
    UIInterfaceOrientationMask mask = [self supportedInterfaceOrientationsForBundleId:bundleId];
    if (mask & UIInterfaceOrientationMaskPortrait) {
        return UIInterfaceOrientationPortrait;
    }
    if (mask & UIInterfaceOrientationMaskPortraitUpsideDown) {
        return UIInterfaceOrientationPortraitUpsideDown;
    }
    if (mask & UIInterfaceOrientationMaskLandscapeRight) {
        return UIInterfaceOrientationLandscapeRight;
    }
    if (mask & UIInterfaceOrientationMaskLandscapeLeft) {
        return UIInterfaceOrientationLandscapeLeft;
    }
    return UIInterfaceOrientationPortrait;
}


+(NSUserDefaults *)settingsDefaults{
    static NSUserDefaults *defaults;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaults = [[NSUserDefaults alloc] initWithSuiteName:@"com.huayuarc.pulloverplus"];
        [defaults registerDefaults:@{
            @"enabled": @YES,
            @"favorites": @[],
            @"recentAppsCount": @5,
        @"mergeFavoritesAndRecents": @YES,     // 收藏 + 最近使用同时使用（默认开）
            @"quickSwitchAppSlots": @5,
            @"style": @"Recent Apps",
            @"actionButtonPanel": @YES,
            @"panelSizePercent": @88,
            @"backdropDim": @50,
            @"railIconSize": @28,
            @"panelCentered": @NO,
            @"showHandle": @YES,
            @"showSideRail": @YES,
            @"showBottomRail": @YES,
            @"leftHanded": @NO,
            @"hideOnScreenshot": @YES,
            @"hideLabels": @NO,
            @"handleSize": @34,
            @"nubHiddenPercentage": @67,
            @"landscapeBehavior": @"rotate",
            @"externalURLRoutingEnabled": @NO,
            @"externalURLRoutingWhitelist": @[],
            @"hapticFeedback": @NO,   /* 535：震动删除 */
            @"soundFeedback": @YES,
            @"keyboardAvoiding": @YES,
            @"landscapeKeyboardZoom": @YES,
            @"autoNub": @NO,
            @"autoNub-time": @0,
            @"handleActivationGuard": @NO,
            POEnabledPendingRespringKey: @NO,
        }];
    });
    return defaults;
}
+(NSDictionary<NSString *, id> *)settings{
    @synchronized (self) {
        if (!POCachedSettings) {
            NSDictionary *snapshot = [[self settingsDefaults] dictionaryRepresentation];
            PORuntimeEnabled = [snapshot[@"enabled"] boolValue];
            PORuntimeEnabledInitialized = YES;
            POCachedSettings = [snapshot copy];
            [self updateExternalURLRoutingCacheWithSettings:POCachedSettings];
        }
        return POCachedSettings;
    }
}
+ (void)reloadSettings {
    @synchronized (self) {
        NSDictionary *snapshot = [[self settingsDefaults] dictionaryRepresentation];
        BOOL pendingRespring = [snapshot[POEnabledPendingRespringKey] boolValue];
        if (!PORuntimeEnabledInitialized) {
            PORuntimeEnabled = [snapshot[@"enabled"] boolValue];
            PORuntimeEnabledInitialized = YES;
        } else if (!pendingRespring) {
            PORuntimeEnabled = [snapshot[@"enabled"] boolValue];
        }

        NSMutableDictionary *effectiveSettings = [snapshot mutableCopy];
        effectiveSettings[@"enabled"] = @(PORuntimeEnabled);
        POCachedSettings = [effectiveSettings copy];
        [self updateExternalURLRoutingCacheWithSettings:POCachedSettings];
    }
}
+ (BOOL)isEnabled {
    return [[self settings][@"enabled"] boolValue];
}

+ (BOOL)isExternalURLRoutingEnabled {
    return [[self settings][@"externalURLRoutingEnabled"] boolValue];
}

+ (BOOL)isExternalURLRoutingTargetBundleId:(NSString *)bundleId {
    if (bundleId.length == 0 || ![self isExternalURLRoutingEnabled]) {
        return NO;
    }
    @synchronized (self) {
        return [POExternalURLRoutingWhitelist containsObject:bundleId];
    }
}

+ (UIImage *)iconImageForIdentifier:(NSString *)identifier {
    if (identifier.length == 0) {
        return nil;
    }

    if (NSProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 26) {
        UIImage *iconServicesImage = POIconServicesImageForIdentifier(identifier);
        if (iconServicesImage) {
            return iconServicesImage;
        }
    }

    Class iconControllerClass = NSClassFromString(@"SBIconController");
    if (!iconControllerClass || ![iconControllerClass respondsToSelector:@selector(sharedInstance)]) {
        return POIconServicesImageForIdentifier(identifier);
    }

    SBIconController *iconController = [iconControllerClass sharedInstance];
    if (!iconController) {
        return POIconServicesImageForIdentifier(identifier);
    }

    SBIconModel *iconModel = nil;
    if (NSProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 26) {
        if (![iconController respondsToSelector:@selector(iconModel)]) {
            return POIconServicesImageForIdentifier(identifier);
        }
        iconModel = iconController.iconModel;
    } else {
        if (![iconController respondsToSelector:@selector(model)]) {
            return POIconServicesImageForIdentifier(identifier);
        }
        iconModel = iconController.model;
    }
    if (!iconModel || ![iconModel respondsToSelector:@selector(applicationIconForBundleIdentifier:)]) {
        return POIconServicesImageForIdentifier(identifier);
    }

    SBIcon *icon = [iconModel applicationIconForBundleIdentifier:identifier];
    SBHIconImageCache *cache = iconController.tableUIIconImageCache;
    if (!icon || !cache || ![cache respondsToSelector:@selector(imageForIcon:)]) {
        return POIconServicesImageForIdentifier(identifier);
    }
    UIImage *cachedImage = [cache imageForIcon:icon];
    return cachedImage ?: POIconServicesImageForIdentifier(identifier);
}


@end
