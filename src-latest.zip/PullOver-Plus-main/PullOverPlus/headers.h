//
//  headers.h
//  PullOverPlus
//
//  Created by Will Smillie on 4/8/19.
//

@interface SpringBoard
-(id)_accessibilityFrontMostApplication;
@end


@interface SBApplication
@property NSString *bundleIdentifier;
@property NSString *displayIdentifier;
@property NSString *displayName;
- (id)mainScene;
@end

@interface SBApplicationController
+ (id)sharedInstance;
- (id)applicationWithBundleIdentifier:(NSString *)bid;
- (SBApplication *)applicationWithDisplayIdentifier:(NSString *)identifier;
@end

@interface SBFluidSwitcherGestureManager
-(void)grabberTongueBeganPulling:(id)arg1 withDistance:(double)arg2 andVelocity:(double)arg3 ;
-(void)grabberTongueCanceledPulling:(id)arg1 withDistance:(double)arg2 andVelocity:(double)arg3 ;
@end

@class SBIcon;
@class SBIconModel;
@class SBHIconImageCache;

@interface SBIconModel : NSObject
- (SBIcon *)applicationIconForBundleIdentifier:(NSString *)identifier;
@end

@interface SBHIconImageCache : NSObject
- (UIImage *)imageForIcon:(SBIcon *)icon;
@end

@interface SBIconController : NSObject
+(id)sharedInstance;
@property (readonly, nonatomic) SBIconModel *iconModel;
@property (nonatomic, retain) SBIconModel *model;
@property (readonly, nonatomic) SBHIconImageCache *tableUIIconImageCache;
@end

// ===================== PullOver Plus 内置日志 =====================
#ifndef POLog
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static inline void POLogWrite(NSString *line) {
    @autoreleasepool {
        NSString *path = @"/var/mobile/Library/Logs/PullOverPlus.log";
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *dir = [path stringByDeletingLastPathComponent];
        if (![fm fileExistsAtPath:dir]) {
            [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:NULL error:NULL];
        }
        NSDictionary *attrs = [fm attributesOfItemAtPath:path error:NULL];
        if ([[attrs objectForKey:NSFileSize] unsignedLongLongValue] > 512ULL * 1024ULL) {
            [@"" writeToFile:path atomically:NO encoding:NSUTF8StringEncoding error:NULL];
        }
        static NSDateFormatter *fmt = nil;
        static dispatch_once_t poLogOnce;
        dispatch_once(&poLogOnce, ^{
            fmt = [[NSDateFormatter alloc] init];
            fmt.dateFormat = @"MM-dd HH:mm:ss.SSS";
        });
        NSString *stamp = [fmt stringFromDate:[NSDate date]];
        NSString *proc = [NSProcessInfo processInfo].processName ?: @"?";
        NSString *row = [NSString stringWithFormat:@"%@ [%@] %@\n", stamp, proc, line];
        NSData *data = [row dataUsingEncoding:NSUTF8StringEncoding];
        if (![fm fileExistsAtPath:path]) {
            [data writeToFile:path atomically:NO];
            return;
        }
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
        if (!fh) {
            [data writeToFile:path atomically:NO];
            return;
        }
        @try {
            [fh seekToEndOfFile];
            [fh writeData:data];
        } @catch (__unused NSException *e) {
        } @finally {
            [fh closeFile];
        }
    }
}
#define POLog(fmt, ...) POLogWrite([NSString stringWithFormat:(fmt), ##__VA_ARGS__])
#endif
// =================== 日志结束 ===================
