//
//  POApplicationHelper.h
//  PullOverPlus
//
//  Created by Will Smillie on 4/8/19.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "headers.h"

@interface POApplicationHelper : NSObject

+ (NSArray<NSString *> *)recentAppsWithCount:(int)count;
+ (NSArray<NSString *> *)quickSwitchBundleIdentifiers;
+ (void)notePluginOpenedBundleId:(NSString *)bundleId;          // 记下"在插件里打开过"的 App
+ (void)noteSystemOpenedBundleId:(NSString *)bundleId;          // 记下"在系统里打开过"的 App（桌面图标/应用开关等）
+ (void)setSplitShowingBundleId:(NSString *)bundleId;           // 告诉采样：这个 App 是分屏里正在显示的，不算"从系统打开"
+ (void)sampleFrontMostAppIfChanged;                            // 看一眼当前前台 App，换了就记一笔
+ (void)startFrontMostSampler;                                  // 启动前台采样定时器
+ (double)systemLastUsedTimeForBundleId:(NSString *)bundleId;   // 系统自己记的"最后一次使用时间"
+ (NSArray<NSString *> *)pluginRecentBundleIdsWithLimit:(NSInteger)limit;
+ (UIImage *)imageForBundleId:(NSString *)bundleId;
+ (NSString *)frontMostBundleId;
+ (BOOL)isUserFacingApplicationBundleId:(NSString *)bundleId;
+ (UIInterfaceOrientationMask)supportedInterfaceOrientationsForBundleId:(NSString *)bundleId;
+ (UIInterfaceOrientation)preferredHostedInterfaceOrientationForBundleId:(NSString *)bundleId;

+ (NSUserDefaults *)settingsDefaults;
+ (NSDictionary<NSString *, id> *)settings;
+ (void)reloadSettings;
+ (BOOL)isEnabled;
+ (BOOL)isExternalURLRoutingEnabled;
+ (BOOL)isExternalURLRoutingTargetBundleId:(NSString *)bundleId;

+ (UIImage *)iconImageForIdentifier:(NSString *)identifier;

@end
