# PullOver Plus

Based on PullOver Pro by `c1d3rDev`.
Adapted for iOS 14+, added some features, and fixed some known issues.

## License

PullOver Plus is distributed under the [GNU General Public License v3.0](LICENSE).
